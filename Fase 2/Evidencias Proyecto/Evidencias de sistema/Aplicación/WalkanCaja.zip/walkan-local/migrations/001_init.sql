-- 001_init.sql — Esquema inicial Walkan on-premise (Fase 1 aprobada).
-- Convenciones: dinero INTEGER (CLP), fechas TEXT ISO-8601 UTC, booleanos 0/1,
-- enums TEXT + CHECK, tenant_id TEXT en toda tabla (mono-tenant, paridad cloud).
-- IDs: UUID TEXT en entidades raíz; INTEGER AUTOINCREMENT en filas hijas.

-- ============================ OPERACIÓN ============================

CREATE TABLE cajeros (
  id         TEXT    PRIMARY KEY,
  tenant_id  TEXT    NOT NULL,
  nombre     TEXT    NOT NULL,
  pin_hash   TEXT    NOT NULL,
  activo     INTEGER NOT NULL DEFAULT 1,
  created_at TEXT    NOT NULL,
  updated_at TEXT    NOT NULL
);

CREATE TABLE productos (
  id            TEXT    PRIMARY KEY,
  tenant_id     TEXT    NOT NULL,
  codigo        TEXT    NOT NULL,
  codigo_barras TEXT,
  nombre        TEXT    NOT NULL,
  descripcion   TEXT,
  precio_venta  INTEGER NOT NULL DEFAULT 0,
  unidad        TEXT    NOT NULL DEFAULT 'UN',
  stock         INTEGER NOT NULL DEFAULT 0,
  stock_minimo  INTEGER NOT NULL DEFAULT 0,
  exento        INTEGER NOT NULL DEFAULT 0,
  activo        INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT    NOT NULL,
  updated_at    TEXT    NOT NULL
);
CREATE UNIQUE INDEX uq_productos_codigo  ON productos(tenant_id, codigo);
CREATE INDEX        idx_productos_barras ON productos(tenant_id, codigo_barras);
CREATE INDEX        idx_productos_nombre ON productos(tenant_id, nombre);

CREATE TABLE cajas_sesion (
  id             TEXT    PRIMARY KEY,
  tenant_id      TEXT    NOT NULL,
  cajero_id      TEXT    NOT NULL REFERENCES cajeros(id),
  monto_apertura INTEGER NOT NULL DEFAULT 0,
  monto_cierre   INTEGER,
  estado         TEXT    NOT NULL DEFAULT 'ABIERTA'
                   CHECK (estado IN ('ABIERTA','CERRADA')),
  fecha_apertura TEXT    NOT NULL,
  fecha_cierre   TEXT,
  created_at     TEXT    NOT NULL,
  updated_at     TEXT    NOT NULL
);
CREATE INDEX idx_caja_cajero ON cajas_sesion(cajero_id);
-- Invariante: una sola caja abierta a la vez en el terminal.
CREATE UNIQUE INDEX uq_caja_abierta ON cajas_sesion(tenant_id) WHERE estado = 'ABIERTA';

-- dte_emitidos se crea antes que ventas porque ventas la referencia.
-- venta_id acá es columna simple (sin FK) para romper la referencia circular
-- ventas <-> dte_emitidos; el vínculo autoritativo es ventas.dte_emitido_id.

CREATE TABLE dte_emitidos (
  id             TEXT    PRIMARY KEY,
  tenant_id      TEXT    NOT NULL,
  venta_id       TEXT,
  tipo_dte       TEXT    NOT NULL,
  folio          INTEGER NOT NULL,
  caf_id         TEXT,
  rut_receptor   TEXT,
  razon_receptor TEXT,
  neto           INTEGER NOT NULL DEFAULT 0,
  iva            INTEGER NOT NULL DEFAULT 0,
  exento         INTEGER NOT NULL DEFAULT 0,
  total          INTEGER NOT NULL DEFAULT 0,
  fecha_emision  TEXT    NOT NULL,
  items_json     TEXT    NOT NULL,
  xml            TEXT,
  track_id       TEXT,
  estado_sii     TEXT    NOT NULL DEFAULT 'EMITIDO'
                   CHECK (estado_sii IN ('EMITIDO','ACEPTADO','RECHAZADO')),
  created_at     TEXT    NOT NULL,
  updated_at     TEXT    NOT NULL,
  UNIQUE (tenant_id, tipo_dte, folio)
);
CREATE INDEX idx_dte_estado ON dte_emitidos(estado_sii);
CREATE INDEX idx_dte_venta  ON dte_emitidos(venta_id);

CREATE TABLE ventas (
  id             TEXT    PRIMARY KEY,
  tenant_id      TEXT    NOT NULL,
  caja_sesion_id TEXT    NOT NULL REFERENCES cajas_sesion(id),
  dte_emitido_id TEXT    NOT NULL REFERENCES dte_emitidos(id),
  tipo_dte       TEXT    NOT NULL,
  medio_pago     TEXT    NOT NULL
                   CHECK (medio_pago IN ('EFECTIVO','TARJETA','TRANSFERENCIA')),
  neto           INTEGER NOT NULL DEFAULT 0,
  iva            INTEGER NOT NULL DEFAULT 0,
  exento         INTEGER NOT NULL DEFAULT 0,
  total          INTEGER NOT NULL DEFAULT 0,
  created_at     TEXT    NOT NULL
);
CREATE INDEX idx_ventas_caja  ON ventas(caja_sesion_id);
CREATE INDEX idx_ventas_fecha ON ventas(tenant_id, created_at);

CREATE TABLE venta_items (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id       TEXT    NOT NULL,
  venta_id        TEXT    NOT NULL REFERENCES ventas(id),
  producto_id     TEXT    NOT NULL REFERENCES productos(id),
  descripcion     TEXT    NOT NULL,
  cantidad        INTEGER NOT NULL,
  precio_unitario INTEGER NOT NULL,
  exento          INTEGER NOT NULL DEFAULT 0,
  total_linea     INTEGER NOT NULL
);
CREATE INDEX idx_venta_items_venta ON venta_items(venta_id);

CREATE TABLE movimientos_stock (
  id               TEXT    PRIMARY KEY,
  tenant_id        TEXT    NOT NULL,
  producto_id      TEXT    NOT NULL REFERENCES productos(id),
  tipo             TEXT    NOT NULL CHECK (tipo IN ('ENTRADA','SALIDA','AJUSTE')),
  motivo           TEXT    NOT NULL CHECK (motivo IN
                     ('INVENTARIO_INICIAL','RECEPCION_COMPRA','VENTA',
                      'AJUSTE_MANUAL','MERMA','DEVOLUCION')),
  cantidad         INTEGER NOT NULL,
  stock_resultante INTEGER NOT NULL,
  referencia       TEXT,
  comentario       TEXT,
  created_at       TEXT    NOT NULL
);
CREATE INDEX idx_mov_producto ON movimientos_stock(producto_id);
CREATE INDEX idx_mov_fecha    ON movimientos_stock(tenant_id, created_at);

-- ============================ FACTURACIÓN ============================

CREATE TABLE caf (
  id              TEXT    PRIMARY KEY,
  tenant_id       TEXT    NOT NULL,
  tipo_dte        TEXT    NOT NULL,
  folio_desde     INTEGER NOT NULL,
  folio_hasta     INTEGER NOT NULL,
  folio_siguiente INTEGER NOT NULL,
  activo          INTEGER NOT NULL DEFAULT 1,
  xml             TEXT,
  fecha_carga     TEXT    NOT NULL,
  created_at      TEXT    NOT NULL,
  updated_at      TEXT    NOT NULL,
  CHECK (folio_hasta >= folio_desde),
  CHECK (folio_siguiente BETWEEN folio_desde AND folio_hasta + 1)
);
CREATE UNIQUE INDEX uq_caf_activo ON caf(tenant_id, tipo_dte) WHERE activo = 1;

CREATE TABLE folios_usados (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id      TEXT    NOT NULL,
  caf_id         TEXT    NOT NULL REFERENCES caf(id),
  tipo_dte       TEXT    NOT NULL,
  folio          INTEGER NOT NULL,
  dte_emitido_id TEXT    REFERENCES dte_emitidos(id),
  venta_id       TEXT    REFERENCES ventas(id),
  created_at     TEXT    NOT NULL,
  UNIQUE (caf_id, folio),
  UNIQUE (tenant_id, tipo_dte, folio)
);
CREATE INDEX idx_folios_dte ON folios_usados(dte_emitido_id);

CREATE TABLE dte_cola (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id       TEXT    NOT NULL,
  dte_emitido_id  TEXT    NOT NULL REFERENCES dte_emitidos(id),
  estado          TEXT    NOT NULL DEFAULT 'PENDIENTE'
                    CHECK (estado IN
                      ('PENDIENTE','ENVIANDO','ENVIADO','ACEPTADO','RECHAZADO','REINTENTAR')),
  intentos        INTEGER NOT NULL DEFAULT 0,
  proximo_intento TEXT,
  ultimo_error    TEXT,
  created_at      TEXT    NOT NULL,
  updated_at      TEXT    NOT NULL
);
CREATE INDEX idx_dtecola_pick ON dte_cola(estado, proximo_intento);

-- ============================ SINCRONIZACIÓN ============================

CREATE TABLE sync_outbox (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id       TEXT    NOT NULL,
  entidad         TEXT    NOT NULL,
  entidad_id      TEXT    NOT NULL,
  operacion       TEXT    NOT NULL CHECK (operacion IN ('INSERT','UPDATE','DELETE')),
  payload         TEXT    NOT NULL,
  estado          TEXT    NOT NULL DEFAULT 'PENDIENTE'
                    CHECK (estado IN ('PENDIENTE','ENVIANDO','ENVIADO','REINTENTAR')),
  intentos        INTEGER NOT NULL DEFAULT 0,
  proximo_intento TEXT,
  ultimo_error    TEXT,
  created_at      TEXT    NOT NULL,
  updated_at      TEXT    NOT NULL
);
CREATE INDEX idx_outbox_pick ON sync_outbox(estado, id);

CREATE TABLE sync_estado (
  id             INTEGER PRIMARY KEY CHECK (id = 1),
  tenant_id      TEXT    NOT NULL,
  ultima_sync_ok TEXT,
  ultimo_cursor  INTEGER NOT NULL DEFAULT 0,
  online         INTEGER NOT NULL DEFAULT 0,
  ultimo_error   TEXT,
  updated_at     TEXT
);
