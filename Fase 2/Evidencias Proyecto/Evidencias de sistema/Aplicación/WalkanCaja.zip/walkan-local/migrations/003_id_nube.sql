-- Enlace estable con el producto de la nube. La caja reconocía los productos por SKU, así que si en el panel
-- se cambiaba el SKU (= código de barras) aparecía un producto duplicado en la caja. Con el id de la web,
-- que nunca cambia, la caja actualiza el código del mismo producto. Los existentes se enlazan solos en la
-- siguiente sincronización del catálogo (por su SKU actual).
ALTER TABLE productos ADD COLUMN id_nube TEXT;
CREATE INDEX idx_productos_id_nube ON productos(tenant_id, id_nube);
