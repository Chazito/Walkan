-- Ajustes que llegan de la nube con el catálogo (clave → JSON). Por ahora 'negocio': nombre y RUT para el
-- encabezado del comprobante, y los datos de transferencia que la caja muestra (con QR) al cobrar.
CREATE TABLE ajustes (
  clave      TEXT PRIMARY KEY,
  valor      TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
