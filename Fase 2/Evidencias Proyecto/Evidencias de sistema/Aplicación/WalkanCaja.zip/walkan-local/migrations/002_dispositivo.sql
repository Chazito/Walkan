-- Vínculo del dispositivo (esta caja) con la nube Walkan. Fila única (id=1).
-- El token se obtiene una sola vez desde la pantalla de bienvenida
-- (POST a la nube /api/cajas/registrar con las credenciales de la cuenta).
-- La caja guarda SOLO el token, nunca la contraseña.
CREATE TABLE dispositivo (
  id           INTEGER PRIMARY KEY CHECK (id = 1),
  caja_id      TEXT,
  token        TEXT,
  nombre       TEXT,
  nube_url     TEXT,
  -- Kill-switch antirrobo: si la nube marca la caja como robada, se protege el
  -- acceso a los datos del negocio (la app se bloquea; el equipo sigue encendido).
  bloqueada    INTEGER NOT NULL DEFAULT 0,
  vinculada_at TEXT,
  updated_at   TEXT NOT NULL
);

INSERT OR IGNORE INTO dispositivo (id, updated_at) VALUES (1, '1970-01-01T00:00:00.000Z');
