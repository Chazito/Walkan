-- Cajeros administrados desde el panel web. id_nube enlaza el cajero local con el de la nube (que no cambia aunque
-- se renombre o cambie el PIN). Los cajeros sin id_nube son los creados en la propia caja al instalarla: se usan
-- mientras la nube no tenga cajeros; cuando el dueño crea el primero en el panel, la lista de la nube manda.
ALTER TABLE cajeros ADD COLUMN id_nube TEXT;
CREATE INDEX idx_cajeros_id_nube ON cajeros(tenant_id, id_nube);
