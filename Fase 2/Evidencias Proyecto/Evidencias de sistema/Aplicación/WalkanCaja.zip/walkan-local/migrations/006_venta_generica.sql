-- C1 (P5): vender un código que no está en el catálogo local como línea "genérica" (descripción y precio a mano).
-- Una venta nunca se bloquea ni se pierde por un código desconocido: queda registrada, no descuenta stock local y
-- la nube la deja en la bandeja "Vendido sin catálogo" del panel para que el dueño cree o vincule el producto.
-- SQLite no permite quitar un NOT NULL: se rehace la tabla (nadie la referencia) con los mismos datos.
CREATE TABLE venta_items_n (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id       TEXT    NOT NULL,
  venta_id        TEXT    NOT NULL REFERENCES ventas(id),
  producto_id     TEXT    REFERENCES productos(id),   -- NULL = línea genérica
  codigo_leido    TEXT,                               -- código que se escaneó (solo en líneas genéricas)
  descripcion     TEXT    NOT NULL,
  cantidad        INTEGER NOT NULL,
  precio_unitario INTEGER NOT NULL,
  exento          INTEGER NOT NULL DEFAULT 0,
  total_linea     INTEGER NOT NULL,
  CHECK (producto_id IS NOT NULL OR codigo_leido IS NOT NULL)
);
INSERT INTO venta_items_n (id, tenant_id, venta_id, producto_id, descripcion, cantidad, precio_unitario, exento, total_linea)
  SELECT id, tenant_id, venta_id, producto_id, descripcion, cantidad, precio_unitario, exento, total_linea FROM venta_items;
DROP TABLE venta_items;
ALTER TABLE venta_items_n RENAME TO venta_items;
CREATE INDEX idx_venta_items_venta ON venta_items(venta_id);
