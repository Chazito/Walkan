'use strict';
const clp = (n) => '$' + (n || 0).toLocaleString('es-CL');
const $ = (id) => document.getElementById(id);

// ---------- Kiosco: atajos del navegador bloqueados ----------
// En un kiosco sin barra de direcciones, salir de esta página deja la caja "atrapada" (F1 abría la ayuda de Google).
// Se bloquean: F1 ayuda, F3 buscar, F6 barra, F7 navegación con cursor, F11, F12 y Ctrl+Shift+I/J/C (herramientas),
// Alt+←/→ (atrás/adelante), Alt+Inicio y los Ctrl+letra del navegador (imprimir, guardar, abrir, historial, nueva pestaña…).
// Se dejan Ctrl+A/C/V/X/Z para editar texto. F2, F5, F9 y F10 los usa la caja.
const TECLAS_BLOQUEADAS = new Set(['F1', 'F3', 'F6', 'F7', 'F11', 'F12', 'Help', 'BrowserBack', 'BrowserForward', 'BrowserHome', 'BrowserSearch', 'BrowserFavorites']);
window.addEventListener('keydown', (ev) => {
  const k = ev.key || '';
  const ctrl = ev.ctrlKey || ev.metaKey;
  const bloquear = TECLAS_BLOQUEADAS.has(k)
    || (ev.altKey && ['ArrowLeft', 'ArrowRight', 'Home', 'F4'].includes(k))
    || (ctrl && k.length === 1 && /[a-z]/i.test(k) && !(/[acvxz]/i.test(k) && !ev.shiftKey));
  if (bloquear) { ev.preventDefault(); ev.stopImmediatePropagation(); }
}, true);
// Sin menú del botón derecho ("Atrás", "Inspeccionar"), sin botones atrás/adelante del mouse y sin soltar archivos o enlaces.
window.addEventListener('contextmenu', (ev) => ev.preventDefault());
window.addEventListener('mouseup', (ev) => { if (ev.button === 3 || ev.button === 4) ev.preventDefault(); });
window.addEventListener('dragover', (ev) => ev.preventDefault());
window.addEventListener('drop', (ev) => ev.preventDefault());
const api = async (m, url, body, extra) => {
  const r = await fetch(url, {
    method: m, headers: Object.assign(body ? { 'Content-Type': 'application/json' } : {}, extra || {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 403 && /bloqueada/i.test(data.message || '')) mostrarBloqueo();
    const m = Array.isArray(data.message) ? data.message[0] : data.message;
    throw new Error(m || ('Error ' + r.status));
  }
  return data;
};

const estado = {
  caja: null,
  resultados: [], selResultado: -1,
  carro: [], selCarro: -1,
  cajeroElegido: null,
  cobroAbierto: false,
  cobrando: false,
  qBuscada: '',
};

// Aviso breve bajo el buscador (producto no encontrado, catálogo actualizado, etc.).
let avisoTimer = null;
function aviso(texto, tipo) {
  const el = $('aviso-venta'); if (!el) return;
  el.textContent = texto; el.className = 'aviso-venta ' + (tipo || 'error'); el.hidden = false;
  clearTimeout(avisoTimer); avisoTimer = setTimeout(() => { el.hidden = true; }, 4000);
}

// ---------- Búsqueda ----------
let debTimer = null;
$('buscar').addEventListener('input', () => {
  clearTimeout(debTimer);
  debTimer = setTimeout(buscar, 150);
});
async function buscar() {
  const q = $('buscar').value.trim();
  estado.qBuscada = q;
  if (!q) { estado.resultados = []; estado.selResultado = -1; return render(); }
  try {
    estado.resultados = await api('GET', '/productos/buscar?q=' + encodeURIComponent(q));
    estado.selResultado = estado.resultados.length ? 0 : -1;
  } catch (e) { estado.resultados = []; }
  render();
}

// Enter en el buscador: el lector de código de barras escribe el código y manda Enter de inmediato,
// así que se busca al tiro (sin esperar el debounce) y se agrega si el código calza exacto.
async function escanear() {
  const q = $('buscar').value.trim();
  if (!q) return;
  if (q !== estado.qBuscada) { clearTimeout(debTimer); await buscar(); }
  const exacto = estado.resultados.find((p) => p.codigoBarras === q || p.codigo === q);
  if (exacto) return agregarProducto(exacto);
  if (estado.resultados.length && estado.selResultado >= 0) return agregarProducto(estado.resultados[estado.selResultado]);
  $('buscar').value = ''; estado.qBuscada = ''; estado.resultados = []; estado.selResultado = -1; render();
  abrirGenerico(q);
}

// ---------- Código desconocido: venta "genérica" (C1) ----------
// Antes la venta se perdía (aviso de 4 s y se borraba el código). Ahora se agrega con descripción y precio a mano;
// la caja no descuenta stock y la nube la deja en la bandeja "Vendido sin catálogo" del dueño.
function abrirGenerico(codigo) {
  // Solo códigos (sin espacios): si escribieron un nombre que no existe, basta con el aviso.
  if (!/^[^\s<>]{1,40}$/.test(codigo)) { aviso('No hay productos con «' + codigo + '».'); return; }
  $('gn-codigo').textContent = codigo; $('gn-desc').value = ''; $('gn-precio').value = ''; $('gn-error').textContent = '';
  $('overlay-generico').dataset.codigo = codigo;
  $('overlay-generico').classList.remove('oculto');
  $('gn-desc').focus();
}
function cerrarGenerico() { $('overlay-generico').classList.add('oculto'); $('buscar').focus(); }
function confirmarGenerico() {
  const codigo = $('overlay-generico').dataset.codigo || '';
  const precio = Math.round(Number($('gn-precio').value));
  if (!Number.isInteger(precio) || precio < 1 || precio > 5000000) { $('gn-error').textContent = 'Indica un precio entre $1 y $5.000.000.'; $('gn-precio').focus(); return; }
  const nombre = $('gn-desc').value.trim().slice(0, 80) || 'Producto sin código';
  const clave = 'gen:' + codigo; // una línea por código: escanearlo de nuevo suma 1
  const existe = estado.carro.find((l) => l.productoId === clave);
  if (existe) existe.cantidad += 1;
  else estado.carro.push({ productoId: clave, generico: { codigo, descripcion: nombre, precio }, nombre: nombre + ' (sin catálogo)', precio, exento: false, cantidad: 1 });
  estado.selCarro = estado.carro.findIndex((l) => l.productoId === clave);
  cerrarGenerico(); render();
  aviso('Venta sin catálogo: el dueño la revisará en el panel.', 'ok');
}
function manejarGenerico(ev) {
  if (ev.key === 'Escape') { ev.preventDefault(); cerrarGenerico(); }
  else if (ev.key === 'Enter') { ev.preventDefault(); if (document.activeElement === $('gn-desc')) $('gn-precio').focus(); else confirmarGenerico(); }
}
$('gn-ok').addEventListener('click', confirmarGenerico);
$('gn-cancelar').addEventListener('click', cerrarGenerico);

function agregarProducto(p) {
  const existe = estado.carro.find((l) => l.productoId === p.id);
  if (existe) existe.cantidad += 1;
  else estado.carro.push({ productoId: p.id, nombre: p.nombre, precio: p.precioVenta, exento: p.exento, cantidad: 1 });
  estado.selCarro = estado.carro.findIndex((l) => l.productoId === p.id);
  $('buscar').value = ''; estado.qBuscada = ''; estado.resultados = []; estado.selResultado = -1;
  render();
}

// ---------- Totales (display; el servidor recalcula igual) ----------
// El precio de góndola ya trae el IVA: el total es la suma y el neto/IVA se desglosan.
function totales() {
  let afecto = 0, exento = 0;
  for (const l of estado.carro) {
    const m = l.precio * l.cantidad;
    if (l.exento) exento += m; else afecto += m;
  }
  const neto = Math.round(afecto / 1.19);
  return { neto, iva: afecto - neto, exento, total: afecto + exento };
}

// ---------- Render ----------
function render() {
  // estado caja
  $('estado-caja').textContent = estado.caja
    ? 'Caja abierta · ' + (estado.caja.cajeroNombre || estado.caja.cajeroId.slice(0, 8))
    : 'Sin caja';
  // resultados
  const ul = $('resultados'); ul.innerHTML = '';
  estado.resultados.forEach((p, i) => {
    const li = document.createElement('li');
    if (i === estado.selResultado) li.className = 'sel';
    const n = document.createElement('span'); n.textContent = p.nombre;
    const st = document.createElement('span'); st.className = 'stock'; st.textContent = 'stock ' + p.stock;
    const pr = document.createElement('span'); pr.className = 'precio'; pr.textContent = clp(p.precioVenta);
    li.append(n, st, pr);
    li.onclick = () => agregarProducto(p);
    ul.appendChild(li);
  });
  // carro
  const tb = $('carro-body'); tb.innerHTML = '';
  estado.carro.forEach((l, i) => {
    const tr = document.createElement('tr');
    if (i === estado.selCarro) tr.className = 'sel';
    [[l.nombre, ''], [l.cantidad, 'num'], [clp(l.precio), 'num'], [clp(l.precio * l.cantidad), 'num']].forEach(([v, c]) => {
      const td = document.createElement('td'); td.textContent = v; if (c) td.className = c; tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
  const t = totales();
  $('t-neto').textContent = clp(t.neto);
  $('t-iva').textContent = clp(t.iva);
  $('t-exento').textContent = clp(t.exento);
  $('t-total').textContent = clp(t.total);
}

// ---------- Teclado global ----------
document.addEventListener('keydown', (ev) => {
  if (redAbierta()) return manejarRed(ev);
  if (ev.key === 'F2' && $('overlay-cobro').classList.contains('oculto')) { ev.preventDefault(); abrirRed(); return; }
  if (!$('overlay-bloqueada').classList.contains('oculto')) { ev.preventDefault(); return; }
  if (!$('overlay-bienvenida').classList.contains('oculto')) {
    if (ev.key === 'Enter') { ev.preventDefault(); vincular(); }
    return;
  }
  if (!$('overlay-generico').classList.contains('oculto')) return manejarGenerico(ev);
  if (!$('overlay-caja').classList.contains('oculto')) return manejarCaja(ev);
  if (!$('overlay-cobro').classList.contains('oculto')) return manejarCobro(ev);
  if (!$('overlay-ticket').classList.contains('oculto')) return manejarTicket(ev);
  // pantalla principal
  if (ev.key === 'F9') { ev.preventDefault(); abrirCobro(); return; }
  if (ev.key === 'F10') { ev.preventDefault(); cerrarCaja(); return; }
  if (ev.key === 'Escape') { $('buscar').value = ''; estado.resultados = []; estado.selResultado = -1; render(); return; }

  const enResultados = estado.resultados.length > 0;
  if (ev.key === 'ArrowDown') {
    ev.preventDefault();
    if (enResultados) estado.selResultado = Math.min(estado.selResultado + 1, estado.resultados.length - 1);
    else estado.selCarro = Math.min(estado.selCarro + 1, estado.carro.length - 1);
    render();
  } else if (ev.key === 'ArrowUp') {
    ev.preventDefault();
    if (enResultados) estado.selResultado = Math.max(estado.selResultado - 1, 0);
    else estado.selCarro = Math.max(estado.selCarro - 1, 0);
    render();
  } else if (ev.key === 'Enter') {
    ev.preventDefault();
    escanear();
  } else if (ev.key === '+' || ev.key === '=') {
    if (estado.selCarro >= 0) { estado.carro[estado.selCarro].cantidad += 1; render(); }
  } else if (ev.key === '-') {
    if (estado.selCarro >= 0) {
      const l = estado.carro[estado.selCarro];
      l.cantidad -= 1; if (l.cantidad <= 0) estado.carro.splice(estado.selCarro, 1);
      estado.selCarro = Math.min(estado.selCarro, estado.carro.length - 1);
      render();
    }
  } else if (ev.key === 'Delete') {
    if (estado.selCarro >= 0) { estado.carro.splice(estado.selCarro, 1); estado.selCarro = Math.min(estado.selCarro, estado.carro.length - 1); render(); }
  }
});

// ---------- Cobro ----------
// Dos pasos: 1) medio de pago, 2) según el medio:
//   Efectivo: monto recibido y vuelto → al confirmar se abre el cajón de dinero.
//   Tarjeta: Enter envía el cobro a la máquina; con el pago aprobado la venta se registra sola.
//   Transferencia: datos de la cuenta del negocio + QR; se confirma cuando el cliente muestra la transferencia.
// Máquina y cajón están SIMULADOS en la caja (PERIFERICOS_MODO=simulado) hasta conectar equipos reales.
const MEDIOS = { '1': ['EFECTIVO', 'Efectivo'], '2': ['TARJETA', 'Tarjeta'], '3': ['TRANSFERENCIA', 'Transferencia'] };
const ETIQUETA_MEDIO = { EFECTIVO: 'Efectivo', TARJETA: 'Tarjeta', TRANSFERENCIA: 'Transferencia' };

async function cargarNegocio() {
  try { estado.negocio = await api('GET', '/negocio'); } catch (_) { /* sin datos: se sigue con lo que haya */ }
  return estado.negocio || { nombre: '', rut: '', transferencia: null };
}
function abrirCobro() {
  if (!estado.caja) { abrirOverlayCaja(); return; }
  if (!estado.carro.length) return;
  estado.cobroAbierto = true;
  $('cobro-total').textContent = clp(totales().total);
  estado.medio = null; estado.tarjeta = null;
  mostrarPasoCobro(1);
  $('overlay-cobro').classList.remove('oculto');
  cargarNegocio();
}
function mostrarPasoCobro(n) {
  $('cobro-paso1').classList.toggle('oculto', n !== 1);
  $('cobro-paso2').classList.toggle('oculto', n !== 2);
  $('error-cobro').textContent = '';
  if (n === 1 && document.activeElement) document.activeElement.blur();
}
function elegirMedio(tecla) {
  const m = MEDIOS[tecla];
  if (!m) return;
  detenerQr(true);
  estado.medio = m[0]; estado.tarjeta = null; estado.modoTransf = null;
  $('cobro-medio').textContent = m[1];
  $('transf-estado').classList.add('oculto'); $('transf-alt').textContent = '';
  $('cobro-efectivo').classList.toggle('oculto', m[0] !== 'EFECTIVO');
  $('cobro-tarjeta').classList.toggle('oculto', m[0] !== 'TARJETA');
  $('cobro-transferencia').classList.toggle('oculto', m[0] !== 'TRANSFERENCIA');
  $('overlay-cobro').querySelector('.panel').classList.toggle('panel-ancho', m[0] === 'TRANSFERENCIA');
  $('btn-confirmar-cobro').disabled = false;
  if (m[0] === 'EFECTIVO') {
    $('cobro-confirma').textContent = 'Ingresa lo que entrega el cliente (vacío = monto exacto). Al confirmar se abre el cajón.';
    $('btn-confirmar-cobro').textContent = 'Confirmar venta (Enter)';
  } else if (m[0] === 'TARJETA') {
    $('cobro-maquina').textContent = '💳 Presiona Enter para enviar ' + clp(totales().total) + ' a la máquina de tarjetas.';
    $('cobro-maquina').className = 'cobro-maquina';
    $('cobro-confirma').textContent = 'Simulación: la máquina aprueba el pago a los pocos segundos.';
    $('btn-confirmar-cobro').textContent = 'Enviar a la máquina (Enter)';
  } else if ((estado.negocio || {}).flowQr) {
    iniciarQrFlow();
  } else {
    modoTransferenciaManual();
  }
  $('cobro-recibido').value = '';
  actualizarVuelto();
  mostrarPasoCobro(2);
  if (m[0] === 'EFECTIVO') $('cobro-recibido').focus(); else $('btn-confirmar-cobro').focus();
}
// Datos de la cuenta del negocio (se configuran en el panel web › Mis cajas) y un QR con esos mismos datos.
function pintarTransferencia() {
  const t = (estado.negocio || {}).transferencia;
  const dl = $('transf-datos'); dl.innerHTML = ''; $('transf-qr').innerHTML = '';
  if (!t) {
    const dd = document.createElement('dd');
    dd.textContent = 'Aún no hay datos de transferencia. Configúralos en el panel web (Mis cajas › Cobro por transferencia).';
    dl.appendChild(dd); return;
  }
  const total = totales().total;
  const filas = [['Monto', clp(total)], ['Banco', t.banco], ['Tipo de cuenta', t.tipoCuenta], ['N.º de cuenta', t.numero],
    ['Titular', t.titular], ['RUT', t.rut]].concat(t.email ? [['Correo', t.email]] : []);
  filas.forEach(([k, v]) => {
    const dt = document.createElement('dt'); dt.textContent = k;
    const dd = document.createElement('dd'); dd.textContent = v;
    dl.append(dt, dd);
  });
  try {
    const q = qrcode(0, 'M');
    // Formato con que los bancos comparten datos: la app del banco los "pega" solos en un nuevo destinatario.
    // "Nombre" primero (con "Titular" la app tomaba el "de" de "Tipo de cuenta") y el monto al final.
    const texto = ['Nombre: ' + t.titular, 'RUT: ' + t.rut, 'Banco: ' + t.banco, 'Tipo de cuenta: ' + t.tipoCuenta,
      'Número de cuenta: ' + t.numero].concat(t.email ? ['Correo: ' + t.email] : []).concat(['Monto: ' + clp(total)]);
    q.addData(texto.join('\n'));
    q.make();
    $('transf-qr').innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
  } catch (_) { /* sin librería QR: quedan los datos en texto */ }
}
// ---------- Transferencia: QR de pago Flow (si el negocio lo conectó) o datos de la cuenta ----------
function modoTransferenciaManual(aviso) {
  detenerQr(true);
  estado.modoTransf = 'manual';
  pintarTransferencia();
  $('transf-qr-nota').textContent = 'Escanéalo con la cámara del celular para copiar los datos';
  $('transf-estado').classList.toggle('oculto', !aviso);
  if (aviso) { $('transf-estado').className = 'cobro-maquina mal'; $('transf-estado').textContent = aviso; }
  $('cobro-confirma').textContent = 'Confirma cuando el cliente te muestre la transferencia realizada.';
  $('btn-confirmar-cobro').textContent = 'Transferencia recibida (Enter)';
  $('btn-confirmar-cobro').disabled = false;
  $('transf-alt').textContent = (estado.negocio || {}).flowQr ? 'Q: volver al QR de pago automático (Flow)' : '';
}
function detenerQr(anular) {
  const q = estado.qr; estado.qr = null;
  if (q && q.timer) clearInterval(q.timer);
  if (anular && q && q.id && !q.pagado) api('POST', '/pagos/qr/' + encodeURIComponent(q.id) + '/anular').catch(() => {});
}
async function iniciarQrFlow() {
  detenerQr(true);
  estado.modoTransf = 'flow';
  const total = totales().total;
  const q = { id: null, timer: null, pagado: false }; estado.qr = q;
  $('transf-datos').innerHTML = ''; $('transf-qr').innerHTML = '';
  $('transf-estado').classList.remove('oculto'); $('transf-estado').className = 'cobro-maquina esperando';
  $('transf-estado').textContent = '⏳ Creando el cobro en Flow…';
  $('cobro-confirma').textContent = 'El cliente escanea el QR con la cámara y paga en Flow (tarjeta o transferencia). La venta se cierra sola.';
  $('btn-confirmar-cobro').textContent = 'Esperando el pago…'; $('btn-confirmar-cobro').disabled = true;
  $('transf-alt').textContent = 'D: mostrar los datos de transferencia en vez del QR';
  try {
    const r = await api('POST', '/pagos/qr', { monto: total });
    if (estado.qr !== q) { api('POST', '/pagos/qr/' + encodeURIComponent(r.id) + '/anular').catch(() => {}); return; }
    q.id = r.id;
    const dl = $('transf-datos');
    [['Monto', clp(total)], ['Pago', 'Flow · tarjeta o transferencia'], ['', 'El cliente no necesita cuenta']].forEach(([k, v]) => {
      const dt = document.createElement('dt'); dt.textContent = k; const dd = document.createElement('dd'); dd.textContent = v; dl.append(dt, dd);
    });
    const qr = qrcode(0, 'M'); qr.addData(r.url); qr.make();
    $('transf-qr').innerHTML = qr.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
    $('transf-qr-nota').textContent = 'Escanéalo con la cámara del celular para pagar';
    $('transf-estado').textContent = '⏳ Esperando el pago en Flow…';
    q.timer = setInterval(() => revisarQr(q), 3000);
  } catch (e) {
    if (estado.qr === q) modoTransferenciaManual('No se pudo crear el QR de Flow (' + e.message + '). Se muestran los datos de transferencia.');
  }
}
async function revisarQr(q) {
  if (estado.qr !== q || q.revisando || !q.id) return;
  q.revisando = true;
  try {
    const r = await api('GET', '/pagos/qr/' + encodeURIComponent(q.id));
    if (estado.qr !== q) return;
    if (r.estado === 'pagado') {
      q.pagado = true; clearInterval(q.timer);
      $('transf-estado').className = 'cobro-maquina ok';
      $('transf-estado').textContent = '✔ Pago recibido en Flow' + (r.flowOrder ? ' · orden ' + r.flowOrder : '');
      estado.qr = null;
      await cobrar('TRANSFERENCIA', { autorizacion: r.flowOrder || undefined, terminal: ('Flow QR' + (r.medio ? ' · ' + r.medio : '')).slice(0, 30) });
    } else if (r.estado === 'rechazado' || r.estado === 'anulado') {
      clearInterval(q.timer); q.id = null; q.rechazado = true;
      $('transf-estado').className = 'cobro-maquina mal';
      $('transf-estado').textContent = '✖ Flow informó el pago como ' + r.estado + '. Presiona Enter para generar un QR nuevo.';
      $('btn-confirmar-cobro').disabled = false; $('btn-confirmar-cobro').textContent = 'Generar QR nuevo (Enter)';
    }
  } catch (_) { /* sin respuesta: se reintenta en el próximo ciclo */ }
  finally { q.revisando = false; }
}

function montoRecibido() {
  const d = $('cobro-recibido').value.replace(/\D/g, '');
  return d ? parseInt(d, 10) : null;
}
function actualizarVuelto() {
  const r = montoRecibido(), total = totales().total;
  $('error-cobro').textContent = '';
  $('cobro-vuelto').textContent = r == null ? clp(0) : r < total ? 'falta ' + clp(total - r) : clp(r - total);
  $('cobro-vuelto').classList.toggle('falta', r != null && r < total);
}
function manejarCobro(ev) {
  const paso2 = !$('cobro-paso2').classList.contains('oculto');
  if (ev.key === 'Escape') {
    ev.preventDefault();
    if (estado.tarjeta === 'esperando') { $('error-cobro').textContent = 'Espera la respuesta de la máquina de tarjetas.'; return; }
    detenerQr(true);
    if (paso2) { mostrarPasoCobro(1); return; }
    $('overlay-cobro').classList.add('oculto'); estado.cobroAbierto = false; $('buscar').focus();
    return;
  }
  if (!paso2) { if (MEDIOS[ev.key]) { ev.preventDefault(); elegirMedio(ev.key); } return; }
  if (estado.medio === 'TRANSFERENCIA' && (estado.negocio || {}).flowQr) {
    if ((ev.key === 'd' || ev.key === 'D') && estado.modoTransf === 'flow') { ev.preventDefault(); modoTransferenciaManual(); return; }
    if ((ev.key === 'q' || ev.key === 'Q') && estado.modoTransf === 'manual') { ev.preventDefault(); iniciarQrFlow(); return; }
  }
  if (ev.key === 'Enter') { ev.preventDefault(); confirmarCobro(); }
}
function confirmarCobro() {
  if (!estado.medio || estado.cobrando) return;
  const total = totales().total;
  if (estado.medio === 'EFECTIVO') {
    const recibido = montoRecibido() ?? total;
    if (recibido < total) { $('error-cobro').textContent = 'El monto recibido no cubre el total: faltan ' + clp(total - recibido) + '.'; return; }
    return cobrar('EFECTIVO', { recibido, vuelto: recibido - total });
  }
  if (estado.medio === 'TARJETA') return cobrarConTarjeta(total);
  if (estado.modoTransf === 'flow') { if (!estado.qr || estado.qr.rechazado) iniciarQrFlow(); return; }
  return cobrar('TRANSFERENCIA');
}
async function cobrarConTarjeta(total) {
  if (estado.tarjeta === 'esperando') return;
  estado.tarjeta = 'esperando';
  $('error-cobro').textContent = '';
  $('btn-confirmar-cobro').disabled = true;
  $('cobro-maquina').className = 'cobro-maquina esperando';
  $('cobro-maquina').textContent = '⏳ Esperando el pago en la máquina de tarjetas… (' + clp(total) + ')';
  try {
    const r = await api('POST', '/pagos/tarjeta', { monto: total });
    if (!r.aprobado) throw new Error(r.motivo || 'La máquina rechazó el pago.');
    $('cobro-maquina').className = 'cobro-maquina ok';
    $('cobro-maquina').textContent = '✔ Pago aprobado · autorización ' + r.autorizacion + (r.tarjeta ? ' · ' + r.tarjeta : '');
    estado.tarjeta = 'aprobada';
    await cobrar('TARJETA', { autorizacion: r.autorizacion, tarjeta: r.tarjeta, terminal: r.terminal, simulado: !!r.simulado });
  } catch (e) {
    estado.tarjeta = null;
    $('cobro-maquina').className = 'cobro-maquina mal';
    $('cobro-maquina').textContent = '✖ ' + e.message + ' Presiona Enter para reintentar.';
  } finally {
    $('btn-confirmar-cobro').disabled = false;
  }
}
$('cobro-recibido').addEventListener('input', actualizarVuelto);
$('btn-confirmar-cobro').addEventListener('click', confirmarCobro);
document.querySelectorAll('#cobro-paso1 [data-medio]').forEach((li) => li.addEventListener('click', () => elegirMedio(li.dataset.medio)));

async function cobrar(medioPago, pago) {
  if (estado.cobrando) return; // evita cobrar dos veces si se aprieta rápido
  estado.cobrando = true;
  // Copia del carro y de los totales para el comprobante en pantalla (el carro se vacía al registrar).
  const lineas = estado.carro.map((l) => ({ ...l }));
  const tot = totales();
  try {
    const r = await api('POST', '/ventas', {
      medioPago, pago: pago || undefined,
      items: lineas.map((l) => (l.generico
        ? { codigo: l.generico.codigo, descripcion: l.generico.descripcion, precio: l.generico.precio, cantidad: l.cantidad }
        : { productoId: l.productoId, cantidad: l.cantidad })),
    });
    $('overlay-cobro').classList.add('oculto'); estado.cobroAbierto = false;
    estado.carro = []; estado.selCarro = -1; render();
    let cajon = null;
    if (medioPago === 'EFECTIVO') { try { cajon = await api('POST', '/pagos/cajon'); } catch (_) { cajon = null; } }
    mostrarComprobante(r, lineas, tot, medioPago, pago || {}, cajon);
  } catch (e) { $('error-cobro').textContent = e.message; }
  finally { estado.cobrando = false; }
}

// ---------- Comprobante en pantalla ----------
function mostrarComprobante(r, lineas, tot, medioPago, pago, cajon) {
  const neg = estado.negocio || {};
  $('bol-negocio').textContent = neg.nombre || 'Walkan';
  $('bol-rut').textContent = neg.rut ? 'RUT ' + neg.rut : '';
  $('tk-folio').textContent = r.dte.folio;
  const ahora = new Date();
  $('bol-meta').textContent = ahora.toLocaleDateString('es-CL') + ' ' + ahora.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })
    + (estado.caja && estado.caja.cajeroNombre ? ' · Atendido por ' + estado.caja.cajeroNombre : '');
  const fila = (tabla, a, b, clase) => {
    const tr = document.createElement('tr'); if (clase) tr.className = clase;
    const ta = document.createElement('td'); ta.textContent = a;
    const tb = document.createElement('td'); tb.textContent = b; tb.className = 'num';
    tr.append(ta, tb); tabla.appendChild(tr);
  };
  const items = $('bol-items'); items.innerHTML = '';
  lineas.forEach((l) => fila(items, l.nombre + ' × ' + l.cantidad, clp(l.precio * l.cantidad)));
  const tt = $('bol-totales'); tt.innerHTML = '';
  fila(tt, 'Neto', clp(tot.neto)); fila(tt, 'IVA 19%', clp(tot.iva));
  if (tot.exento) fila(tt, 'Exento', clp(tot.exento));
  fila(tt, 'TOTAL', clp(r.dte.total), 'bol-total');
  const tp = $('tk-pago'); tp.innerHTML = '';
  const linea = (txt, clase) => { const d = document.createElement('div'); d.textContent = txt; if (clase) d.className = clase; tp.appendChild(d); };
  const viaFlow = /^Flow/.test(pago.terminal || '');
  linea('Pago: ' + (viaFlow ? pago.terminal.replace('Flow QR', 'QR Flow') : (ETIQUETA_MEDIO[medioPago] || medioPago))
    + (pago.autorizacion ? (viaFlow ? ' · orden ' : ' · autorización ') + pago.autorizacion : '') + (pago.tarjeta ? ' · ' + pago.tarjeta : ''));
  if (pago.recibido != null) { linea('Recibido ' + clp(pago.recibido)); linea('VUELTO ' + clp(pago.vuelto || 0), 'ticket-vuelto'); }
  if (cajon && cajon.ok) linea('🔓 Cajón de dinero abierto' + (cajon.simulado ? ' (simulado)' : ''), 'ticket-cajon');
  $('tk-estado').textContent = 'Venta registrada · se sincroniza con la nube en segundo plano';
  $('tk-correo').classList.add('oculto'); $('tk-correo-msg').textContent = ''; $('tk-email').value = '';
  estado.ticketFolio = r.dte.folio;
  if (document.activeElement) document.activeElement.blur();
  $('overlay-ticket').classList.remove('oculto');
}
function mostrarCorreo() {
  $('tk-correo').classList.remove('oculto'); $('tk-correo-msg').textContent = 'Escribe el correo y presiona Enter · Esc cancela';
  $('tk-email').focus();
}
async function enviarCorreo() {
  const email = $('tk-email').value.trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { $('tk-correo-msg').textContent = 'Correo no válido.'; return; }
  try {
    await api('POST', '/ventas/correo', { folio: Number(estado.ticketFolio), email });
    $('tk-correo').classList.add('oculto');
    $('tk-correo-msg').textContent = '✉ El comprobante se enviará a ' + email + ' (sale apenas haya conexión).';
    $('tk-email').blur();
  } catch (e) { $('tk-correo-msg').textContent = e.message; }
}
function manejarTicket(ev) {
  const correoAbierto = !$('tk-correo').classList.contains('oculto');
  if (correoAbierto) {
    if (ev.key === 'Enter') { ev.preventDefault(); enviarCorreo(); }
    else if (ev.key === 'Escape') { ev.preventDefault(); $('tk-correo').classList.add('oculto'); $('tk-correo-msg').textContent = ''; $('tk-email').blur(); }
    return;
  }
  if (ev.key === 'Enter' || ev.key === 'Escape') { ev.preventDefault(); cerrarTicket(); }
  else if (ev.key === 'c' || ev.key === 'C') { ev.preventDefault(); mostrarCorreo(); }
}
function cerrarTicket() { $('overlay-ticket').classList.add('oculto'); $('buscar').focus(); }
$('btn-nueva').addEventListener('click', cerrarTicket);
$('btn-correo').addEventListener('click', mostrarCorreo);

// ---------- Caja ----------
async function cargarCaja() {
  estado.caja = await api('GET', '/caja/actual');
  if (!estado.caja) abrirOverlayCaja(); else render();
}
async function abrirOverlayCaja() {
  let cajeros = [];
  try { cajeros = await api('GET', '/cajeros'); } catch (e) { cajeros = []; }
  estado._cajeros = cajeros;
  const hay = cajeros.length > 0;
  $('alta-cajero').classList.toggle('oculto', hay);
  $('abrir-caja-form').classList.toggle('oculto', !hay);
  $('error-caja').textContent = '';
  $('overlay-caja').classList.remove('oculto');

  if (hay) {
    $('titulo-caja').textContent = 'Abrir caja';
    $('sub-caja').textContent = 'Selecciona cajero e ingresa el PIN';
    const ul = $('lista-cajeros'); ul.innerHTML = '';
    cajeros.forEach((c, i) => {
      const li = document.createElement('li');
      li.textContent = (i + 1) + ') ' + c.nombre;
      li.onclick = () => { estado.cajeroElegido = c; $('cajero-elegido').textContent = c.nombre; marcarCajero(cajeros); $('pin').focus(); };
      ul.appendChild(li);
    });
    estado.cajeroElegido = cajeros[0];
    $('cajero-elegido').textContent = cajeros[0].nombre;
    marcarCajero(cajeros);
    $('pin').focus();
  } else {
    // Caja recién vinculada, sin cajeros: primer paso del onboarding.
    $('titulo-caja').textContent = 'Crea tu primer cajero';
    $('sub-caja').textContent = 'Un cajero es quien opera la caja. Ponle un nombre y un PIN de 4 a 8 dígitos.';
    $('nc-nombre').focus();
  }
}
$('btn-crear-cajero').onclick = crearCajero;
async function crearCajero() {
  const nombre = $('nc-nombre').value.trim();
  const pin = $('nc-pin').value.trim();
  if (!nombre) { $('error-caja').textContent = 'Ingresa el nombre del cajero.'; return; }
  if (!/^[0-9]{4,8}$/.test(pin)) { $('error-caja').textContent = 'El PIN debe tener entre 4 y 8 dígitos.'; return; }
  try {
    await api('POST', '/cajeros', { nombre, pin });
    $('nc-nombre').value = ''; $('nc-pin').value = '';
    await abrirOverlayCaja(); // ya hay un cajero: pasa al modo apertura
  } catch (e) { $('error-caja').textContent = e.message; }
}
function marcarCajero(cajeros) {
  [...$('lista-cajeros').children].forEach((li, i) => li.className = cajeros[i] === estado.cajeroElegido ? 'sel' : '');
}
function manejarCaja(ev) {
  // Modo "crear primer cajero": Enter crea el cajero.
  if (!$('alta-cajero').classList.contains('oculto')) {
    if (ev.key === 'Enter') { ev.preventDefault(); crearCajero(); }
    return;
  }
  const cajeros = estado._cajeros || [];
  const escribiendo = document.activeElement && document.activeElement.tagName === 'INPUT';
  if (ev.key >= '1' && ev.key <= '9' && !escribiendo) {
    ev.preventDefault();
    const idx = parseInt(ev.key, 10) - 1;
    if (cajeros[idx]) { estado.cajeroElegido = cajeros[idx]; $('cajero-elegido').textContent = cajeros[idx].nombre; marcarCajero(cajeros); $('pin').focus(); }
  } else if (ev.key === 'Enter') { ev.preventDefault(); confirmarAbrirCaja(); }
}
$('btn-abrir').onclick = confirmarAbrirCaja;
async function confirmarAbrirCaja() {
  if (!estado.cajeroElegido) { $('error-caja').textContent = 'Elige un cajero.'; return; }
  try {
    estado.caja = await api('POST', '/caja/abrir', {
      cajeroId: estado.cajeroElegido.id, pin: $('pin').value,
      montoApertura: parseInt($('monto-apertura').value || '0', 10),
    });
    estado.caja.cajeroNombre = estado.cajeroElegido.nombre;
    $('overlay-caja').classList.add('oculto'); $('pin').value = '';
    render(); $('buscar').focus();
  } catch (e) { $('error-caja').textContent = e.message; }
}
async function cerrarCaja() {
  if (!estado.caja) return;
  const monto = prompt('Monto de cierre (efectivo contado):', '0');
  if (monto === null) return;
  try {
    await api('POST', '/caja/cerrar', { montoCierre: parseInt(monto || '0', 10) });
    estado.caja = null; render(); abrirOverlayCaja();
  } catch (e) { alert(e.message); }
}

// ---------- Vínculo de la caja ----------
function abrirBienvenida() {
  $('overlay-bienvenida').classList.remove('oculto');
  $('bv-nombre').focus();
}
$('btn-vincular').onclick = vincular;
$('btn-mas-tarde').onclick = usarSinVincular;
function usarSinVincular() {
  // Cerrar la bienvenida y operar como POS offline (el sync queda dormido hasta vincular).
  $('overlay-bienvenida').classList.add('oculto');
  $('buscar').focus();
  cargarCaja().catch(function (e) { $('error-caja').textContent = e.message; $('overlay-caja').classList.remove('oculto'); });
}
async function vincular() {
  const nombre = $('bv-nombre').value.trim();
  const email = $('bv-email').value.trim();
  const password = $('bv-pass').value;
  if (!email || !password) { $('error-bienvenida').textContent = 'Ingresa correo y contraseña.'; return; }
  $('error-bienvenida').textContent = 'Vinculando…';
  try {
    await api('POST', '/vinculo/registrar', { email, password, nombre });
    location.reload(); // ya vinculada: recarga y entra a la app normal
  } catch (e) { $('error-bienvenida').textContent = e.message; }
}

// ---------- Bloqueo por robo ----------
// Mientras está bloqueada, se consulta cada 20 s: si el dueño la desbloquea en el panel, la caja vuelve sola.
let bloqueoTimer = null;
function mostrarBloqueo() {
  $('overlay-bloqueada').classList.remove('oculto');
  if (bloqueoTimer) return;
  bloqueoTimer = setInterval(async () => {
    try { const e = await api('GET', '/vinculo/estado'); if (!e.bloqueada) location.reload(); } catch (_) { /* sin respuesta: seguir esperando */ }
  }, 20000);
}

// ---------- Catálogo desde la nube ----------
async function actualizarCatalogo() {
  try {
    const r = await api('POST', '/sync/catalogo');
    if (r && r.ok && (r.nuevos || r.actualizados)) aviso('Catálogo actualizado desde la nube.', 'ok');
  } catch (_) { /* sin conexión: se sigue con el catálogo local */ }
}

// ---------- Cuenta en pausa ----------
// Si el plan del negocio venció, la nube deja de aceptar la sincronización (403). La caja sigue vendiendo y guarda
// las ventas en su cola; aquí solo se muestra la franja de aviso. Se revisa cada minuto (barato: es local).
async function revisarPausa() {
  try { const e = await api('GET', '/vinculo/estado'); $('aviso-pausa').hidden = !e.cuentaEnPausa; } catch (_) { /* sin respuesta: no se cambia */ }
}
setInterval(revisarPausa, 60000);

// ---------- Inicio ----------
async function arranque() {
  let est;
  try {
    est = await api('GET', '/vinculo/estado');
  } catch (e) {
    // Si no se puede leer el estado, no bloqueamos la venta: seguimos al POS.
    est = { vinculada: true, bloqueada: false };
  }
  if (est.bloqueada) { mostrarBloqueo(); return; }
  if (!est.vinculada) { abrirBienvenida(); return; }
  $('buscar').focus();
  actualizarCatalogo().then(revisarPausa);
  if (est.cuentaEnPausa) $('aviso-pausa').hidden = false;
  cargarNegocio();
  cargarCaja().catch((e) => { $('error-caja').textContent = e.message; $('overlay-caja').classList.remove('oculto'); });
}
arranque();

// ---------- Red / Wi-Fi (F2) ----------
// Muestra por dónde sale la caja a internet (cable, Wi-Fi USB, celular por USB) y si llega a la nube.
// Buscar y conectar redes pide el PIN de un cajero (la API de la caja también escucha en la red local).
function redAbierta() { return !$('overlay-red').classList.contains('oculto'); }
function pintarIndicadorRed(e) {
  const el = $('estado-red'); if (!el) return;
  const via = e && Array.isArray(e.interfaces) ? e.interfaces.find((i) => i.estado === 'conectado') : null;
  el.textContent = e && e.nube ? '● En línea' + (via ? ' · ' + via.tipo : '') : '● Sin nube';
  el.className = 'estado-red ' + (e && e.nube ? 'ok' : 'mal');
}
async function refrescarIndicadorRed() {
  try { const e = await api('GET', '/red/estado'); pintarIndicadorRed(e); return e; }
  catch (_) { pintarIndicadorRed(null); return null; }
}
function pintarEstadoRed(e) {
  const ul = $('red-interfaces'); ul.innerHTML = '';
  const linea = (t) => { const li = document.createElement('li'); li.textContent = t; ul.appendChild(li); };
  if (!e) { $('red-nube').textContent = 'No se pudo leer el estado de la red.'; $('red-nube').className = 'red-nube mal'; return; }
  $('red-nube').textContent = e.nube ? '✔ La caja llega a la nube Walkan.'
    : '✖ La caja no llega a la nube. Puedes seguir vendiendo: las ventas se envían al volver la conexión.';
  $('red-nube').className = 'red-nube ' + (e.nube ? 'ok' : 'mal');
  if (!e.networkManager) linea('NetworkManager no está instalado: no se pueden configurar redes Wi-Fi desde aquí.');
  (e.interfaces || []).forEach((i) => linea(i.tipo + ': ' + i.estado + (i.estado === 'conectado' && i.conexion ? ' (' + i.conexion + ')' : '') + (i.ip ? ' · ' + i.ip : '')));
  if (e.networkManager && !e.wifiDisponible) linea('Wi-Fi: no hay adaptador. Conecta un adaptador Wi-Fi USB o usa el anclaje USB del celular.');
  $('btn-red-buscar').disabled = !e.wifiDisponible;
}
async function abrirRed() {
  $('overlay-red').classList.remove('oculto');
  $('error-red').textContent = ''; $('red-wifi').innerHTML = '';
  $('red-conectar').classList.add('oculto'); estado.redSsid = null;
  $('red-nube').textContent = 'Revisando conexión…'; $('red-nube').className = 'red-nube';
  $('red-pin').focus();
  pintarEstadoRed(await refrescarIndicadorRed());
}
function cerrarRed() {
  $('overlay-red').classList.add('oculto');
  if (!$('overlay-bienvenida').classList.contains('oculto')) $('bv-nombre').focus(); else $('buscar').focus();
}
const pinRed = () => ({ 'X-Pin': $('red-pin').value.trim() });
async function buscarRedes() {
  $('error-red').textContent = ''; $('red-conectar').classList.add('oculto');
  const ul = $('red-wifi'); ul.innerHTML = '<li class="sub">Buscando redes…</li>';
  try {
    const redes = await api('GET', '/red/wifi', undefined, pinRed());
    ul.innerHTML = '';
    if (!redes.length) { ul.innerHTML = '<li class="sub">No se encontraron redes.</li>'; return; }
    redes.forEach((r) => {
      const li = document.createElement('li'); li.tabIndex = 0;
      const n = document.createElement('span'); n.textContent = (r.enUso ? '✔ ' : '') + r.ssid + (r.segura ? ' 🔒' : '');
      const s = document.createElement('span'); s.className = 'senal'; s.textContent = r.senal + '%';
      li.append(n, s);
      const elegir = () => elegirRed(r);
      li.onclick = elegir; li.onkeydown = (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); ev.stopPropagation(); elegir(); } };
      ul.appendChild(li);
    });
    ul.querySelector('li').focus();
  } catch (e) { ul.innerHTML = ''; $('error-red').textContent = e.message; }
}
function elegirRed(r) {
  estado.redSsid = r.ssid; estado.redSegura = r.segura;
  $('red-ssid').textContent = r.ssid; $('red-clave').value = '';
  $('red-clave').parentElement.classList.toggle('oculto', !r.segura);
  $('red-conectar').classList.remove('oculto');
  if (r.segura) $('red-clave').focus(); else $('btn-red-conectar').focus();
}
async function conectarRed() {
  if (!estado.redSsid || estado.conectandoRed) return;
  estado.conectandoRed = true;
  $('error-red').textContent = ''; $('btn-red-conectar').textContent = 'Conectando…';
  try {
    const e = await api('POST', '/red/conectar', { ssid: estado.redSsid, clave: estado.redSegura ? $('red-clave').value : undefined }, pinRed());
    pintarEstadoRed(e); pintarIndicadorRed(e);
    $('red-conectar').classList.add('oculto'); $('red-wifi').innerHTML = '';
    aviso('Conectada a ' + estado.redSsid + '.', 'ok');
  } catch (e) { $('error-red').textContent = e.message; $('error-red').scrollIntoView({ block: 'nearest' }); }
  finally { estado.conectandoRed = false; $('btn-red-conectar').textContent = 'Conectar (Enter)'; }
}
function manejarRed(ev) {
  if (ev.key === 'Escape') { ev.preventDefault(); cerrarRed(); return; }
  if (ev.key !== 'Enter' || ev.defaultPrevented) return;
  const t = document.activeElement;
  if (t && (t.id === 'red-clave' || t.id === 'btn-red-conectar')) { ev.preventDefault(); conectarRed(); }
  else if (t && t.id === 'red-pin') { ev.preventDefault(); buscarRedes(); }
}
$('btn-red-buscar').onclick = buscarRedes;
$('btn-red-conectar').onclick = conectarRed;
$('btn-red-bv').onclick = abrirRed;
$('estado-red').onclick = abrirRed;
refrescarIndicadorRed();
setInterval(() => { if (!redAbierta()) refrescarIndicadorRed(); }, 30000);

// ---------- Reloj (esquina inferior derecha) ----------
// Fecha y hora del TV Box para que el cajero no dependa del celular. Se refresca cada 10 s (basta para los minutos).
function actualizarReloj() {
  const a = new Date();
  const dia = a.toLocaleDateString('es-CL', { weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric' });
  const hora = a.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });
  $('reloj').textContent = dia.charAt(0).toUpperCase() + dia.slice(1) + '  ·  ' + hora;
}
actualizarReloj();
setInterval(actualizarReloj, 10000);
