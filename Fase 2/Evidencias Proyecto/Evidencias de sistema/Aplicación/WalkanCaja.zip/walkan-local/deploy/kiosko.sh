#!/bin/bash
# Sesión X del kiosco (la lanza walkan-kiosk.service con xinit). Se instala en /home/pos/kiosko.sh.
xrandr --output Composite-1 --off
xrandr --output HDMI-1 --primary --mode 1920x1080
xset s off; xset -dpms; xset s noblank
# Sin repetición de teclas: si la pistola se reconecta a mitad de una lectura, X la reactiva; se reaplica cada 3 s.
( while sleep 3; do xset r off; done ) &
setxkbmap -layout latam -option numpad:mac
RES=$(xrandr | awk '/\*/{print $1; exit}' | tr x ,)
# espera a que el backend responda antes de abrir
until curl -sf http://localhost:3000/salud >/dev/null; do sleep 1; done
exec chromium --kiosk --start-fullscreen --window-position=0,0 --window-size=${RES:-1920,1080} \
  --noerrdialogs --disable-infobars --incognito --disable-gpu --no-first-run \
  --disable-background-networking --disable-sync --disable-component-update \
  --check-for-update-interval=31536000 http://localhost:3000
