#!/usr/bin/env bash
# Instalador para la caja (aarch64, Debian). Ejecutar desde la raíz del repo:
#   sudo bash deploy/install.sh
set -euo pipefail

DEST=/opt/walkan
SRC="$(cd "$(dirname "$0")/.." && pwd)"

echo ">> Verificando Node >= 20"
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  echo "ERROR: se requiere Node.js 20+ instalado en la caja." >&2
  exit 1
fi

echo ">> Copiando a $DEST (sin node_modules ni data)"
mkdir -p "$DEST"
rsync -a --delete \
  --exclude node_modules --exclude dist --exclude data --exclude .git --exclude .env \
  "$SRC"/ "$DEST"/
cd "$DEST"

echo ">> Instalando dependencias EN LA CAJA (compila better-sqlite3 aarch64)"
npm install --no-audit --no-fund
echo ">> Compilando"
npm run build
echo ">> Podando devDependencies"
npm prune --omit=dev

echo ">> Configuración (.env)"
[ -f .env ] || cp .env.example .env

echo ">> Usuario de servicio 'walkan'"
id walkan &>/dev/null || useradd --system --home "$DEST" --shell /usr/sbin/nologin walkan
mkdir -p "$DEST/data"
chown -R walkan:walkan "$DEST"
# BD (con el token de la caja) y .env solo para el usuario walkan; el kiosko (pos) no los lee.
chmod 700 "$DEST/data"
chmod 600 "$DEST/.env"
find "$DEST/data" -type f -exec chmod 600 {} +

echo ">> Red: NetworkManager para Wi-Fi USB y anclaje USB del celular (pantalla Red, F2)"
# La config va ANTES de instalar: NetworkManager parte apenas se instala y no debe tomar eth0 ni ZeroTier.
install -D -m 644 deploy/90-walkan-nm.conf /etc/NetworkManager/conf.d/90-walkan-nm.conf
apt-get install -y network-manager polkitd
# Firmware de antenas Wi-Fi USB: Realtek (RTL8192EU, RTL8188EU…) y MediaTek (MT7601U, MT7610U…). Requiere non-free-firmware.
apt-get install -y firmware-realtek firmware-misc-nonfree || echo 'AVISO: no se pudo instalar el firmware Wi-Fi (revisa non-free-firmware en apt).'
install -m 644 deploy/50-walkan-red.rules /etc/polkit-1/rules.d/50-walkan-red.rules
systemctl restart polkit NetworkManager || true
install -m 644 deploy/90-walkan-red.conf /etc/sysctl.d/90-walkan-red.conf
sysctl --system >/dev/null || true

echo ">> Periféricos USB sin suspensión"
install -m 644 deploy/50-usb-sin-suspension.rules /etc/udev/rules.d/50-usb-sin-suspension.rules
udevadm control --reload-rules || true

echo ">> Kiosco (usuario 'pos', X en vt7, Chromium a pantalla completa)"
id pos &>/dev/null || useradd --create-home --groups video,render,input,tty pos
install -m 755 -o pos -g pos deploy/kiosko.sh /home/pos/kiosko.sh
# Políticas de Chromium: solo puede abrir la caja (localhost:3000); sin herramientas de desarrollo ni descargas.
install -D -m 644 deploy/chromium-walkan.json /etc/chromium/policies/managed/walkan.json
mkdir -p /etc/X11/xorg.conf.d
install -m 644 deploy/10-hdmi.conf /etc/X11/xorg.conf.d/10-hdmi.conf
grep -q '^allowed_users=anybody' /etc/X11/Xwrapper.config 2>/dev/null || printf 'allowed_users=anybody\nneeds_root_rights=yes\n' > /etc/X11/Xwrapper.config

echo ">> Instalando unidades systemd"
cp deploy/walkan.service /etc/systemd/system/
cp deploy/walkan-kiosk.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now walkan.service
systemctl enable --now walkan-kiosk.service

echo ">> Listo. Verifica: curl http://localhost:3000/salud"
