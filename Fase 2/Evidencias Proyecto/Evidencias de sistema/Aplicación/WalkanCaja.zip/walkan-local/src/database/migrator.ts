import { readdirSync, readFileSync } from 'fs';
import { join } from 'path';
import type Database from 'better-sqlite3';

// Migrador casero: sin ORM no hay migraciones "gratis" (D-02), así que esto lee
// los .sql de migrations/ y lleva la cuenta en una tablita propia.
const TABLA_CONTROL = '_migraciones';

/**
 * Aplica en orden las migraciones *.sql que aún no estén registradas.
 * Idempotente: correrla dos veces no vuelve a aplicar nada.
 * Cada migración corre dentro de su propia transacción.
 */
export function ejecutarMigraciones(
  db: Database.Database,
  dir: string,
  log: (msg: string) => void = () => {},
): string[] {
  db.prepare(
    `CREATE TABLE IF NOT EXISTS ${TABLA_CONTROL} (
       nombre      TEXT PRIMARY KEY,
       aplicada_en TEXT NOT NULL
     )`,
  ).run();

  // El orden sale del nombre (001_, 002_...), por eso el prefijo numérico con ceros.
  const archivos = readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  const yaAplicada = db.prepare(`SELECT 1 FROM ${TABLA_CONTROL} WHERE nombre = ?`);
  const registrar = db.prepare(
    `INSERT INTO ${TABLA_CONTROL} (nombre, aplicada_en) VALUES (?, ?)`,
  );

  const aplicadas: string[] = [];
  for (const archivo of archivos) {
    if (yaAplicada.get(archivo)) continue;
    const sql = readFileSync(join(dir, archivo), 'utf8');
    // El .sql y su registro van juntos: si el script falla a la mitad, rollback
    // completo y no queda marcada como aplicada. Ojo que no se compara contenido:
    // editar una migración ya aplicada no hace nada, hay que crear otra.
    const correr = db.transaction(() => {
      db.exec(sql);
      registrar.run(archivo, new Date().toISOString());
    });
    correr.immediate();
    aplicadas.push(archivo);
    log(`migración aplicada: ${archivo}`);
  }
  return aplicadas;
}
