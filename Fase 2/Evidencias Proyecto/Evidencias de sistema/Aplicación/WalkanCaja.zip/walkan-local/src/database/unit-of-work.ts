import type Database from 'better-sqlite3';

/**
 * Envuelve una función en una transacción IMMEDIATE: toma el lock de escritura
 * al iniciar (evita deadlocks de upgrade). Devuelve una función que ejecuta la
 * transacción con los argumentos dados. Es la unidad de trabajo de la venta.
 *
 * Ojo: better-sqlite3 es síncrono, así que `fn` NO puede ser async. Si metes un
 * await adentro, la transacción hace commit antes de que vuelva la promesa y
 * quedas con medio trabajo guardado. Nada de red acá adentro (D-07).
 */
export function transaccionInmediata<A extends unknown[], R>(
  db: Database.Database,
  fn: (...args: A) => R,
): (...args: A) => R {
  const tx = db.transaction(fn);
  return (...args: A): R => tx.immediate(...args);
}
