import { Global, Module } from '@nestjs/common';
import { sqliteProvider, SQLITE } from './sqlite.provider';

/** Provee la conexión SQLite única (y corre las migraciones al crearla). */
@Global()
@Module({
  providers: [sqliteProvider],
  exports: [SQLITE],
})
export class DatabaseModule {}
