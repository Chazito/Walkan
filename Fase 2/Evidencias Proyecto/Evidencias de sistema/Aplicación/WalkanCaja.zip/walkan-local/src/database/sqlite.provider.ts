// Abre la base SQLite de la caja y la deja lista (PRAGMAs + migraciones) para inyectarla en el resto.
import { mkdirSync } from 'fs';
import { dirname } from 'path';
import Database from 'better-sqlite3';
import { AppConfig, cargarConfig } from '../config/configuracion';
import { aplicarPragmas } from '../config/pragmas';
import { ejecutarMigraciones } from './migrator';

/** Token de inyección de la conexión SQLite única. */
export const SQLITE = Symbol('SQLITE');

/** Abre (o crea) la base, asegura la carpeta y aplica los PRAGMAs. */
export function abrirBaseDeDatos(config: AppConfig): Database.Database {
  mkdirSync(dirname(config.dbPath), { recursive: true });
  const db = new Database(config.dbPath);
  aplicarPragmas(db);
  return db;
}

/**
 * Provee la conexión. Corre las migraciones AQUÍ (antes de que Nest construya
 * los repositorios), para que las tablas existan cuando cada repo prepara sus
 * statements en su constructor.
 */
export const sqliteProvider = {
  provide: SQLITE,
  useFactory: (): Database.Database => {
    const cfg = cargarConfig();
    const db = abrirBaseDeDatos(cfg);
    const aplicadas = ejecutarMigraciones(db, cfg.migrationsDir, (m) =>
      console.log(`[migrator] ${m}`),
    );
    if (!aplicadas.length) console.log('[migrator] sin migraciones pendientes');
    return db;
  },
};
