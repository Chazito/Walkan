// Módulo de red: junta el controller y el service de la conexión a internet de la caja.
import { Module } from '@nestjs/common';
import { CajerosModule } from '../cajeros/cajeros.module';
import { RedController } from './red.controller';
import { RedService } from './red.service';

// Conexión a internet de la caja (cable, Wi-Fi USB, celular por USB) vía NetworkManager.
@Module({
  imports: [CajerosModule],
  controllers: [RedController],
  providers: [RedService],
})
export class RedModule {}
