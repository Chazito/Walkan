// Lo que se valida del body al cargar un CAF.
import { IsIn, IsInt, IsOptional, IsString, Min } from 'class-validator';
import { TipoDte } from '../../tipos/tipo-dte';

const TIPOS = Object.values(TipoDte);

/** Carga un rango de folios (CAF) autorizado por el SII. */
export class RegistrarCafDto {
  @IsIn(TIPOS) tipoDte: string;
  @IsInt() @Min(1) folioDesde: number;
  @IsInt() @Min(1) folioHasta: number;
  // El XML del CAF tal como lo baja el SII. Opcional mientras el envío sea simulado.
  @IsOptional() @IsString() xml?: string;
}
