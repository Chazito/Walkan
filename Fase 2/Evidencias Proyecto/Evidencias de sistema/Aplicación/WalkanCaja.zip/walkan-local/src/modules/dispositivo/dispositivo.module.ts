// Módulo del dispositivo: vínculo de la caja con la nube y bloqueo antirrobo.
import { Global, Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { DispositivoRepository } from './dispositivo.repository';
import { DispositivoService } from './dispositivo.service';
import { VinculoController } from './vinculo.controller';
import { BloqueoGuard } from './bloqueo.guard';

// Global: el vínculo/kill-switch se consulta desde el cliente de sync y desde
// el guard de bloqueo que protege toda la app.
@Global()
@Module({
  controllers: [VinculoController],
  providers: [
    DispositivoRepository,
    DispositivoService,
    { provide: APP_GUARD, useClass: BloqueoGuard },
  ],
  exports: [DispositivoRepository, DispositivoService],
})
export class DispositivoModule {}
