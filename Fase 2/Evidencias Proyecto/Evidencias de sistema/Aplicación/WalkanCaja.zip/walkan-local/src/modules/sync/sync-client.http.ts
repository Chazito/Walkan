// Sube los cambios del outbox a la nube por HTTP y reacciona a bloqueo, pausa o renumeración.
import { Injectable, Logger } from '@nestjs/common';
import { DispositivoService } from '../dispositivo/dispositivo.service';
import { CambioSync, SyncClient, SyncResultado } from './sync-client.interface';
import { SyncRepository } from './sync.repository';

/**
 * Cliente de sincronización REAL. Empuja los cambios del outbox a la nube
 * (unidireccional caja → nube) contra POST {nube}/api/sync, autenticando con
 * el token del dispositivo (header X-Caja-Token).
 *
 * Contrato con el worker:
 *  - Fallo de red / caja no vinculada / rechazo → lanza excepción (reintenta).
 *  - Kill-switch: si la nube responde {bloqueada:true}, marca la caja como
 *    bloqueada localmente (la app se candará) y lanza para NO marcar la fila
 *    como enviada.
 *  - Cuenta en pausa (403): se avisa en pantalla; la venta sigue y la cola espera.
 *  - Numeración reiniciada (C3): la cola pendiente se renumera sobre lo que la nube ya recibió y se reintenta.
 */
@Injectable()
export class SyncClientHttp implements SyncClient {
  private readonly logger = new Logger('SyncClientHttp');

  constructor(private readonly dispositivo: DispositivoService, private readonly repo: SyncRepository) {}

  async enviar(cambios: CambioSync[]): Promise<SyncResultado> {
    const v = this.dispositivo.vinculo();
    if (!v.token || !v.nubeUrl) {
      throw new Error('Caja no vinculada: falta enrolar el dispositivo.');
    }

    // uid = id de la venta (o del evento) en la caja: con él la nube reconoce un reenvío aunque el seq se repita.
    const eventos = cambios.map((c) => ({ seq: c.id, uid: c.entidadId, tipo: c.entidad, payload: c.payload }));

    let resp: Response;
    try {
      resp = await fetch(`${v.nubeUrl}/api/sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Caja-Token': v.token },
        body: JSON.stringify({ eventos }),
        // Sin tope, una conexión colgada dejaba el worker "procesando" para siempre y la cola no avanzaba (C6).
        signal: AbortSignal.timeout(15_000),
      });
    } catch (e) {
      // Sin conexión (o la nube no respondió a tiempo): el worker reintenta con backoff. No es error lógico.
      throw new Error(`Nube no disponible: ${(e as Error).message}`);
    }

    const data: any = await resp.json().catch(() => ({}));

    // Kill-switch: la nube ordena bloquear esta caja (robo).
    if (data?.bloqueada) {
      this.dispositivo.marcarBloqueada();
      throw new Error('Caja bloqueada por la nube (antirrobo).');
    }

    if (resp.status === 401) {
      // Token inválido/revocado: reintentar no ayuda, pero tampoco marcamos enviado.
      throw new Error('Token de caja inválido o revocado por la nube.');
    }
    if (resp.status === 403) {
      // Plan vencido o cuenta suspendida: la caja sigue vendiendo y la cola sube sola cuando el dueño pague.
      this.dispositivo.marcarPausa(true);
      throw new Error(data?.message || 'Cuenta del negocio en pausa: las ventas se sincronizan al reactivarla.');
    }
    if (data?.reiniciada && Number.isSafeInteger(data.ultimoSeq)) {
      const n = this.repo.renumerarPendientes(data.ultimoSeq);
      this.logger.warn(`La nube ya tenía ventas hasta el n° ${data.ultimoSeq} (la caja reinició su numeración): ${n} envío(s) renumerado(s).`);
      throw new Error('Cola de envío renumerada: se reintenta en el próximo ciclo.');
    }
    if (!resp.ok || data?.ok === false) {
      throw new Error(data?.message || `La nube rechazó la sincronización (HTTP ${resp.status}).`);
    }
    // La nube respondió bien y sin orden de bloqueo: si estaba bloqueada, se desbloquea.
    if (data?.bloqueada === false) this.dispositivo.marcarDesbloqueada();
    this.dispositivo.marcarPausa(false);

    return { ok: true };
  }
}
