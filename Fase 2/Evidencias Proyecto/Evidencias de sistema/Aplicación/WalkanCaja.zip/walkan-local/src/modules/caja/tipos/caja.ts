export type EstadoCaja = 'ABIERTA' | 'CERRADA';

// Un turno de caja, de la apertura al cierre. Montos en pesos (sin decimales).
export interface SesionCaja {
  id: string;
  tenantId: string;
  cajeroId: string;
  montoApertura: number;
  montoCierre: number | null;
  estado: EstadoCaja;
  fechaApertura: string;
  fechaCierre: string | null;
  createdAt: string;
  updatedAt: string;
}
