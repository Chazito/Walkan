// SQL del stock del producto y de la tabla movimientos_stock (el kardex).
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { MovimientoStock } from './tipos/movimiento';

type Fila = Record<string, any>;

@Injectable()
export class InventarioRepository {
  private readonly _prod: Database.Statement;
  private readonly _setStock: Database.Statement;
  private readonly _insertMov: Database.Statement;
  private readonly _listMov: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._prod = db.prepare('SELECT stock, activo FROM productos WHERE tenant_id=? AND id=?');
    this._setStock = db.prepare(
      'UPDATE productos SET stock=@stock, updated_at=@now WHERE tenant_id=@t AND id=@id',
    );
    this._insertMov = db.prepare(
      `INSERT INTO movimientos_stock
         (id,tenant_id,producto_id,tipo,motivo,cantidad,stock_resultante,referencia,comentario,created_at)
       VALUES (@id,@tenantId,@productoId,@tipo,@motivo,@cantidad,@stockResultante,@referencia,@comentario,@createdAt)`,
    );
    this._listMov = db.prepare(
      `SELECT * FROM movimientos_stock
        WHERE tenant_id=? AND producto_id=? ORDER BY created_at DESC, id DESC LIMIT ?`,
    );
  }

  obtenerProducto(tenantId: string, id: string): { stock: number; activo: number } | undefined {
    return this._prod.get(tenantId, id) as { stock: number; activo: number } | undefined;
  }

  setStock(tenantId: string, id: string, stock: number, now: string): void {
    this._setStock.run({ t: tenantId, id, stock, now });
  }

  insertarMovimiento(m: MovimientoStock): void {
    this._insertMov.run({
      id: m.id, tenantId: m.tenantId, productoId: m.productoId, tipo: m.tipo,
      motivo: m.motivo, cantidad: m.cantidad, stockResultante: m.stockResultante,
      referencia: m.referencia ?? null, comentario: m.comentario ?? null, createdAt: m.createdAt,
    });
  }

  listarMovimientos(tenantId: string, productoId: string, limit: number): MovimientoStock[] {
    return (this._listMov.all(tenantId, productoId, limit) as Fila[]).map(mapear);
  }
}

function mapear(r: Fila): MovimientoStock {
  return {
    id: r.id, tenantId: r.tenant_id, productoId: r.producto_id, tipo: r.tipo,
    motivo: r.motivo, cantidad: r.cantidad, stockResultante: r.stock_resultante,
    referencia: r.referencia, comentario: r.comentario, createdAt: r.created_at,
  };
}
