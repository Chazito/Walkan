// Tipos del kardex: qué clase de movimiento es, por qué se hizo y cómo se ve guardado.
export const TipoMovimiento = {
  ENTRADA: 'ENTRADA',
  SALIDA: 'SALIDA',
  AJUSTE: 'AJUSTE',
} as const;
export type TipoMovimiento = (typeof TipoMovimiento)[keyof typeof TipoMovimiento];

export const MotivoMovimiento = {
  INVENTARIO_INICIAL: 'INVENTARIO_INICIAL',
  RECEPCION_COMPRA: 'RECEPCION_COMPRA',
  VENTA: 'VENTA',
  AJUSTE_MANUAL: 'AJUSTE_MANUAL',
  MERMA: 'MERMA',
  DEVOLUCION: 'DEVOLUCION',
} as const;
export type MotivoMovimiento = (typeof MotivoMovimiento)[keyof typeof MotivoMovimiento];

export interface MovimientoStock {
  id: string;
  tenantId: string;
  productoId: string;
  tipo: TipoMovimiento;
  motivo: MotivoMovimiento;
  /** Delta con signo aplicado al stock (+ entrada, - salida). */
  cantidad: number;
  stockResultante: number;
  referencia: string | null;
  comentario: string | null;
  createdAt: string;
}

/** Entrada al servicio. Para ENTRADA/SALIDA `cantidad` es magnitud (>0);
 *  para AJUSTE es el stock absoluto objetivo. */
export interface EntradaMovimiento {
  tenantId: string;
  productoId: string;
  tipo: TipoMovimiento;
  motivo: MotivoMovimiento;
  cantidad: number;
  referencia?: string | null;
  comentario?: string | null;
}
