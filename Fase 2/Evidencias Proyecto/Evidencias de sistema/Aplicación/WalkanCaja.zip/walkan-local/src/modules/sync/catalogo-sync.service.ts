// Baja el catálogo, los cajeros y los datos del negocio desde la nube cada cierto rato.
import { Inject, Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { CONFIG } from '../../common/config.provider';
import { AppConfig } from '../../config/configuracion';
import { TenantContext } from '../../common/contexto/tenant.context';
import { ahora } from '../../common/util/id';
import { DispositivoService } from '../dispositivo/dispositivo.service';
import { ProductosRepository } from '../productos/productos.repository';
import { ProductosService } from '../productos/productos.service';
import { InventarioService } from '../inventario/inventario.service';
import { MotivoMovimiento, TipoMovimiento } from '../inventario/tipos/movimiento';
import { SyncRepository } from './sync.repository';
import { CajerosService } from '../cajeros/cajeros.service';
import { AjustesService } from '../pagos/ajustes.service';

interface ProductoNube { id?: string; sku: string; nombre: string; precio: number; stock: number }
export interface ResultadoCatalogo {
  ok: boolean; motivo?: string; nuevos?: number; actualizados?: number; stockAjustado?: number; desactivados?: number; conStock?: boolean;
}

/**
 * Catálogo nube → caja. Los productos se administran en el panel web (Franco) y la caja
 * los recibe por SKU: GET {nube}/api/catalogo con el token del dispositivo.
 *
 * - Crea en la caja los productos nuevos y actualiza nombre y precio de los existentes.
 *   La llave es el SKU de la web = `codigo` de la caja.
 * - El stock de la caja se iguala al de la nube SOLO si no quedan ventas sin subir
 *   (si hay pendientes, la nube todavía no las descontó y se pisaría el stock local).
 * - Cada producto queda enlazado al id de la web (id_nube): si en el panel cambian el SKU, se actualiza el
 *   código del MISMO producto en vez de crear un duplicado.
 * - Lo que ya no está en el catálogo de la nube (archivado o eliminado) se desactiva en la caja.
 * - Sirve también de latido: si el dueño bloqueó o desbloqueó la caja en el panel, la
 *   caja se entera aquí aunque no tenga ventas que subir.
 * - Sin internet no pasa nada: la caja sigue vendiendo con su catálogo local.
 */
@Injectable()
export class CatalogoSyncService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger('Catalogo');
  private timer?: NodeJS.Timeout;
  private corriendo = false;

  constructor(
    private readonly dispositivo: DispositivoService,
    private readonly productosRepo: ProductosRepository,
    private readonly productos: ProductosService,
    private readonly inventario: InventarioService,
    private readonly syncRepo: SyncRepository,
    private readonly cajeros: CajerosService,
    private readonly ajustes: AjustesService,
    private readonly tenant: TenantContext,
    @Inject(CONFIG) private readonly cfg: AppConfig,
  ) {}

  onModuleInit(): void {
    if (process.env.SYNC_MODO === 'simulado') return;
    setTimeout(() => void this.sincronizar(), 5_000).unref?.();
    this.timer = setInterval(() => void this.sincronizar(), this.cfg.intervaloCatalogoMs);
    this.timer.unref?.();
  }
  onModuleDestroy(): void {
    if (this.timer) clearInterval(this.timer);
  }

  async sincronizar(): Promise<ResultadoCatalogo> {
    if (this.corriendo) return { ok: false, motivo: 'en-curso' };
    const v = this.dispositivo.vinculo();
    if (!v.token || !v.nubeUrl) return { ok: false, motivo: 'no-vinculada' };
    this.corriendo = true;
    try {
      let resp: Response;
      try {
        resp = await fetch(`${v.nubeUrl}/api/catalogo`, {
          headers: { 'X-Caja-Token': v.token }, signal: AbortSignal.timeout(15_000),
        });
      } catch {
        return { ok: false, motivo: 'sin-conexion' }; // sin internet: se sigue vendiendo con lo local
      }
      const data: any = await resp.json().catch(() => ({}));
      if (data?.bloqueada) { this.dispositivo.marcarBloqueada(); return { ok: false, motivo: 'bloqueada' }; }
      if (resp.status === 403) { this.dispositivo.marcarPausa(true); return { ok: false, motivo: 'cuenta-en-pausa' }; }
      if (!resp.ok) return { ok: false, motivo: data?.message || `HTTP ${resp.status}` };

      this.dispositivo.marcarDesbloqueada();
      this.dispositivo.marcarPausa(false);
      this.syncRepo.adelantarReintentos(ahora()); // la nube responde: que salgan ya las ventas en espera
      const lista: ProductoNube[] = Array.isArray(data?.productos) ? data.productos : [];
      // C2: antes, con CUALQUIER fila pendiente (lo normal: el propio catálogo encola filas) no se tocaba ningún stock y
      // un producto nuevo nacía con 0, así que no se podía vender. Ahora solo se congela el stock de los productos con
      // ventas aún sin subir (la nube todavía no las descontó); el resto toma el stock de la nube.
      const congelados = this.syncRepo.skusConVentasPendientes();
      const r = this.aplicar(lista, congelados);
      const conStock = congelados.size === 0;
      // Datos del negocio: encabezado del comprobante y cuenta para transferencias.
      if (data?.negocio && typeof data.negocio === 'object') this.ajustes.guardar('negocio', data.negocio);
      // Cajeros del panel (solo si la nube los envía: una nube antigua sin el campo no toca los locales).
      if (Array.isArray(data?.cajeros)) {
        const c = this.cajeros.sincronizarDesdeNube(data.cajeros);
        if (c.nuevos || c.actualizados || c.desactivados) {
          this.logger.log(`Cajeros: ${c.nuevos} nuevo(s), ${c.actualizados} actualizado(s), ${c.desactivados} desactivado(s).`);
        }
      }
      if (r.nuevos || r.actualizados || r.stockAjustado || r.desactivados) {
        this.logger.log(`Catálogo: ${r.nuevos} nuevo(s), ${r.actualizados} actualizado(s), ${r.desactivados} desactivado(s), ${r.stockAjustado} stock(s) ajustado(s)${conStock ? '' : ` (stock sin tocar en ${congelados.size} código(s) con ventas pendientes de subir)`}.`);
      }
      return { ok: true, ...r, conStock };
    } catch (e) {
      this.logger.warn(`No se pudo aplicar el catálogo: ${(e as Error).message}`);
      return { ok: false, motivo: (e as Error).message };
    } finally {
      this.corriendo = false;
    }
  }

  private aplicar(lista: ProductoNube[], congelados: Set<string>) {
    const t = this.tenant.id;
    const now = ahora();
    let nuevos = 0, actualizados = 0, stockAjustado = 0, desactivados = 0;
    const vistos = new Set<string>();
    for (const p of lista) {
      const sku = String(p.sku ?? '').trim().slice(0, 40);
      if (!sku || !p.nombre) continue;
      const idNube = p.id ? String(p.id).slice(0, 64) : undefined;
      const nombre = String(p.nombre).slice(0, 120);
      const precio = Math.max(0, Math.round(Number(p.precio) || 0));
      const stockNube = Math.max(0, Math.round(Number(p.stock) || 0));
      const esEan = /^\d{8,14}$/.test(sku);

      // 1) Por id de la nube (estable). 2) Si aún no está enlazado, por SKU, salvo que ese producto de la
      //    caja ya pertenezca a OTRO producto de la nube.
      const porSku = this.productosRepo.obtenerPorCodigo(t, sku);
      let actual = idNube ? this.productosRepo.obtenerPorIdNube(t, idNube) : undefined;
      if (!actual && porSku) {
        const otro = idNube ? this.productosRepo.idNubeDe(t, porSku.id) : null;
        if (!otro || otro === idNube) actual = porSku;
      }
      // El SKU lo tiene otro producto de la caja (un duplicado viejo o uno al que le cambiaron el SKU en la nube):
      // se le libera el código y se desactiva; si sigue en la nube, su propio ciclo lo reactiva con su SKU.
      if (porSku && porSku.id !== actual?.id) {
        this.productosRepo.actualizar(t, porSku.id, {
          codigo: `${porSku.codigo}~${porSku.id.slice(0, 8)}`, codigoBarras: null, activo: false,
        }, now);
        desactivados++;
      }

      if (!actual) {
        const creado = this.productos.crear({
          codigo: sku, codigoBarras: esEan ? sku : undefined, nombre, precioVenta: precio,
          stockInicial: congelados.has(sku) ? 0 : stockNube,
        } as any);
        if (idNube) this.productosRepo.asignarIdNube(t, creado.id, idNube);
        vistos.add(creado.id);
        nuevos++;
        continue;
      }
      if (idNube && this.productosRepo.idNubeDe(t, actual.id) !== idNube) this.productosRepo.asignarIdNube(t, actual.id, idNube);
      vistos.add(actual.id);

      const cambios: Record<string, unknown> = {};
      if (actual.codigo !== sku) { cambios.codigo = sku; cambios.codigoBarras = esEan ? sku : null; }
      else if (!actual.codigoBarras && esEan) cambios.codigoBarras = sku;
      if (actual.nombre !== nombre) cambios.nombre = nombre;
      if (actual.precioVenta !== precio) cambios.precioVenta = precio;
      if (!actual.activo) cambios.activo = true;
      if (Object.keys(cambios).length) { this.productosRepo.actualizar(t, actual.id, cambios, now); actualizados++; }
      // Por el código antiguo y el nuevo: una venta pendiente pudo salir con cualquiera de los dos.
      if (!congelados.has(sku) && !congelados.has(actual.codigo) && actual.stock !== stockNube) {
        this.inventario.aplicar({
          tenantId: t, productoId: actual.id, tipo: TipoMovimiento.AJUSTE, motivo: MotivoMovimiento.AJUSTE_MANUAL,
          cantidad: stockNube, comentario: 'Stock sincronizado desde la nube',
        });
        stockAjustado++;
      }
    }

    // La caja vinculada vende el catálogo del panel: lo que se archivó o eliminó en la nube deja de venderse aquí.
    // Solo con una lista no vacía, para que una respuesta rara de la nube no apague todo el catálogo.
    if (vistos.size) {
      for (const id of this.productosRepo.idsActivos(t)) {
        if (!vistos.has(id)) { this.productosRepo.actualizar(t, id, { activo: false }, now); desactivados++; }
      }
    }
    return { nuevos, actualizados, stockAjustado, desactivados };
  }
}
