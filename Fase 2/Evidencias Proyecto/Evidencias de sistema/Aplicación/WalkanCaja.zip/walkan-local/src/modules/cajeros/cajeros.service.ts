// Lógica de cajeros: alta del primero, sync desde la nube y chequeo de PIN con bloqueo por intentos.
import {
  ForbiddenException, HttpException, HttpStatus, Inject, Injectable, NotFoundException, UnauthorizedException,
} from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { TenantContext } from '../../common/contexto/tenant.context';
import { OutboxService } from '../../common/sync/outbox.service';
import { transaccionInmediata } from '../../database/unit-of-work';
import { ahora, nuevoId } from '../../common/util/id';
import { CajerosRepository } from './cajeros.repository';
import { Cajero, CajeroPublico, aPublico } from './tipos/cajero';
import { CrearCajeroDto } from './dto/crear-cajero.dto';
import { hashPin, verificarPin } from './pin';

// Intentos de PIN: 5 fallos seguidos bloquean ese cajero (o el PIN de /red) 5 minutos. Un PIN de 4 dígitos
// son 10.000 combinaciones; sin tope se adivinaba en minutos.
const MAX_FALLOS_PIN = 5;
const BLOQUEO_PIN_MS = 5 * 60_000;

// Alta de cajeros y validación de PIN. El hash nunca sale de acá: hacia afuera
// (API y nube) siempre va el CajeroPublico.
@Injectable()
export class CajerosService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: CajerosRepository,
    private readonly outbox: OutboxService,
    private readonly tenant: TenantContext,
  ) {}

  // ponytail: en memoria; se reinicia con el servicio (igual frena el ataque, que es en línea).
  private readonly fallosPin = new Map<string, { n: number; hasta: number }>();
  // Tira 429 si esa clave (un cajero, o 'red') está bloqueada por demasiados fallos.
  private revisarPin(clave: string): void {
    const f = this.fallosPin.get(clave);
    if (f && f.hasta > Date.now()) {
      throw new HttpException(`Demasiados PIN incorrectos. Espera ${Math.ceil((f.hasta - Date.now()) / 60_000)} minuto(s).`, HttpStatus.TOO_MANY_REQUESTS);
    }
  }
  private resultadoPin(clave: string, ok: boolean): void {
    if (ok) { this.fallosPin.delete(clave); return; }
    const f = this.fallosPin.get(clave);
    const n = (f && f.hasta && f.hasta <= Date.now() ? 0 : f?.n ?? 0) + 1;
    this.fallosPin.set(clave, { n, hasta: n >= MAX_FALLOS_PIN ? Date.now() + BLOQUEO_PIN_MS : 0 });
  }

  crear(dto: CrearCajeroDto): CajeroPublico {
    const t = this.tenant.id;
    // Desde la caja solo se crea el PRIMER cajero (instalación). Después se administran en el panel web:
    // así nadie con acceso a la caja puede agregarse un cajero por su cuenta.
    if (this.repo.listar(t).length > 0) {
      throw new ForbiddenException('Los cajeros se administran desde el panel web (Mis cajas › Cajeros).');
    }
    const now = ahora();
    // hashPin (scrypt, lento) se calcula antes de tomar el lock de escritura.
    const cajero: Cajero = {
      id: nuevoId(), tenantId: t, nombre: dto.nombre, pinHash: hashPin(dto.pin),
      activo: true, createdAt: now, updatedAt: now,
    };
    transaccionInmediata(this.db, () => {
      this.repo.crear(cajero);
      // Se sincroniza sin el hash del PIN.
      this.outbox.encolar({
        tenantId: t, entidad: 'cajero', entidadId: cajero.id,
        operacion: 'INSERT', payload: aPublico(cajero),
      });
    })();
    return aPublico(cajero);
  }

  /**
   * Aplica la lista de cajeros de la nube (viene con el catálogo). Con lista vacía no hace nada: la nube aún no
   * administra cajeros y se respetan los creados en la caja. Con lista, la nube manda: crea o actualiza cada uno
   * (nombre, hash del PIN, activo) y desactiva los locales que no estén en ella.
   */
  sincronizarDesdeNube(lista: { id?: string; nombre?: string; pinHash?: string; activo?: boolean }[]) {
    const r = { nuevos: 0, actualizados: 0, desactivados: 0 };
    const validos = (lista || []).filter((c) => c && c.id && c.nombre && typeof c.pinHash === 'string' && c.pinHash.startsWith('scrypt$'));
    if (!validos.length) return r;
    const t = this.tenant.id;
    const now = ahora();
    const mantener: string[] = [];
    transaccionInmediata(this.db, () => {
      for (const c of validos) {
        const idNube = String(c.id).slice(0, 64);
        const d = { nombre: String(c.nombre).slice(0, 60), pinHash: String(c.pinHash), activo: c.activo !== false };
        const local = this.repo.idPorNube(t, idNube);
        if (local) {
          if (this.repo.actualizarDesdeNube(t, local, d, now)) r.actualizados++;
          if (d.activo) mantener.push(local);
          continue;
        }
        const cajero: Cajero = { id: nuevoId(), tenantId: t, nombre: d.nombre, pinHash: d.pinHash, activo: d.activo, createdAt: now, updatedAt: now };
        this.repo.crear(cajero);
        this.repo.enlazarNube(t, cajero.id, idNube);
        if (d.activo) mantener.push(cajero.id);
        r.nuevos++;
      }
      r.desactivados = this.repo.desactivarExcepto(t, mantener, now);
    })();
    return r;
  }

  /** true si el PIN es de algún cajero activo (o si aún no hay cajeros: caja recién instalada). */
  pinDeAlgunCajero(pin: string): boolean {
    const activos = this.repo.listar(this.tenant.id);
    if (!activos.length) return true;
    this.revisarPin('red');
    const ok = /^[0-9]{4,8}$/.test(pin) && activos.some((c) => verificarPin(pin, c.pinHash));
    this.resultadoPin('red', ok);
    return ok;
  }

  listar(): CajeroPublico[] {
    return this.repo.listar(this.tenant.id).map(aPublico);
  }

  /** Nombre del cajero (para etiquetar ventas al sincronizar). */
  nombreDe(cajeroId: string): string | null {
    return this.repo.obtenerPorId(this.tenant.id, cajeroId)?.nombre ?? null;
  }

  /** Valida cajero + PIN. Lanza 404 si no existe, 401 si el PIN no coincide. */
  obtenerValidado(cajeroId: string, pin: string): Cajero {
    const c = this.repo.obtenerPorId(this.tenant.id, cajeroId);
    if (!c || !c.activo) throw new NotFoundException('Cajero no encontrado o inactivo.');
    this.revisarPin(c.id);
    const ok = verificarPin(pin, c.pinHash);
    this.resultadoPin(c.id, ok);
    if (!ok) throw new UnauthorizedException('PIN incorrecto.');
    return c;
  }
}
