// Estados del despacho al SII. REINTENTAR = falló la red, se vuelve a probar;
// RECHAZADO = el SII dijo que no, y ahí se acaba (D-05).
export type EstadoDteCola =
  | 'PENDIENTE'
  | 'ENVIANDO'
  | 'ENVIADO'
  | 'ACEPTADO'
  | 'RECHAZADO'
  | 'REINTENTAR';

export interface DteColaItem {
  id: number;
  tenantId: string;
  dteEmitidoId: string;
  estado: EstadoDteCola;
  intentos: number;
  proximoIntento: string | null;
  ultimoError: string | null;
  createdAt: string;
  updatedAt: string;
}

/** Reintentos por número de intento: 1, 2, 5, 15, 60 min; luego 60 (tope). */
export const REINTENTOS_MIN = [1, 2, 5, 15, 60];

// Nunca se rinde: pasado el quinto intento queda probando cada 60 min para siempre.
export function esperaReintentoMs(intentos: number): number {
  const idx = Math.min(Math.max(intentos, 1), REINTENTOS_MIN.length) - 1;
  return REINTENTOS_MIN[idx] * 60_000;
}
