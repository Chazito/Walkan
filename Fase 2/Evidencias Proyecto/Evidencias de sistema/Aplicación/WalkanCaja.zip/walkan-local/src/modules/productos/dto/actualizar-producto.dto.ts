// Body para editar un producto: todo opcional, solo se toca lo que venga. El stock no se edita acá.
import { IsBoolean, IsInt, IsOptional, IsString, Length, Min } from 'class-validator';

export class ActualizarProductoDto {
  @IsOptional() @IsString() @Length(1, 40) codigo?: string;
  @IsOptional() @IsString() @Length(1, 60) codigoBarras?: string;
  @IsOptional() @IsString() @Length(1, 120) nombre?: string;
  @IsOptional() @IsString() descripcion?: string;
  @IsOptional() @IsInt() @Min(0) precioVenta?: number;
  @IsOptional() @IsString() @Length(1, 8) unidad?: string;
  @IsOptional() @IsInt() @Min(0) stockMinimo?: number;
  @IsOptional() @IsBoolean() exento?: boolean;
  @IsOptional() @IsBoolean() activo?: boolean;
}
