// Módulo de pagos: periféricos de la caja (tarjetas, cajón), cobro QR y ajustes del negocio.
import { Global, Module } from '@nestjs/common';
import { PagosController } from './pagos.controller';
import { PerifericosService } from './perifericos.service';
import { AjustesService } from './ajustes.service';
import { CobroQrService } from './cobro-qr.service';

// Global: AjustesService lo usa la sincronización del catálogo para guardar los datos del negocio.
@Global()
@Module({
  controllers: [PagosController],
  providers: [PerifericosService, AjustesService, CobroQrService],
  exports: [PerifericosService, AjustesService],
})
export class PagosModule {}
