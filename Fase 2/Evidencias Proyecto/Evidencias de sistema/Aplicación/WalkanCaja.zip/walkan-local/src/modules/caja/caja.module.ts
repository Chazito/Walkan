// Módulo de caja (apertura y cierre de turno del cajero).
import { Module } from '@nestjs/common';
import { CajaController } from './caja.controller';
import { CajaService } from './caja.service';
import { CajaRepository } from './caja.repository';
import { CajerosModule } from '../cajeros/cajeros.module';

// Necesita CajerosModule para validar el PIN al abrir; exporta el service a Ventas.
@Module({
  imports: [CajerosModule],
  controllers: [CajaController],
  providers: [CajaService, CajaRepository],
  exports: [CajaService],
})
export class CajaModule {}
