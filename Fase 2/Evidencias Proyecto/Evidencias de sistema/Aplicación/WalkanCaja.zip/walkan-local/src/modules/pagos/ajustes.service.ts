// Guarda y lee ajustes sueltos (clave → JSON), como los datos del negocio que baja la nube.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ahora } from '../../common/util/id';

export interface DatosNegocio {
  nombre: string; rut: string;
  transferencia: { banco: string; tipoCuenta: string; numero: string; titular: string; rut: string; email: string } | null;
}

/** Ajustes clave → JSON que manda la nube (tabla ajustes). Sin nube, la caja sigue con lo último guardado. */
@Injectable()
export class AjustesService {
  constructor(@Inject(SQLITE) private readonly db: Database.Database) {}

  guardar(clave: string, valor: unknown): void {
    this.db.prepare(`INSERT INTO ajustes (clave, valor, updated_at) VALUES (?, ?, ?)
      ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor, updated_at=excluded.updated_at`).run(clave, JSON.stringify(valor), ahora());
  }

  leer<T>(clave: string): T | null {
    const r = this.db.prepare('SELECT valor FROM ajustes WHERE clave=?').get(clave) as { valor: string } | undefined;
    try { return r ? (JSON.parse(r.valor) as T) : null; } catch { return null; }
  }

  negocio(): DatosNegocio {
    return this.leer<DatosNegocio>('negocio') ?? { nombre: '', rut: '', transferencia: null };
  }
}
