import { IsString, Length, Matches } from 'class-validator';

// Alta de cajero: nombre y PIN en claro (se hashea al tiro en el service).
export class CrearCajeroDto {
  @IsString() @Length(1, 60) nombre: string;
  /** PIN numérico de 4 a 8 dígitos. */
  @Matches(/^[0-9]{4,8}$/, { message: 'El PIN debe tener entre 4 y 8 dígitos.' })
  pin: string;
}
