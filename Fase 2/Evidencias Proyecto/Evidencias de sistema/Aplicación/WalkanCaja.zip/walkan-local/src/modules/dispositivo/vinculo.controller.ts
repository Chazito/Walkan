import { Body, Controller, Get, Post } from '@nestjs/common';
import { DispositivoService } from './dispositivo.service';
import { RegistrarDispositivoDto } from './dto/registrar-dispositivo.dto';

// Vínculo de la caja con la nube. Accesible aunque la caja esté bloqueada
// (para que la UI pueda mostrar el estado y el candado).
@Controller('vinculo')
export class VinculoController {
  constructor(private readonly srv: DispositivoService) {}

  @Get('estado')
  estado() {
    return this.srv.estado();
  }

  @Post('registrar')
  registrar(@Body() dto: RegistrarDispositivoDto) {
    return this.srv.registrar(dto);
  }
}
