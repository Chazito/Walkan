import { IsEmail, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

// Credenciales de la cuenta web para vincular la caja; la contraseña no se guarda.
export class RegistrarDispositivoDto {
  @IsEmail() email!: string;
  @IsString() @MinLength(1) password!: string;
  @IsOptional() @IsString() @MaxLength(40) nombre?: string;
}
