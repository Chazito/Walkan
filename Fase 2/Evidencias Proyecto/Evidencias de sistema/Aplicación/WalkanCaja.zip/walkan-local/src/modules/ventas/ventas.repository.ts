// SQL de las tablas ventas y venta_items.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { Venta, VentaItem } from './tipos/venta';

type Fila = Record<string, any>;

@Injectable()
export class VentasRepository {
  private readonly _insert: Database.Statement;
  private readonly _insertItem: Database.Statement;
  private readonly _list: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._insert = db.prepare(
      `INSERT INTO ventas
         (id, tenant_id, caja_sesion_id, dte_emitido_id, tipo_dte, medio_pago, neto, iva, exento, total, created_at)
       VALUES (@id, @tenantId, @cajaSesionId, @dteEmitidoId, @tipoDte, @medioPago, @neto, @iva, @exento, @total, @createdAt)`,
    );
    this._insertItem = db.prepare(
      `INSERT INTO venta_items
         (tenant_id, venta_id, producto_id, codigo_leido, descripcion, cantidad, precio_unitario, exento, total_linea)
       VALUES (@tenantId, @ventaId, @productoId, @codigoLeido, @descripcion, @cantidad, @precioUnitario, @exento, @totalLinea)`,
    );
    this._list = db.prepare(
      'SELECT * FROM ventas WHERE tenant_id=? ORDER BY created_at DESC LIMIT ?',
    );
  }

  insertar(v: Venta): void {
    this._insert.run(v);
  }
  insertarItem(i: VentaItem): void {
    this._insertItem.run({ codigoLeido: null, ...i, exento: i.exento ? 1 : 0 });
  }
  listar(tenantId: string, limit: number): Venta[] {
    return (this._list.all(tenantId, limit) as Fila[]).map((r) => ({
      id: r.id, tenantId: r.tenant_id, cajaSesionId: r.caja_sesion_id, dteEmitidoId: r.dte_emitido_id,
      tipoDte: r.tipo_dte, medioPago: r.medio_pago, neto: r.neto, iva: r.iva, exento: r.exento,
      total: r.total, createdAt: r.created_at,
    }));
  }
}
