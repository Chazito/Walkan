// Lee y guarda el vínculo de esta caja con la nube (token, nombre, bloqueo).
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ahora } from '../../common/util/id';

export interface Vinculo {
  cajaId: string | null;
  token: string | null;
  nombre: string | null;
  nubeUrl: string | null;
  bloqueada: boolean;
  vinculadaAt: string | null;
}

type Fila = Record<string, any>;

// La tabla dispositivo tiene UNA sola fila (id=1, la crea la migración 002):
// por eso todo es UPDATE ... WHERE id=1 y nunca INSERT.
@Injectable()
export class DispositivoRepository {
  private readonly _get: Database.Statement;
  private readonly _setVinculo: Database.Statement;
  private readonly _setBloqueada: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._get = db.prepare('SELECT * FROM dispositivo WHERE id=1');
    this._setVinculo = db.prepare(
      `UPDATE dispositivo
         SET caja_id=@cajaId, token=@token, nombre=@nombre, nube_url=@nubeUrl,
             bloqueada=0, vinculada_at=@now, updated_at=@now
       WHERE id=1`,
    );
    this._setBloqueada = db.prepare('UPDATE dispositivo SET bloqueada=@b, updated_at=@now WHERE id=1');
  }

  // Si por algún motivo no estuviera la fila, devuelve todo en null en vez de reventar.
  leer(): Vinculo {
    const r = (this._get.get() as Fila) || {};
    return {
      cajaId: r.caja_id ?? null,
      token: r.token ?? null,
      nombre: r.nombre ?? null,
      nubeUrl: r.nube_url ?? null,
      bloqueada: !!r.bloqueada,
      vinculadaAt: r.vinculada_at ?? null,
    };
  }

  // Vincular de nuevo limpia el bloqueo (bloqueada=0 en el SQL).
  guardarVinculo(v: { cajaId: string; token: string; nombre: string; nubeUrl: string }): void {
    this._setVinculo.run({ ...v, now: ahora() });
  }

  setBloqueada(bloqueada: boolean): void {
    this._setBloqueada.run({ b: bloqueada ? 1 : 0, now: ahora() });
  }
}
