// Worker que va sacando la cola de DTE y los manda al SII, con reintentos si no hay internet.
import { Inject, Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../../database/sqlite.provider';
import { OutboxService } from '../../../common/sync/outbox.service';
import { CONFIG } from '../../../common/config.provider';
import { AppConfig } from '../../../config/configuracion';
import { transaccionInmediata } from '../../../database/unit-of-work';
import { ahora } from '../../../common/util/id';
import { DteRepository } from './dte.repository';
import { SII_CLIENT, SiiClient } from '../sii/sii-client.interface';
import { DteColaItem, esperaReintentoMs } from '../tipos/cola';

/**
 * Procesa la cola de envío al SII. Corre en intervalo. NUNCA mantiene una
 * transacción de escritura abierta durante el await de red: leer → marcar
 * ENVIANDO → red → escribir resultado. Así no bloquea al único escritor (la caja).
 *
 * Sin internet por horas es lo normal, no la excepción: los fallos de red se
 * reintentan para siempre (D-05); solo un rechazo del SII cierra el caso.
 */
@Injectable()
export class DteDispatcherService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger('DteDispatcher');
  private readonly lote = 10;
  // Un ENVIANDO más viejo que esto se da por colgado (el proceso murió a medio
  // envío) y se vuelve a tomar (D-14).
  private readonly staleMs = 120_000;
  private timer?: NodeJS.Timeout;
  private procesando = false;

  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: DteRepository,
    private readonly outbox: OutboxService,
    @Inject(SII_CLIENT) private readonly sii: SiiClient,
    @Inject(CONFIG) private readonly cfg: AppConfig,
  ) {}

  // setInterval a mano y no @Interval para poder ajustar el intervalo por .env (D-14).
  // unref: el timer no mantiene vivo el proceso si Nest se está apagando.
  onModuleInit(): void {
    this.timer = setInterval(() => void this.procesarCola(), this.cfg.intervaloDteMs);
    this.timer.unref?.();
  }
  onModuleDestroy(): void {
    if (this.timer) clearInterval(this.timer);
  }

  async procesarCola(): Promise<void> {
    // Si la vuelta anterior sigue esperando al SII, esta se salta (no se encaballan).
    if (this.procesando) return;
    this.procesando = true;
    try {
      const pendientes = this.repo.pickCola(ahora(), this.staleMs, this.lote);
      if (!pendientes.length) return;

      // Marca todo el lote como ENVIANDO en un tx cortito y suelta el lock al tiro.
      transaccionInmediata(this.db, () => {
        const now = ahora();
        for (const c of pendientes) this.repo.actualizarCola(c.id, { estado: 'ENVIANDO' }, now);
      })();

      // De a uno y en orden; acá ya no hay ningún tx abierto mientras se espera la red.
      for (const c of pendientes) {
        const dte = this.repo.obtenerDte(c.tenantId, c.dteEmitidoId);
        if (dte) await this.procesarUno(c, dte);
      }
    } finally {
      this.procesando = false;
    }
  }

  private async procesarUno(c: DteColaItem, dte: import('../tipos/dte').DteEmitido): Promise<void> {
    try {
      const r = await this.sii.enviar(dte);
      const now = ahora();
      // Veredicto del SII: cola + documento + outbox en el mismo tx. El payload
      // del outbox es parcial a propósito (solo lo que cambió del DTE).
      transaccionInmediata(this.db, () => {
        if (r.aceptado) {
          this.repo.actualizarCola(c.id, { estado: 'ACEPTADO', proximoIntento: null, ultimoError: null }, now);
          this.repo.actualizarEstadoSii(dte.tenantId, dte.id, 'ACEPTADO', r.trackId ?? null, now);
          this.outbox.encolar({
            tenantId: dte.tenantId, entidad: 'dte_emitido', entidadId: dte.id, operacion: 'UPDATE',
            payload: { id: dte.id, tenantId: dte.tenantId, estadoSii: 'ACEPTADO', trackId: r.trackId ?? null, updatedAt: now },
          });
        } else {
          this.repo.actualizarCola(c.id, { estado: 'RECHAZADO', proximoIntento: null, ultimoError: r.motivoRechazo ?? 'Rechazado por el SII.' }, now);
          this.repo.actualizarEstadoSii(dte.tenantId, dte.id, 'RECHAZADO', null, now);
          this.outbox.encolar({
            tenantId: dte.tenantId, entidad: 'dte_emitido', entidadId: dte.id, operacion: 'UPDATE',
            payload: { id: dte.id, tenantId: dte.tenantId, estadoSii: 'RECHAZADO', updatedAt: now },
          });
          this.logger.warn(`DTE ${dte.id} folio ${dte.folio} RECHAZADO por el SII: ${r.motivoRechazo ?? ''}`);
        }
      })();
    } catch (e) {
      // Excepción = problema de transporte (contrato de SiiClient). No se
      // toca el DTE, solo se reagenda en la cola.
      const now = ahora();
      const intentos = c.intentos + 1;
      const espera = esperaReintentoMs(intentos);
      const prox = new Date(Date.now() + espera).toISOString();
      transaccionInmediata(this.db, () => {
        this.repo.actualizarCola(c.id, { estado: 'REINTENTAR', intentos, proximoIntento: prox, ultimoError: (e as Error).message }, now);
      })();
      this.logger.warn(`DTE folio ${dte.folio}: reintento ${intentos} en ${espera / 60000} min (${(e as Error).message})`);
    }
  }
}
