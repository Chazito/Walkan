import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { DispositivoService } from '../dispositivo/dispositivo.service';

/**
 * Cobro con QR de Flow (opcional, si el negocio conectó Flow en el panel). La caja no tiene las llaves de Flow:
 * le pide a la nube (con su token) que cree el cobro y después consulta el estado. Requiere internet; sin conexión,
 * la pantalla vuelve a los datos de transferencia.
 */
@Injectable()
export class CobroQrService {
  constructor(private readonly dispositivo: DispositivoService) {}

  private async nube(metodo: 'GET' | 'POST', ruta: string, cuerpo?: unknown) {
    const v = this.dispositivo.vinculo();
    if (!v.token || !v.nubeUrl) throw new BadRequestException('La caja no está vinculada a la nube.');
    let r: Response;
    try {
      r = await fetch(`${v.nubeUrl}/api/caja/cobro-qr${ruta}`, {
        method: metodo, signal: AbortSignal.timeout(20_000),
        headers: { 'X-Caja-Token': v.token, ...(cuerpo ? { 'Content-Type': 'application/json' } : {}) },
        body: cuerpo ? JSON.stringify(cuerpo) : undefined,
      });
    } catch {
      throw new BadGatewayException('Sin conexión con la nube: usa los datos de transferencia.');
    }
    const data: any = await r.json().catch(() => ({}));
    if (!r.ok) throw new BadRequestException(Array.isArray(data?.message) ? data.message[0] : data?.message || `Error ${r.status}`);
    return data;
  }

  crear(monto: number) { return this.nube('POST', '', { monto }); }
  estado(id: string) { return this.nube('GET', '/' + encodeURIComponent(id)); }
  anular(id: string) { return this.nube('POST', '/' + encodeURIComponent(id) + '/anular'); }
}
