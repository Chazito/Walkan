// Módulo de inventario (stock y movimientos). Ventas lo usa para descontar al vender.
import { Module } from '@nestjs/common';
import { InventarioController } from './inventario.controller';
import { InventarioService } from './inventario.service';
import { InventarioRepository } from './inventario.repository';

@Module({
  controllers: [InventarioController],
  providers: [InventarioService, InventarioRepository],
  exports: [InventarioService],
})
export class InventarioModule {}
