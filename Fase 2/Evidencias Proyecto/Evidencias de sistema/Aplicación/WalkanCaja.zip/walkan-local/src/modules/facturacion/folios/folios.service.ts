// Reserva el siguiente folio de un CAF al vender y deja registro de cuál se usó.
import { ConflictException, Inject, Injectable, Logger } from '@nestjs/common';
import { CafRepository } from '../caf/caf.repository';
import { FoliosRepository, UsoFolio } from './folios.repository';
import { TenantContext } from '../../../common/contexto/tenant.context';
import { CONFIG } from '../../../common/config.provider';
import { AppConfig } from '../../../config/configuracion';
import { ahora, nuevoId } from '../../../common/util/id';

export interface FolioReservado {
  folio: number;
  cafId: string;
}

/**
 * Asignación de folios CAF. Pensada para correr DENTRO del tx de la venta.
 * Garantía: un solo escritor (SQLite) + CAS sobre el puntero del CAF + UNIQUE
 * en folios_usados. Si el tx hace ROLLBACK, el folio vuelve (no se salta).
 *
 * Por qué tanto cuidado: el SII exige correlatividad. Un folio repetido o un
 * hoyo en la numeración es un problema tributario, no un bug cosmético. Y no
 * hay rango "infinito" de demo acá: si se acaban los CAF, no se vende (D-04).
 */
@Injectable()
export class FoliosService {
  private readonly logger = new Logger('Folios');

  constructor(
    private readonly caf: CafRepository,
    private readonly folios: FoliosRepository,
    private readonly tenant: TenantContext,
    @Inject(CONFIG) private readonly cfg: AppConfig,
  ) {}

  /** Reserva el siguiente folio del tipo (avanza el puntero). NO registra el uso
   *  todavía (eso se hace tras crear el DTE y la venta, por las FKs). */
  reservarEnTx(tenantId: string, tipoDte: string): FolioReservado {
    let caf = this.caf.obtenerActivo(tenantId, tipoDte);
    // Emisión simulada (sin SII): si la caja nunca tuvo un rango de numeración, se crea
    // uno propio automáticamente para que pueda vender desde el primer día.
    if (!caf && !this.caf.obtenerPendiente(tenantId, tipoDte) && !this.caf.tieneAlguno(tenantId, tipoDte)) {
      const now = ahora();
      this.caf.crear({
        id: nuevoId(), tenantId, tipoDte: tipoDte as any, folioDesde: 1, folioHasta: 9_999_999,
        folioSiguiente: 1, activo: true, xml: null, fechaCarga: now, createdAt: now, updatedAt: now,
      });
      this.logger.log(`Rango de numeración creado automáticamente para el tipo ${tipoDte} (emisión simulada).`);
      caf = this.caf.obtenerActivo(tenantId, tipoDte);
    }
    if (!caf) {
      // ¿hay un CAF pendiente que activar? Pasa justo cuando el anterior se
      // agotó en la venta pasada: el siguiente CAF entra solo, sin intervención.
      const pend = this.caf.obtenerPendiente(tenantId, tipoDte);
      if (pend && this.caf.activar(pend.id, ahora()) === 1) caf = { ...pend, activo: true };
    }
    if (!caf || caf.folioSiguiente > caf.folioHasta) {
      throw new ConflictException(
        'No quedan números de comprobante disponibles. Avisa al administrador.',
      );
    }

    const folio = caf.folioSiguiente;
    const cambios = this.caf.avanzarPuntero(caf.id, folio, ahora());
    // Con un solo escritor esto no debería pasar nunca; si pasa, algo raro hay
    // y es mejor botar la venta entera que emitir con un folio dudoso.
    if (cambios !== 1) {
      throw new ConflictException('Conflicto al asignar folio; reintenta la venta.');
    }

    // Ojo que solo mira el CAF activo, no suma los pendientes del mismo tipo:
    // puede avisar aunque haya otro CAF cargado esperando.
    const restantes = caf.folioHasta - folio;
    if (restantes < this.cfg.folioAlerta) {
      this.logger.warn(
        `Folios bajos para tipo ${tipoDte}: quedan ${restantes} en el CAF ${caf.id}. Solicita un CAF nuevo al SII.`,
      );
    }
    return { folio, cafId: caf.id };
  }

  /** Registra el folio consumido (UNIQUE(caf_id, folio) blinda el no-duplicado). */
  registrarUsoEnTx(u: Omit<UsoFolio, 'createdAt'>): void {
    this.folios.registrarUso({ ...u, createdAt: ahora() });
  }
}
