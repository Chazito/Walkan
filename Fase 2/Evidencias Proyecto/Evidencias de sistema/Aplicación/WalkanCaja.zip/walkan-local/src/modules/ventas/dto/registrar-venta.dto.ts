// Validación de lo que manda la pantalla de venta: items, medio de pago, receptor y pedido de correo.
import { Type } from 'class-transformer';
import {
  ArrayMaxSize, ArrayMinSize, IsBoolean, IsEmail, IsIn, IsInt, IsOptional, IsString, Matches, Max, MaxLength, Min, ValidateNested,
} from 'class-validator';
import { TipoDte } from '../../facturacion/tipos/tipo-dte';

const MEDIOS = ['EFECTIVO', 'TARJETA', 'TRANSFERENCIA'];
const TIPOS = Object.values(TipoDte);

// Línea normal: productoId. Línea genérica (C1, código que no está en el catálogo): codigo + descripcion + precio, sin
// productoId. Una de las dos formas es obligatoria (lo revisa VentasService).
export class ItemVentaDto {
  @IsOptional() @IsString() @MaxLength(64) productoId?: string;
  @IsOptional() @IsString() @Matches(/^[^\s<>]{1,40}$/, { message: 'Código inválido (sin espacios, máx. 40).' }) codigo?: string;
  @IsOptional() @IsString() @MaxLength(80) descripcion?: string;
  // Tope por unidad: un precio genérico absurdo es un error de digitación (o un abuso) y queda en la bandeja del dueño igual.
  @IsOptional() @IsInt() @Min(1) @Max(5_000_000) precio?: number;
  // Tope sano: una línea con millones de unidades es un error de digitación o un abuso.
  @IsInt() @Min(1) @Max(100000) cantidad: number;
}

/** Detalle del pago (autorización de la máquina de tarjetas, o efectivo recibido y vuelto). Viaja al panel. */
export class DetallePagoDto {
  @IsOptional() @IsString() @MaxLength(20) autorizacion?: string;
  @IsOptional() @IsString() @MaxLength(20) tarjeta?: string;
  @IsOptional() @IsString() @MaxLength(30) terminal?: string;
  @IsOptional() @IsInt() @Min(0) recibido?: number;
  @IsOptional() @IsInt() @Min(0) vuelto?: number;
  @IsOptional() @IsBoolean() simulado?: boolean;
}

/** Pedido de enviar el comprobante de una venta por correo (lo envía la nube al sincronizar). */
export class CorreoComprobanteDto {
  @IsInt() @Min(1) folio: number;
  @IsEmail({}, { message: 'Correo no válido.' }) @MaxLength(120) email: string;
}

export class RegistrarVentaDto {
  @IsIn(MEDIOS) medioPago: string;
  @IsOptional() @ValidateNested() @Type(() => DetallePagoDto) pago?: DetallePagoDto;
  @IsOptional() @IsIn(TIPOS) tipoDte?: string;
  @IsOptional() @IsString() @Matches(/^[\d.]{1,12}-[\dkK]$/, { message: 'RUT no válido (formato 12.345.678-9).' }) rutReceptor?: string;
  @IsOptional() @IsString() @MaxLength(100) razonReceptor?: string;
  @ValidateNested({ each: true }) @ArrayMinSize(1) @ArrayMaxSize(500) @Type(() => ItemVentaDto)
  items: ItemVentaDto[];
}
