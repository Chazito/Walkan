// Maneja la conexión a internet de la caja llamando a nmcli (NetworkManager) y a ip.
import { BadRequestException, Injectable, Logger, ServiceUnavailableException } from '@nestjs/common';
import { execFile } from 'child_process';
import { readFileSync } from 'fs';
import { DispositivoService } from '../dispositivo/dispositivo.service';

export interface Interfaz { dispositivo: string; tipo: string; estado: string; conexion: string; ip: string | null }
export interface RedWifi { ssid: string; senal: number; segura: boolean; enUso: boolean }

/**
 * Conexión a internet de la caja (pantalla "Red" del kiosco). Usa NetworkManager (nmcli): cable, Wi-Fi por
 * adaptador USB y anclaje USB del celular. El usuario `walkan` necesita permiso de NetworkManager por polkit
 * (deploy/50-walkan-red.rules). Sin NetworkManager instalado, el estado igual informa si se llega a la nube.
 */
@Injectable()
export class RedService {
  private readonly logger = new Logger('Red');
  constructor(private readonly dispositivo: DispositivoService) {}

  private nmcli(args: string[], timeoutMs = 15_000): Promise<string> {
    return new Promise((resolve, reject) => {
      execFile('nmcli', args, { timeout: timeoutMs, env: { ...process.env, LC_ALL: 'C' } }, (err, stdout, stderr) => {
        if (err) {
          if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
            return reject(new ServiceUnavailableException('NetworkManager no está instalado en esta caja.'));
          }
          const msg = String(stderr || err.message).replace(/^Error:\s*/i, '').trim();
          return reject(new BadRequestException(traducir(msg)));
        }
        resolve(stdout);
      });
    });
  }

  /** Interfaces (cable, Wi-Fi, celular), su IP y si la caja llega a la nube. */
  async estado() {
    let interfaces: Interfaz[] = [];
    let nm = true;
    try {
      const salida = await this.nmcli(['-t', '-f', 'DEVICE,TYPE,STATE,CONNECTION', 'device', 'status']);
      const filas = salida.split('\n').filter(Boolean).map(campos)
        .filter(([dev, tipo]) => ['ethernet', 'wifi', 'gsm'].includes(tipo) && !dev.startsWith('zt'));
      for (const [dev, tipo, estado, conexion] of filas) {
        let ip: string | null = null;
        if (estado.startsWith('connected')) {
          ip = (await this.nmcli(['-g', 'IP4.ADDRESS', 'device', 'show', dev]).catch(() => '')).split(/[|\n]/)[0].trim() || null;
        } else if (estado === 'unmanaged' && conCable(dev)) {
          ip = await ipDe(dev); // el cable lo maneja el sistema (ifupdown), no NetworkManager
        }
        const conectado = estado.startsWith('connected') || (estado === 'unmanaged' && !!ip);
        interfaces.push({ dispositivo: dev, tipo: tipoLegible(dev, tipo), estado: conectado ? 'conectado' : estado.startsWith('unavailable') ? 'sin señal / desconectado' : 'desconectado', conexion: conexion || (conectado ? dev : ''), ip });
      }
    } catch (e) {
      if (e instanceof ServiceUnavailableException) nm = false; else throw e;
    }
    const nube = await this.llegaANube();
    return { networkManager: nm, interfaces, wifiDisponible: interfaces.some((i) => i.tipo === 'Wi-Fi'), nube };
  }

  private async llegaANube(): Promise<boolean> {
    const url = this.dispositivo.vinculo().nubeUrl;
    if (!url) return false;
    try {
      const r = await fetch(url, { method: 'HEAD', signal: AbortSignal.timeout(5_000) });
      return r.status < 500;
    } catch { return false; }
  }

  /** Redes Wi-Fi cercanas (una por nombre, la de mejor señal), ordenadas por señal. */
  async redes(): Promise<RedWifi[]> {
    const salida = await this.nmcli(['-t', '-f', 'IN-USE,SSID,SIGNAL,SECURITY', 'device', 'wifi', 'list', '--rescan', 'yes'], 25_000);
    const porNombre = new Map<string, RedWifi>();
    for (const [uso, ssid, senal, seguridad] of salida.split('\n').filter(Boolean).map(campos)) {
      if (!ssid) continue; // redes ocultas
      const r: RedWifi = { ssid, senal: Number(senal) || 0, segura: !!seguridad && seguridad !== '--', enUso: uso === '*' };
      const prev = porNombre.get(ssid);
      if (!prev || r.senal > prev.senal || r.enUso) porNombre.set(ssid, { ...r, enUso: r.enUso || !!prev?.enUso });
    }
    return [...porNombre.values()].sort((a, b) => Number(b.enUso) - Number(a.enUso) || b.senal - a.senal);
  }

  /** Conecta a una red Wi-Fi; NetworkManager la recuerda y se reconecta sola en los próximos arranques. */
  async conectar(ssid: string, clave?: string) {
    const s = String(ssid ?? '').trim();
    if (!s || s.length > 64) throw new BadRequestException('Elige una red Wi-Fi.');
    const args = ['device', 'wifi', 'connect', s];
    if (clave) {
      if (clave.length < 8 || clave.length > 63) throw new BadRequestException('La clave Wi-Fi debe tener entre 8 y 63 caracteres.');
      args.push('password', clave);
    }
    await this.nmcli(args, 45_000);
    this.logger.log(`Conectada a la red Wi-Fi "${s}".`);
    return this.estado();
  }

  /** Olvida una red guardada (por ejemplo, si cambió la clave). */
  async olvidar(ssid: string) {
    const s = String(ssid ?? '').trim();
    if (!s) throw new BadRequestException('Indica la red a olvidar.');
    await this.nmcli(['connection', 'delete', 'id', s]);
    return { ok: true };
  }
}

/** Separa una línea de `nmcli -t` (campos con ':' y escapes '\:'). */
function campos(linea: string): string[] {
  const out: string[] = []; let cur = '';
  for (let i = 0; i < linea.length; i++) {
    const c = linea[i];
    if (c === '\\' && i + 1 < linea.length) { cur += linea[++i]; continue; }
    if (c === ':') { out.push(cur); cur = ''; continue; }
    cur += c;
  }
  out.push(cur);
  return out;
}

function tipoLegible(dev: string, tipo: string): string {
  if (tipo === 'wifi') return 'Wi-Fi';
  if (tipo === 'gsm') return 'Módem móvil';
  if (/^(usb|enx|rndis)/.test(dev)) return 'Celular (USB)';
  return 'Cable';
}

function traducir(msg: string): string {
  if (/secrets were required|802-1x|psk|password/i.test(msg)) return 'Clave Wi-Fi incorrecta o la red pide otro tipo de acceso.';
  if (/No network with SSID/i.test(msg)) return 'No se encontró esa red. Acércate o vuelve a buscar.';
  if (/not authorized|Insufficient privileges/i.test(msg)) return 'La caja no tiene permiso para cambiar la red (falta la regla de polkit).';
  if (/No Wi-Fi device|no wifi device/i.test(msg)) return 'No hay adaptador Wi-Fi conectado.';
  if (/timeout|Timeout/i.test(msg)) return 'La red no respondió a tiempo. Intenta de nuevo.';
  return msg || 'No se pudo completar la operación de red.';
}

/** true si la interfaz tiene enlace físico (cable enchufado). Sin cable, la IP puede seguir asignada. */
function conCable(dev: string): boolean {
  try { return readFileSync(`/sys/class/net/${dev}/carrier`, 'utf8').trim() === '1'; } catch { return false; }
}

/** IPv4 de una interfaz con `ip` (para las que NetworkManager no administra). */
function ipDe(dev: string): Promise<string | null> {
  return new Promise((resolve) => {
    execFile('ip', ['-4', '-o', 'addr', 'show', 'dev', dev], { timeout: 5_000 }, (err, out) => {
      if (err) return resolve(null);
      const m = /inet\s+(\S+)/.exec(out);
      resolve(m ? m[1] : null);
    });
  });
}
