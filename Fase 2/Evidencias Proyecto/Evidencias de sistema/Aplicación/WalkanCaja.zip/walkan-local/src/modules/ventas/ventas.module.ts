// Módulo de ventas: junta caja, productos, inventario y facturación, porque una venta toca todo eso.
import { Module } from '@nestjs/common';
import { VentasController } from './ventas.controller';
import { VentasService } from './ventas.service';
import { VentasRepository } from './ventas.repository';
import { CajaModule } from '../caja/caja.module';
import { CajerosModule } from '../cajeros/cajeros.module';
import { ProductosModule } from '../productos/productos.module';
import { InventarioModule } from '../inventario/inventario.module';
import { FacturacionModule } from '../facturacion/facturacion.module';

@Module({
  imports: [CajaModule, CajerosModule, ProductosModule, InventarioModule, FacturacionModule],
  controllers: [VentasController],
  providers: [VentasService, VentasRepository],
  exports: [VentasService],
})
export class VentasModule {}
