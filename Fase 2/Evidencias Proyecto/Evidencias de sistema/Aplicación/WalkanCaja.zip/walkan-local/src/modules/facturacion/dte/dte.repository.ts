// SQL de los DTE emitidos y de su cola de envío al SII.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../../database/sqlite.provider';
import { DteEmitido, EstadoSii } from '../tipos/dte';
import { DteColaItem } from '../tipos/cola';

type Fila = Record<string, any>;

// Dos tablas en un repo: dte_emitidos (el documento, permanente) y dte_cola
// (el trámite de envío al SII, transitorio). Ver D-08.
@Injectable()
export class DteRepository {
  private readonly _insertDte: Database.Statement;
  private readonly _getDte: Database.Statement;
  private readonly _listDte: Database.Statement;
  private readonly _estadoSii: Database.Statement;
  private readonly _insertCola: Database.Statement;
  private readonly _pickCola: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._insertDte = db.prepare(
      `INSERT INTO dte_emitidos
         (id, tenant_id, venta_id, tipo_dte, folio, caf_id, rut_receptor, razon_receptor,
          neto, iva, exento, total, fecha_emision, items_json, xml, track_id, estado_sii, created_at, updated_at)
       VALUES (@id, @tenantId, @ventaId, @tipoDte, @folio, @cafId, @rutReceptor, @razonReceptor,
          @neto, @iva, @exento, @total, @fechaEmision, @itemsJson, @xml, @trackId, @estadoSii, @createdAt, @updatedAt)`,
    );
    this._getDte = db.prepare('SELECT * FROM dte_emitidos WHERE tenant_id=? AND id=?');
    this._listDte = db.prepare(
      'SELECT * FROM dte_emitidos WHERE tenant_id=? ORDER BY created_at DESC LIMIT ?',
    );
    this._estadoSii = db.prepare(
      `UPDATE dte_emitidos
          SET estado_sii=@estadoSii, track_id=@trackId, updated_at=@now
        WHERE tenant_id=@t AND id=@id`,
    );
    this._insertCola = db.prepare(
      `INSERT INTO dte_cola (tenant_id, dte_emitido_id, estado, intentos, created_at, updated_at)
       VALUES (@tenantId, @dteEmitidoId, 'PENDIENTE', 0, @now, @now)`,
    );
    // PENDIENTE, REINTENTAR vencidos, o ENVIANDO colgados (recuperación tras caída).
    this._pickCola = db.prepare(
      `SELECT * FROM dte_cola
        WHERE estado='PENDIENTE'
           OR (estado='REINTENTAR' AND proximo_intento<=@now)
           OR (estado='ENVIANDO'  AND updated_at<=@stale)
        ORDER BY id ASC LIMIT @lim`,
    );
  }

  insertarDte(dte: DteEmitido): void {
    this._insertDte.run({
      ...dte,
      itemsJson: JSON.stringify(dte.items),
    });
  }

  obtenerDte(tenantId: string, id: string): DteEmitido | undefined {
    const r = this._getDte.get(tenantId, id) as Fila | undefined;
    return r ? mapearDte(r) : undefined;
  }

  listarDte(tenantId: string, limit: number): DteEmitido[] {
    return (this._listDte.all(tenantId, limit) as Fila[]).map(mapearDte);
  }

  actualizarEstadoSii(
    tenantId: string, id: string, estadoSii: EstadoSii, trackId: string | null, now: string,
  ): void {
    this._estadoSii.run({ t: tenantId, id, estadoSii, trackId, now });
  }

  insertarCola(tenantId: string, dteEmitidoId: string, now: string): void {
    this._insertCola.run({ tenantId, dteEmitidoId, now });
  }

  pickCola(now: string, staleMs: number, limit: number): DteColaItem[] {
    // Las fechas son ISO-8601 en UTC, así que compararlas como texto en SQL funciona.
    const stale = new Date(Date.now() - staleMs).toISOString();
    return (this._pickCola.all({ now, stale, lim: limit }) as Fila[]).map(mapearCola);
  }

  actualizarCola(
    id: number,
    campos: { estado?: string; intentos?: number; proximoIntento?: string | null; ultimoError?: string | null },
    now: string,
  ): void {
    // UPDATE armado al vuelo con solo los campos que vienen definidos. Los nombres
    // de columna salen de la lista fija de abajo, nunca del input, así que no hay
    // riesgo de inyección. Se prepara en cada llamada (no se cachea); la cola es chica.
    const sets: string[] = [];
    const params: Fila = { id, now };
    for (const clave of ['estado', 'intentos', 'proximoIntento', 'ultimoError'] as const) {
      if (campos[clave] !== undefined) {
        const col = { estado: 'estado', intentos: 'intentos', proximoIntento: 'proximo_intento', ultimoError: 'ultimo_error' }[clave];
        sets.push(`${col}=@${clave}`);
        params[clave] = campos[clave];
      }
    }
    sets.push('updated_at=@now');
    this.db.prepare(`UPDATE dte_cola SET ${sets.join(',')} WHERE id=@id`).run(params);
  }
}

function mapearDte(r: Fila): DteEmitido {
  return {
    id: r.id, tenantId: r.tenant_id, ventaId: r.venta_id, tipoDte: r.tipo_dte, folio: r.folio,
    cafId: r.caf_id, rutReceptor: r.rut_receptor, razonReceptor: r.razon_receptor,
    neto: r.neto, iva: r.iva, exento: r.exento, total: r.total, fechaEmision: r.fecha_emision,
    items: JSON.parse(r.items_json), xml: r.xml, trackId: r.track_id, estadoSii: r.estado_sii,
    createdAt: r.created_at, updatedAt: r.updated_at,
  };
}

function mapearCola(r: Fila): DteColaItem {
  return {
    id: r.id, tenantId: r.tenant_id, dteEmitidoId: r.dte_emitido_id, estado: r.estado,
    intentos: r.intentos, proximoIntento: r.proximo_intento, ultimoError: r.ultimo_error,
    createdAt: r.created_at, updatedAt: r.updated_at,
  };
}
