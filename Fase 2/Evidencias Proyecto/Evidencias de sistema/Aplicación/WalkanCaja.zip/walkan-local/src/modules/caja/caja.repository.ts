// Acceso a la tabla cajas_sesion: crear, buscar la abierta, cerrar y listar.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { SesionCaja } from './tipos/caja';

type Fila = Record<string, any>;

// SQL de cajas_sesion. Los statements se preparan una vez en el constructor y se
// reusan; así cada consulta en el TV Box no paga el parseo de nuevo.
@Injectable()
export class CajaRepository {
  private readonly _insert: Database.Statement;
  private readonly _abierta: Database.Statement;
  private readonly _getById: Database.Statement;
  private readonly _cerrar: Database.Statement;
  private readonly _list: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._insert = db.prepare(
      `INSERT INTO cajas_sesion
         (id, tenant_id, cajero_id, monto_apertura, monto_cierre, estado, fecha_apertura, fecha_cierre, created_at, updated_at)
       VALUES (@id, @tenantId, @cajeroId, @montoApertura, @montoCierre, @estado, @fechaApertura, @fechaCierre, @createdAt, @updatedAt)`,
    );
    this._abierta = db.prepare(
      "SELECT * FROM cajas_sesion WHERE tenant_id=? AND estado='ABIERTA' LIMIT 1",
    );
    this._getById = db.prepare('SELECT * FROM cajas_sesion WHERE tenant_id=? AND id=?');
    // El `estado='ABIERTA'` del WHERE evita cerrar dos veces la misma sesión.
    this._cerrar = db.prepare(
      `UPDATE cajas_sesion
          SET estado='CERRADA', monto_cierre=@montoCierre, fecha_cierre=@fechaCierre, updated_at=@now
        WHERE tenant_id=@t AND id=@id AND estado='ABIERTA'`,
    );
    this._list = db.prepare(
      'SELECT * FROM cajas_sesion WHERE tenant_id=? ORDER BY fecha_apertura DESC LIMIT ?',
    );
  }

  crear(s: SesionCaja): void {
    this._insert.run(s);
  }

  obtenerAbierta(tenantId: string): SesionCaja | undefined {
    const r = this._abierta.get(tenantId) as Fila | undefined;
    return r ? mapear(r) : undefined;
  }

  obtenerPorId(tenantId: string, id: string): SesionCaja | undefined {
    const r = this._getById.get(tenantId, id) as Fila | undefined;
    return r ? mapear(r) : undefined;
  }

  cerrar(tenantId: string, id: string, montoCierre: number, fechaCierre: string, now: string): number {
    return this._cerrar.run({ t: tenantId, id, montoCierre, fechaCierre, now }).changes;
  }

  listar(tenantId: string, limit: number): SesionCaja[] {
    return (this._list.all(tenantId, limit) as Fila[]).map(mapear);
  }
}

// snake_case de la base → camelCase del dominio.
function mapear(r: Fila): SesionCaja {
  return {
    id: r.id, tenantId: r.tenant_id, cajeroId: r.cajero_id,
    montoApertura: r.monto_apertura, montoCierre: r.monto_cierre,
    estado: r.estado, fechaApertura: r.fecha_apertura, fechaCierre: r.fecha_cierre,
    createdAt: r.created_at, updatedAt: r.updated_at,
  };
}
