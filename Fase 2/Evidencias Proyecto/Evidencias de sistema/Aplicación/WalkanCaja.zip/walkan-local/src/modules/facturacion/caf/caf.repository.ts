// SQL de la tabla caf (rangos de folios del SII): activo, pendiente, y avance del puntero de folio.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../../database/sqlite.provider';
import { Caf } from '../tipos/caf';

type Fila = Record<string, any>;

// Tabla caf: cada fila es un rango de folios con su puntero `folio_siguiente`.
@Injectable()
export class CafRepository {
  private readonly _insert: Database.Statement;
  private readonly _activo: Database.Statement;
  private readonly _pendiente: Database.Statement;
  private readonly _activar: Database.Statement;
  private readonly _avanzar: Database.Statement;
  private readonly _list: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._insert = db.prepare(
      `INSERT INTO caf
         (id, tenant_id, tipo_dte, folio_desde, folio_hasta, folio_siguiente, activo, xml, fecha_carga, created_at, updated_at)
       VALUES (@id, @tenantId, @tipoDte, @folioDesde, @folioHasta, @folioSiguiente, @activo, @xml, @fechaCarga, @createdAt, @updatedAt)`,
    );
    this._activo = db.prepare(
      'SELECT * FROM caf WHERE tenant_id=? AND tipo_dte=? AND activo=1 LIMIT 1',
    );
    // El pendiente que sigue es el de rango más bajo, para gastar los folios en orden.
    this._pendiente = db.prepare(
      `SELECT * FROM caf
        WHERE tenant_id=? AND tipo_dte=? AND activo=0 AND folio_siguiente<=folio_hasta
        ORDER BY folio_desde ASC LIMIT 1`,
    );
    this._activar = db.prepare(
      'UPDATE caf SET activo=1, updated_at=@now WHERE id=@id AND activo=0',
    );
    // CAS: avanza el puntero solo si sigue donde lo leímos; desactiva si se agota.
    this._avanzar = db.prepare(
      `UPDATE caf
          SET folio_siguiente = folio_siguiente + 1,
              activo = CASE WHEN folio_siguiente + 1 > folio_hasta THEN 0 ELSE 1 END,
              updated_at = @now
        WHERE id=@id AND folio_siguiente=@folioActual`,
    );
    this._list = db.prepare(
      'SELECT * FROM caf WHERE tenant_id=? ORDER BY tipo_dte, folio_desde',
    );
  }

  crear(c: Caf): void {
    this._insert.run({ ...c, activo: c.activo ? 1 : 0 });
  }
  obtenerActivo(tenantId: string, tipoDte: string): Caf | undefined {
    const r = this._activo.get(tenantId, tipoDte) as Fila | undefined;
    return r ? mapear(r) : undefined;
  }
  /** ¿Hubo alguna vez un rango de este tipo (activo, pendiente o agotado)? */
  tieneAlguno(tenantId: string, tipoDte: string): boolean {
    return !!this.db.prepare('SELECT 1 FROM caf WHERE tenant_id=? AND tipo_dte=? LIMIT 1').get(tenantId, tipoDte);
  }
  obtenerPendiente(tenantId: string, tipoDte: string): Caf | undefined {
    const r = this._pendiente.get(tenantId, tipoDte) as Fila | undefined;
    return r ? mapear(r) : undefined;
  }
  activar(id: string, now: string): number {
    return this._activar.run({ id, now }).changes;
  }
  avanzarPuntero(id: string, folioActual: number, now: string): number {
    return this._avanzar.run({ id, folioActual, now }).changes;
  }
  listar(tenantId: string): Caf[] {
    return (this._list.all(tenantId) as Fila[]).map(mapear);
  }
}

function mapear(r: Fila): Caf {
  return {
    id: r.id, tenantId: r.tenant_id, tipoDte: r.tipo_dte,
    folioDesde: r.folio_desde, folioHasta: r.folio_hasta, folioSiguiente: r.folio_siguiente,
    activo: !!r.activo, xml: r.xml, fechaCarga: r.fecha_carga,
    createdAt: r.created_at, updatedAt: r.updated_at,
  };
}
