// Contrato del cliente SII: hoy lo cumple el simulado, mañana uno real sin tocar el resto.
import { DteEmitido } from '../tipos/dte';

export interface SiiEnvioResultado {
  aceptado: boolean;
  trackId?: string;
  motivoRechazo?: string;
}

/**
 * Abstracción del envío al SII.
 * Contrato de errores:
 *  - Fallo de conexión / temporal → lanzar excepción (el despachador reintenta).
 *  - Rechazo de negocio del SII    → devolver { aceptado: false, motivoRechazo }.
 */
export interface SiiClient {
  enviar(dte: DteEmitido): Promise<SiiEnvioResultado>;
}

export const SII_CLIENT = Symbol('SII_CLIENT');
