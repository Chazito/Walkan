import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { DteService } from './dte.service';
import { EmitirDteDto } from './dto/emitir-dte.dto';

// Emitir a mano y consultar DTE. Las boletas de venta normal salen por /ventas.
@Controller('dte')
export class DteController {
  constructor(private readonly dte: DteService) {}

  @Post('emitir')
  emitir(@Body() dto: EmitirDteDto) {
    return this.dte.emitir(dto);
  }

  @Get()
  listar() {
    return this.dte.listar();
  }

  @Get(':id')
  obtener(@Param('id') id: string) {
    return this.dte.obtener(id);
  }
}
