import { TipoDte } from './tipo-dte';

// Rango de folios autorizado por el SII. folioSiguiente es el próximo a entregar.
export interface Caf {
  id: string;
  tenantId: string;
  tipoDte: TipoDte;
  folioDesde: number;
  folioHasta: number;
  folioSiguiente: number;
  activo: boolean;
  xml: string | null;
  fechaCarga: string;
  createdAt: string;
  updatedAt: string;
}
