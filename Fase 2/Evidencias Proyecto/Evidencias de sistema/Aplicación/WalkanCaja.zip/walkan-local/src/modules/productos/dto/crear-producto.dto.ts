// Body para crear un producto (código, nombre y precio son lo mínimo).
import { IsBoolean, IsInt, IsOptional, IsString, Length, Min } from 'class-validator';

export class CrearProductoDto {
  @IsString() @Length(1, 40) codigo: string;
  @IsOptional() @IsString() @Length(1, 60) codigoBarras?: string;
  @IsString() @Length(1, 120) nombre: string;
  @IsOptional() @IsString() descripcion?: string;
  @IsInt() @Min(0) precioVenta: number;
  @IsOptional() @IsString() @Length(1, 8) unidad?: string;
  @IsOptional() @IsInt() @Min(0) stockInicial?: number;
  @IsOptional() @IsInt() @Min(0) stockMinimo?: number;
  @IsOptional() @IsBoolean() exento?: boolean;
}
