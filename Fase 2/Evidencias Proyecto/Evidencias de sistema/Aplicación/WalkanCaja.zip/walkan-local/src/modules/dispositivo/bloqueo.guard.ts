import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { DispositivoRepository } from './dispositivo.repository';

/**
 * Kill-switch antirrobo. Si esta caja fue marcada como robada (bloqueada=1),
 * se corta el acceso a todos los endpoints de negocio: no se puede vender ni
 * leer datos. Solo se dejan pasar las rutas de /vinculo (para que la UI muestre
 * el candado) y los estáticos. El equipo sigue encendido; los datos quedan
 * protegidos. (El cifrado en reposo de la BD es el candado de fondo pendiente.)
 */
@Injectable()
export class BloqueoGuard implements CanActivate {
  constructor(private readonly repo: DispositivoRepository) {}

  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest();
    // req es el request de Fastify; req.raw es el de Node pelado, de respaldo.
    const url: string = req?.url || req?.raw?.url || '';
    // /red: una caja bloqueada igual puede cambiar de red para recibir el desbloqueo desde la nube.
    if (url.startsWith('/vinculo') || url.startsWith('/red')) return true;
    // Esto corre en CADA request y va a la base; es una lectura de una fila por
    // PK, así que en la práctica no se nota.
    if (!this.repo.leer().bloqueada) return true;
    throw new ForbiddenException('Esta caja fue bloqueada por robo desde la nube. Datos protegidos.');
  }
}
