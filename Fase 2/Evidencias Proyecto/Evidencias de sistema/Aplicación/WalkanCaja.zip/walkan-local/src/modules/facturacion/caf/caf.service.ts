// Registrar y listar los CAF (rangos de folios) de la caja.
import { ConflictException, Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../../database/sqlite.provider';
import { TenantContext } from '../../../common/contexto/tenant.context';
import { OutboxService } from '../../../common/sync/outbox.service';
import { transaccionInmediata } from '../../../database/unit-of-work';
import { ahora, nuevoId } from '../../../common/util/id';
import { CafRepository } from './caf.repository';
import { Caf } from '../tipos/caf';
import { RegistrarCafDto } from './dto/registrar-caf.dto';

// Carga de CAF (los rangos de folios que entrega el SII). Se pueden tener varios
// por tipo: uno activo y el resto en fila esperando su turno.
@Injectable()
export class CafService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: CafRepository,
    private readonly outbox: OutboxService,
    private readonly tenant: TenantContext,
  ) {}

  /** Carga un CAF. Queda activo si no hay otro activo del mismo tipo; si ya hay
   *  uno activo, entra como pendiente y se activará al agotarse el actual. */
  registrar(dto: RegistrarCafDto): Caf {
    // Ojo: no se revisa que el rango se traslape con otro CAF ya cargado.
    if (dto.folioHasta < dto.folioDesde) {
      throw new ConflictException('Rango de folios inválido (hasta < desde).');
    }
    const t = this.tenant.id;
    const now = ahora();
    return transaccionInmediata(this.db, (): Caf => {
      const hayActivo = !!this.repo.obtenerActivo(t, dto.tipoDte);
      const caf: Caf = {
        id: nuevoId(), tenantId: t, tipoDte: dto.tipoDte as Caf['tipoDte'],
        folioDesde: dto.folioDesde, folioHasta: dto.folioHasta,
        folioSiguiente: dto.folioDesde, activo: !hayActivo,
        xml: dto.xml ?? null, fechaCarga: now, createdAt: now, updatedAt: now,
      };
      this.repo.crear(caf);
      // El XML del CAF trae la llave privada del SII: no viaja a la nube.
      this.outbox.encolar({
        tenantId: t, entidad: 'caf', entidadId: caf.id, operacion: 'INSERT',
        payload: { ...caf, xml: caf.xml ? '[omitido]' : null },
      });
      return caf;
    })();
  }

  /** CAFs con folios restantes, para monitoreo/alarma. */
  listar() {
    return this.repo.listar(this.tenant.id).map((c) => ({
      ...c,
      xml: c.xml ? '[cargado]' : null,
      restantes: c.folioHasta - c.folioSiguiente + 1, // +1: el rango es inclusivo
    }));
  }
}
