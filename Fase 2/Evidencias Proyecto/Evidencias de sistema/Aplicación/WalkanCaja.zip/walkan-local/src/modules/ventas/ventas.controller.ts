// Rutas de venta: cobrar, pedir comprobante por correo y listar ventas.
import { Body, Controller, Get, Post } from '@nestjs/common';
import { VentasService } from './ventas.service';
import { CorreoComprobanteDto, RegistrarVentaDto } from './dto/registrar-venta.dto';

@Controller('ventas')
export class VentasController {
  constructor(private readonly ventas: VentasService) {}

  @Post()
  vender(@Body() dto: RegistrarVentaDto) {
    return this.ventas.vender(dto);
  }

  /** Enviar el comprobante por correo: queda en el outbox y la nube lo envía al sincronizar. */
  @Post('correo')
  correo(@Body() dto: CorreoComprobanteDto) {
    return this.ventas.pedirCorreo(dto.folio, dto.email);
  }

  @Get()
  listar() {
    return this.ventas.listar();
  }
}
