// Módulo de productos. Importa Inventario porque el stock inicial entra como movimiento.
import { Module } from '@nestjs/common';
import { ProductosController } from './productos.controller';
import { ProductosService } from './productos.service';
import { ProductosRepository } from './productos.repository';
import { InventarioModule } from '../inventario/inventario.module';

@Module({
  imports: [InventarioModule],
  controllers: [ProductosController],
  providers: [ProductosService, ProductosRepository],
  exports: [ProductosService, ProductosRepository],
})
export class ProductosModule {}
