// Vincular la caja a la cuenta del dueño en la nube, y marcarla bloqueada o en pausa según lo que responda la nube.
import { BadGatewayException, BadRequestException, ConflictException, ForbiddenException, Inject, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { CONFIG } from '../../common/config.provider';
import { AppConfig } from '../../config/configuracion';
import { DispositivoRepository, Vinculo } from './dispositivo.repository';
import { RegistrarDispositivoDto } from './dto/registrar-dispositivo.dto';

/**
 * Todo lo que es "esta caja frente a la nube": enrolarla con la cuenta del
 * dueño, guardar su token y obedecer la orden de bloqueo por robo. Es lo único
 * del sistema que necesita internet para funcionar (una vez, al vincular).
 */
@Injectable()
export class DispositivoService {
  private readonly logger = new Logger('Dispositivo');

  constructor(
    private readonly repo: DispositivoRepository,
    @Inject(CONFIG) private readonly cfg: AppConfig,
  ) {}

  // Cuenta del negocio en pausa (plan vencido o suspendida): la nube responde 403 al sincronizar. Solo en memoria: al
  // arrancar se vuelve a saber con la primera consulta del catálogo (a los 5 s). No bloquea nada; la pantalla avisa.
  private pausa = false;
  marcarPausa(si: boolean): void {
    if (si !== this.pausa) this.logger.warn(si ? 'Cuenta del negocio en pausa: se sigue vendiendo y las ventas esperan en la cola.' : 'Cuenta del negocio activa de nuevo: la cola se sincroniza.');
    this.pausa = si;
  }

  /** Estado del vínculo para la UI (no expone el token). */
  estado() {
    const v = this.repo.leer();
    return {
      vinculada: !!v.token,
      bloqueada: v.bloqueada,
      cuentaEnPausa: this.pausa,
      cajaId: v.cajaId,
      nombre: v.nombre,
      nubeUrl: v.nubeUrl || this.cfg.nubeUrl,
    };
  }

  /** Vínculo completo (con token) para uso interno del cliente de sync. */
  vinculo(): Vinculo {
    return this.repo.leer();
  }

  // Lo llama el sync cuando la nube responde que la caja está bloqueada. Solo
  // escribe la primera vez, para no llenar el log en cada ciclo.
  /** La nube informa que la caja ya NO está bloqueada (el dueño la desbloqueó en el panel). */
  marcarDesbloqueada(): void {
    const v = this.repo.leer();
    if (v.bloqueada) {
      this.repo.setBloqueada(false);
      this.logger.log('La nube desbloqueó esta caja. Vuelve a operar normalmente.');
    }
  }

  marcarBloqueada(): void {
    const v = this.repo.leer();
    if (!v.bloqueada) {
      this.repo.setBloqueada(true);
      this.logger.warn('La nube ordenó BLOQUEAR esta caja (antirrobo). Datos protegidos.');
    }
  }

  /**
   * Enrolamiento: envía las credenciales de la cuenta a la nube UNA sola vez,
   * recibe un token de caja y lo guarda localmente. Nunca guarda la contraseña.
   */
  /**
   * Antes de (re)vincular: una caja bloqueada por robo nunca se revincula (si no, el ladrón la pasa a su
   * cuenta y se salta el bloqueo). Una caja ya vinculada solo se revincula si la nube confirma que su token
   * actual ya no vale (la nube responde 401); si no, cualquiera podría moverla a otra cuenta.
   */
  private async exigirRevinculable(nubeUrl: string): Promise<void> {
    const v = this.repo.leer();
    if (v.bloqueada) throw new ForbiddenException('Esta caja está bloqueada por robo. Desbloquéala desde el panel web.');
    if (!v.token) return;
    let status = 0;
    try {
      status = (await fetch(`${v.nubeUrl || nubeUrl}/api/catalogo`, { headers: { 'X-Caja-Token': v.token }, signal: AbortSignal.timeout(15_000) })).status;
    } catch { /* sin nube no se puede confirmar: se rechaza abajo */ }
    if (status !== 401) {
      throw new ConflictException('Esta caja ya está vinculada a una cuenta. Para pasarla a otra, contacta al equipo Walkan.');
    }
  }

  async registrar(dto: RegistrarDispositivoDto) {
    const nubeUrl = this.cfg.nubeUrl;
    // La clave del dueño viaja en este POST: nunca por http plano, salvo una nube local de desarrollo.
    if (!/^https:\/\//.test(nubeUrl) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(nubeUrl)) {
      throw new BadRequestException('NUBE_URL debe ser https:// para vincular la caja (revisa el .env).');
    }
    await this.exigirRevinculable(nubeUrl);
    let resp: Response;
    try {
      resp = await fetch(`${nubeUrl}/api/cajas/registrar`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: dto.email, password: dto.password, nombre: dto.nombre }),
      });
    } catch (e) {
      throw new BadGatewayException(
        `No se pudo contactar la nube (${nubeUrl}). Revisa la conexión a internet. Detalle: ${(e as Error).message}`,
      );
    }

    // Si la nube responde algo que no es JSON (un 502 de proxy, por ejemplo),
    // seguimos con {} y cae en el error de abajo con el status HTTP.
    const data: any = await resp.json().catch(() => ({}));
    if (resp.status === 401) {
      throw new UnauthorizedException('Correo o contraseña incorrectos.');
    }
    if (!resp.ok || !data?.token) {
      throw new BadGatewayException(data?.message || `La nube rechazó el registro (HTTP ${resp.status}).`);
    }

    this.repo.guardarVinculo({
      cajaId: data.cajaId,
      token: data.token,
      nombre: data.nombre || dto.nombre || 'Caja',
      nubeUrl,
    });
    this.logger.log(`Caja vinculada: ${data.cajaId} ("${data.nombre}") contra ${nubeUrl}`);
    return { ok: true, cajaId: data.cajaId, nombre: data.nombre };
  }
}
