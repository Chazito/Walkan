// Acá se cobra una venta: valida, reserva folio, emite el DTE, descuenta stock y encola todo para la nube.
import { BadRequestException, ConflictException, Inject, Injectable, Logger } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { OutboxService } from '../../common/sync/outbox.service';
import { TenantContext } from '../../common/contexto/tenant.context';
import { transaccionInmediata } from '../../database/unit-of-work';
import { ahora, nuevoId } from '../../common/util/id';
import { VentasRepository } from './ventas.repository';
import { Venta } from './tipos/venta';
import { RegistrarVentaDto } from './dto/registrar-venta.dto';
import { CajaService } from '../caja/caja.service';
import { CajerosService } from '../cajeros/cajeros.service';
import { ProductosService } from '../productos/productos.service';
import { InventarioService } from '../inventario/inventario.service';
import { MotivoMovimiento, TipoMovimiento } from '../inventario/tipos/movimiento';
import { FoliosService } from '../facturacion/folios/folios.service';
import { DteService } from '../facturacion/dte/dte.service';
import { ItemDte, TipoDte } from '../facturacion/tipos/tipo-dte';

@Injectable()
export class VentasService {
  private readonly logger = new Logger('Ventas');

  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: VentasRepository,
    private readonly caja: CajaService,
    private readonly cajeros: CajerosService,
    private readonly productos: ProductosService,
    private readonly inventario: InventarioService,
    private readonly folios: FoliosService,
    private readonly dte: DteService,
    private readonly outbox: OutboxService,
    private readonly tenant: TenantContext,
  ) {}

  vender(dto: RegistrarVentaDto) {
    const t = this.tenant.id;
    const tipo = (dto.tipoDte ?? TipoDte.BOLETA) as TipoDte;

    // --- FUERA de la transacción: precondiciones, resolución y validación (lecturas) ---
    const sesion = this.caja.requerirSesionAbierta(t); // 409 si no hay caja abierta
    const cajeroNombre = this.cajeros.nombreDe(sesion.cajeroId) ?? sesion.cajeroId;

    const lineas = dto.items.map((it) => {
      // Línea genérica (C1): código que no está en el catálogo local. No toca stock aquí; la nube la deja en la bandeja
      // del dueño ("Vendido sin catálogo") y la descuenta cuando crea o vincula el producto.
      if (!it.productoId) {
        const codigo = (it.codigo ?? '').trim(), descripcion = (it.descripcion ?? '').trim() || 'Producto sin código';
        if (!codigo || !it.precio) throw new BadRequestException('Línea sin producto: indica el código leído y el precio.');
        return { productoId: null as string | null, codigo, descripcion, cantidad: it.cantidad, precioUnitario: it.precio, exento: false, generico: true };
      }
      const p = this.productos.obtener(it.productoId); // 404 si no existe
      if (!p.activo) throw new ConflictException(`El producto ${p.codigo} está inactivo.`);
      if (p.stock < it.cantidad) {
        throw new ConflictException(
          `Stock insuficiente para "${p.nombre}": disponible ${p.stock}, solicitado ${it.cantidad}.`,
        );
      }
      return {
        productoId: p.id as string | null, codigo: p.codigo, descripcion: p.nombre, cantidad: it.cantidad,
        precioUnitario: p.precioVenta, exento: p.exento, generico: false,
      };
    });

    const ventaId = nuevoId();
    const dteId = nuevoId();
    const itemsDte: ItemDte[] = lineas.map((l) => ({
      descripcion: l.descripcion, cantidad: l.cantidad,
      precioUnitario: l.precioUnitario, exento: l.exento,
    }));

    // --- DENTRO de la transacción: todo se confirma o se revierte junto ---
    const resultado = transaccionInmediata(this.db, () => {
      // 1) reservar folio (avanza el puntero del CAF)
      const { folio, cafId } = this.folios.reservarEnTx(t, tipo);

      // 2) emitir el DTE (queda EN COLA para envío asíncrono al SII)
      const dteEmitido = this.dte.emitirEnTx({
        id: dteId, tenantId: t, tipoDte: tipo, folio, cafId, ventaId,
        rutReceptor: dto.rutReceptor, razonReceptor: dto.razonReceptor, items: itemsDte,
      });

      // 3) registrar la venta
      const now = ahora();
      const venta: Venta = {
        id: ventaId, tenantId: t, cajaSesionId: sesion.id, dteEmitidoId: dteId,
        tipoDte: tipo, medioPago: dto.medioPago as Venta['medioPago'],
        neto: dteEmitido.neto, iva: dteEmitido.iva, exento: dteEmitido.exento,
        total: dteEmitido.total, createdAt: now,
      };
      this.repo.insertar(venta);

      // 4) líneas de la venta
      for (const l of lineas) {
        this.repo.insertarItem({
          tenantId: t, ventaId, productoId: l.productoId, codigoLeido: l.generico ? l.codigo : null, descripcion: l.descripcion,
          cantidad: l.cantidad, precioUnitario: l.precioUnitario, exento: l.exento,
          totalLinea: l.cantidad * l.precioUnitario,
        });
      }

      // 5) descontar stock (kardex + outbox), reutilizando el inventario
      for (const l of lineas) {
        if (!l.productoId) continue; // genérica: sin stock local
        this.inventario.aplicarEnTx({
          tenantId: t, productoId: l.productoId, tipo: TipoMovimiento.SALIDA,
          motivo: MotivoMovimiento.VENTA, cantidad: l.cantidad, referencia: ventaId,
        });
      }

      // 6) registrar el folio consumido (UNIQUE blinda el no-duplicado)
      this.folios.registrarUsoEnTx({
        tenantId: t, cafId, tipoDte: tipo, folio, dteEmitidoId: dteId, ventaId,
      });

      // 7) encolar la venta para sincronizar (payload enriquecido para el panel:
      //    folio, ítems con SKU, medio de pago y cajero; el panel descuenta stock por SKU)
      const payloadSync = {
        folio: dteEmitido.folio,
        tipoDte: tipo,
        medioPago: dto.medioPago,
        neto: dteEmitido.neto, iva: dteEmitido.iva, exento: dteEmitido.exento, total: dteEmitido.total,
        fecha: now,
        cajero: cajeroNombre,
        sii: dteEmitido.estadoSii,
        pago: dto.pago,
        items: lineas.map((l) => ({
          sku: l.codigo, nombre: l.descripcion, cantidad: l.cantidad, precio: l.precioUnitario,
          ...(l.generico ? { generico: true } : {}),
        })),
      };
      this.outbox.encolar({ tenantId: t, entidad: 'venta', entidadId: ventaId, operacion: 'INSERT', payload: payloadSync });

      return { venta, dte: dteEmitido };
    })();

    // --- FUERA de la transacción: imprimir. Un fallo acá NO deshace la venta. ---
    this.imprimirTicket(resultado.venta, resultado.dte);

    return {
      venta: resultado.venta,
      dte: {
        id: resultado.dte.id, folio: resultado.dte.folio, tipoDte: resultado.dte.tipoDte,
        estadoSii: resultado.dte.estadoSii, total: resultado.dte.total,
      },
    };
  }

  listar() {
    return this.repo.listar(this.tenant.id, 100);
  }

  /** Encola el envío del comprobante por correo. Sin internet queda en espera y sale al volver la conexión. */
  pedirCorreo(folio: number, email: string) {
    const correo = email.trim().toLowerCase();
    this.outbox.encolar({
      tenantId: this.tenant.id, entidad: 'correo_comprobante', entidadId: nuevoId(), operacion: 'INSERT',
      payload: { folio, email: correo },
    });
    this.logger.log(`Comprobante ${folio}: envío por correo en cola`);
    return { ok: true, email: correo };
  }

  /** Stub de impresión (Módulo 5 conectará la impresora 58 mm real). */
  private imprimirTicket(venta: Venta, dte: { folio: number }): void {
    this.logger.log(`TICKET · folio ${dte.folio} · total $${venta.total} · pago ${venta.medioPago}`);
  }
}
