// Emisión de DTE: guarda el documento, lo encola para el SII y avisa a la nube, todo en una transacción.
import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../../database/sqlite.provider';
import { OutboxService } from '../../../common/sync/outbox.service';
import { TenantContext } from '../../../common/contexto/tenant.context';
import { transaccionInmediata } from '../../../database/unit-of-work';
import { ahora, nuevoId } from '../../../common/util/id';
import { DteRepository } from './dte.repository';
import { FoliosService } from '../folios/folios.service';
import { calcularMontos } from '../montos';
import { DteEmitido } from '../tipos/dte';
import { ItemDte, TipoDte } from '../tipos/tipo-dte';
import { EmitirDteDto } from './dto/emitir-dte.dto';

export interface EmitirEnTxInput {
  id: string;
  tenantId: string;
  tipoDte: TipoDte;
  folio: number;
  cafId: string | null;
  ventaId: string | null;
  rutReceptor?: string | null;
  razonReceptor?: string | null;
  items: ItemDte[];
}

// Emite DTE: los deja guardados y encolados para el SII. El envío real lo hace
// después el DteDispatcherService; acá no se toca la red, así se emite offline.
@Injectable()
export class DteService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: DteRepository,
    private readonly folios: FoliosService,
    private readonly outbox: OutboxService,
    private readonly tenant: TenantContext,
  ) {}

  /** Emite el DTE dentro del tx del llamador (la venta ya reservó el folio). */
  emitirEnTx(input: EmitirEnTxInput): DteEmitido {
    const now = ahora();
    const montos = calcularMontos(input.items);
    const dte: DteEmitido = {
      id: input.id, tenantId: input.tenantId, ventaId: input.ventaId,
      tipoDte: input.tipoDte, folio: input.folio, cafId: input.cafId,
      rutReceptor: input.rutReceptor ?? null, razonReceptor: input.razonReceptor ?? null,
      neto: montos.neto, iva: montos.iva, exento: montos.exento, total: montos.total,
      fechaEmision: now, items: input.items, xml: null, trackId: null,
      estadoSii: 'EMITIDO', createdAt: now, updatedAt: now,
    };
    // Tres escrituras, una sola transacción (la del llamador): el documento, su
    // fila en la cola del SII y el aviso para la nube. O quedan las tres o ninguna.
    this.repo.insertarDte(dte);
    this.repo.insertarCola(input.tenantId, input.id, now);
    this.outbox.encolar({
      tenantId: input.tenantId, entidad: 'dte_emitido', entidadId: input.id,
      operacion: 'INSERT', payload: dte,
    });
    return dte;
  }

  /** Emisión independiente de una venta (reserva folio + emite + registra uso). */
  emitir(dto: EmitirDteDto): DteEmitido {
    const t = this.tenant.id;
    const id = nuevoId();
    const items: ItemDte[] = dto.items.map((i) => ({
      descripcion: i.descripcion, cantidad: i.cantidad,
      precioUnitario: i.precioUnitario, exento: i.exento ?? false,
    }));
    return transaccionInmediata(this.db, (): DteEmitido => {
      // Orden: reservar folio → crear DTE → registrar uso. El uso va al final
      // porque folios_usados tiene FK al DTE.
      const { folio, cafId } = this.folios.reservarEnTx(t, dto.tipoDte);
      const dte = this.emitirEnTx({
        id, tenantId: t, tipoDte: dto.tipoDte as TipoDte, folio, cafId, ventaId: null,
        rutReceptor: dto.rutReceptor, razonReceptor: dto.razonReceptor, items,
      });
      this.folios.registrarUsoEnTx({
        tenantId: t, cafId, tipoDte: dto.tipoDte, folio, dteEmitidoId: id, ventaId: null,
      });
      return dte;
    })();
  }

  listar(): DteEmitido[] {
    return this.repo.listarDte(this.tenant.id, 100);
  }

  obtener(id: string): DteEmitido {
    const dte = this.repo.obtenerDte(this.tenant.id, id);
    if (!dte) throw new NotFoundException('Documento no encontrado.');
    return dte;
  }
}
