// Rutas de inventario: recepción, ajuste, merma y el kardex de un producto.
import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { InventarioService } from './inventario.service';
import { TenantContext } from '../../common/contexto/tenant.context';
import { MotivoMovimiento, TipoMovimiento } from './tipos/movimiento';
import { RecepcionDto } from './dto/recepcion.dto';
import { AjusteDto } from './dto/ajuste.dto';
import { MermaDto } from './dto/merma.dto';

@Controller('inventario')
export class InventarioController {
  constructor(
    private readonly inventario: InventarioService,
    private readonly tenant: TenantContext,
  ) {}

  @Post('recepcion')
  recepcion(@Body() d: RecepcionDto) {
    return this.inventario.aplicar({
      tenantId: this.tenant.id, productoId: d.productoId, tipo: TipoMovimiento.ENTRADA,
      motivo: MotivoMovimiento.RECEPCION_COMPRA, cantidad: d.cantidad,
      comentario: d.comentario, referencia: d.referencia,
    });
  }

  @Post('ajuste')
  ajuste(@Body() d: AjusteDto) {
    return this.inventario.aplicar({
      tenantId: this.tenant.id, productoId: d.productoId, tipo: TipoMovimiento.AJUSTE,
      motivo: MotivoMovimiento.AJUSTE_MANUAL, cantidad: d.cantidad, comentario: d.comentario,
    });
  }

  @Post('merma')
  merma(@Body() d: MermaDto) {
    return this.inventario.aplicar({
      tenantId: this.tenant.id, productoId: d.productoId, tipo: TipoMovimiento.SALIDA,
      motivo: MotivoMovimiento.MERMA, cantidad: d.cantidad, comentario: d.comentario,
    });
  }

  @Get('movimientos')
  movimientos(@Query('productoId') productoId: string, @Query('limit') limit?: string) {
    return this.inventario.listarMovimientos(
      this.tenant.id, productoId, limit ? parseInt(limit, 10) : 100,
    );
  }
}
