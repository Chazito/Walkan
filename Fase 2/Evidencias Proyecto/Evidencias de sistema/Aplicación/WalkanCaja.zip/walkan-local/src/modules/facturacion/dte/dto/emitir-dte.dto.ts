// Validación del body para emitir un DTE a mano (tipo, receptor e items).
import { Type } from 'class-transformer';
import {
  ArrayMinSize, IsBoolean, IsIn, IsInt, IsOptional, IsString, Min, ValidateNested,
} from 'class-validator';
import { TipoDte } from '../../tipos/tipo-dte';

const TIPOS = Object.values(TipoDte);

export class ItemDteDto {
  @IsString() descripcion: string;
  @IsInt() @Min(1) cantidad: number;
  @IsInt() @Min(0) precioUnitario: number;
  @IsOptional() @IsBoolean() exento?: boolean;
}

// Emisión manual de un DTE (sin venta detrás). El receptor solo hace falta en facturas.
export class EmitirDteDto {
  @IsIn(TIPOS) tipoDte: string;
  @IsOptional() @IsString() rutReceptor?: string;
  @IsOptional() @IsString() razonReceptor?: string;
  @ValidateNested({ each: true }) @ArrayMinSize(1) @Type(() => ItemDteDto)
  items: ItemDteDto[];
}
