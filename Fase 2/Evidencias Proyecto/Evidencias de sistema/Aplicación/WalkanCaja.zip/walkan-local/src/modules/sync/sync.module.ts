// Módulo de sincronización con la nube: el worker que sube cambios y el que baja el catálogo.
import { Module } from '@nestjs/common';
import { ProductosModule } from '../productos/productos.module';
import { InventarioModule } from '../inventario/inventario.module';
import { CajerosModule } from '../cajeros/cajeros.module';
import { CatalogoSyncService } from './catalogo-sync.service';
import { SyncRepository } from './sync.repository';
import { SyncWorkerService } from './sync-worker.service';
import { SyncController } from './sync.controller';
import { SYNC_CLIENT } from './sync-client.interface';
import { SyncClientSimulado } from './sync-client.simulado';
import { SyncClientHttp } from './sync-client.http';

// Cliente de sync: HTTP real por defecto. Con SYNC_MODO=simulado usa el
// simulado (útil para probar la caja sin la nube levantada).
@Module({
  imports: [ProductosModule, InventarioModule, CajerosModule],
  controllers: [SyncController],
  providers: [
    SyncRepository,
    CatalogoSyncService,
    SyncWorkerService,
    SyncClientSimulado,
    SyncClientHttp,
    {
      provide: SYNC_CLIENT,
      useFactory: (http: SyncClientHttp, sim: SyncClientSimulado) =>
        process.env.SYNC_MODO === 'simulado' ? sim : http,
      inject: [SyncClientHttp, SyncClientSimulado],
    },
  ],
})
export class SyncModule {}
