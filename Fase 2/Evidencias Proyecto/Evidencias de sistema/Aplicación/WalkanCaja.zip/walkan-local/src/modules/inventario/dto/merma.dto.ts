// Body para registrar una merma (producto perdido o dañado, sale del stock).
import { IsInt, IsOptional, IsString, Length, Min } from 'class-validator';

export class MermaDto {
  @IsString() @Length(1, 60) productoId: string;
  @IsInt() @Min(1) cantidad: number;
  @IsOptional() @IsString() comentario?: string;
}
