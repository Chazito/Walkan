// Contrato del cliente de sync: el worker no sabe si habla con la nube de verdad o con un simulado.
export interface CambioSync {
  id: number;
  entidad: string;
  entidadId: string;
  operacion: string;
  payload: unknown;
}

export interface SyncResultado {
  ok: boolean;
  error?: string;
}

/**
 * Envío de cambios a la nube (unidireccional local → nube).
 *  - Fallo de conexión → lanzar excepción (el worker reintenta).
 *  - Rechazo lógico     → devolver { ok: false, error }.
 */
export interface SyncClient {
  enviar(cambios: CambioSync[]): Promise<SyncResultado>;
}

export const SYNC_CLIENT = Symbol('SYNC_CLIENT');
