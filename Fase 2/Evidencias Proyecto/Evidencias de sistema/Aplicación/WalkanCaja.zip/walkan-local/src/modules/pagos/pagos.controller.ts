// Rutas de cobro de la caja: tarjeta, cajón de dinero, QR de Flow y datos del negocio.
import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { IsInt, Max, Min } from 'class-validator';
import { PerifericosService } from './perifericos.service';
import { AjustesService } from './ajustes.service';
import { CobroQrService } from './cobro-qr.service';

class CobroTarjetaDto { @IsInt() @Min(1) @Max(100_000_000) monto!: number; }

// Cobro en la caja: máquina de tarjetas, cajón de dinero y datos del negocio (encabezado y transferencia).
@Controller()
export class PagosController {
  constructor(private readonly perifericos: PerifericosService, private readonly ajustes: AjustesService, private readonly qr: CobroQrService) {}

  @Get('negocio')
  negocio() { return this.ajustes.negocio(); }

  @Post('pagos/tarjeta')
  tarjeta(@Body() dto: CobroTarjetaDto) { return this.perifericos.cobrarConTarjeta(dto.monto); }

  @Post('pagos/cajon')
  cajon() { return this.perifericos.abrirCajon(); }

  // Cobro con QR de Flow (lo crea la nube con las llaves del negocio).
  @Post('pagos/qr')
  crearQr(@Body() dto: CobroTarjetaDto) { return this.qr.crear(dto.monto); }

  @Get('pagos/qr/:id')
  estadoQr(@Param('id') id: string) { return this.qr.estado(id); }

  @Post('pagos/qr/:id/anular')
  anularQr(@Param('id') id: string) { return this.qr.anular(id); }
}
