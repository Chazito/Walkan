// El cajero completo, con hash incluido. Solo para uso interno.
export interface Cajero {
  id: string;
  tenantId: string;
  nombre: string;
  pinHash: string;
  activo: boolean;
  createdAt: string;
  updatedAt: string;
}

/** Cajero sin el hash del PIN, para respuestas y sincronización. */
export type CajeroPublico = Omit<Cajero, 'pinHash'>;

export function aPublico(c: Cajero): CajeroPublico {
  const { pinHash, ...pub } = c;
  return pub;
}
