import { IsInt, IsOptional, IsString, Length, Matches, Min } from 'class-validator';

// Para abrir caja: quién, su PIN (4 a 8 dígitos) y con cuánta plata parte.
export class AbrirCajaDto {
  @IsString() @Length(1, 60) cajeroId: string;
  @Matches(/^[0-9]{4,8}$/) pin: string;
  @IsOptional() @IsInt() @Min(0) montoApertura?: number;
}
