import { Injectable, Logger } from '@nestjs/common';
import { SiiClient, SiiEnvioResultado } from './sii-client.interface';
import { DteEmitido } from '../tipos/dte';

/**
 * Cliente SII SIMULADO para desarrollo/pruebas. No firma ni envía documentos
 * reales. Con SII_SIMULAR_OFFLINE=true lanza excepción (simula caída de red)
 * para ver la cola reintentar. La integración real (firma XML + envío) la hace
 * otra persona detrás de esta misma interfaz.
 */
@Injectable()
export class SiiClientSimulado implements SiiClient {
  private readonly logger = new Logger('SiiClientSimulado');

  async enviar(dte: DteEmitido): Promise<SiiEnvioResultado> {
    if (process.env.SII_SIMULAR_OFFLINE === 'true') {
      throw new Error('SII no disponible (simulación offline).');
    }
    // Siempre acepta: el camino de RECHAZADO no se puede probar con este cliente.
    const trackId = `SIM-${dte.tipoDte}-${dte.folio}-${Date.now()}`;
    this.logger.log(`DTE tipo ${dte.tipoDte} folio ${dte.folio} enviado al SII (simulado). trackId=${trackId}`);
    return { aceptado: true, trackId };
  }
}
