// Lógica de abrir y cerrar caja. Cada cambio queda también en el outbox para subirlo a la nube.
import { ConflictException, Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { TenantContext } from '../../common/contexto/tenant.context';
import { OutboxService } from '../../common/sync/outbox.service';
import { transaccionInmediata } from '../../database/unit-of-work';
import { ahora, nuevoId } from '../../common/util/id';
import { CajaRepository } from './caja.repository';
import { CajerosService } from '../cajeros/cajeros.service';
import { SesionCaja } from './tipos/caja';
import { AbrirCajaDto } from './dto/abrir-caja.dto';
import { CerrarCajaDto } from './dto/cerrar-caja.dto';

/**
 * Abrir y cerrar caja. La caja abierta ES la sesión del cajero (D-12): no hay
 * login ni tokens, si hay caja abierta se puede vender y punto.
 */
@Injectable()
export class CajaService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: CajaRepository,
    private readonly cajeros: CajerosService,
    private readonly outbox: OutboxService,
    private readonly tenant: TenantContext,
  ) {}

  abrir(dto: AbrirCajaDto): SesionCaja {
    const t = this.tenant.id;
    // El PIN se valida fuera de la transacción: scrypt es lento a propósito y
    // no queremos tener el lock de escritura tomado mientras calcula.
    const cajero = this.cajeros.obtenerValidado(dto.cajeroId, dto.pin); // 404/401
    const now = ahora();
    return transaccionInmediata(this.db, (): SesionCaja => {
      // Este chequeo es para dar un 409 bonito; el que manda de verdad es el
      // índice único uq_caja_abierta en la base (D-09).
      if (this.repo.obtenerAbierta(t)) {
        throw new ConflictException('Ya hay una caja abierta; ciérrala antes de abrir otra.');
      }
      const sesion: SesionCaja = {
        id: nuevoId(), tenantId: t, cajeroId: cajero.id,
        montoApertura: dto.montoApertura ?? 0, montoCierre: null,
        estado: 'ABIERTA', fechaApertura: now, fechaCierre: null,
        createdAt: now, updatedAt: now,
      };
      this.repo.crear(sesion);
      this.outbox.encolar({
        tenantId: t, entidad: 'caja_sesion', entidadId: sesion.id,
        operacion: 'INSERT', payload: sesion,
      });
      return sesion;
    })();
  }

  cerrar(dto: CerrarCajaDto): SesionCaja {
    const t = this.tenant.id;
    const now = ahora();
    return transaccionInmediata(this.db, (): SesionCaja => {
      const abierta = this.repo.obtenerAbierta(t);
      if (!abierta) throw new ConflictException('No hay ninguna caja abierta.');
      this.repo.cerrar(t, abierta.id, dto.montoCierre, now, now);
      // Se relee para mandar al outbox la fila tal como quedó guardada.
      const cerrada = this.repo.obtenerPorId(t, abierta.id) as SesionCaja;
      this.outbox.encolar({
        tenantId: t, entidad: 'caja_sesion', entidadId: cerrada.id,
        operacion: 'UPDATE', payload: cerrada,
      });
      return cerrada;
    })();
  }

  /** Caja abierta actual, o null. */
  actual(): (SesionCaja & { cajeroNombre: string | null }) | null {
    return this.conNombre(this.repo.obtenerAbierta(this.tenant.id) ?? null);
  }

  /** Agrega el nombre del cajero (la barra de la caja y el comprobante lo muestran). */
  conNombre<T extends SesionCaja | null>(s: T): (T & { cajeroNombre: string | null }) | null {
    return s ? { ...s, cajeroNombre: this.cajeros.nombreDe(s.cajeroId) } : null;
  }

  /** Exige una caja abierta (precondición de la venta). Lanza 409 si no hay. */
  requerirSesionAbierta(tenantId: string): SesionCaja {
    const abierta = this.repo.obtenerAbierta(tenantId);
    if (!abierta) throw new ConflictException('No hay caja abierta; abre caja para vender.');
    return abierta;
  }
}
