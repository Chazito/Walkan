import { Injectable, Logger } from '@nestjs/common';

export interface ResultadoTarjeta { aprobado: boolean; autorizacion?: string; tarjeta?: string; terminal: string; simulado: boolean; motivo?: string }

/**
 * Periféricos de cobro: máquina de tarjetas (POS) y cajón de dinero.
 * Hoy solo existe el modo SIMULADO (PERIFERICOS_MODO=simulado, por defecto): la máquina "aprueba" a los
 * pocos segundos y el cajón "se abre" en el log. Para conectar equipos reales (POS integrado, cajón por la
 * impresora térmica con el comando ESC/POS de apertura) se agrega otra implementación con la misma interfaz.
 */
@Injectable()
export class PerifericosService {
  private readonly logger = new Logger('Perifericos');
  private readonly modo = (process.env.PERIFERICOS_MODO || 'simulado').toLowerCase();

  /** Envía el cobro a la máquina de tarjetas y espera la respuesta. */
  async cobrarConTarjeta(monto: number): Promise<ResultadoTarjeta> {
    if (this.modo !== 'simulado') {
      return { aprobado: false, terminal: this.modo, simulado: false, motivo: 'No hay una máquina de tarjetas configurada.' };
    }
    this.logger.log(`[simulado] Cobro con tarjeta por $${monto} enviado a la máquina`);
    await new Promise((r) => setTimeout(r, 2500)); // lo que tarda el cliente en pasar la tarjeta
    const autorizacion = String(Math.floor(100000 + Math.random() * 900000));
    const tarjeta = '•••• ' + String(Math.floor(1000 + Math.random() * 9000));
    this.logger.log(`[simulado] Pago aprobado · autorización ${autorizacion}`);
    return { aprobado: true, autorizacion, tarjeta, terminal: 'Máquina simulada', simulado: true };
  }

  /** Abre el cajón de dinero (pagos en efectivo). */
  abrirCajon(): { ok: boolean; simulado: boolean } {
    this.logger.log(this.modo === 'simulado' ? '[simulado] Cajón de dinero abierto' : `Cajón: modo ${this.modo} sin implementar`);
    return { ok: this.modo === 'simulado', simulado: this.modo === 'simulado' };
  }
}
