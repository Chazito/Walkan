// SQL de la tabla cajeros, incluidos los helpers para aplicar los cajeros que vienen de la nube.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { Cajero } from './tipos/cajero';

type Fila = Record<string, any>;

// Acceso a la tabla cajeros. Listar solo trae los activos.
@Injectable()
export class CajerosRepository {
  private readonly _insert: Database.Statement;
  private readonly _getById: Database.Statement;
  private readonly _list: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._insert = db.prepare(
      `INSERT INTO cajeros (id, tenant_id, nombre, pin_hash, activo, created_at, updated_at)
       VALUES (@id, @tenantId, @nombre, @pinHash, @activo, @createdAt, @updatedAt)`,
    );
    this._getById = db.prepare('SELECT * FROM cajeros WHERE tenant_id=? AND id=?');
    this._list = db.prepare(
      'SELECT * FROM cajeros WHERE tenant_id=? AND activo=1 ORDER BY nombre',
    );
  }

  // SQLite no tiene boolean: activo se guarda como 0/1.
  crear(c: Cajero): void {
    this._insert.run({ ...c, activo: c.activo ? 1 : 0 });
  }

  obtenerPorId(tenantId: string, id: string): Cajero | undefined {
    const r = this._getById.get(tenantId, id) as Fila | undefined;
    return r ? mapear(r) : undefined;
  }

  listar(tenantId: string): Cajero[] {
    return (this._list.all(tenantId) as Fila[]).map(mapear);
  }

  // ---- Cajeros que vienen de la nube (panel web) ----
  /** Id local del cajero enlazado a un cajero de la nube. */
  idPorNube(tenantId: string, idNube: string): string | undefined {
    const r = this.db.prepare('SELECT id FROM cajeros WHERE tenant_id=? AND id_nube=?').get(tenantId, idNube) as Fila | undefined;
    return r?.id;
  }
  enlazarNube(tenantId: string, id: string, idNube: string): void {
    this.db.prepare('UPDATE cajeros SET id_nube=? WHERE tenant_id=? AND id=?').run(idNube, tenantId, id);
  }
  /** Actualiza nombre, hash y estado; devuelve true si cambió algo. */
  actualizarDesdeNube(tenantId: string, id: string, d: { nombre: string; pinHash: string; activo: boolean }, updatedAt: string): boolean {
    const r = this.db.prepare(
      `UPDATE cajeros SET nombre=@nombre, pin_hash=@pinHash, activo=@activo, updated_at=@updatedAt
        WHERE tenant_id=@t AND id=@id AND (nombre<>@nombre OR pin_hash<>@pinHash OR activo<>@activo)`,
    ).run({ ...d, activo: d.activo ? 1 : 0, updatedAt, t: tenantId, id });
    return r.changes > 0;
  }
  /** Desactiva los cajeros activos que no estén en `mantener` (ids locales). Devuelve cuántos. */
  desactivarExcepto(tenantId: string, mantener: string[], updatedAt: string): number {
    let n = 0;
    for (const r of this._list.all(tenantId) as Fila[]) {
      if (mantener.includes(r.id)) continue;
      this.db.prepare('UPDATE cajeros SET activo=0, updated_at=? WHERE tenant_id=? AND id=?').run(updatedAt, tenantId, r.id);
      n++;
    }
    return n;
  }
}

function mapear(r: Fila): Cajero {
  return {
    id: r.id, tenantId: r.tenant_id, nombre: r.nombre, pinHash: r.pin_hash,
    activo: !!r.activo, createdAt: r.created_at, updatedAt: r.updated_at,
  };
}
