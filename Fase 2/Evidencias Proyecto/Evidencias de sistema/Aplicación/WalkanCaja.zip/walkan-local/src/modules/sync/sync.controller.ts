// Rutas para ver cómo va la sincronización y pedir el catálogo a la nube a mano.
import { Controller, Get, Post } from '@nestjs/common';
import { SyncRepository } from './sync.repository';
import { CatalogoSyncService } from './catalogo-sync.service';

@Controller('sync')
export class SyncController {
  constructor(private readonly repo: SyncRepository, private readonly catalogo: CatalogoSyncService) {}

  @Get('estado')
  estado() {
    return { ...this.repo.obtenerEstado(), pendientes: this.repo.hayPendientes() };
  }

  /** Pide el catálogo a la nube ahora (la pantalla lo llama al arrancar). */
  @Post('catalogo')
  catalogoAhora() {
    return this.catalogo.sincronizar();
  }
}
