// Rutas de la pantalla "Red" del kiosco: estado, buscar redes Wi-Fi, conectar y olvidar.
import { Body, Controller, Get, Headers, Post, UnauthorizedException } from '@nestjs/common';
import { IsOptional, IsString, MaxLength } from 'class-validator';
import { RedService } from './red.service';
import { CajerosService } from '../cajeros/cajeros.service';

class ConectarDto {
  @IsString() @MaxLength(64) ssid!: string;
  @IsOptional() @IsString() @MaxLength(63) clave?: string;
}
class OlvidarDto { @IsString() @MaxLength(64) ssid!: string; }

// Pantalla "Red" del kiosco. Ver el estado es libre; buscar, conectar u olvidar redes pide el PIN de un cajero
// activo (header X-Pin), porque la API de la caja también escucha en la red local.
@Controller('red')
export class RedController {
  constructor(private readonly red: RedService, private readonly cajeros: CajerosService) {}

  private exigirPin(pin?: string) {
    if (!this.cajeros.pinDeAlgunCajero(pin ?? '')) throw new UnauthorizedException('PIN incorrecto: usa el PIN de un cajero.');
  }

  @Get('estado')
  estado() { return this.red.estado(); }

  @Get('wifi')
  redes(@Headers('x-pin') pin?: string) { this.exigirPin(pin); return this.red.redes(); }

  @Post('conectar')
  conectar(@Headers('x-pin') pin: string, @Body() dto: ConectarDto) { this.exigirPin(pin); return this.red.conectar(dto.ssid, dto.clave); }

  @Post('olvidar')
  olvidar(@Headers('x-pin') pin: string, @Body() dto: OlvidarDto) { this.exigirPin(pin); return this.red.olvidar(dto.ssid); }
}
