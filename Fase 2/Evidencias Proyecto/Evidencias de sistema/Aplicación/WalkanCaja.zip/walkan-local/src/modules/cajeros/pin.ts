import { randomBytes, scryptSync, timingSafeEqual } from 'crypto';

// Hash de PIN con el crypto de Node, sin bcrypt/argon2: esas libs son nativas y
// compilarlas en el ARM del TV Box es puro dolor (D-12). Un PIN de 4 dígitos
// igual se revienta por fuerza bruta si se roban la base; esto es para no
// guardarlo en texto plano, no una bóveda.

/** Deriva un hash del PIN con scrypt + salt. Formato: scrypt$<salt>$<hash>. */
export function hashPin(pin: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(pin, salt, 32);
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

/** Verifica un PIN contra el valor almacenado, en tiempo constante. */
export function verificarPin(pin: string, almacenado: string): boolean {
  const partes = almacenado.split('$');
  // Formato raro o algoritmo desconocido = no pasa, sin tirar excepción.
  if (partes.length !== 3 || partes[0] !== 'scrypt') return false;
  const salt = Buffer.from(partes[1], 'base64');
  const esperado = Buffer.from(partes[2], 'base64');
  const calculado = scryptSync(pin, salt, esperado.length);
  // timingSafeEqual revienta si los largos difieren, por eso el chequeo previo.
  return calculado.length === esperado.length && timingSafeEqual(calculado, esperado);
}
