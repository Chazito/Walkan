// Tipos de una venta y de sus líneas, como se usan dentro de la caja.
export type MedioPago = 'EFECTIVO' | 'TARJETA' | 'TRANSFERENCIA';

export interface Venta {
  id: string;
  tenantId: string;
  cajaSesionId: string;
  dteEmitidoId: string;
  tipoDte: string;
  medioPago: MedioPago;
  neto: number;
  iva: number;
  exento: number;
  total: number;
  createdAt: string;
}

export interface VentaItem {
  tenantId: string;
  ventaId: string;
  productoId: string | null; // null = línea genérica (código que no está en el catálogo, C1)
  codigoLeido?: string | null;
  descripcion: string;
  cantidad: number;
  precioUnitario: number;
  exento: boolean;
  totalLinea: number;
}
