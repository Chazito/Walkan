// SQL de la tabla productos, incluido el enlace con los productos de la nube (id_nube).
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { Producto } from './tipos/producto';

type Fila = Record<string, any>;

const COLS =
  'id,tenant_id,codigo,codigo_barras,nombre,descripcion,precio_venta,unidad,stock,stock_minimo,exento,activo,created_at,updated_at';

// Campos que un UPDATE de producto puede tocar (stock NO: solo por movimientos).
const ACTUALIZABLES: Record<string, string> = {
  codigo: 'codigo',
  codigoBarras: 'codigo_barras',
  nombre: 'nombre',
  descripcion: 'descripcion',
  precioVenta: 'precio_venta',
  unidad: 'unidad',
  stockMinimo: 'stock_minimo',
  exento: 'exento',
  activo: 'activo',
};

@Injectable()
export class ProductosRepository {
  private readonly _insert: Database.Statement;
  private readonly _getById: Database.Statement;
  private readonly _list: Database.Statement;
  private readonly _buscar: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._insert = db.prepare(
      `INSERT INTO productos (${COLS}) VALUES
       (@id,@tenant_id,@codigo,@codigo_barras,@nombre,@descripcion,@precio_venta,@unidad,@stock,@stock_minimo,@exento,@activo,@created_at,@updated_at)`,
    );
    this._getById = db.prepare('SELECT * FROM productos WHERE tenant_id=? AND id=?');
    this._list = db.prepare(
      'SELECT * FROM productos WHERE tenant_id=? AND activo=1 ORDER BY nombre LIMIT ?',
    );
    this._buscar = db.prepare(
      `SELECT * FROM productos
        WHERE tenant_id=@t AND activo=1 AND (codigo_barras=@q OR codigo=@q OR nombre LIKE @pref)
        ORDER BY (codigo_barras=@q OR codigo=@q) DESC, nombre LIMIT @lim`,
    );
  }

  crear(p: Producto): void {
    this._insert.run({
      id: p.id, tenant_id: p.tenantId, codigo: p.codigo, codigo_barras: p.codigoBarras,
      nombre: p.nombre, descripcion: p.descripcion, precio_venta: p.precioVenta,
      unidad: p.unidad, stock: p.stock, stock_minimo: p.stockMinimo,
      exento: p.exento ? 1 : 0, activo: p.activo ? 1 : 0,
      created_at: p.createdAt, updated_at: p.updatedAt,
    });
  }

  /** Producto por código interno (el SKU de la web). Incluye inactivos. */
  obtenerPorCodigo(tenantId: string, codigo: string): Producto | undefined {
    const r = this.db.prepare('SELECT * FROM productos WHERE tenant_id=? AND codigo=? LIMIT 1').get(tenantId, codigo) as Fila | undefined;
    return r ? mapear(r) : undefined;
  }

  /** Producto enlazado a un producto de la nube (id de la web, que no cambia aunque cambie el SKU). */
  obtenerPorIdNube(tenantId: string, idNube: string): Producto | undefined {
    const r = this.db.prepare('SELECT * FROM productos WHERE tenant_id=? AND id_nube=? LIMIT 1').get(tenantId, idNube) as Fila | undefined;
    return r ? mapear(r) : undefined;
  }

  idNubeDe(tenantId: string, id: string): string | null {
    const r = this.db.prepare('SELECT id_nube FROM productos WHERE tenant_id=? AND id=?').get(tenantId, id) as Fila | undefined;
    return r?.id_nube ?? null;
  }

  asignarIdNube(tenantId: string, id: string, idNube: string): void {
    this.db.prepare('UPDATE productos SET id_nube=? WHERE tenant_id=? AND id=?').run(idNube, tenantId, id);
  }

  /** Ids de los productos activos de la caja (para desactivar los que ya no están en la nube). */
  idsActivos(tenantId: string): string[] {
    return (this.db.prepare('SELECT id FROM productos WHERE tenant_id=? AND activo=1').all(tenantId) as Fila[]).map((r) => r.id);
  }

  obtenerPorId(tenantId: string, id: string): Producto | undefined {
    const r = this._getById.get(tenantId, id) as Fila | undefined;
    return r ? mapear(r) : undefined;
  }

  listar(tenantId: string, limit: number): Producto[] {
    return (this._list.all(tenantId, limit) as Fila[]).map(mapear);
  }

  buscar(tenantId: string, q: string, limit: number): Producto[] {
    const pref = '%' + q.replace(/[%_]/g, '') + '%'; // contiene (no solo empieza con)
    return (this._buscar.all({ t: tenantId, q, pref, lim: limit }) as Fila[]).map(mapear);
  }

  actualizar(
    tenantId: string,
    id: string,
    cambios: Record<string, unknown>,
    updatedAt: string,
  ): Producto | undefined {
    const sets: string[] = [];
    const params: Fila = { tenant_id: tenantId, id, updated_at: updatedAt };
    for (const [clave, col] of Object.entries(ACTUALIZABLES)) {
      if (cambios[clave] !== undefined) {
        let v: any = cambios[clave];
        if (clave === 'exento' || clave === 'activo') v = v ? 1 : 0;
        sets.push(`${col}=@${col}`);
        params[col] = v;
      }
    }
    sets.push('updated_at=@updated_at');
    this.db
      .prepare(`UPDATE productos SET ${sets.join(',')} WHERE tenant_id=@tenant_id AND id=@id`)
      .run(params);
    return this.obtenerPorId(tenantId, id);
  }
}

function mapear(r: Fila): Producto {
  return {
    id: r.id, tenantId: r.tenant_id, codigo: r.codigo, codigoBarras: r.codigo_barras,
    nombre: r.nombre, descripcion: r.descripcion, precioVenta: r.precio_venta,
    unidad: r.unidad, stock: r.stock, stockMinimo: r.stock_minimo,
    exento: !!r.exento, activo: !!r.activo, createdAt: r.created_at, updatedAt: r.updated_at,
  };
}
