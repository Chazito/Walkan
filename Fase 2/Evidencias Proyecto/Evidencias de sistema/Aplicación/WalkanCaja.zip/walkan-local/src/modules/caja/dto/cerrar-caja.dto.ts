import { IsInt, Min } from 'class-validator';

// Lo contado en el cajón al cerrar, en pesos enteros.
export class CerrarCajaDto {
  @IsInt() @Min(0) montoCierre: number;
}
