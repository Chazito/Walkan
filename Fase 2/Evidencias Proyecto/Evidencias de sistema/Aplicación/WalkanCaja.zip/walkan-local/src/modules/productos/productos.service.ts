// Lógica de productos: crear, editar y buscar. Cada cambio se anota en el outbox para la nube.
import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { TenantContext } from '../../common/contexto/tenant.context';
import { OutboxService } from '../../common/sync/outbox.service';
import { transaccionInmediata } from '../../database/unit-of-work';
import { ahora, nuevoId } from '../../common/util/id';
import { ProductosRepository } from './productos.repository';
import { Producto } from './tipos/producto';
import { CrearProductoDto } from './dto/crear-producto.dto';
import { ActualizarProductoDto } from './dto/actualizar-producto.dto';
import { InventarioService } from '../inventario/inventario.service';
import { MotivoMovimiento, TipoMovimiento } from '../inventario/tipos/movimiento';

@Injectable()
export class ProductosService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: ProductosRepository,
    private readonly outbox: OutboxService,
    private readonly tenant: TenantContext,
    private readonly inventario: InventarioService,
  ) {}

  crear(dto: CrearProductoDto): Producto {
    const t = this.tenant.id;
    const now = ahora();
    const producto: Producto = {
      id: nuevoId(), tenantId: t, codigo: dto.codigo,
      codigoBarras: dto.codigoBarras ?? null, nombre: dto.nombre,
      descripcion: dto.descripcion ?? null, precioVenta: dto.precioVenta,
      unidad: dto.unidad ?? 'UN', stock: 0, stockMinimo: dto.stockMinimo ?? 0,
      exento: dto.exento ?? false, activo: true, createdAt: now, updatedAt: now,
    };
    transaccionInmediata(this.db, () => {
      this.repo.crear(producto);
      this.outbox.encolar({
        tenantId: t, entidad: 'producto', entidadId: producto.id,
        operacion: 'INSERT', payload: producto,
      });
      if (dto.stockInicial && dto.stockInicial > 0) {
        const mov = this.inventario.aplicarEnTx({
          tenantId: t, productoId: producto.id, tipo: TipoMovimiento.ENTRADA,
          motivo: MotivoMovimiento.INVENTARIO_INICIAL, cantidad: dto.stockInicial,
        });
        producto.stock = mov.stockResultante;
      }
    })();
    return producto;
  }

  actualizar(id: string, dto: ActualizarProductoDto): Producto {
    const t = this.tenant.id;
    const now = ahora();
    return transaccionInmediata(this.db, (): Producto => {
      if (!this.repo.obtenerPorId(t, id)) {
        throw new NotFoundException(`Producto ${id} no existe.`);
      }
      const actualizado = this.repo.actualizar(t, id, { ...dto }, now) as Producto;
      this.outbox.encolar({
        tenantId: t, entidad: 'producto', entidadId: id,
        operacion: 'UPDATE', payload: actualizado,
      });
      return actualizado;
    })();
  }

  obtener(id: string): Producto {
    const p = this.repo.obtenerPorId(this.tenant.id, id);
    if (!p) throw new NotFoundException(`Producto ${id} no existe.`);
    return p;
  }

  listar(limit = 100): Producto[] {
    return this.repo.listar(this.tenant.id, limit);
  }

  buscar(q: string, limit = 10): Producto[] {
    const term = (q ?? '').trim();
    if (!term) return [];
    return this.repo.buscar(this.tenant.id, term, Math.min(limit, 10));
  }
}
