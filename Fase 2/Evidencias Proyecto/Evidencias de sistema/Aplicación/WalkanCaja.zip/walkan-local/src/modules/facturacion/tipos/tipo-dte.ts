/** Tipos de DTE del SII (el valor es el código oficial). */
export const TipoDte = {
  BOLETA: '39',
  FACTURA_AFECTA: '33',
  FACTURA_EXENTA: '34',
  NOTA_CREDITO: '61',
  GUIA_DESPACHO: '52',
} as const;
export type TipoDte = (typeof TipoDte)[keyof typeof TipoDte];

// Una línea del documento. precioUnitario va en pesos, con IVA incluido (precio de góndola).
export interface ItemDte {
  descripcion: string;
  cantidad: number;
  precioUnitario: number;
  exento: boolean;
}
