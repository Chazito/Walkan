// Rutas HTTP de la caja: abrir turno, cerrar turno y ver cuál está abierta.
import { Body, Controller, Get, Post } from '@nestjs/common';
import { CajaService } from './caja.service';
import { AbrirCajaDto } from './dto/abrir-caja.dto';
import { CerrarCajaDto } from './dto/cerrar-caja.dto';

// Endpoints de apertura/cierre de caja que usa la pantalla de venta.
@Controller('caja')
export class CajaController {
  constructor(private readonly caja: CajaService) {}

  @Post('abrir')
  abrir(@Body() dto: AbrirCajaDto) {
    return this.caja.conNombre(this.caja.abrir(dto));
  }

  @Post('cerrar')
  cerrar(@Body() dto: CerrarCajaDto) {
    return this.caja.cerrar(dto);
  }

  @Get('actual')
  actual() {
    return this.caja.actual();
  }
}
