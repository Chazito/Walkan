// Módulo de facturación electrónica: CAF, folios, emisión de DTE y el worker que los manda al SII.
import { Module } from '@nestjs/common';
import { CafRepository } from './caf/caf.repository';
import { CafService } from './caf/caf.service';
import { CafController } from './caf/caf.controller';
import { FoliosRepository } from './folios/folios.repository';
import { FoliosService } from './folios/folios.service';
import { DteRepository } from './dte/dte.repository';
import { DteService } from './dte/dte.service';
import { DteController } from './dte/dte.controller';
import { DteDispatcherService } from './dte/dte-dispatcher.service';
import { SII_CLIENT } from './sii/sii-client.interface';
import { SiiClientSimulado } from './sii/sii-client.simulado';

@Module({
  controllers: [CafController, DteController],
  providers: [
    CafRepository, CafService,
    FoliosRepository, FoliosService,
    DteRepository, DteService, DteDispatcherService,
    // Cuando exista el cliente SII de verdad, se cambia solo esta línea.
    { provide: SII_CLIENT, useClass: SiiClientSimulado },
  ],
  exports: [FoliosService, DteService, CafService],
})
export class FacturacionModule {}
