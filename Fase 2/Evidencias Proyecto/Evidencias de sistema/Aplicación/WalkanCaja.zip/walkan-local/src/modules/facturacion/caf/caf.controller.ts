import { Body, Controller, Get, Post } from '@nestjs/common';
import { CafService } from './caf.service';
import { RegistrarCafDto } from './dto/registrar-caf.dto';

// Cargar un CAF nuevo y ver cuántos folios le quedan a cada uno.
@Controller('caf')
export class CafController {
  constructor(private readonly caf: CafService) {}

  @Post()
  registrar(@Body() dto: RegistrarCafDto) {
    return this.caf.registrar(dto);
  }

  @Get()
  listar() {
    return this.caf.listar();
  }
}
