import { IsInt, IsOptional, IsString, Length, Min } from 'class-validator';

export class AjusteDto {
  @IsString() @Length(1, 60) productoId: string;
  /** Stock absoluto objetivo tras el ajuste. */
  @IsInt() @Min(0) cantidad: number;
  @IsOptional() @IsString() comentario?: string;
}
