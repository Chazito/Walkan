// Worker que vacía la cola sync_outbox hacia la nube, de a una fila y en orden.
import { Inject, Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { CONFIG } from '../../common/config.provider';
import { AppConfig } from '../../config/configuracion';
import { ahora } from '../../common/util/id';
import { SyncRepository } from './sync.repository';
import { SYNC_CLIENT, SyncClient } from './sync-client.interface';

const REINTENTOS_MIN = [1, 2, 5, 15, 60];
const esperaMs = (intentos: number) =>
  REINTENTOS_MIN[Math.min(Math.max(intentos, 1), REINTENTOS_MIN.length) - 1] * 60_000;

/**
 * Vacía sync_outbox hacia la nube en ORDEN ESTRICTO (FIFO por id),
 * unidireccional. Procesa siempre la fila más antigua no enviada; si esa fila
 * no está lista (REINTENTAR no vencido, o ENVIANDO reciente) DETIENE el ciclo:
 * nunca adelanta una fila posterior. Nunca sostiene el tx durante la red.
 */
@Injectable()
export class SyncWorkerService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger('SyncWorker');
  private readonly maxPorCiclo = 100;
  private readonly staleMs = 120_000;
  private timer?: NodeJS.Timeout;
  private procesando = false;

  constructor(
    private readonly repo: SyncRepository,
    @Inject(SYNC_CLIENT) private readonly cloud: SyncClient,
    @Inject(CONFIG) private readonly cfg: AppConfig,
  ) {}

  onModuleInit(): void {
    this.timer = setInterval(() => void this.procesar(), this.cfg.intervaloSyncMs);
    this.timer.unref?.();
  }
  onModuleDestroy(): void {
    if (this.timer) clearInterval(this.timer);
  }

  async procesar(): Promise<void> {
    if (this.procesando) return;
    this.procesando = true;
    try {
      for (let i = 0; i < this.maxPorCiclo; i++) {
        const f = this.repo.masAntiguaNoEnviada();
        if (!f) break; // todo sincronizado

        const now = ahora();
        // ¿La fila más antigua está lista para enviarse?
        if (f.estado === 'REINTENTAR' && f.proximoIntento && f.proximoIntento > now) break;
        if (f.estado === 'ENVIANDO' && Date.now() - Date.parse(f.updatedAt) < this.staleMs) break;

        this.repo.marcar(f.id, { estado: 'ENVIANDO' }, ahora());
        try {
          await this.cloud.enviar([
            { id: f.id, entidad: f.entidad, entidadId: f.entidadId, operacion: f.operacion, payload: JSON.parse(f.payload) },
          ]);
          const n = ahora();
          this.repo.marcar(f.id, { estado: 'ENVIADO', ultimoError: null, proximoIntento: null }, n);
          this.repo.actualizarEstado({ ultimoCursor: f.id, online: 1, ultimoError: null, ultimaSyncOk: n }, n);
        } catch (e) {
          const n = ahora();
          const intentos = f.intentos + 1;
          this.repo.marcar(
            f.id,
            { estado: 'REINTENTAR', intentos, proximoIntento: new Date(Date.now() + esperaMs(intentos)).toISOString(), ultimoError: (e as Error).message },
            n,
          );
          this.repo.actualizarEstado({ online: 0, ultimoError: (e as Error).message }, n);
          this.logger.warn(`Sync detenida en id ${f.id}; reintento en ${esperaMs(intentos) / 60000} min: ${(e as Error).message}`);
          break; // orden estricto: no adelantar filas posteriores
        }
      }
    } finally {
      this.procesando = false;
    }
  }
}
