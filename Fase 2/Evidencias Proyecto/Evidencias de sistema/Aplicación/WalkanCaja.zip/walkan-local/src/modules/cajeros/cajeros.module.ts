// Módulo de cajeros: alta, listado y validación de PIN.
import { Module } from '@nestjs/common';
import { CajerosController } from './cajeros.controller';
import { CajerosService } from './cajeros.service';
import { CajerosRepository } from './cajeros.repository';

// Cajeros y sus PIN. Lo usan Caja (abrir) y Ventas (nombre del cajero).
@Module({
  controllers: [CajerosController],
  providers: [CajerosService, CajerosRepository],
  exports: [CajerosService],
})
export class CajerosModule {}
