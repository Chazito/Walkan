import { Body, Controller, Get, Post } from '@nestjs/common';
import { CajerosService } from './cajeros.service';
import { CrearCajeroDto } from './dto/crear-cajero.dto';

// Crear y listar cajeros. Las respuestas nunca traen el hash del PIN.
@Controller('cajeros')
export class CajerosController {
  constructor(private readonly cajeros: CajerosService) {}

  @Post()
  crear(@Body() dto: CrearCajeroDto) {
    return this.cajeros.crear(dto);
  }

  @Get()
  listar() {
    return this.cajeros.listar();
  }
}
