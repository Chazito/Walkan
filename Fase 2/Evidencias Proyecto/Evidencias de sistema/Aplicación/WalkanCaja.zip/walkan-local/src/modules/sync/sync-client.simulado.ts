import { Injectable, Logger } from '@nestjs/common';
import { CambioSync, SyncClient, SyncResultado } from './sync-client.interface';

/**
 * Cliente de sincronización SIMULADO. No envía a una nube real. Con
 * SYNC_SIMULAR_OFFLINE=true lanza excepción para ver el worker reintentar.
 * La integración real (HTTP a la API cloud) va detrás de esta misma interfaz.
 */
@Injectable()
export class SyncClientSimulado implements SyncClient {
  private readonly logger = new Logger('SyncClientSimulado');

  async enviar(cambios: CambioSync[]): Promise<SyncResultado> {
    if (process.env.SYNC_SIMULAR_OFFLINE === 'true') {
      throw new Error('Nube no disponible (simulación offline).');
    }
    this.logger.log(`Sincronizados ${cambios.length} cambio(s) a la nube (simulado).`);
    return { ok: true };
  }
}
