// Cómo es un producto en el dominio de la caja (camelCase, distinto de las columnas de la base).
export interface Producto {
  id: string;
  tenantId: string;
  codigo: string;
  codigoBarras: string | null;
  nombre: string;
  descripcion: string | null;
  precioVenta: number;
  unidad: string;
  stock: number;
  stockMinimo: number;
  exento: boolean;
  activo: boolean;
  createdAt: string;
  updatedAt: string;
}
