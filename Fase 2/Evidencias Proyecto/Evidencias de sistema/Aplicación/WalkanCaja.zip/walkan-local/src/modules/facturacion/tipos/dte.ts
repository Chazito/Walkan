import { ItemDte, TipoDte } from './tipo-dte';

export type EstadoSii = 'EMITIDO' | 'ACEPTADO' | 'RECHAZADO';

// El documento tributario tal cual se emitió (D-08). `items` es una foto: si
// después el producto cambia de nombre o precio, el DTE no se entera.
export interface DteEmitido {
  id: string;
  tenantId: string;
  ventaId: string | null;
  tipoDte: TipoDte;
  folio: number;
  cafId: string | null;
  rutReceptor: string | null;
  razonReceptor: string | null;
  neto: number;
  iva: number;
  exento: number;
  total: number;
  fechaEmision: string;
  items: ItemDte[];
  xml: string | null;
  trackId: string | null;
  estadoSii: EstadoSii;
  createdAt: string;
  updatedAt: string;
}
