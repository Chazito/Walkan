// Cálculo de neto, IVA y total de un comprobante a partir de sus items.
import { ItemDte } from './tipos/tipo-dte';

export const TASA_IVA = 0.19; // 19% en Chile

export interface MontosDte {
  neto: number;
  iva: number;
  exento: number;
  total: number;
}

/**
 * Calcula los montos del comprobante a partir de sus items. El precio de venta es el
 * precio de góndola, CON IVA INCLUIDO (lo que paga el cliente, como en el panel web).
 * El neto y el IVA se desglosan desde el total afecto. Montos en pesos enteros.
 */
// El desglose se hace UNA vez sobre el total afecto (no línea por línea), igual que
// la nube (total / 1,19), para que caja y panel muestren los mismos números.
export function calcularMontos(items: ItemDte[]): MontosDte {
  let afecto = 0; // suma con IVA incluido
  let exento = 0;
  for (const item of items) {
    const monto = Math.round(item.cantidad * item.precioUnitario);
    if (item.exento) exento += monto;
    else afecto += monto;
  }
  const neto = Math.round(afecto / (1 + TASA_IVA));
  const iva = afecto - neto;
  return { neto, iva, exento, total: afecto + exento };
}
