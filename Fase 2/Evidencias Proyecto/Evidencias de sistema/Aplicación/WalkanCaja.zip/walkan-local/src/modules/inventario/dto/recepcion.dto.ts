// Body para registrar una recepción de mercadería (suma al stock).
import { IsInt, IsOptional, IsString, Length, Min } from 'class-validator';

export class RecepcionDto {
  @IsString() @Length(1, 60) productoId: string;
  @IsInt() @Min(1) cantidad: number;
  @IsOptional() @IsString() comentario?: string;
  @IsOptional() @IsString() referencia?: string;
}
