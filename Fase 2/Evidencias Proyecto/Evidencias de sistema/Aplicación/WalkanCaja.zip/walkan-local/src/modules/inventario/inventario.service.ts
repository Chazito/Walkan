// Mueve el stock (entrada, salida o ajuste) y deja el movimiento anotado en el kardex y en el outbox.
import { ConflictException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { OutboxService } from '../../common/sync/outbox.service';
import { transaccionInmediata } from '../../database/unit-of-work';
import { ahora, nuevoId } from '../../common/util/id';
import { InventarioRepository } from './inventario.repository';
import { EntradaMovimiento, MovimientoStock, TipoMovimiento } from './tipos/movimiento';

@Injectable()
export class InventarioService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: InventarioRepository,
    private readonly outbox: OutboxService,
  ) {}

  /**
   * Aplica un movimiento SIN abrir transacción. Úsalo dentro del tx del llamador
   * (p. ej. la venta), para que stock, kardex y outbox se confirmen juntos.
   */
  aplicarEnTx(e: EntradaMovimiento): MovimientoStock {
    const prod = this.repo.obtenerProducto(e.tenantId, e.productoId);
    if (!prod) throw new NotFoundException(`Producto ${e.productoId} no existe.`);
    if (!prod.activo) throw new ConflictException(`Producto ${e.productoId} está inactivo.`);

    let nuevo: number;
    if (e.tipo === TipoMovimiento.ENTRADA) {
      nuevo = prod.stock + e.cantidad;
    } else if (e.tipo === TipoMovimiento.SALIDA) {
      if (prod.stock < e.cantidad) {
        throw new ConflictException(
          `Stock insuficiente: disponible ${prod.stock}, solicitado ${e.cantidad}.`,
        );
      }
      nuevo = prod.stock - e.cantidad;
    } else {
      nuevo = e.cantidad; // AJUSTE: stock absoluto objetivo
    }
    if (nuevo < 0) throw new ConflictException('El stock no puede quedar negativo.');

    const now = ahora();
    const mov: MovimientoStock = {
      id: nuevoId(), tenantId: e.tenantId, productoId: e.productoId,
      tipo: e.tipo, motivo: e.motivo, cantidad: nuevo - prod.stock,
      stockResultante: nuevo, referencia: e.referencia ?? null,
      comentario: e.comentario ?? null, createdAt: now,
    };

    this.repo.setStock(e.tenantId, e.productoId, nuevo, now);
    this.repo.insertarMovimiento(mov);
    this.outbox.encolar({
      tenantId: e.tenantId, entidad: 'movimiento_stock', entidadId: mov.id,
      operacion: 'INSERT', payload: mov,
    });
    this.outbox.encolar({
      tenantId: e.tenantId, entidad: 'producto', entidadId: e.productoId,
      operacion: 'UPDATE', payload: { id: e.productoId, tenantId: e.tenantId, stock: nuevo, updatedAt: now },
    });
    return mov;
  }

  /** Igual que aplicarEnTx, pero abriendo su propia transacción IMMEDIATE. */
  aplicar(e: EntradaMovimiento): MovimientoStock {
    return transaccionInmediata(this.db, (): MovimientoStock => this.aplicarEnTx(e))();
  }

  listarMovimientos(tenantId: string, productoId: string, limit = 100): MovimientoStock[] {
    return this.repo.listarMovimientos(tenantId, productoId, limit);
  }
}
