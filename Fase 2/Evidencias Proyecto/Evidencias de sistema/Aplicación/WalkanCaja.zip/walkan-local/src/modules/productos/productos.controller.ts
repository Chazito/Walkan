// Rutas de productos: crear, listar, buscar (para el lector de barras), ver y editar.
import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ProductosService } from './productos.service';
import { CrearProductoDto } from './dto/crear-producto.dto';
import { ActualizarProductoDto } from './dto/actualizar-producto.dto';

@Controller('productos')
export class ProductosController {
  constructor(private readonly productos: ProductosService) {}

  @Post()
  crear(@Body() dto: CrearProductoDto) {
    return this.productos.crear(dto);
  }

  @Get()
  listar() {
    return this.productos.listar();
  }

  @Get('buscar')
  buscar(@Query('q') q: string) {
    return this.productos.buscar(q ?? '');
  }

  @Get(':id')
  obtener(@Param('id') id: string) {
    return this.productos.obtener(id);
  }

  @Patch(':id')
  actualizar(@Param('id') id: string, @Body() dto: ActualizarProductoDto) {
    return this.productos.actualizar(id, dto);
  }
}
