// SQL de sync_outbox (la cola de cambios por subir) y de sync_estado (cómo va la última sync).
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { CONFIG } from '../../common/config.provider';
import { AppConfig } from '../../config/configuracion';
import { ahora } from '../../common/util/id';

export interface OutboxRow {
  id: number;
  tenantId: string;
  entidad: string;
  entidadId: string;
  operacion: string;
  payload: string;
  estado: string;
  intentos: number;
  proximoIntento: string | null;
  updatedAt: string;
  createdAt: string;
}

type Fila = Record<string, any>;

@Injectable()
export class SyncRepository {
  private readonly _oldest: Database.Statement;
  private readonly _estadoGet: Database.Statement;

  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    @Inject(CONFIG) cfg: AppConfig,
  ) {
    this.db
      .prepare(
        `INSERT OR IGNORE INTO sync_estado (id, tenant_id, ultimo_cursor, online, updated_at)
         VALUES (1, ?, 0, 0, ?)`,
      )
      .run(cfg.tenantId, ahora());

    // La fila más antigua AÚN NO enviada. Preserva el orden causal: el worker
    // nunca envía una fila posterior mientras esta no esté ENVIADO.
    this._oldest = db.prepare(
      "SELECT * FROM sync_outbox WHERE estado!='ENVIADO' ORDER BY id ASC LIMIT 1",
    );
    this._estadoGet = db.prepare('SELECT * FROM sync_estado WHERE id=1');
  }

  /** ¿Quedan cambios sin subir a la nube? */
  hayPendientes(): boolean {
    return !!this._oldest.get();
  }

  /** Códigos (SKU) con ventas aún no subidas: la nube todavía no las descontó, así que su stock no se pisa (C2). */
  skusConVentasPendientes(): Set<string> {
    const s = new Set<string>();
    for (const r of this.db.prepare("SELECT payload FROM sync_outbox WHERE estado!='ENVIADO' AND entidad='venta'").all() as { payload: string }[]) {
      try { for (const it of JSON.parse(r.payload)?.items ?? []) if (it?.sku) s.add(String(it.sku)); } catch { /* fila rara: no congela nada */ }
    }
    return s;
  }

  /** La nube volvió a responder: los reintentos en espera se adelantan para salir en el próximo ciclo. */
  adelantarReintentos(now: string): void {
    this.db.prepare("UPDATE sync_outbox SET proximo_intento=NULL, updated_at=? WHERE estado='REINTENTAR'").run(now);
  }

  /**
   * C3: la nube ya recibió ventas hasta `ultimoSeq` con OTRA numeración (la base de la caja se restauró de un respaldo
   * viejo o se reinstaló conservando el vínculo). Las filas aún no enviadas pasan a numerarse después de `ultimoSeq`,
   * en el mismo orden, y vuelven a PENDIENTE. Se pasa por ids negativos para no chocar con la PK a mitad del UPDATE.
   * Devuelve cuántas filas se renumeraron.
   */
  renumerarPendientes(ultimoSeq: number): number {
    return this.db.transaction(() => {
      const r = this.db.prepare("SELECT MIN(id) AS min, COUNT(*) AS n FROM sync_outbox WHERE estado!='ENVIADO'").get() as { min: number | null; n: number };
      if (!r.n || r.min == null || r.min > ultimoSeq) return 0;
      const ocupado = (this.db.prepare('SELECT COALESCE(MAX(id),0) AS m FROM sync_outbox').get() as { m: number }).m;
      const desplazo = Math.max(ultimoSeq, ocupado) + 1 - r.min;
      this.db.prepare("UPDATE sync_outbox SET id=-id WHERE estado!='ENVIADO'").run();
      this.db.prepare("UPDATE sync_outbox SET id=-id+?, estado='PENDIENTE', proximo_intento=NULL, updated_at=? WHERE id<0").run(desplazo, ahora());
      // AUTOINCREMENT: las ventas nuevas siguen después de la última renumerada.
      this.db.prepare("UPDATE sqlite_sequence SET seq=(SELECT MAX(id) FROM sync_outbox) WHERE name='sync_outbox'").run();
      return r.n;
    })();
  }

  masAntiguaNoEnviada(): OutboxRow | undefined {
    const r = this._oldest.get() as Fila | undefined;
    if (!r) return undefined;
    return {
      id: r.id, tenantId: r.tenant_id, entidad: r.entidad, entidadId: r.entidad_id,
      operacion: r.operacion, payload: r.payload, estado: r.estado, intentos: r.intentos,
      proximoIntento: r.proximo_intento, updatedAt: r.updated_at, createdAt: r.created_at,
    };
  }

  marcar(
    id: number,
    campos: { estado?: string; intentos?: number; proximoIntento?: string | null; ultimoError?: string | null },
    now: string,
  ): void {
    const sets: string[] = [];
    const params: Fila = { id, now };
    const mapa: Record<string, string> = {
      estado: 'estado', intentos: 'intentos', proximoIntento: 'proximo_intento', ultimoError: 'ultimo_error',
    };
    for (const clave of Object.keys(mapa)) {
      if ((campos as Fila)[clave] !== undefined) {
        sets.push(`${mapa[clave]}=@${clave}`);
        params[clave] = (campos as Fila)[clave];
      }
    }
    sets.push('updated_at=@now');
    this.db.prepare(`UPDATE sync_outbox SET ${sets.join(',')} WHERE id=@id`).run(params);
  }

  actualizarEstado(
    campos: { ultimoCursor?: number; online?: number; ultimoError?: string | null; ultimaSyncOk?: string },
    now: string,
  ): void {
    const sets: string[] = [];
    const params: Fila = { now };
    const mapa: Record<string, string> = {
      ultimoCursor: 'ultimo_cursor', online: 'online', ultimoError: 'ultimo_error', ultimaSyncOk: 'ultima_sync_ok',
    };
    for (const clave of Object.keys(mapa)) {
      if ((campos as Fila)[clave] !== undefined) {
        sets.push(`${mapa[clave]}=@${clave}`);
        params[clave] = (campos as Fila)[clave];
      }
    }
    sets.push('updated_at=@now');
    this.db.prepare(`UPDATE sync_estado SET ${sets.join(',')} WHERE id=1`).run(params);
  }

  obtenerEstado(): Record<string, unknown> {
    return this._estadoGet.get() as Record<string, unknown>;
  }
}
