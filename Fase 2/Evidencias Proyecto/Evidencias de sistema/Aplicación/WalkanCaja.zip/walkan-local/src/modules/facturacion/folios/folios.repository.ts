// Guarda en folios_usados cada folio que se gastó.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../../database/sqlite.provider';

export interface UsoFolio {
  tenantId: string;
  cafId: string;
  tipoDte: string;
  folio: number;
  dteEmitidoId: string | null;
  ventaId: string | null;
  createdAt: string;
}

// Bitácora de folios gastados: qué folio de qué CAF se usó en qué DTE/venta.
// Sirve de respaldo ante el SII y el UNIQUE de la tabla ataja duplicados.
@Injectable()
export class FoliosRepository {
  private readonly _insertUso: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this._insertUso = db.prepare(
      `INSERT INTO folios_usados
         (tenant_id, caf_id, tipo_dte, folio, dte_emitido_id, venta_id, created_at)
       VALUES (@tenantId, @cafId, @tipoDte, @folio, @dteEmitidoId, @ventaId, @createdAt)`,
    );
  }

  registrarUso(u: UsoFolio): void {
    this._insertUso.run(u);
  }
}
