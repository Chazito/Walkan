// Endpoint de salud de la caja: lo pega systemd o uno mismo para ver si el proceso y la base están vivos.
import { Controller, Get, Inject } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from './database/sqlite.provider';

@Controller()
export class AppController {
  constructor(@Inject(SQLITE) private readonly db: Database.Database) {}

  /** Salud del proceso y estado de la base (para systemd / diagnóstico). */
  @Get('salud')
  salud() {
    const row = this.db
      .prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type='table'")
      .get() as { n: number };
    return {
      ok: true,
      motor: 'sqlite',
      journal_mode: this.db.pragma('journal_mode', { simple: true }),
      synchronous: this.db.pragma('synchronous', { simple: true }),
      foreign_keys: this.db.pragma('foreign_keys', { simple: true }),
      tablas: row.n,
    };
  }
}
