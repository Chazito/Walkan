/* Prueba de humo del Módulo 1: crea el esquema, verifica tablas y PRAGMAs,
   y comprueba que la migración es idempotente. No arranca el servidor Nest. */
import { cargarConfig } from '../config/configuracion';
import { abrirBaseDeDatos } from '../database/sqlite.provider';
import { ejecutarMigraciones } from '../database/migrator';
import { SyncRepository } from '../modules/sync/sync.repository';

// Tablas que tienen que existir después de correr las migraciones.
const ESPERADAS = [
  'productos', 'movimientos_stock', 'cajas_sesion', 'ventas', 'venta_items',
  'cajeros', 'caf', 'folios_usados', 'dte_emitidos', 'dte_cola',
  'sync_outbox', 'sync_estado', '_migraciones',
];

function main(): void {
  const cfg = cargarConfig();
  const db = abrirBaseDeDatos(cfg);
  const aplicadas = ejecutarMigraciones(db, cfg.migrationsDir, (m) => console.log(' -', m));

  const tablas = (
    db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all() as { name: string }[]
  ).map((r) => r.name);
  const jm = db.pragma('journal_mode', { simple: true });
  const sy = db.pragma('synchronous', { simple: true });
  const fk = db.pragma('foreign_keys', { simple: true });

  console.log('migraciones aplicadas:', aplicadas.length);
  console.log('journal_mode:', jm, '| synchronous:', sy, '(1=NORMAL) | foreign_keys:', fk);
  console.log('tablas:', tablas.join(', '));

  const faltan = ESPERADAS.filter((t) => !tablas.includes(t));
  const okPragmas = jm === 'wal' && sy === 1 && fk === 1;
  if (faltan.length || !okPragmas) {
    console.error('FALLO — faltan tablas:', faltan, '| pragmas ok:', okPragmas);
    process.exit(1);
  }

  const otra = ejecutarMigraciones(db, cfg.migrationsDir);
  if (otra.length !== 0) {
    console.error('FALLO — la migración no es idempotente');
    process.exit(1);
  }
  console.log('OK — esquema creado y migración idempotente');

  // C1/C2/C3 (nov-2026). Dentro de un SAVEPOINT que se deshace al final: no deja filas de prueba en la base real.
  const falla = (m: string) => { console.error('FALLO — ' + m); process.exit(1); };
  const col = (db.prepare("SELECT \"notnull\" AS nn FROM pragma_table_info('venta_items') WHERE name='producto_id'").get() as { nn: number });
  if (col.nn !== 0) falla('venta_items.producto_id debe aceptar NULL (línea genérica, C1)');
  db.exec('SAVEPOINT smoke');
  try {
    const repo = new SyncRepository(db, cfg);
    const now = new Date().toISOString();
    const ins = db.prepare("INSERT INTO sync_outbox (tenant_id, entidad, entidad_id, operacion, payload, estado, created_at, updated_at) VALUES ('t',?,?,'INSERT',?,?,?,?)");
    const base = (db.prepare('SELECT COALESCE(MAX(id),0) AS m FROM sync_outbox').get() as { m: number }).m;
    ins.run('venta', 'v-env', JSON.stringify({ items: [{ sku: 'ENVIADO' }] }), 'ENVIADO', now, now);
    ins.run('venta', 'v-1', JSON.stringify({ items: [{ sku: 'A1' }, { sku: 'B2' }] }), 'REINTENTAR', now, now);
    ins.run('producto', 'p-1', JSON.stringify({ sku: 'NO-CUENTA' }), 'PENDIENTE', now, now);
    const skus = [...repo.skusConVentasPendientes()].sort().join(',');
    if (skus !== 'A1,B2') falla(`C2: solo se congelan los SKU con ventas sin subir (salió "${skus}")`);
    // La nube ya tiene hasta base+50 con otra numeración: las 2 pendientes pasan a base+51 y base+52, en orden.
    const n = repo.renumerarPendientes(base + 50);
    const ids = (db.prepare('SELECT id, entidad_id AS e, estado FROM sync_outbox WHERE id>? ORDER BY id').all(base) as { id: number; e: string; estado: string }[]);
    const esperado = `${base + 1}:v-env:ENVIADO,${base + 51}:v-1:PENDIENTE,${base + 52}:p-1:PENDIENTE`;
    const salio = ids.map((r) => `${r.id}:${r.e}:${r.estado}`).join(',');
    if (n !== 2 || salio !== esperado) falla(`C3: renumerar la cola (esperado ${esperado}, salió ${salio})`);
    if (repo.renumerarPendientes(base + 50) !== 0) falla('C3: renumerar dos veces no debe mover nada');
  } finally {
    db.exec('ROLLBACK TO smoke; RELEASE smoke');
  }
  console.log('OK — venta genérica, stock congelado por SKU y cola renumerada');
  process.exit(0);
}

main();
