// Módulo global: lo que cualquier otro módulo necesita sin tener que importarlo a mano.
import { Global, Module } from '@nestjs/common';
import { configProvider, CONFIG } from './config.provider';
import { TenantContext } from './contexto/tenant.context';
import { OutboxService } from './sync/outbox.service';

/** Provee configuración, contexto de tenant y el outbox de sincronización. */
@Global()
@Module({
  providers: [configProvider, TenantContext, OutboxService],
  exports: [CONFIG, TenantContext, OutboxService],
})
export class CommonModule {}
