// Cola de salida (outbox): acá se anotan los cambios locales que después se suben a la nube.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ahora } from '../util/id';

export type OperacionOutbox = 'INSERT' | 'UPDATE' | 'DELETE';

export interface CambioOutbox {
  tenantId: string;
  entidad: string;
  entidadId: string;
  operacion: OperacionOutbox;
  payload: unknown;
}

/**
 * Encola un cambio para sincronizar a la nube. DEBE llamarse dentro de la misma
 * transacción que produce el cambio (misma conexión síncrona de better-sqlite3),
 * para que dato y outbox se confirmen o se reviertan juntos.
 *
 * Básicamente es el patrón outbox (D-11): la caja nunca le habla directo a la
 * nube al vender; deja anotado qué cambió y el SyncWorker lo manda cuando haya
 * internet. Así vender offline da lo mismo.
 */
@Injectable()
export class OutboxService {
  private readonly insert: Database.Statement;

  constructor(@Inject(SQLITE) db: Database.Database) {
    this.insert = db.prepare(
      `INSERT INTO sync_outbox
         (tenant_id, entidad, entidad_id, operacion, payload, estado, created_at, updated_at)
       VALUES (@tenantId, @entidad, @entidadId, @operacion, @payload, 'PENDIENTE', @now, @now)`,
    );
  }

  // El payload se guarda como foto completa en JSON, no como diff: la nube lo
  // aplica tal cual sin tener que recalcular nada.
  encolar(cambio: CambioOutbox): void {
    this.insert.run({
      tenantId: cambio.tenantId,
      entidad: cambio.entidad,
      entidadId: cambio.entidadId,
      operacion: cambio.operacion,
      payload: JSON.stringify(cambio.payload),
      now: ahora(),
    });
  }
}
