import { randomUUID } from 'crypto';

/** UUID para entidades raíz (únicos globales, listos para sincronizar). */
export const nuevoId = (): string => randomUUID();

/** Timestamp ISO-8601 UTC. */
export const ahora = (): string => new Date().toISOString();
