import { Inject, Injectable } from '@nestjs/common';
import { AppConfig } from '../../config/configuracion';
import { CONFIG } from '../config.provider';

/** Tenant fijo (mono-tenant). Centraliza de dónde sale el tenant_id. */
@Injectable()
export class TenantContext {
  constructor(@Inject(CONFIG) private readonly cfg: AppConfig) {}
  get id(): string {
    return this.cfg.tenantId;
  }
}
