import { AppConfig, cargarConfig } from '../config/configuracion';

// La config inyectable, para no andar leyendo process.env por todos lados.
export const CONFIG = Symbol('CONFIG');

export const configProvider = {
  provide: CONFIG,
  useFactory: (): AppConfig => cargarConfig(),
};
