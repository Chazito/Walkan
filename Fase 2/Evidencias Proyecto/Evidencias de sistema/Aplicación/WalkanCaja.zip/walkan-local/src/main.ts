// Punto de entrada de la caja: levanta Nest sobre Fastify y sirve también la interfaz de venta.
import 'reflect-metadata';
import { join } from 'path';
import { NestFactory } from '@nestjs/core';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { Logger, ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';
import { cargarConfig } from './config/configuracion';

// Arranque de la caja. Fastify y no Express porque en el TV Box cada MB cuenta (D-10).
async function bootstrap(): Promise<void> {
  const config = cargarConfig();
  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter(),
  );
  // whitelist + forbidNonWhitelisted: si llega un campo que el DTO no conoce,
  // se rechaza al tiro en vez de colarse callado hasta la base.
  app.useGlobalPipes(
    new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }),
  );
  // Interfaz de venta servida por el mismo Node (sin CDN). index.html en /.
  app.useStaticAssets({ root: join(process.cwd(), 'public'), prefix: '/' });
  // Solo localhost: el kiosko abre localhost:3000 y la API no tiene login propio. Escuchando en 0.0.0.0
  // cualquiera en el WiFi del local podía vender, cambiar precios, abrir el cajón o revincular la caja.
  // HOST=0.0.0.0 la abre a propósito (diagnóstico), sabiendo ese riesgo.
  const host = process.env.HOST || '127.0.0.1';
  await app.listen(config.port, host);
  new Logger('Bootstrap').log(
    `Walkan on-premise en http://${host}:${config.port} (tenant ${config.tenantId})`,
  );
}

void bootstrap();
