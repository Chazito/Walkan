import type Database from 'better-sqlite3';

/**
 * PRAGMAs de la conexión SQLite, en un solo lugar.
 * synchronous=NORMAL (definido en decisiones D-01): latencia mínima por venta;
 * WAL no corrompe la base ante corte de luz.
 */
export function aplicarPragmas(db: Database.Database): void {
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  // Si el worker tiene el lock justo cuando entra una venta, ésta espera hasta 5 s
  // en vez de reventar con SQLITE_BUSY.
  db.pragma('busy_timeout = 5000');
}
