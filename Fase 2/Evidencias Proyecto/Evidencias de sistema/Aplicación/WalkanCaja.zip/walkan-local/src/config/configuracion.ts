import { resolve } from 'path';

// Datos del negocio que emite las boletas; salen en cada DTE.
export interface DatosEmisor {
  rut: string;
  razonSocial: string;
  direccion: string;
}

export interface AppConfig {
  port: number;
  dbPath: string;
  tenantId: string;
  migrationsDir: string;
  intervaloDteMs: number;
  intervaloSyncMs: number;
  intervaloCatalogoMs: number;
  folioAlerta: number;
  nubeUrl: string;
  emisor: DatosEmisor;
}

/** Config desde variables de entorno (.env). Rutas resueltas contra el cwd. */
export function cargarConfig(): AppConfig {
  return {
    port: parseInt(process.env.PORT ?? '3000', 10),
    dbPath: resolve(process.env.DB_PATH ?? './data/walkan.db'),
    tenantId: process.env.TENANT_ID ?? 'local',
    migrationsDir: resolve(process.env.MIGRATIONS_DIR ?? './migrations'),
    intervaloDteMs: parseInt(process.env.DTE_INTERVALO_MS ?? '20000', 10),
    intervaloSyncMs: parseInt(process.env.SYNC_INTERVALO_MS ?? '30000', 10),
    // Cada cuánto la caja pide el catálogo (y el estado de bloqueo) a la nube.
    intervaloCatalogoMs: parseInt(process.env.CATALOGO_INTERVALO_MS ?? '120000', 10),
    // Bajo este número de folios disponibles la caja empieza a avisar (D-04).
    folioAlerta: parseInt(process.env.FOLIOS_ALERTA ?? '100', 10),
    // Sin el slash final, para armar las rutas con `${nubeUrl}/...` sin dobles barras.
    nubeUrl: (process.env.NUBE_URL ?? 'http://localhost:4000').replace(/\/+$/, ''),
    emisor: {
      rut: process.env.EMISOR_RUT ?? '',
      razonSocial: process.env.EMISOR_RAZON ?? '',
      direccion: process.env.EMISOR_DIRECCION ?? '',
    },
  };
}
