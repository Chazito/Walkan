// Acá se juntan todos los módulos de la caja (ventas, inventario, DTE, sync, etc.).
import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { DatabaseModule } from './database/database.module';
import { CommonModule } from './common/common.module';
import { InventarioModule } from './modules/inventario/inventario.module';
import { ProductosModule } from './modules/productos/productos.module';
import { CajerosModule } from './modules/cajeros/cajeros.module';
import { CajaModule } from './modules/caja/caja.module';
import { FacturacionModule } from './modules/facturacion/facturacion.module';
import { VentasModule } from './modules/ventas/ventas.module';
import { SyncModule } from './modules/sync/sync.module';
import { DispositivoModule } from './modules/dispositivo/dispositivo.module';
import { RedModule } from './modules/red/red.module';
import { PagosModule } from './modules/pagos/pagos.module';
import { AppController } from './app.controller';

// Módulo raíz. ScheduleModule es el que mueve los workers de DTE y sync en segundo plano.
@Module({
  imports: [
    ScheduleModule.forRoot(),
    DatabaseModule,
    CommonModule,
    InventarioModule,
    ProductosModule,
    CajerosModule,
    CajaModule,
    FacturacionModule,
    VentasModule,
    SyncModule,
    DispositivoModule,
    RedModule,
    PagosModule,
  ],
  controllers: [AppController],
})
export class AppModule {}
