# Walkan Caja (app local / on-premise) — cómo hacerla andar

Esta es la caja de Walkan: el punto de venta que corre en el mismo local (en producción, un TV Box con
Linux conectado a una pantalla, lector de códigos y cajón). Funciona **sin internet**: vende, descuenta
stock y numera las boletas con sus folios aunque se caiga la conexión. Cuando vuelve internet, manda las
ventas a la web (la nube, que va en el otro zip) y baja el catálogo y los cajeros del panel.

## Qué necesitas

| Cosa | Versión | Para qué |
|---|---|---|
| Node.js | 20 o superior (probado con 22 y 24) | Corre la app |
| npm | el que viene con Node | Instala las librerías |
| Internet (solo para `npm install`) | — | Bajar las librerías |
| Navegador (Chrome, Edge, Firefox) | cualquiera reciente | La pantalla de venta es una página web local |

No hay que instalar base de datos: usa **SQLite** (archivo `data/walkan.db`) a través de `better-sqlite3`.
La web **no** es obligatoria: la caja puede vender sola. Solo hace falta para vincularla y sincronizar.

### Librerías que usa (se instalan solas con `npm install`)

- **NestJS 10** (`@nestjs/core`, `@nestjs/common`, `@nestjs/platform-fastify`): el framework del backend.
- **@nestjs/schedule**: los trabajos que corren cada cierto rato (cola de boletas al SII, sincronización con la nube, catálogo).
- **Fastify** + **@fastify/static**: servidor HTTP liviano que además sirve la pantalla de venta (`public/`).
- **better-sqlite3**: la base de datos SQLite.
- **class-validator** / **class-transformer**: validan lo que llega a la API.
- **reflect-metadata**, **rxjs**: los pide NestJS.
- De desarrollo: **typescript**, **@nestjs/cli** (compila), y los `@types/*`.
- La pantalla de venta no usa frameworks: HTML, CSS y JavaScript a mano, más `public/vendor/qrcode.js` para dibujar QR.

## Paso a paso (en un computador cualquiera)

Abre una terminal dentro de esta carpeta (`walkan-local`):

```bash
# 1. Instalar librerías
npm install

# 2. Compilar (TypeScript → dist/)
npm run build

# 3. Crear la base con datos de prueba (cajero con PIN 1234, 10 productos con stock y folios de boleta)
node base-de-datos/crear-bd.js --seed

# 4. Arrancar
npm start
```

Abre **http://localhost:3000** en el navegador.

- En la bienvenida puedes elegir **Usar sin conexión · vincular después** para vender de una con los datos de prueba.
- Entra con el cajero **Cajero Demo**, PIN **1234**, abre la caja y vende (puedes buscar por nombre o código, ej. `P001`).

Si te saltas el paso 3, la app crea la base vacía sola al arrancar y en la primera pantalla te pide crear el
primer cajero; los productos llegan desde la web al vincularla.

Para desarrollo, en vez de `build` + `start` puedes usar `npm run start:dev` (recompila solo al guardar).
`npm run smoke` (después de compilar) revisa que la base tenga todas sus tablas y que las migraciones no se repitan.

### Vincularla con la web

1. Arranca la web (zip de Walkan Web) en http://localhost:4000 y carga sus datos de prueba.
2. Arranca la caja. Por defecto ya apunta a `http://localhost:4000`.
3. En la bienvenida elige **Vincular caja** y entra con `admin@walkan.cl` / `walkan123`.
4. Listo: la caja baja el catálogo y los cajeros del panel, y sus ventas aparecen en el panel web.
   Desde ahí mandan los datos de la web (los productos y cajeros del seed local dejan de usarse).

## Base de datos

- `migrations/` tiene los scripts SQL numerados (001 a 006). La app los corre sola al arrancar, en orden,
  y anota cuáles ya aplicó en la tabla `_migraciones`.
- `base-de-datos/esquema-completo.sql`: todas las migraciones juntas en un solo archivo (sirve para ver el
  esquema completo o crear la base con el cliente `sqlite3`).
- `base-de-datos/seed.sql`: los datos de prueba (cajero, productos con su stock inicial y un rango de folios).
- `base-de-datos/crear-bd.js`: crea la base corriendo esos archivos, sin necesitar el cliente sqlite3.
  `node base-de-datos/crear-bd.js` solo tablas; con `--seed` también los datos de prueba.
- Para partir de cero: detén la app y borra `data/walkan.db` (y los `-wal` / `-shm`).

## Configuración (opcional)

La caja lee la configuración de variables de entorno. Para probar no hace falta tocar nada. Si quieres
cambiar algo, defínelas antes de `npm start` (en PowerShell: `$env:PORT=3001; npm start`).
En el TV Box salen del archivo `/opt/walkan/.env` (ver `.env.example`, lo usa el servicio systemd).

| Variable | Por defecto | Qué hace |
|---|---|---|
| `PORT` | `3000` | Puerto de la caja |
| `DB_PATH` | `./data/walkan.db` | Dónde queda la base |
| `NUBE_URL` | `http://localhost:4000` | Dirección de la web con la que se sincroniza |
| `TENANT_ID` | `local` | Identificador interno del negocio en la base local |
| `EMISOR_RUT` / `EMISOR_RAZON` / `EMISOR_DIRECCION` | vacías | Datos del negocio que salen en la boleta |
| `FOLIOS_ALERTA` | `100` | Con menos folios que esto, la caja avisa |
| `DTE_INTERVALO_MS` / `SYNC_INTERVALO_MS` / `CATALOGO_INTERVALO_MS` | 20 s / 30 s / 120 s | Cada cuánto corre la cola de boletas, la sincronización y el catálogo |
| `PERIFERICOS_MODO` | `simulado` | Máquina de tarjetas y cajón: simulados hasta conectar equipos reales |
| `SII_SIMULAR_OFFLINE` / `SYNC_SIMULAR_OFFLINE` | — | `true` simula que se cayó el SII o internet (para probar el modo sin conexión) |
| `HOST` | `127.0.0.1` | Solo escucha en el mismo equipo. `0.0.0.0` la abre a la red (solo para diagnóstico: la API no tiene login) |

## Instalarla en el TV Box (producción)

La carpeta `deploy/` tiene todo lo del equipo real (Debian aarch64): servicio systemd de la app
(`walkan.service`), el kiosko que abre Chromium a pantalla completa (`walkan-kiosk.service`, `kiosko.sh`,
`chromium-walkan.json`) y la configuración de red, HDMI y USB. Con Node 20+ instalado en el equipo:

```bash
sudo bash deploy/install.sh
```

Copia la app a `/opt/walkan`, instala y compila ahí mismo (better-sqlite3 se compila para ARM), crea el
usuario de servicio, deja el `.env` y activa los servicios. Después edita `/opt/walkan/.env` (sobre todo
`NUBE_URL` y los datos del emisor) y reinicia con `sudo systemctl restart walkan`.
