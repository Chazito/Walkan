import { deflateRawSync } from 'zlib';

// ZIP mínimo (sin librerías): varios archivos comprimidos con deflate, nombres en UTF-8. Lo usa la descarga de
// "Mis datos". Formato: por cada archivo una cabecera local + datos; al final el directorio central y su cierre.
// ponytail: todo en memoria y sin ZIP64 (hasta 4 GB y 65.535 archivos); sobra para los datos de un negocio.

const TABLA_CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(b: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < b.length; i++) c = TABLA_CRC[(c ^ b[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

export interface ArchivoZip { nombre: string; contenido: Buffer | string }

export function crearZip(archivos: ArchivoZip[], fecha: Date = new Date()): Buffer {
  // Fecha y hora en formato MS-DOS (el que guarda el ZIP).
  const hora = (fecha.getHours() << 11) | (fecha.getMinutes() << 5) | (fecha.getSeconds() >> 1);
  const dia = ((Math.max(fecha.getFullYear(), 1980) - 1980) << 9) | ((fecha.getMonth() + 1) << 5) | fecha.getDate();
  const locales: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  for (const a of archivos) {
    const nombre = Buffer.from(a.nombre, 'utf8');
    const datos = Buffer.isBuffer(a.contenido) ? a.contenido : Buffer.from(a.contenido, 'utf8');
    const comprimido = deflateRawSync(datos);
    const crc = crc32(datos);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);       // firma de cabecera local
    local.writeUInt16LE(20, 4);               // versión necesaria (2.0)
    local.writeUInt16LE(0x0800, 6);           // bit 11: nombres en UTF-8
    local.writeUInt16LE(8, 8);                // método: deflate
    local.writeUInt16LE(hora, 10);
    local.writeUInt16LE(dia, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(comprimido.length, 18);
    local.writeUInt32LE(datos.length, 22);
    local.writeUInt16LE(nombre.length, 26);   // (28: largo del campo extra = 0)
    locales.push(local, nombre, comprimido);

    const c = Buffer.alloc(46);
    c.writeUInt32LE(0x02014b50, 0);           // firma del directorio central
    c.writeUInt16LE(20, 4);                   // versión que lo creó
    c.writeUInt16LE(20, 6);                   // versión necesaria
    c.writeUInt16LE(0x0800, 8);
    c.writeUInt16LE(8, 10);
    c.writeUInt16LE(hora, 12);
    c.writeUInt16LE(dia, 14);
    c.writeUInt32LE(crc, 16);
    c.writeUInt32LE(comprimido.length, 20);
    c.writeUInt32LE(datos.length, 24);
    c.writeUInt16LE(nombre.length, 28);       // (30–41: extra, comentario, disco y atributos = 0)
    c.writeUInt32LE(offset, 42);              // dónde empieza su cabecera local
    central.push(c, nombre);

    offset += local.length + nombre.length + comprimido.length;
  }
  const directorio = Buffer.concat(central);
  const fin = Buffer.alloc(22);
  fin.writeUInt32LE(0x06054b50, 0);           // firma de fin del directorio central
  fin.writeUInt16LE(archivos.length, 8);      // archivos en este disco
  fin.writeUInt16LE(archivos.length, 10);     // archivos en total
  fin.writeUInt32LE(directorio.length, 12);
  fin.writeUInt32LE(offset, 16);              // dónde empieza el directorio central
  return Buffer.concat([...locales, directorio, fin]);
}
