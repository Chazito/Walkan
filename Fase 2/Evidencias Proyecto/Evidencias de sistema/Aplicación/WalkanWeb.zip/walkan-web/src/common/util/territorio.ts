import { BadRequestException } from '@nestjs/common';
import { readFileSync } from 'fs';
import { join } from 'path';

// Regiones y comunas de Chile con su Código Único Territorial (CUT). Es el mismo archivo que usa el
// navegador para los selectores (public/geo/territorio-cl.json): una sola lista para ambos lados.
type Comuna = { cut: string; nombre: string; regionId: string; region: string };
let indice: Map<string, Comuna> | null = null;

function cargar(): Map<string, Comuna> {
  if (!indice) {
    const d = JSON.parse(readFileSync(join(process.cwd(), 'public', 'geo', 'territorio-cl.json'), 'utf8')) as {
      regiones: { id: string; nombre: string; comunas: [string, string][] }[];
    };
    indice = new Map();
    for (const r of d.regiones) for (const [cut, nombre] of r.comunas) indice.set(cut, { cut, nombre, regionId: r.id, region: r.nombre });
  }
  return indice;
}

export function comunaPorCut(cut: string): Comuna | undefined {
  return cargar().get(cut);
}

/** Normaliza la ubicación que llega de un formulario. Todo es opcional, pero si viene la calle
 *  tiene que venir la comuna (una dirección sin comuna no sirve para llegar al local). */
export function normalizarUbicacion(d: { comunaCut?: string; comuna?: string; direccion?: string }) {
  const direccion = (d.direccion ?? '').replace(/\s+/g, ' ').trim();
  if (d.comunaCut) {
    const c = comunaPorCut(d.comunaCut);
    if (!c) throw new BadRequestException('Elige una comuna de la lista.');
    return { comuna: c.nombre, comunaCut: c.cut, region: c.region, direccion };
  }
  if (direccion) throw new BadRequestException('Elige la región y la comuna del local.');
  // Formularios antiguos que mandan la comuna como texto libre: se guarda tal cual.
  return { comuna: (d.comuna ?? '').trim(), comunaCut: null, region: null, direccion: '' };
}
