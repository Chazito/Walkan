import { registerDecorator, ValidationOptions } from 'class-validator';

/** RUT chileno con dígito verificador (módulo 11). Acepta puntos y guion: 12.345.678-5 o 12345678-5. */
export function rutValido(v: string): boolean {
  const m = String(v).replace(/\./g, '').trim().toUpperCase().match(/^(\d{1,8})-?([\dK])$/);
  if (!m) return false;
  let suma = 0, mul = 2;
  for (let i = m[1].length - 1; i >= 0; i--) { suma += Number(m[1][i]) * mul; mul = mul === 7 ? 2 : mul + 1; }
  const dv = 11 - (suma % 11);
  return m[2] === (dv === 11 ? '0' : dv === 10 ? 'K' : String(dv));
}

/** Decorador: RUT válido, o vacío (el campo es opcional). */
export function Rut(opts?: ValidationOptions) {
  return function (obj: object, propertyName: string) {
    registerDecorator({
      name: 'rut', target: obj.constructor, propertyName, options: { message: 'RUT no válido (revisa el dígito verificador).', ...opts },
      validator: { validate: (v: unknown) => v === '' || (typeof v === 'string' && rutValido(v)) },
    });
  };
}
