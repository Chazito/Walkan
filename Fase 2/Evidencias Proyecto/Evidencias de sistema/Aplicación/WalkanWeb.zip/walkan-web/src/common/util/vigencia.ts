/**
 * Vigencia del plan de un negocio. El plan se paga por mes adelantado (pago manual con Flow): cada pago cubre
 * DIAS_PERIODO días. Si vence y no se paga, el panel sigue DIAS_GRACIA días y después queda en pausa: el dueño
 * solo puede entrar a Mi cuenta (pagar, descargar sus datos, cerrar la cuenta) y las cajas dejan de sincronizar
 * (siguen vendiendo en el local y suben sus ventas cuando la cuenta vuelve a estar al día).
 * Todo se calcula con fechas; no hay un estado guardado que se pueda desincronizar.
 */
const DIA = 86_400_000;
export const DIAS_PERIODO = 30;        // días que cubre cada pago
export const DIAS_GRACIA = 5;          // días que el panel sigue funcionando después de vencer
export const DIAS_RENOVAR_ANTES = 7;   // desde cuántos días antes de vencer se puede pagar la renovación
export const DIAS_AVISO_CORREO = 3;    // el correo de aviso sale estos días antes de vencer
export const DIAS_PARA_ELIMINAR = 30;  // plazo para arrepentirse después de pedir que se elimine la cuenta

export type Situacion =
  | 'sin-plan'    // cuenta creada por el equipo Walkan, sin pagos en línea: no vence
  | 'al-dia'
  | 'por-vencer'  // faltan DIAS_RENOVAR_ANTES días o menos: ya se puede renovar
  | 'gracia'      // venció, pero aún corren los días de gracia
  | 'vencida'     // en pausa por falta de pago (o plan cancelado cuyo período ya terminó)
  | 'cancelada'   // el dueño canceló: acceso hasta el fin del período pagado
  | 'cerrada';    // el dueño pidió eliminar la cuenta: en pausa hasta que se borre o la recupere

export interface DatosVigencia { periodoFin: string | null; canceladoEn: string | null; eliminarEn: string | null }
export interface Vigencia {
  situacion: Situacion;
  /** false = panel y sincronización de cajas en pausa. */
  operativa: boolean;
  vigenteHasta: string | null;
  /** En gracia: cuándo queda en pausa si no se paga. */
  pausaEl: string | null;
  eliminarEn: string | null;
  cancelado: boolean;
  puedeRenovar: boolean;
}

export function calcularVigencia(d: DatosVigencia, ahoraMs: number = Date.now()): Vigencia {
  const fin = d.periodoFin ? Date.parse(d.periodoFin) : NaN;
  const base = { vigenteHasta: d.periodoFin, pausaEl: null, eliminarEn: d.eliminarEn, cancelado: !!d.canceladoEn };
  if (d.eliminarEn) return { ...base, situacion: 'cerrada', operativa: false, puedeRenovar: false };
  if (isNaN(fin)) return { ...base, situacion: 'sin-plan', operativa: true, cancelado: false, puedeRenovar: false };
  if (ahoraMs <= fin) {
    const puedeRenovar = ahoraMs >= fin - DIAS_RENOVAR_ANTES * DIA;
    if (d.canceladoEn) return { ...base, situacion: 'cancelada', operativa: true, puedeRenovar };
    return { ...base, situacion: puedeRenovar ? 'por-vencer' : 'al-dia', operativa: true, puedeRenovar };
  }
  // Los días de gracia son para quien se atrasó en pagar; quien canceló mantiene el acceso solo hasta el fin del período.
  const pausa = fin + DIAS_GRACIA * DIA;
  if (!d.canceladoEn && ahoraMs <= pausa) {
    return { ...base, situacion: 'gracia', operativa: true, pausaEl: new Date(pausa).toISOString(), puedeRenovar: true };
  }
  return { ...base, situacion: 'vencida', operativa: false, puedeRenovar: true };
}

/** Bajo este monto no se cobra la diferencia al subir de plan (quedan muy pocos días): el cambio es sin costo. */
export const MINIMO_COBRO_CAMBIO = 1000;

/**
 * Subir de plan a mitad de mes: se paga solo la diferencia de precio por los días que quedan pagados
 * (diferencia × días / 30, redondeada a $10). `dias` cuenta todo lo ya pagado, también un mes renovado por adelantado.
 */
export function diferenciaProrrateada(montoActual: number, montoNuevo: number, periodoFin: string, ahoraMs: number = Date.now()): { dias: number; monto: number } {
  const dias = Math.max(0, Math.ceil((Date.parse(periodoFin) - ahoraMs) / DIA));
  const monto = Math.round((Math.max(0, montoNuevo - montoActual) * dias) / DIAS_PERIODO / 10) * 10;
  return { dias, monto: monto < MINIMO_COBRO_CAMBIO ? 0 : monto };
}

/**
 * Rutas (tal como las registra el router) que siguen disponibles con la cuenta en pausa: la sesión, Mi plan,
 * las acciones de Mi cuenta (pagar, cancelar, descargar datos, eliminar o recuperar la cuenta), la privacidad
 * y la apariencia. Todo lo demás del panel responde 403 hasta que la cuenta vuelva a estar al día.
 */
const EXACTAS_EN_PAUSA = new Set(['/api/mi-plan', '/api/apariencia']);
const PREFIJOS_EN_PAUSA = ['/api/auth/', '/api/cuenta/', '/api/privacidad/', '/api/soporte/']; // con la cuenta en pausa igual se puede pedir ayuda
export const permitidaEnPausa = (rutaDelRouter: string | undefined): boolean =>
  !!rutaDelRouter && (EXACTAS_EN_PAUSA.has(rutaDelRouter) || PREFIJOS_EN_PAUSA.some((p) => rutaDelRouter.startsWith(p)));
