// CSV pensado para abrirlo con Excel en español: separador ";", coma decimal, UTF-8 con BOM y fin de línea CRLF.

/** Una celda. Los textos que empiezan con = + - @ (o tabulador / retorno) llevan un apóstrofo delante: así Excel
 *  los muestra como texto y no los ejecuta como fórmula (un nombre de producto no debe poder correr nada). */
function celda(v: unknown): string {
  if (v == null) return '';
  if (typeof v === 'number') return Number.isFinite(v) ? String(v).replace('.', ',') : '';
  if (typeof v === 'boolean') return v ? 'sí' : 'no';
  let s = typeof v === 'string' ? v : JSON.stringify(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return /[";\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

/** Arma un CSV con una fila de encabezados y una fila por objeto (solo las columnas indicadas, en ese orden). */
export function aCsv(columnas: string[], filas: Record<string, unknown>[]): string {
  const lineas = [columnas.map(celda).join(';')];
  for (const f of filas) lineas.push(columnas.map((c) => celda(f[c])).join(';'));
  return '﻿' + lineas.join('\r\n') + '\r\n';
}
