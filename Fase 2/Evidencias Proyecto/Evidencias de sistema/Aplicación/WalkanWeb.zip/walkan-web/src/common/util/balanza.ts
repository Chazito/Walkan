// Código que imprime la balanza (EAN-13 con prefijo GS1 2 = uso interno de la tienda), como en Odoo:
//   21 PPPPP GGGGG C → peso en gramos     23 PPPPP $$$$$ C → precio total en pesos
// PPPPP = código de balanza (PLU) del producto, GGGGG/$$$$$ = el valor, C = dígito verificador.
// El prefijo 20 queda para los códigos internos fijos (ver ProductosService.codigoInterno).
/** Dígito verificador EAN-13 de 12 dígitos (mismo cálculo que public/js/ean13.js). */
export function verificadorEan(d12: string): number {
  let s = 0;
  for (let i = 0; i < 12; i++) s += Number(d12[i]) * (i % 2 ? 3 : 1);
  return (10 - (s % 10)) % 10;
}

export function leerBalanza(cod: string): { plu: number; gramos?: number; pesos?: number } | null {
  const m = /^(21|23)(\d{5})(\d{5})(\d)$/.exec(String(cod ?? '').trim());
  if (!m) return null;
  if (verificadorEan(m[0]) !== Number(m[4])) return null;
  const plu = Number(m[2]), valor = Number(m[3]);
  return m[1] === '21' ? { plu, gramos: valor } : { plu, pesos: valor };
}
