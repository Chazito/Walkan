// Nombres de los planes. Los antiguos (hasta nov 2026) se leen como su equivalente actual, por si quedó alguno
// guardado en una fila o llega desde una caja o un enlace viejo.
export const PLANES = ['Esencial', 'Profesional', 'Empresa'];
const ANTIGUOS: Record<string, string> = { Kiosko: 'Esencial', Minimarket: 'Profesional', 'Minisúper': 'Empresa', Minisuper: 'Empresa' };

export const planCanon = (p: string | null | undefined): string => {
  const s = String(p ?? '').trim();
  return PLANES.includes(s) ? s : (ANTIGUOS[s] ?? s);
};
