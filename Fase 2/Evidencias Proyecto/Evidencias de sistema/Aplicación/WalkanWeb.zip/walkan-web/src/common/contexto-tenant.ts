// Guarda quién es el usuario y de qué cliente (tenant) en cada request, para que los repositorios filtren solos.
import { Global, Injectable, Module } from '@nestjs/common';
import { AsyncLocalStorage } from 'async_hooks';

export interface TenantStore {
  userId: string;
  clienteId: string | null; // null = staff Walkan (ve todo)
  rol: string;
}

/**
 * Contexto de tenant por request, sostenido con AsyncLocalStorage. main.ts abre un store vacío por request
 * con run() (hook onRequest de Fastify) y el SesionGuard lo llena al validar la sesión; los repositorios
 * lo leen para filtrar cada consulta por cliente_id, de modo que un cliente jamás ve datos de otro.
 * run() deja el store pegado a esa request y a nada más (enterWith podía filtrarse a lo que siguiera en el mismo contexto).
 */
@Injectable()
export class ContextoTenant {
  private readonly als = new AsyncLocalStorage<TenantStore>();

  /** Abre el store vacío de una request (lo llama el hook de main.ts); todo lo que corra dentro de fn lo ve. */
  abrir(fn: () => void): void {
    this.als.run({} as TenantStore, fn);
  }
  // Llena el store de la request. Sin store abierto (scripts, pruebas) cae a enterWith como antes.
  set(store: TenantStore): void {
    const s = this.als.getStore();
    if (s) Object.assign(s, store); else this.als.enterWith(store);
  }
  // run sirve para correr algo fuera del flujo del guard: el contexto vive solo dentro de fn.
  run<T>(store: TenantStore, fn: () => T): T {
    return this.als.run(store, fn);
  }

  get store(): TenantStore | undefined {
    return this.als.getStore();
  }
  get rol(): string | null {
    return this.als.getStore()?.rol ?? null;
  }
  get userId(): string | null {
    return this.als.getStore()?.userId ?? null;
  }
  // Versión que no lanza: para código que corre igual para staff (null) y para clientes.
  get clienteIdOpt(): string | null {
    return this.als.getStore()?.clienteId ?? null;
  }
  /** cliente_id obligatorio (lanza si no hay). Para consultas del panel del cliente. */
  get clienteId(): string {
    const c = this.als.getStore()?.clienteId;
    if (!c) throw new Error('Operación de cliente sin contexto de tenant.');
    return c;
  }
}

@Global()
@Module({
  providers: [ContextoTenant],
  exports: [ContextoTenant],
})
export class ContextoTenantModule {}
