import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, randomInt, timingSafeEqual } from 'crypto';

/**
 * Verificación en dos pasos con app de códigos (TOTP, RFC 6238): el mismo estándar de Google Authenticator,
 * Microsoft Authenticator, Authy, etc. Código de 6 dígitos que cambia cada 30 segundos, calculado con HMAC-SHA1
 * sobre un secreto compartido. Sin librerías: viene todo en Node.
 */
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export const PASO_S = 30;

export function base32(buf: Buffer): string {
  let bits = 0, val = 0, out = '';
  for (const b of buf) {
    val = (val << 8) | b; bits += 8;
    while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += B32[(val << (5 - bits)) & 31];
  return out;
}
export function desdeBase32(s: string): Buffer {
  const limpio = s.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0, val = 0; const out: number[] = [];
  for (const c of limpio) {
    val = (val << 5) | B32.indexOf(c); bits += 5;
    if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}

/** Secreto nuevo: 20 bytes al azar (160 bits, lo que recomienda el RFC para HMAC-SHA1), en base32. */
export const nuevoSecreto = (): string => base32(randomBytes(20));

/** Código de 6 dígitos para un paso de tiempo (paso = segundos desde 1970 / 30). */
export function codigo(secreto: string, paso: number): string {
  const msg = Buffer.alloc(8);
  msg.writeUInt32BE(Math.floor(paso / 2 ** 32), 0);
  msg.writeUInt32BE(paso >>> 0, 4);
  const h = createHmac('sha1', desdeBase32(secreto)).update(msg).digest();
  const o = h[h.length - 1] & 15;
  const n = ((h[o] & 127) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(n % 1_000_000).padStart(6, '0');
}

export const pasoActual = (ahoraMs = Date.now()): number => Math.floor(ahoraMs / 1000 / PASO_S);

/**
 * Revisa un código. Acepta el paso actual y uno antes o después (±30 s por relojes desfasados).
 * Devuelve el paso que calzó, o null. `ultimoPaso`: el último usado; uno igual o anterior se rechaza para que
 * un código ya usado (por ejemplo, visto por encima del hombro) no sirva de nuevo.
 */
export function verificarCodigo(secreto: string, entrada: string, ultimoPaso: number | null, ahoraMs = Date.now()): number | null {
  const c = String(entrada ?? '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(c)) return null;
  const p = pasoActual(ahoraMs);
  for (const d of [0, -1, 1]) {
    const paso = p + d;
    if (ultimoPaso != null && paso <= ultimoPaso) continue;
    const esperado = Buffer.from(codigo(secreto, paso));
    if (timingSafeEqual(esperado, Buffer.from(c))) return paso;
  }
  return null;
}

/** Enlace otpauth:// que se muestra como QR para que la app agregue la cuenta. */
export function uriOtpauth(cuenta: string, secreto: string, emisor = 'Walkan'): string {
  const etiqueta = encodeURIComponent(`${emisor}:${cuenta}`);
  return `otpauth://totp/${etiqueta}?secret=${secreto}&issuer=${encodeURIComponent(emisor)}&algorithm=SHA1&digits=6&period=${PASO_S}`;
}

// ---- El secreto se guarda cifrado (AES-256-GCM) con una clave derivada de SESSION_SECRET ----
// Así una copia de la base de datos sola no alcanza para generar códigos. Si cambia SESSION_SECRET,
// los secretos guardados dejan de servir y cada usuario tiene que configurar la app de nuevo.
const clave = (sesion: string): Buffer => createHash('sha256').update('walkan-dos-pasos:' + sesion).digest();
export function cifrar(texto: string, sesion: string): string {
  const iv = randomBytes(12);
  const c = createCipheriv('aes-256-gcm', clave(sesion), iv);
  const datos = Buffer.concat([c.update(texto, 'utf8'), c.final()]);
  return ['v1', iv.toString('base64url'), c.getAuthTag().toString('base64url'), datos.toString('base64url')].join('.');
}
export function descifrar(guardado: string, sesion: string): string | null {
  try {
    const [v, iv, tag, datos] = guardado.split('.');
    if (v !== 'v1') return null;
    const d = createDecipheriv('aes-256-gcm', clave(sesion), Buffer.from(iv, 'base64url'));
    d.setAuthTag(Buffer.from(tag, 'base64url'));
    return Buffer.concat([d.update(Buffer.from(datos, 'base64url')), d.final()]).toString('utf8');
  } catch { return null; }
}

/** Códigos de respaldo (para cuando no se tiene el celular): 8 de 10 caracteres, se guardan solo como hash. */
const ALFA = 'abcdefghjkmnpqrstuvwxyz23456789';
export function codigosRespaldo(n = 8): string[] {
  return Array.from({ length: n }, () => {
    let s = '';
    for (let i = 0; i < 10; i++) s += ALFA[randomInt(ALFA.length)];
    return s.slice(0, 5) + '-' + s.slice(5);
  });
}
export const hashRespaldo = (c: string): string =>
  createHash('sha256').update(String(c).toLowerCase().replace(/[^a-z0-9]/g, '')).digest('hex');
