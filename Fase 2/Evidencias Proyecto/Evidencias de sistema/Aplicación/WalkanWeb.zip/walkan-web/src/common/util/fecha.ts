// "Hoy" y las horas se calculan con la zona horaria de Chile, no la del servidor.
const TZ = 'America/Santiago';
const dia = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' });
const hora = new Intl.DateTimeFormat('es-CL', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });

const fmt = (f: Intl.DateTimeFormat, d: string | number | Date): string => {
  const t = new Date(d);
  return isNaN(t.getTime()) ? '' : f.format(t); // fecha inválida desde la caja: vacío, no error
};

/** Fecha local de Chile en formato YYYY-MM-DD. */
export const fechaCL = (d: string | number | Date = new Date()): string => fmt(dia, d);
/** AAAA-MM-DD que existe en el calendario (rechaza 2026-02-30) y con año 2000–2099. */
export const fechaValida = (s: string): boolean => {
  if (!/^20\d{2}-\d{2}-\d{2}$/.test(s)) return false;
  const t = new Date(s + 'T00:00:00Z');
  return !isNaN(t.getTime()) && t.toISOString().slice(0, 10) === s;
};
/** Hora local de Chile en formato HH:MM. */
export const horaCL = (d: string | number | Date): string => fmt(hora, d);
/** AAAA-MM-DD + n días (calendario, sin zona horaria). */
export const sumarDias = (s: string, n: number): string => new Date(Date.parse(s + 'T00:00:00Z') + n * 86_400_000).toISOString().slice(0, 10);
