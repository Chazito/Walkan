import { isIPv6 } from 'net';

/**
 * Clave con la que se cuenta a un cliente en los topes de tráfico y en el bloqueo de login.
 * - IPv4: la dirección tal cual.
 * - IPv6: su red /64. Una conexión IPv6 normal (una casa, un servidor arrendado) trae un /64 completo, o sea
 *   millones de direcciones propias: contando por dirección exacta, bastaba rotarlas para saltarse cada tope
 *   y para bloquearle la cuenta a cualquiera (ver docs/plan/revision-seguridad-2026-11-12.md, N1).
 * - IPv4 escrita como IPv6 (::ffff:1.2.3.4): se cuenta como la IPv4.
 */
export function claveIp(ip: string | null | undefined): string {
  const s = String(ip ?? '').trim().toLowerCase().split('%')[0]; // sin zona (fe80::1%eth0)
  const v4 = /^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/.exec(s);
  if (v4) return v4[1];
  if (!isIPv6(s)) return s;
  const [izq, der] = s.split('::');
  const a = izq ? izq.split(':') : [];
  const b = der ? der.split(':') : [];
  // "::" abrevia los grupos en cero que faltan para completar 8.
  const grupos = s.includes('::') ? [...a, ...Array(Math.max(0, 8 - a.length - b.length)).fill('0'), ...b] : a;
  return grupos.slice(0, 4).map((g) => (parseInt(g, 16) || 0).toString(16)).join(':') + '::/64';
}
