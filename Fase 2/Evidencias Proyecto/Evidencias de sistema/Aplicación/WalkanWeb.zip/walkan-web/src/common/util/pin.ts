import { randomBytes, scryptSync } from 'crypto';

// Hash del PIN de los cajeros. DEBE ser idéntico al de la caja (local erp-saas/src/modules/cajeros/pin.ts):
// la nube hashea y la caja verifica. Formato: scrypt$<salt base64>$<hash base64>, hash de 32 bytes.
export function hashPin(pin: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(pin, salt, 32);
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

/** PIN numérico de 4 a 8 dígitos (mismo rango que acepta la caja). */
export const PIN_VALIDO = /^[0-9]{4,8}$/;
