import { RouteConfig } from '@nestjs/platform-fastify';

/**
 * Tope propio por IP para una ruta (reemplaza el tope global de main.ts en esa ruta, con contador aparte).
 * Para rutas públicas caras o sensibles: login, registro, formulario de contacto, enrolamiento de cajas.
 * allowList: null para que la exclusión global (estáticos) no se herede.
 * max es función porque el .env se carga después de importar los controladores. Si RATE_LIMIT_MAX está
 * subido (pruebas e2e, todo desde una IP), las rutas también se relajan.
 */
/**
 * Rutas (tal como las registra el router) que quedan fuera del tope global: los archivos estáticos de public/
 * (el comodín de @fastify/static) y las imágenes de productos. Se decide con la ruta que EL ROUTER eligió y no
 * mirando la URL: antes bastaba agregar "?x=.css" a una página, o escribir "/%61pi/..." en vez de "/api/...",
 * para que la petición pasara por "archivo estático" y no contara en el tope.
 */
const RUTAS_SIN_TOPE = new Set(['/*', '/api/productos/:id/img']);
export const sinTopeGlobal = (rutaDelRouter: string | undefined): boolean => !!rutaDelRouter && RUTAS_SIN_TOPE.has(rutaDelRouter);

/** Únicas rutas de la API que aceptan formularios (application/x-www-form-urlencoded): los avisos que manda Flow. */
export const RUTAS_FORMULARIO_FLOW = new Set(['/api/registro/confirmar', '/api/pagos/confirmar', '/api/flow/cobro-qr/confirmacion']);

/**
 * Segunda capa contra CSRF para las rutas de la API que cambian datos (la primera es la cookie SameSite=Lax).
 * Devuelve [código, mensaje] si hay que rechazar, o null si pasa.
 * - Sec-Fetch-Site lo pone el navegador y una página no lo puede falsear: si la petición viene de otro sitio
 *   (o de otro subdominio), se rechaza. Las cajas y Flow no son navegadores y no lo envían.
 * - Solo JSON: un formulario HTML de otro sitio no puede enviar JSON. Excepción: los avisos de Flow.
 */
export function rechazoCsrf(metodo: string, rutaDelRouter: string | undefined, cabeceras: Record<string, unknown>): [number, string] | null {
  const ruta = rutaDelRouter ?? '';
  if (!ruta.startsWith('/api/') || metodo === 'GET' || metodo === 'HEAD' || metodo === 'OPTIONS') return null;
  const sitio = String(cabeceras['sec-fetch-site'] ?? '');
  if (sitio && sitio !== 'same-origin' && sitio !== 'none') return [403, 'Solicitud desde otro sitio no permitida.'];
  const tipo = String(cabeceras['content-type'] ?? '');
  if (tipo && !/^application\/json\b/i.test(tipo) && !RUTAS_FORMULARIO_FLOW.has(ruta)) return [415, 'Esta ruta solo acepta JSON.'];
  return null;
}

export const Limite = (max: number, ventana = '1 minute') =>
  RouteConfig({ rateLimit: { max: () => (Number(process.env.RATE_LIMIT_MAX) > 10000 ? 100000 : max), timeWindow: ventana, allowList: null } });
