import { registerDecorator, ValidationOptions } from 'class-validator';

// Política de contraseñas de Walkan (la misma regla se muestra en el front: public/js/clave.js).
// Mínimo 8 caracteres, con mayúscula, minúscula, número y carácter especial, sin espacios.
export const REGLAS_CLAVE: { id: string; texto: string; ok: (p: string) => boolean }[] = [
  { id: 'largo', texto: 'al menos 8 caracteres', ok: (p) => p.length >= 8 },
  { id: 'mayus', texto: 'una letra mayúscula', ok: (p) => /[A-ZÁÉÍÓÚÑ]/.test(p) },
  { id: 'minus', texto: 'una letra minúscula', ok: (p) => /[a-záéíóúñ]/.test(p) },
  { id: 'numero', texto: 'un número', ok: (p) => /\d/.test(p) },
  { id: 'especial', texto: 'un carácter especial (por ejemplo ! @ # $ % & * ? -)', ok: (p) => /[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ\s]/.test(p) },
  { id: 'espacios', texto: 'sin espacios', ok: (p) => !/\s/.test(p) },
];

/** Lista de reglas que la contraseña NO cumple (vacía = válida). */
export function faltasClave(p: string): string[] {
  const s = typeof p === 'string' ? p : '';
  return REGLAS_CLAVE.filter((r) => !r.ok(s)).map((r) => r.texto);
}

/** Decorador de class-validator: la contraseña debe cumplir toda la política. */
export function ClaveSegura(opts?: ValidationOptions) {
  return function (obj: object, propertyName: string) {
    registerDecorator({
      name: 'claveSegura', target: obj.constructor, propertyName, options: opts,
      validator: {
        validate: (v: unknown) => typeof v === 'string' && v.length <= 100 && faltasClave(v).length === 0,
        defaultMessage: (args) => {
          const f = faltasClave(String(args?.value ?? ''));
          return f.length ? 'La contraseña debe tener ' + f.join(', ') + '.' : 'La contraseña no es válida.';
        },
      },
    });
  };
}
