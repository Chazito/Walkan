import { randomUUID } from 'crypto';
// Ids como UUID y timestamps en ISO UTC. Ojo: `ahora()` es UTC, para "hoy" en Chile usa fechaCL().
export const nuevoId = (): string => randomUUID();
export const ahora = (): string => new Date().toISOString();
