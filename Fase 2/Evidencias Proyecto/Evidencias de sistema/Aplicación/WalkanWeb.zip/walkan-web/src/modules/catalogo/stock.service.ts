// Stock del negocio: todo movimiento (venta, ingreso, ajuste, devolución) pasa por acá y queda en el kardex, con sus lotes.
import { BadRequestException, Inject, Injectable, NotFoundException, Optional } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ahora, nuevoId } from '../../common/util/id';
import { ContextoTenant } from '../../common/contexto-tenant';
import { fechaCL, sumarDias } from '../../common/util/fecha';

export type TipoMovimiento = 'inicial' | 'venta' | 'recepcion' | 'compra' | 'ajuste' | 'devolucion';
export interface Movimiento {
  clienteId: string;
  productoId: string;
  tipo: TipoMovimiento;
  cantidad: number; // con signo: + entra, - sale. Entera si el producto va por unidad; hasta 3 decimales si va por kg
  costoUnit?: number | null;
  refId?: string | null;
  motivo?: string | null;
  fecha?: string;
  lote?: string | null;  // código del lote (opcional, el que trae el envase)
  vence?: string | null; // AAAA-MM-DD; obligatorio al entrar stock de un producto que controla vencimiento
  loteId?: string | null; // salida: descuenta primero de este lote en vez del FEFO (retirar un lote puntual)
  usuarioId?: string | null; // quién lo hizo; si no viene, el usuario de la sesión. La caja pasa null explícito.
}

/** Valor FIFO de un producto: `entradas` = total de entradas del kardex, para saber cuánto stock no explica. */
export type FilaFifo = { pid: string; valor: number; entradas: number };

/**
 * Único punto por el que cambia el stock: actualiza productos.stock, los lotes y el
 * kardex en la misma transacción. Recibe clienteId explícito porque también lo usa
 * la sincronización de cajas, que no tiene sesión de usuario.
 * El stock puede quedar negativo: refleja errores de carga en vez de ocultarlos.
 *
 * Lotes (FEFO): una entrada en un producto con controla_vence crea un lote; una salida
 * consume los lotes que vencen antes (sin fecha al final) y deja una fila de kardex por
 * lote tocado. Lo que ningún lote alcanza a cubrir queda sin lote. productos.vence
 * queda derivado (vencimiento más próximo con saldo) para que alertas y predicción sigan igual.
 */
@Injectable()
export class StockService {
  private upd!: Database.Statement;
  private ins!: Database.Statement;
  private bySku!: Database.Statement;
  private movs!: Database.Statement;
  private tiene!: Database.Statement;
  private prod!: Database.Statement;
  private sumLotes!: Database.Statement;
  private insLote!: Database.Statement;
  private fefo!: Database.Statement;
  private bajaLote!: Database.Statement;
  private setVence!: Database.Statement;
  private lotesProd!: Database.Statement;
  private porVencer!: Database.Statement;
  private bajas!: Database.Statement;
  private capas!: Database.Statement;

  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    @Optional() private readonly ctx?: ContextoTenant,
  ) {
    // Recepciones y compras dejan el costo en el último costo de compra.
    // ROUND(…,3): el granel se mueve en kg con 3 decimales y la suma de decimales no debe dejar 0,30000000000000004.
    this.upd = db.prepare(`UPDATE productos SET stock=ROUND(stock+@cantidad,3),
      costo=CASE WHEN @tipo IN ('recepcion','compra') AND @costoUnit IS NOT NULL THEN @costoUnit ELSE costo END,
      updated_at=@now WHERE id=@productoId AND cliente_id=@clienteId`);
    this.ins = db.prepare(`INSERT INTO movimientos_stock
      (id,cliente_id,producto_id,tipo,cantidad,costo_unit,ref_id,motivo,fecha,created_at,lote_id,usuario_id)
      VALUES (@id,@clienteId,@productoId,@tipo,@cantidad,@costoUnit,@refId,@motivo,@fecha,@now,@loteId,@usuarioId)`);
    this.bySku = db.prepare('SELECT id FROM productos WHERE cliente_id=? AND sku=?');
    this.movs = db.prepare(`SELECT m.tipo, m.cantidad, m.costo_unit AS costoUnit, m.ref_id AS refId, m.motivo, m.fecha,
        l.codigo AS lote, l.vence AS loteVence, u.nombre AS usuario
      FROM movimientos_stock m LEFT JOIN lotes l ON l.id=m.lote_id AND l.cliente_id=m.cliente_id
      LEFT JOIN usuarios u ON u.id=m.usuario_id
      WHERE m.cliente_id=? AND m.producto_id=? ORDER BY m.fecha DESC, m.created_at DESC LIMIT 200`);
    this.tiene = db.prepare('SELECT 1 FROM movimientos_stock WHERE cliente_id=? AND producto_id=? LIMIT 1');
    this.prod = db.prepare(`SELECT nombre, stock, costo, controla_vence AS controla, unidad, vida_util_dias AS vida
      FROM productos WHERE id=? AND cliente_id=?`);
    // Valor de las n unidades más nuevas según las entradas del kardex (FIFO, ver valorFifo).
    this.capas = db.prepare(`SELECT COALESCE(SUM(MAX(0, MIN(q, @n-(acum-q)))*c),0) AS valor, COALESCE(MAX(acum),0) AS entradas FROM (
        SELECT m.cantidad AS q, COALESCE(m.costo_unit, @costo) AS c,
          SUM(m.cantidad) OVER (ORDER BY m.fecha DESC, m.created_at DESC, m.rowid DESC) AS acum
        FROM movimientos_stock m WHERE m.cliente_id=@clienteId AND m.producto_id=@productoId AND m.cantidad>0 AND m.tipo<>'venta')`);
    this.sumLotes = db.prepare('SELECT COALESCE(SUM(cantidad),0) AS s FROM lotes WHERE cliente_id=? AND producto_id=? AND cantidad>0');
    this.insLote = db.prepare(`INSERT INTO lotes (id,cliente_id,producto_id,codigo,vence,cantidad_inicial,cantidad,created_at)
      VALUES (@id,@clienteId,@productoId,@codigo,@vence,@inicial,@cantidad,@now)`);
    // FEFO: lo que vence primero sale primero; sin fecha al final; empate por antigüedad.
    this.fefo = db.prepare(`SELECT id, cantidad FROM lotes WHERE cliente_id=? AND producto_id=? AND cantidad>0
      ORDER BY vence IS NULL, vence, created_at, id`);
    this.bajaLote = db.prepare('UPDATE lotes SET cantidad=ROUND(cantidad-?,3) WHERE id=? AND cliente_id=?');
    this.setVence = db.prepare(`UPDATE productos SET vence=(SELECT MIN(vence) FROM lotes
      WHERE cliente_id=@clienteId AND producto_id=@productoId AND cantidad>0 AND vence IS NOT NULL)
      WHERE id=@productoId AND cliente_id=@clienteId`);
    this.lotesProd = db.prepare(`SELECT id, codigo, vence, cantidad, cantidad_inicial AS cantidadInicial, created_at AS creado
      FROM lotes WHERE cliente_id=? AND producto_id=? AND cantidad>0 ORDER BY vence IS NULL, vence, created_at, id`);
    this.porVencer = db.prepare(`SELECT l.id, l.codigo, l.vence, l.cantidad, p.id AS productoId, p.nombre, p.emoji
      FROM lotes l JOIN productos p ON p.id=l.producto_id AND p.cliente_id=l.cliente_id
      WHERE l.cliente_id=? AND l.cantidad>0 AND p.activo=1 AND l.vence IS NOT NULL AND l.vence<=?
      ORDER BY l.vence, l.created_at, l.id`);
    // Mermas = ajustes negativos (vencido, roto, robo…), valorizados al costo del momento o, si no lo guardó, al actual.
    this.bajas = db.prepare(`SELECT m.cantidad, COALESCE(m.costo_unit, p.costo, 0) AS costo, m.motivo, m.fecha, p.nombre, p.id AS pid
      FROM movimientos_stock m JOIN productos p ON p.id=m.producto_id AND p.cliente_id=m.cliente_id
      WHERE m.cliente_id=? AND m.tipo='ajuste' AND m.cantidad<0 AND m.fecha>=? AND m.fecha<?`);
  }

  mover(m: Movimiento): void {
    const now = ahora();
    const cantidad = Math.round(m.cantidad * 1000) / 1000;
    const base = {
      clienteId: m.clienteId, productoId: m.productoId, tipo: m.tipo,
      costoUnit: m.costoUnit ?? (null as number | null), refId: m.refId ?? null, motivo: m.motivo ?? null, fecha: m.fecha || now, now,
      usuarioId: m.usuarioId !== undefined ? m.usuarioId : (this.ctx?.userId ?? null), // null = caja/sync o script
    };
    const fila = (cantidad: number, loteId: string | null) => this.ins.run({ ...base, id: nuevoId(), cantidad, loteId });
    // (Si ya hay una transacción abierta afuera, better-sqlite3 la anida como savepoint.)
    this.db.transaction(() => {
      // Producto inexistente o de otro cliente: se aborta sin dejar kardex.
      const p = this.prod.get(m.productoId, m.clienteId) as { nombre: string; stock: number; costo: number; controla: number; unidad: string; vida: number | null } | undefined;
      if (!p) throw new NotFoundException('Producto no encontrado.');
      // La caja manda lo que vendió tal cual (una venta no se rechaza); las demás rutas sí validan la unidad.
      if (p.unidad !== 'kg' && m.tipo !== 'venta' && !Number.isInteger(cantidad)) {
        throw new BadRequestException(`"${p.nombre}" se maneja por unidad: la cantidad debe ser entera.`);
      }
      // Lo que sale (venta, merma, devolución) se costea por FIFO: lo que valían las unidades más viejas que quedaban.
      // Lo que pasa del stock (queda negativo) va al costo actual.
      // ponytail: dos pasadas por las entradas de ese producto por cada salida; si un producto acumula decenas de miles
      // de entradas, guardar una tabla de capas (saldo por entrada) y descontar ahí.
      if (cantidad < 0 && m.costoUnit == null) {
        const c = p.costo || 0;
        const v = (n: number) => {
          const r = this.capas.get({ clienteId: m.clienteId, productoId: m.productoId, costo: c, n }) as { valor: number; entradas: number };
          return r.valor + Math.max(0, n - r.entradas) * c;
        };
        const s = Math.max(p.stock, 0), q = -cantidad;
        base.costoUnit = Math.round((v(s) - v(Math.max(s - q, 0)) + Math.max(0, q - s) * c) / q);
      }
      // Vida útil (pan = 1 día): si no indican fecha, el lote vence hoy + vida útil.
      const vence = m.vence || (p.controla && p.vida ? sumarDias(fechaCL(now), p.vida) : null);
      // Una devolución en la caja (venta positiva) no trae vencimiento: entra sin lote.
      if (cantidad > 0 && p.controla && m.tipo !== 'venta') {
        if (!vence) throw new BadRequestException(`"${p.nombre}" controla vencimiento: indica la fecha de vencimiento.`);
        // Si había stock negativo sin lote (se vendió de más), esas unidades salieron de este lote.
        const sinLote = p.stock - (this.sumLotes.get(m.clienteId, m.productoId) as { s: number }).s;
        const loteId = nuevoId();
        this.insLote.run({
          id: loteId, clienteId: m.clienteId, productoId: m.productoId, codigo: m.lote?.trim() || null,
          vence, inicial: cantidad, cantidad: Math.max(0, Math.round((cantidad + Math.min(0, sinLote)) * 1000) / 1000), now,
        });
        fila(cantidad, loteId);
      } else if (cantidad < 0) {
        let falta = -cantidad;
        const lotes = this.fefo.all(m.clienteId, m.productoId) as { id: string; cantidad: number }[];
        if (m.loteId) lotes.sort((a, b) => Number(b.id === m.loteId) - Number(a.id === m.loteId)); // estable: el resto sigue en FEFO
        for (const l of lotes) {
          if (!falta) break;
          const q = Math.min(falta, l.cantidad);
          this.bajaLote.run(q, l.id, m.clienteId);
          fila(-q, l.id);
          falta = Math.round((falta - q) * 1000) / 1000; // kg con decimales: sin restos de coma flotante
        }
        if (falta) fila(-falta, null); // lo que ningún lote cubre queda sin lote (stock negativo permitido)
      } else {
        fila(cantidad, null);
      }
      this.upd.run({ ...base, cantidad: cantidad });
      this.recalcularVence(m.clienteId, m.productoId);
    })();
    this.invalidarValor(m.clienteId, m.productoId);
  }

  /** productos.vence = vencimiento más próximo entre los lotes con saldo (NULL si no hay). */
  recalcularVence(clienteId: string, productoId: string): void { this.setVence.run({ clienteId, productoId }); }

  // Así la caja encuentra el producto: por SKU dentro del mismo cliente (dos tiendas pueden repetir SKU).
  // Si ningún producto activo lo tiene, vale el archivado más reciente con ese código (I5): archivar libera el SKU,
  // pero la caja puede seguir vendiendo lo que le quedaba en góndola y esas ventas deben ir a su kardex.
  productoPorSku(clienteId: string, sku: string): string | undefined {
    return (this.bySku.get(clienteId, sku) as { id: string } | undefined)?.id
      ?? (this.db.prepare('SELECT id FROM productos WHERE cliente_id=? AND activo=0 AND sku_archivado=? ORDER BY updated_at DESC LIMIT 1')
        .get(clienteId, sku) as { id: string } | undefined)?.id;
  }

  // Producto a granel por su código de balanza (PLU), con el precio por kg para traducir una etiqueta con precio a kg.
  productoPorPlu(clienteId: string, plu: number): { id: string; precio: number } | undefined {
    return this.db.prepare('SELECT id, precio FROM productos WHERE cliente_id=? AND plu=? AND activo=1').get(clienteId, plu) as { id: string; precio: number } | undefined;
  }

  movimientos(clienteId: string, productoId: string) { return this.movs.all(clienteId, productoId); }
  tieneMovimientos(clienteId: string, productoId: string): boolean { return !!this.tiene.get(clienteId, productoId); }
  /** Lotes con saldo en orden FEFO (el primero es el que hay que vender primero). */
  lotes(clienteId: string, productoId: string) { return this.lotesProd.all(clienteId, productoId); }
  /**
   * Capas FIFO del stock: recorre las entradas del kardex de la más nueva a la más vieja y toma de cada una
   * lo que cabe hasta completar el stock actual. `entradas` = total de entradas, para saber cuánto stock
   * no explica el kardex. Las devoluciones de caja (venta positiva) no traen costo y no cuentan como capa.
   */
  // El panel pide /api/productos cada 30 s por pestaña y la consulta completa recorre todo el kardex (~120 ms con
  // 50 mil movimientos). Se calcula una vez por negocio y después, cuando un producto cambia (mover, costo, archivar),
  // solo se marca "sucio" y en la próxima lectura se recalcula ese producto (usa idx_mov_cliente_prod_fecha).
  // Marcar en vez de recalcular al tiro: si la transacción que movió el stock se revierte, no queda un valor falso.
  // ponytail: caché en memoria de un solo proceso; con varios procesos, mover esto a una tabla de capas.
  private cacheFifo = new Map<string, { filas: Map<string, FilaFifo>; sucios: Set<string> }>();
  private fifoSql = (filtro: string) => this.db.prepare(`WITH ent AS (
        SELECT m.producto_id AS pid, m.cantidad AS q, COALESCE(m.costo_unit, p.costo, 0) AS c, p.stock,
          SUM(m.cantidad) OVER (PARTITION BY m.producto_id ORDER BY m.fecha DESC, m.created_at DESC, m.rowid DESC) AS acum
        FROM movimientos_stock m JOIN productos p ON p.id=m.producto_id AND p.cliente_id=m.cliente_id
        WHERE m.cliente_id=@clienteId AND p.activo=1 AND p.stock>0 AND m.cantidad>0 AND m.tipo<>'venta' ${filtro})
      SELECT pid, SUM(MAX(0, MIN(q, stock-(acum-q)))*c) AS valor, MAX(acum) AS entradas FROM ent GROUP BY pid`);
  private fifoTodos?: Database.Statement;
  private fifoUno?: Database.Statement;

  /** Sin producto se olvida todo el negocio; con producto, solo ese se recalcula en la próxima lectura. */
  invalidarValor(clienteId: string, productoId?: string): void {
    if (productoId) this.cacheFifo.get(clienteId)?.sucios.add(productoId);
    else this.cacheFifo.delete(clienteId);
  }

  valorFifo(clienteId: string, productoId?: string): FilaFifo[] {
    const uno = (pid: string) => (this.fifoUno ??= this.fifoSql('AND m.producto_id=@productoId')).all({ clienteId, productoId: pid }) as FilaFifo[];
    if (productoId) return uno(productoId);
    let c = this.cacheFifo.get(clienteId);
    if (!c) {
      const filas = (this.fifoTodos ??= this.fifoSql('')).all({ clienteId }) as FilaFifo[];
      this.cacheFifo.set(clienteId, c = { filas: new Map(filas.map((f) => [f.pid, f])), sucios: new Set() });
    }
    for (const pid of c.sucios) {
      const [f] = uno(pid); // sin fila = quedó sin stock o se archivó
      if (f) c.filas.set(pid, f); else c.filas.delete(pid);
    }
    c.sucios.clear();
    return [...c.filas.values()];
  }

  /** Lotes con saldo que vencen hasta `hasta` (AAAA-MM-DD), incluidos los ya vencidos. */
  lotesPorVencer(clienteId: string, hasta: string) { return this.porVencer.all(clienteId, hasta); }

  /**
   * Todos los datos de inventario del negocio, para descargarlos (portabilidad, Ley 21.719). Nombres de tabla fijos (sin
   * entrada del usuario). Quedan fuera: las imágenes (pesadas; se bajan por /img), las cajas (tienen el token) y los usuarios.
   */
  exportar(clienteId: string) {
    const tablas = ['productos', 'lotes', 'movimientos_stock', 'proveedores', 'pedidos', 'compras', 'ventas', 'precios_historial', 'config_inventario'];
    const datos: Record<string, unknown[]> = {};
    for (const t of tablas) {
      datos[t] = (this.db.prepare(`SELECT * FROM ${t} WHERE cliente_id=?`).all(clienteId) as Record<string, unknown>[])
        .map((r) => { const { img, cliente_id, ...resto } = r as any; return resto; });
    }
    return { generado: ahora(), formato: 'walkan-inventario-v1', datos };
  }

  /**
   * Corrige el código o el vencimiento de un lote (error de tipeo al recibir). No mueve stock, pero deja una fila
   * de kardex con cantidad 0 que dice qué cambió y quién lo hizo, para no perder la trazabilidad.
   */
  editarLote(clienteId: string, loteId: string, codigo: string | null, vence: string) {
    const l = this.db.prepare('SELECT producto_id AS productoId, codigo, vence FROM lotes WHERE id=? AND cliente_id=?').get(loteId, clienteId) as { productoId: string; codigo: string | null; vence: string | null } | undefined;
    if (!l) throw new NotFoundException('Lote no encontrado.');
    if (!vence) throw new BadRequestException('Indica el vencimiento.');
    const cambios = [
      (l.codigo || null) !== codigo ? `código ${l.codigo || 'sin código'} → ${codigo || 'sin código'}` : '',
      l.vence !== vence ? `vence ${l.vence || 'sin fecha'} → ${vence}` : '',
    ].filter(Boolean);
    if (!cambios.length) return { ok: true, cambios: 0 };
    const now = ahora();
    this.db.transaction(() => {
      this.db.prepare('UPDATE lotes SET codigo=?, vence=? WHERE id=? AND cliente_id=?').run(codigo, vence, loteId, clienteId);
      this.ins.run({ id: nuevoId(), clienteId, productoId: l.productoId, tipo: 'ajuste', cantidad: 0, costoUnit: null, refId: null,
        motivo: 'Lote corregido: ' + cambios.join(', '), fecha: now, now, loteId, usuarioId: this.ctx?.userId ?? null });
      this.recalcularVence(clienteId, l.productoId);
    })();
    return { ok: true, cambios: cambios.length };
  }

  /**
   * Da de baja todo el saldo de un lote (vencido, retirado por el proveedor…) como un ajuste negativo de ese lote
   * puntual, sin pasar por el FEFO: así sale justo el lote elegido aunque haya otro que venza antes.
   */
  retirarLote(clienteId: string, loteId: string, motivo: string) {
    const l = this.db.prepare('SELECT producto_id AS productoId, cantidad FROM lotes WHERE id=? AND cliente_id=?').get(loteId, clienteId) as { productoId: string; cantidad: number } | undefined;
    if (!l) throw new NotFoundException('Lote no encontrado.');
    if (l.cantidad <= 0) throw new BadRequestException('El lote ya no tiene saldo.');
    this.mover({ clienteId, productoId: l.productoId, tipo: 'ajuste', cantidad: -l.cantidad, motivo, loteId });
    return { ok: true, productoId: l.productoId, cantidad: l.cantidad };
  }

  /**
   * Mermas entre dos días de Chile (AAAA-MM-DD, inclusive): total, por motivo y los 5 productos que más pierden.
   * El SQL trae un rango holgado en UTC y se recorta con fechaCL (igual que las ventas).
   */
  /**
   * Costo de lo vendido entre dos días de Chile: cada venta guarda su costo FIFO del momento (ver mover).
   * Las ventas viejas (sin costo guardado) y las devoluciones de caja van al costo actual.
   */
  costoVentas(clienteId: string, desde: string, hasta: string): { costo: number } {
    const holgura = (d: string, dias: number) => new Date(Date.parse(d + 'T00:00:00Z') + dias * 86_400_000).toISOString();
    const filas = this.db.prepare(`SELECT m.cantidad, COALESCE(m.costo_unit, p.costo, 0) AS costo, m.fecha
      FROM movimientos_stock m JOIN productos p ON p.id=m.producto_id AND p.cliente_id=m.cliente_id
      WHERE m.cliente_id=? AND m.tipo='venta' AND m.fecha>=? AND m.fecha<?`).all(clienteId, holgura(desde, -1), holgura(hasta, 2)) as { cantidad: number; costo: number; fecha: string }[];
    // Chile va 3 o 4 horas atrás de UTC: todo lo que cae entre las 00:00 UTC del día siguiente a `desde` y las 00:00
    // UTC de `hasta` es seguro del rango. Solo las orillas pasan por fechaCL (Intl, lo caro con miles de ventas).
    const segDesde = holgura(desde, 1), segHasta = holgura(hasta, 0);
    const costo = filas.filter((f) => {
      if (f.fecha >= segDesde && f.fecha < segHasta) return true;
      const d = fechaCL(f.fecha); return d >= desde && d <= hasta;
    }).reduce((s, f) => s - f.cantidad * f.costo, 0);
    return { costo: Math.round(costo) };
  }

  /**
   * Productos cuyo costo subió en los últimos `dias`: costo de hoy contra el último registrado antes del período
   * (o el primero dentro de él), desde el historial de precios. Con el proveedor, para ver quién subió.
   */
  alzasCosto(clienteId: string, dias: number) {
    const desde = new Date(Date.now() - dias * 86_400_000).toISOString();
    return (this.db.prepare(`SELECT p.id, p.nombre, p.costo AS ahora, COALESCE(pr.nombre, '') AS proveedor,
        COALESCE((SELECT h.costo FROM precios_historial h WHERE h.cliente_id=p.cliente_id AND h.producto_id=p.id AND h.fecha<@desde ORDER BY h.id DESC LIMIT 1),
                 (SELECT h.costo FROM precios_historial h WHERE h.cliente_id=p.cliente_id AND h.producto_id=p.id AND h.fecha>=@desde ORDER BY h.id LIMIT 1)) AS antes
      FROM productos p LEFT JOIN proveedores pr ON pr.id=p.proveedor_id AND pr.cliente_id=p.cliente_id
      WHERE p.cliente_id=@clienteId AND p.activo=1`).all({ clienteId, desde }) as { id: string; nombre: string; ahora: number; antes: number | null; proveedor: string }[])
      .filter((r) => r.antes && r.ahora > r.antes)
      .map((r) => ({ ...r, pct: Math.round((r.ahora - (r.antes as number)) / (r.antes as number) * 100) }))
      .sort((a, b) => b.pct - a.pct);
  }

  /**
   * Último costo pagado a cada proveedor por un producto, del kardex: un ingreso directo deja su id de compra
   * como ref (proveedor = nombre en compras); una recepción deja el id del pedido (proveedor del pedido).
   */
  costosPorProveedor(clienteId: string, productoId: string) {
    const filas = this.db.prepare(`SELECT COALESCE(pr.nombre, c.proveedor, 'Sin proveedor') AS proveedor, m.costo_unit AS costo, m.fecha
      FROM movimientos_stock m
      LEFT JOIN pedidos pe ON pe.id=m.ref_id AND pe.cliente_id=m.cliente_id
      LEFT JOIN proveedores pr ON pr.id=pe.proveedor_id AND pr.cliente_id=m.cliente_id
      LEFT JOIN compras c ON c.id=m.ref_id AND c.cliente_id=m.cliente_id
      WHERE m.cliente_id=? AND m.producto_id=? AND m.tipo IN ('compra','recepcion') AND m.costo_unit IS NOT NULL
      ORDER BY m.fecha DESC, m.rowid DESC LIMIT 500`).all(clienteId, productoId) as { proveedor: string; costo: number; fecha: string }[];
    const vistos = new Map<string, { proveedor: string; costo: number; fecha: string }>();
    for (const f of filas) if (!vistos.has(f.proveedor)) vistos.set(f.proveedor, { ...f, fecha: fechaCL(f.fecha) });
    return [...vistos.values()].sort((a, b) => a.costo - b.costo);
  }

  mermas(clienteId: string, desde: string, hasta: string) {
    const holgura = (d: string, dias: number) => new Date(Date.parse(d + 'T00:00:00Z') + dias * 86_400_000).toISOString();
    const filas = (this.bajas.all(clienteId, holgura(desde, -1), holgura(hasta, 2)) as { cantidad: number; costo: number; motivo: string | null; fecha: string; nombre: string; pid: string }[])
      .filter((f) => { const d = fechaCL(f.fecha); return d >= desde && d <= hasta; });
    const sumar = (m: Map<string, { nombre: string; unidades: number; costo: number }>, clave: string, nombre: string, f: { cantidad: number; costo: number }) => {
      const x = m.get(clave) ?? { nombre, unidades: 0, costo: 0 };
      x.unidades += -f.cantidad; x.costo += -f.cantidad * f.costo; m.set(clave, x);
    };
    const porMotivo = new Map<string, { nombre: string; unidades: number; costo: number }>();
    const porProducto = new Map<string, { nombre: string; unidades: number; costo: number }>();
    for (const f of filas) {
      const motivo = (f.motivo || 'Sin motivo').trim();
      sumar(porMotivo, motivo.toLowerCase(), motivo.charAt(0).toUpperCase() + motivo.slice(1), f);
      sumar(porProducto, f.pid, f.nombre, f); // por id: dos productos con el mismo nombre no se mezclan
    }
    const orden = (m: Map<string, { nombre: string; unidades: number; costo: number }>) => [...m.values()].sort((a, b) => b.costo - a.costo || b.unidades - a.unidades);
    return {
      desde, hasta,
      unidades: filas.reduce((s, f) => s - f.cantidad, 0),
      costo: filas.reduce((s, f) => s - f.cantidad * f.costo, 0),
      porMotivo: orden(porMotivo),
      productos: porProducto.size, // cuántos productos distintos tuvieron mermas (el detalle es solo el top 5)
      porProducto: orden(porProducto).slice(0, 5),
    };
  }
}
