// Bodies de los endpoints de contraseña: pedir el enlace, restablecer con el token y cambiarla desde Mi cuenta.
import { IsEmail, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { Rut } from '../../../common/util/rut';
import { ClaveSegura } from '../../../common/util/politica-clave';
import { CambiarPasswordDto } from '../../auth/dto/cambiar-password.dto';

export class PedirRecuperacionDto {
  @IsEmail({}, { message: 'Escribe un correo válido.' }) @MaxLength(200) email!: string;
  /** RUT del negocio: obligatorio en la práctica para dueños cuyo negocio lo tiene registrado (se revisa en silencio). */
  @IsOptional() @IsString() @MaxLength(20) @Rut() rut?: string;
}
// El token es el que viene en el enlace del correo.
export class RestablecerDto {
  @IsString() @MinLength(20) @MaxLength(100) token!: string;
  @IsString() @ClaveSegura() password!: string;
}
/** Cambiar la contraseña en Mi cuenta: la actual, la nueva y el código (app de dos pasos, de respaldo o del correo). */
export class CambiarPasswordConCodigoDto extends CambiarPasswordDto {
  @IsString() @MaxLength(20) codigo!: string;
}
