import { IsEmail, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

// La caja se registra con las credenciales del dueño; `nombre` es opcional para distinguir cajas.
export class RegistroCajaDto {
  @IsEmail() @MaxLength(254) email!: string;
  @IsString() @MinLength(1) @MaxLength(100) password!: string;
  @IsOptional() @IsString() @MaxLength(40) nombre?: string;
}
