// Lógica de tickets de soporte: crearlos, conversar con el cliente, y las acciones del equipo (responder, asignar, quitar dos pasos).
import { BadRequestException, ConflictException, HttpException, HttpStatus, Inject, Injectable, Logger, NotFoundException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { ahora, nuevoId } from '../../common/util/id';
import { UsuariosRepository } from '../auth/usuarios.repository';
import { CorreoService } from '../sync/correo.service';
import { Usuario } from '../auth/tipos';
import { nombreCategoria } from './categorias';

type Fila = Record<string, any>;
export type EstadoTicket = 'abierto' | 'en_curso' | 'resuelto';
const ESTADOS: Record<EstadoTicket, string> = { abierto: 'Abierto', en_curso: 'En curso', resuelto: 'Resuelto' };
const MAX_PUBLICOS_POR_HORA = 3; // por correo (además del tope por IP de la ruta)

// Todo texto de usuario que va a un correo se escapa antes; parrafos además respeta los saltos de línea.
const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
const parrafos = (t: string) => esc(t).replace(/\r?\n/g, '<br>');
const normalizarRut = (r?: string | null) => String(r ?? '').replace(/[.\-\s]/g, '').toUpperCase();
export const numeroTicket = (n: number) => `WK-${n}`;

/**
 * Soporte: tickets desde el panel (con sesión) o desde /ayuda/contacto (sin sesión, para quien no puede entrar).
 * La conversación queda en el ticket; cada respuesta del equipo además llega por correo.
 * - Un ticket sin sesión nunca revela si el correo tiene cuenta: la respuesta es siempre la misma.
 * - El dueño ve los tickets de su negocio; el equipo Walkan los ve todos en /admin.
 */
@Injectable()
export class SoporteService {
  private readonly logger = new Logger('Soporte');
  private readonly publicos = new Map<string, number[]>(); // correo → envíos de la última hora (en memoria)

  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly usuarios: UsuariosRepository,
    private readonly correo: CorreoService,
    @Inject(CONFIG) private readonly cfg: AppConfig,
  ) {}

  /** Correo del equipo que recibe el aviso de cada ticket nuevo o respuesta del cliente. */
  private get buzonEquipo(): string { return process.env.SOPORTE_CORREO || 'soporte@walkan.cl'; }

  // ---------- Crear ----------
  private crear(t: { origen: 'panel' | 'publico'; clienteId: string | null; usuarioId: string | null; nombre: string; email: string;
    rut?: string | null; ordenPago?: string | null; categoria: string; asunto: string; mensaje: string }) {
    const now = ahora(), id = nuevoId();
    const numero = this.db.transaction(() => {
      const n = ((this.db.prepare('SELECT COALESCE(MAX(numero), 1000) AS n FROM tickets').get() as Fila).n as number) + 1;
      this.db.prepare(`INSERT INTO tickets (id,numero,origen,cliente_id,usuario_id,nombre,email,rut,orden_pago,categoria,asunto,estado,creado_en,actualizado_en)
        VALUES (@id,@numero,@origen,@clienteId,@usuarioId,@nombre,@email,@rut,@ordenPago,@categoria,@asunto,'abierto',@now,@now)`)
        .run({ id, numero: n, origen: t.origen, clienteId: t.clienteId, usuarioId: t.usuarioId, nombre: t.nombre.trim(), email: t.email.toLowerCase().trim(),
          rut: t.rut?.trim() || null, ordenPago: t.ordenPago?.trim() || null, categoria: t.categoria, asunto: t.asunto.trim(), now });
      this.agregarMensaje(id, t.clienteId, 'cliente', t.nombre.trim(), t.mensaje);
      return n;
    })();
    this.logger.log(`Ticket ${numeroTicket(numero)} creado (${t.origen}, ${t.categoria})`);
    return { id, numero };
  }

  private agregarMensaje(ticketId: string, clienteId: string | null, autor: 'cliente' | 'equipo' | 'sistema', autorNombre: string, texto: string) {
    const now = ahora();
    this.db.prepare(`INSERT INTO ticket_mensajes (id,ticket_id,cliente_id,autor,autor_nombre,texto,creado_en) VALUES (?,?,?,?,?,?,?)`)
      .run(nuevoId(), ticketId, clienteId, autor, autorNombre, texto.trim(), now);
    this.db.prepare('UPDATE tickets SET actualizado_en=? WHERE id=?').run(now, ticketId);
  }

  /** Sin sesión. Misma respuesta exista o no una cuenta con ese correo. */
  async crearPublico(dto: { nombre: string; email: string; rut?: string; ordenPago?: string; categoria: string; asunto: string; mensaje: string; web?: string }) {
    const email = dto.email.toLowerCase().trim();
    const respuesta = (numero?: number) => ({ ok: true, numero: numero ? numeroTicket(numero) : null,
      mensaje: 'Recibimos tu solicitud. Te responderemos al correo que escribiste (revisa también la carpeta de spam).' });
    if (dto.web) { this.logger.warn('Ticket público descartado: campo trampa lleno'); return respuesta(); }
    const ms = Date.now();
    const previos = (this.publicos.get(email) ?? []).filter((t) => t > ms - 3600_000);
    if (previos.length >= MAX_PUBLICOS_POR_HORA) throw new HttpException('Ya recibimos varias solicitudes de este correo. Espera una hora o responde el correo que te enviamos.', HttpStatus.TOO_MANY_REQUESTS);
    this.publicos.set(email, [...previos, ms]);
    // Si el correo es de un dueño, el ticket queda en su negocio (lo verá en su panel). Quien escribe no se entera.
    const u = this.usuarios.porEmail(email);
    const clienteId = u && u.rol !== 'staff' ? (u.cliente_id ?? null) : null;
    const { id, numero } = this.crear({ origen: 'publico', clienteId, usuarioId: null, nombre: dto.nombre, email, rut: dto.rut, ordenPago: dto.ordenPago,
      categoria: dto.categoria, asunto: dto.asunto, mensaje: dto.mensaje });
    this.enSegundoPlano(this.avisarCreado(id)); // la solicitud ya quedó guardada: los correos no hacen esperar a nadie
    return respuesta(numero);
  }

  /** Desde el panel: el negocio, el nombre y el correo salen de la sesión. */
  async crearDesdePanel(u: Usuario, dto: { categoria: string; asunto: string; mensaje: string }) {
    if (!u.clienteId) throw new BadRequestException('Esta cuenta no pertenece a un negocio.');
    const { id, numero } = this.crear({ origen: 'panel', clienteId: u.clienteId, usuarioId: u.id, nombre: u.nombre || u.email, email: u.email,
      categoria: dto.categoria, asunto: dto.asunto, mensaje: dto.mensaje });
    this.enSegundoPlano(this.avisarCreado(id)); // la solicitud ya quedó guardada: los correos no hacen esperar a nadie
    return this.miTicket(u, id);
  }

  // ---------- Lado del dueño ----------
  /** El dueño ve los tickets de su negocio; otro usuario del negocio, solo los suyos. */
  private filtroDe(u: Usuario): { sql: string; params: unknown[] } {
    if (!u.clienteId) throw new BadRequestException('Esta cuenta no pertenece a un negocio.');
    return u.rol === 'admin' ? { sql: 't.cliente_id=?', params: [u.clienteId] } : { sql: 't.usuario_id=?', params: [u.id] };
  }

  // Los 100 más recientes. Trae quién escribió último para marcar a quién le toca responder.
  misTickets(u: Usuario) {
    const f = this.filtroDe(u);
    return (this.db.prepare(`SELECT t.*, (SELECT autor FROM ticket_mensajes m WHERE m.ticket_id=t.id ORDER BY creado_en DESC, rowid DESC LIMIT 1) AS ultimo_autor
      FROM tickets t WHERE ${f.sql} ORDER BY t.actualizado_en DESC LIMIT 100`).all(...f.params) as Fila[]).map((t) => this.resumen(t));
  }

  miTicket(u: Usuario, id: string) {
    const f = this.filtroDe(u);
    const t = this.db.prepare(`SELECT t.* FROM tickets t WHERE t.id=? AND ${f.sql}`).get(id, ...f.params) as Fila | undefined;
    if (!t) throw new NotFoundException('No encontramos ese ticket.');
    return { ...this.resumen(t), mensajes: this.mensajes(id) };
  }

  /** El dueño responde. Si el ticket estaba resuelto, se reabre. */
  async responderCliente(u: Usuario, id: string, texto: string) {
    const t = this.miTicket(u, id);
    this.agregarMensaje(id, u.clienteId, 'cliente', u.nombre || u.email, texto);
    if (t.estado === 'resuelto') this.db.prepare("UPDATE tickets SET estado='abierto' WHERE id=?").run(id);
    this.enSegundoPlano(this.correo.enviarAviso(this.buzonEquipo, `[${t.numero}] Nueva respuesta del cliente: ${t.asunto}`,
      this.marco(`<p><b>${esc(u.nombre || u.email)}</b> respondió el ticket <b>${esc(t.numero)}</b>:</p><blockquote style="margin:12px 0;padding:10px 14px;background:#f4f6f5;border-radius:6px">${parrafos(texto)}</blockquote>`,
        'Abrir en el panel del equipo', '/admin#soporte')));
    return this.miTicket(u, id);
  }

  // ---------- Lado del equipo Walkan ----------
  listar(estado?: string) {
    const conEstado = estado && ['abierto', 'en_curso', 'resuelto'].includes(estado);
    return (this.db.prepare(`SELECT t.*, c.negocio AS negocio, a.nombre AS asignado_nombre,
        (SELECT autor FROM ticket_mensajes m WHERE m.ticket_id=t.id ORDER BY creado_en DESC, rowid DESC LIMIT 1) AS ultimo_autor
      FROM tickets t LEFT JOIN clientes c ON c.id=t.cliente_id LEFT JOIN usuarios a ON a.id=t.asignado_a
      ${conEstado ? 'WHERE t.estado=?' : ''} ORDER BY CASE t.estado WHEN 'abierto' THEN 0 WHEN 'en_curso' THEN 1 ELSE 2 END, t.actualizado_en DESC LIMIT 300`)
      .all(...(conEstado ? [estado] : [])) as Fila[])
      .map((t) => ({ ...this.resumen(t), nombre: t.nombre, email: t.email, origen: t.origen, negocio: t.negocio ?? null, asignado: t.asignado_nombre ?? null }));
  }

  /** Detalle para el equipo, con la verificación de identidad (para tickets de quien no puede entrar). */
  detalle(id: string) {
    const t = this.fila(id);
    const negocio = t.cliente_id ? (this.db.prepare('SELECT negocio, rut FROM clientes WHERE id=?').get(t.cliente_id) as Fila | undefined) : undefined;
    const asignado = t.asignado_a ? this.usuarios.porId(t.asignado_a) : undefined;
    return {
      ...this.resumen(t), nombre: t.nombre, email: t.email, origen: t.origen, rut: t.rut ?? null, ordenPago: t.orden_pago ?? null,
      negocio: negocio?.negocio ?? null, asignado: asignado ? asignado.nombre : null, mensajes: this.mensajes(id), verificacion: this.verificacion(t),
    };
  }

  /** ¿Quién es el dueño de la cuenta con ese correo y coinciden los datos que escribió? Solo lo ve el equipo. */
  private verificacion(t: Fila) {
    const u = this.usuarios.porEmail(String(t.email));
    if (!u) return { cuenta: false };
    if (u.rol === 'staff') return { cuenta: true, equipo: true };
    const cli = u.cliente_id ? (this.db.prepare('SELECT negocio, rut FROM clientes WHERE id=?').get(u.cliente_id) as Fila | undefined) : undefined;
    const rutRegistrado = cli?.rut ? String(cli.rut) : null;
    const pago = t.orden_pago && u.cliente_id
      ? this.db.prepare("SELECT 1 FROM suscripciones WHERE cliente_id=? AND estado='pagada' AND flow_order=?").get(u.cliente_id, String(t.orden_pago).trim())
      : undefined;
    return {
      cuenta: true, equipo: false, usuarioId: u.id, negocio: cli?.negocio ?? null, rol: u.rol, dosPasos: !!u.totp_secreto, desactivada: !!u.desactivado_en,
      rutRegistrado, rutCoincide: t.rut ? (rutRegistrado ? normalizarRut(t.rut) === normalizarRut(rutRegistrado) : null) : null,
      ordenCoincide: t.orden_pago ? !!pago : null,
    };
  }

  /** El equipo responde: queda en la conversación y le llega por correo a quien abrió el ticket. */
  async responderEquipo(actor: { id?: string; nombre?: string; email?: string }, id: string, texto: string, estado?: string) {
    const t = this.fila(id);
    this.agregarMensaje(id, t.cliente_id ?? null, 'equipo', 'Equipo Walkan', texto);
    const nuevo = (estado as EstadoTicket) || (t.estado === 'abierto' ? 'en_curso' : (t.estado as EstadoTicket));
    this.db.prepare('UPDATE tickets SET estado=?, asignado_a=COALESCE(asignado_a, ?) WHERE id=?').run(nuevo, actor.id ?? null, id);
    const enPanel = t.cliente_id && this.usuarios.porEmail(String(t.email))?.rol !== 'staff';
    const envio = await this.correo.enviarAviso(String(t.email), `[${numeroTicket(t.numero)}] Respuesta del equipo Walkan: ${t.asunto}`,
      this.marco(`<p>Hola ${esc(t.nombre)}:</p><p>Te respondimos en tu solicitud <b>${esc(numeroTicket(t.numero))}</b> (${esc(t.asunto)}):</p>
        <blockquote style="margin:12px 0;padding:10px 14px;background:#f4f6f5;border-radius:6px">${parrafos(texto)}</blockquote>
        ${nuevo === 'resuelto' ? '<p style="font-size:13px;color:#555">Dimos la solicitud por resuelta. Si necesitas algo más, respóndela desde tu panel o abre una nueva.</p>' : ''}`,
        enPanel ? 'Ver en mi panel' : 'Ir a la ayuda de Walkan', enPanel ? '/panel#soporte' : '/ayuda'));
    return { ...this.detalle(id), envio };
  }

  setEstado(id: string, estado: EstadoTicket) {
    this.fila(id);
    this.db.prepare('UPDATE tickets SET estado=?, actualizado_en=? WHERE id=?').run(estado, ahora(), id);
    return this.detalle(id);
  }

  asignar(id: string, usuarioId: string) {
    this.fila(id);
    this.db.prepare('UPDATE tickets SET asignado_a=? WHERE id=?').run(usuarioId, id);
    return this.detalle(id);
  }

  /** Para el dueño que perdió el celular: tras verificar su identidad, el equipo le quita la verificación en dos pasos.
   *  Se olvidan sus dispositivos recordados, se cierran sus sesiones y le llega un aviso al correo de la cuenta. */
  async quitarDosPasos(id: string) {
    const t = this.fila(id);
    const v = this.verificacion(t);
    if (!v.cuenta || v.equipo || !('usuarioId' in v) || !v.usuarioId) throw new BadRequestException('Este ticket no corresponde a la cuenta de un dueño.');
    if (!v.dosPasos) throw new ConflictException('Esa cuenta no tiene la verificación en dos pasos activa.');
    const u = this.usuarios.porId(v.usuarioId)!;
    this.usuarios.desactivarTotp(u.id, ahora());
    this.usuarios.borrarSesionesDe(u.id);
    this.agregarMensaje(id, t.cliente_id ?? null, 'sistema', 'Walkan', 'El equipo Walkan quitó la verificación en dos pasos de la cuenta, después de verificar la identidad del dueño.');
    await this.correo.enviarAviso(u.email, 'Quitamos la verificación en dos pasos de tu cuenta Walkan',
      this.marco(`<p>Hola ${esc(u.nombre || '')}:</p><p>A pedido tuyo (solicitud <b>${esc(numeroTicket(t.numero))}</b>), quitamos la verificación en dos pasos de tu cuenta y cerramos las sesiones abiertas. Ya puedes entrar solo con tu contraseña.</p>
        <p>Te recomendamos activarla de nuevo con tu celular nuevo en <b>Mi cuenta › Verificación en dos pasos</b>.</p>
        <p style="font-size:13px;color:#555">Si no lo pediste tú, responde este correo de inmediato.</p>`, 'Ir a Walkan', '/mi-cuenta'));
    this.logger.warn(`Dos pasos quitados por soporte: usuario ${u.id} (ticket ${numeroTicket(t.numero)})`);
    return { email: u.email as string, negocio: v.negocio, detalle: this.detalle(id) };
  }

  /** Para "¿cuántos pendientes?" en el menú del equipo: tickets abiertos cuyo último mensaje es del cliente. */
  pendientes(): number {
    return (this.db.prepare(`SELECT COUNT(*) AS n FROM tickets t WHERE t.estado<>'resuelto' AND
      (SELECT autor FROM ticket_mensajes m WHERE m.ticket_id=t.id ORDER BY creado_en DESC, rowid DESC LIMIT 1)='cliente'`).get() as Fila).n as number;
  }

  // ---------- Ayudantes ----------
  /** Un correo que no se espera: la respuesta al navegador sale al tiro y el envío sigue por detrás.
   *  enviarAviso no lanza errores (devuelve 'error' y lo deja en el log); el catch es por si algo inesperado falla. */
  private enSegundoPlano(p: Promise<unknown>): void {
    p.catch((e) => this.logger.warn(`Aviso de soporte no enviado: ${(e as Error).message}`));
  }
  private fila(id: string): Fila {
    const t = this.db.prepare('SELECT * FROM tickets WHERE id=?').get(id) as Fila | undefined;
    if (!t) throw new NotFoundException('Ticket no encontrado.');
    return t;
  }
  private mensajes(id: string) {
    return (this.db.prepare('SELECT autor, autor_nombre, texto, creado_en FROM ticket_mensajes WHERE ticket_id=? ORDER BY creado_en, rowid').all(id) as Fila[])
      .map((m) => ({ autor: m.autor, nombre: m.autor_nombre, texto: m.texto, fecha: m.creado_en }));
  }
  private resumen(t: Fila) {
    return { id: t.id as string, numero: numeroTicket(t.numero), asunto: t.asunto as string, categoria: t.categoria as string, categoriaNombre: nombreCategoria(t.categoria),
      estado: t.estado as EstadoTicket, estadoNombre: ESTADOS[t.estado as EstadoTicket], creado: t.creado_en as string, actualizado: t.actualizado_en as string,
      esperaRespuesta: t.ultimo_autor === 'cliente' };
  }

  // Dos correos al crear un ticket: confirmación para quien lo abrió y aviso al buzón del equipo.
  private async avisarCreado(id: string) {
    const t = this.fila(id);
    const n = numeroTicket(t.numero);
    const [primer] = this.mensajes(id);
    await this.correo.enviarAviso(String(t.email), `[${n}] Recibimos tu solicitud: ${t.asunto}`,
      this.marco(`<p>Hola ${esc(t.nombre)}:</p><p>Recibimos tu solicitud <b>${esc(n)}</b> sobre <b>${esc(nombreCategoria(t.categoria))}</b>. Te responderemos por este medio, normalmente dentro de un día hábil.</p>
        <blockquote style="margin:12px 0;padding:10px 14px;background:#f4f6f5;border-radius:6px">${parrafos(primer?.texto ?? '')}</blockquote>
        <p style="font-size:13px;color:#555">El equipo Walkan nunca te pedirá tu contraseña ni los códigos de tu app de verificación.</p>`,
        t.origen === 'panel' ? 'Ver en mi panel' : 'Ir a la ayuda de Walkan', t.origen === 'panel' ? '/panel#soporte' : '/ayuda'));
    await this.correo.enviarAviso(this.buzonEquipo, `[${n}] Nuevo ticket (${nombreCategoria(t.categoria)}): ${t.asunto}`,
      this.marco(`<p>Nuevo ticket <b>${esc(n)}</b> de <b>${esc(t.nombre)}</b> (${esc(t.email)}), ${t.origen === 'panel' ? 'desde su panel' : 'sin sesión'}.</p>
        <blockquote style="margin:12px 0;padding:10px 14px;background:#f4f6f5;border-radius:6px">${parrafos(primer?.texto ?? '')}</blockquote>`,
        'Abrir en el panel del equipo', '/admin#soporte'));
  }

  // Envoltorio HTML de los correos de soporte: logo, cuerpo y un botón que lleva al panel.
  private marco(cuerpo: string, boton: string, ruta: string): string {
    return `<!doctype html><html lang="es"><body style="margin:0;background:#f4f6f5;font-family:Arial,Helvetica,sans-serif;color:#111">
<div style="max-width:480px;margin:24px auto;background:#fff;border-radius:12px;padding:24px;border:1px solid #e3e7e5">
  <p style="margin:0 0 16px;font-weight:800;font-size:18px;color:#0B7C4E">Walkan</p>${cuerpo}
  <p style="margin:20px 0 0"><a href="${esc(this.cfg.appUrl.replace(/\/$/, '') + ruta)}" style="display:inline-block;background:#0B7C4E;color:#fff;text-decoration:none;font-weight:700;padding:11px 18px;border-radius:6px">${esc(boton)}</a></p>
  <p style="font-size:12px;color:#888;margin:20px 0 0">Walkan · Tu negocio siempre funcionando.</p>
</div></body></html>`;
  }
}
