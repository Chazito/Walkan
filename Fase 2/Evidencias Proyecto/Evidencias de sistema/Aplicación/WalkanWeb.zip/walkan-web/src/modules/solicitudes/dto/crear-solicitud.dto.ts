import { Equals, IsBoolean, IsEmail, IsOptional, IsString, Length, MaxLength } from 'class-validator';

// Lo que manda el formulario público de "quiero Walkan". Viene de cualquiera, por eso los largos acotados.
export class CrearSolicitudDto {
  @IsString() @Length(1, 80) nombre: string;      // persona de contacto
  @IsString() @Length(1, 120) negocio: string;
  @IsEmail() @MaxLength(254) email: string;
  @IsOptional() @IsString() @MaxLength(30) telefono?: string;
  @IsOptional() @IsString() @MaxLength(60) comuna?: string;
  @IsOptional() @IsString() @MaxLength(30) plan?: string;
  @IsOptional() @IsString() @MaxLength(2000) mensaje?: string;
  @Equals(true, { message: 'Debes aceptar la Política de Privacidad para continuar.' }) aceptaPrivacidad!: boolean;
  @IsOptional() @IsBoolean() aceptaMarketing?: boolean;
}
