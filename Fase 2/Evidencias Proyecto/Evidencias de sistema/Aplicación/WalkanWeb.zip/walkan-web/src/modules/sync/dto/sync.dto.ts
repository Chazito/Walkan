// Envelope del outbox de la caja (interfaces: sin validación de clase para no
// recortar payloads anidados; se validan a mano en el servicio).
export interface EventoSync {
  seq: number;                  // correlativo de la caja; sirve para no aplicar dos veces el mismo evento
  tipo: string;                 // 'venta' (extensible)
  fecha?: string;
  uid?: string;                 // id del evento en la caja (el de la venta): detecta una caja que reinició su seq (C3)
  payload: any;
}
export interface SyncBody {
  eventos: EventoSync[];
}
