import { createHmac } from 'crypto';

/**
 * Firma Flow: se ordenan los parámetros por nombre (excluyendo 's'), se
 * concatenan como nombreValor sin separadores y se firma con HMAC-SHA256
 * usando el secretKey. Devuelve hex.
 * Ojo: si cambia el orden o se cuela un separador, Flow rechaza todo con
 * "firma inválida", así que esto no se toca sin probar contra el sandbox.
 */
export function firmarParams(params: Record<string, string | number>, secret: string): string {
  const cadena = Object.keys(params)
    .filter((k) => k !== 's')
    .sort()
    .map((k) => k + String(params[k]))
    .join('');
  return createHmac('sha256', secret).update(cadena).digest('hex');
}
