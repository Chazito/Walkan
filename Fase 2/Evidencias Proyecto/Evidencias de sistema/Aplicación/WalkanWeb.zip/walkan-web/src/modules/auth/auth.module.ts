// Módulo de autenticación: login, sesiones y dos pasos.
import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { UsuariosRepository } from './usuarios.repository';
import { SesionGuard } from './auth.guard';
import { DosPasosService } from './dos-pasos.service';

// Exporta el guard y el repo de usuarios porque admin y sync también los ocupan.
@Module({
  controllers: [AuthController],
  providers: [AuthService, UsuariosRepository, SesionGuard, DosPasosService],
  exports: [AuthService, SesionGuard, UsuariosRepository, DosPasosService],
})
export class AuthModule {}
