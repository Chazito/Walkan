// Body de POST /api/cuenta/eliminar: solo la contraseña, para confirmar que es el dueño de verdad.
import { IsString, MaxLength, MinLength } from 'class-validator';

export class EliminarCuentaDto {
  @IsString() @MinLength(1) @MaxLength(100) password!: string;
}
