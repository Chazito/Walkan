// Endpoints de /api/productos: CRUD del catálogo, ingresos y ajustes de stock, importación, precios masivos e imagen.
import { Body, Controller, Delete, Get, NotFoundException, Param, Post, Put, Res, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { ProductosService } from './productos.service';
import { ProductoDto, IngresoDto, AjusteDto, ImportarDto, PreciosDto } from './dto/producto.dto';

// Catálogo del negocio. Ojo: el stock no se edita con PUT, solo con /ingreso y /ajuste,
// así cada cambio deja su movimiento registrado.
@Controller('api/productos')
@UseGuards(SesionGuard)
export class ProductosController {
  constructor(private readonly srv: ProductosService) {}

  @Get()
  listar() { return this.srv.listar(); }

  // Archivados (eliminados que tenían historial) y su restauración.
  @Get('archivados')
  archivados() { return this.srv.archivados(); }
  @Post(':id/restaurar')
  restaurar(@Param('id') id: string) { return this.srv.restaurar(id); }

  @Post()
  crear(@Body() dto: ProductoDto) { return this.srv.crear(dto); }

  // Importar CSV: todas las filas en una request; responde el resultado de cada una.
  @Post('importar')
  importar(@Body() dto: ImportarDto) { return this.srv.importar(dto.productos); }

  // ％ Precios: cambia el precio de venta de muchos productos de una vez (todo o nada).
  @Put('precios')
  cambiarPrecios(@Body() dto: PreciosDto) { return this.srv.cambiarPrecios(dto.cambios); }

  @Put(':id')
  actualizar(@Param('id') id: string, @Body() dto: ProductoDto) { return this.srv.actualizar(id, dto); }

  @Delete(':id')
  eliminar(@Param('id') id: string) { return this.srv.eliminar(id); }

  @Post(':id/ingreso')
  ingreso(@Param('id') id: string, @Body() dto: IngresoDto) {
    return this.srv.ingresarStock(id, dto.cantidad, dto.costo, dto.vence, dto.lote);
  }

  @Post(':id/ajuste')
  ajuste(@Param('id') id: string, @Body() dto: AjusteDto) { return this.srv.ajustar(id, dto.cantidad, dto.motivo, dto.vence, dto.lote); }

  @Get(':id/movimientos')
  movimientos(@Param('id') id: string) { return this.srv.movimientos(id); }

  // Lotes con saldo en orden FEFO (el primero es el que se vende primero).
  @Get(':id/lotes')
  lotes(@Param('id') id: string) { return this.srv.lotes(id); }

  // Historial de precio y costo (para ver cuándo cambió y cómo quedó el margen).
  @Get(':id/precios')
  precios(@Param('id') id: string) { return this.srv.precios(id); }

  // Último costo pagado a cada proveedor por este producto, para comparar.
  @Get(':id/costos-proveedor')
  costosProveedor(@Param('id') id: string) { return this.srv.costosProveedor(id); }

  // Imagen del producto como archivo. La URL lleva ?v=<updated_at>, así que se puede guardar en caché (privada: es de un negocio).
  @Get(':id/img')
  imagen(@Param('id') id: string, @Res({ passthrough: true }) reply: any) {
    const m = /^data:(image\/(?:jpeg|png|webp));base64,(.+)$/.exec(this.srv.imagenDe(id) ?? '');
    if (!m) throw new NotFoundException('El producto no tiene imagen.');
    reply.header('Content-Type', m[1]).header('Cache-Control', 'private, max-age=31536000, immutable').header('X-Content-Type-Options', 'nosniff');
    return Buffer.from(m[2], 'base64');
  }
}
