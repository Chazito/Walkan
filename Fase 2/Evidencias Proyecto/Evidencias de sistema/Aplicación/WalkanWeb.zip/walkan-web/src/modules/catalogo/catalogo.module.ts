// Módulo del catálogo: productos, proveedores, inventario, stock, límites del plan y ventas pendientes.
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { ProductosController } from './productos.controller';
import { ProductosService } from './productos.service';
import { ProductosRepository } from './productos.repository';
import { ProveedoresController } from './proveedores.controller';
import { ProveedoresService } from './proveedores.service';
import { ProveedoresRepository } from './proveedores.repository';
import { StockService } from './stock.service';
import { PrediccionService } from './prediccion.service';
import { InventarioController, LotesController } from './inventario.controller';
import { LimitesPlan } from './limites-plan.service';
import { VentasPendientesService } from './ventas-pendientes.service';
import { VentasPendientesController } from './ventas-pendientes.controller';

// Productos, proveedores, stock y predicción. StockService se exporta porque sync (ventas)
// y compras también mueven stock, y conviene que pase todo por el mismo lado.
@Module({
  imports: [AuthModule],
  controllers: [ProductosController, ProveedoresController, InventarioController, LotesController, VentasPendientesController],
  providers: [ProductosService, ProductosRepository, ProveedoresService, ProveedoresRepository, StockService, PrediccionService, LimitesPlan, VentasPendientesService],
  exports: [ProductosService, ProveedoresRepository, StockService, LimitesPlan, VentasPendientesService],
})
export class CatalogoModule {}
