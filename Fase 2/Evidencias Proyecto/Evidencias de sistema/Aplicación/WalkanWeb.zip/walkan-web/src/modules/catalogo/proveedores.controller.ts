// Endpoints de /api/proveedores: listar, crear, editar y eliminar.
import { Body, Controller, Delete, Get, Param, Post, Put, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { ProveedoresService } from './proveedores.service';
import { ProveedorDto } from './dto/proveedor.dto';

// CRUD de proveedores del negocio logueado (el filtro por cliente lo hace el repo).
@Controller('api/proveedores')
@UseGuards(SesionGuard)
export class ProveedoresController {
  constructor(private readonly srv: ProveedoresService) {}

  @Get()
  listar() { return this.srv.listar(); }

  @Post()
  crear(@Body() dto: ProveedorDto) { return this.srv.crear(dto); }

  @Put(':id')
  actualizar(@Param('id') id: string, @Body() dto: ProveedorDto) { return this.srv.actualizar(id, dto); }

  @Delete(':id')
  eliminar(@Param('id') id: string) { return this.srv.eliminar(id); }
}
