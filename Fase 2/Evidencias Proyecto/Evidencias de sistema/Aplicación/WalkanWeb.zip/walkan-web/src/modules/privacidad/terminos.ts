// Términos y Condiciones del servicio Walkan. Comparten VERSION con la Política de Privacidad (politica.ts):
// si cambias un texto de aquí, sube VERSION allá y los dueños tendrán que aceptar de nuevo al ingresar.
// Texto base redactado para el proyecto; antes de operar comercialmente conviene que lo revise un abogado.
// No importa nada de politica.ts (evita un import circular): el responsable y el correo llegan como parámetros.

type Seccion = { titulo: string; parrafos: string[] };

export function terminos(responsable = 'Walkan (proyecto en formación)', correo = 'walkan.pos@gmail.com'): Seccion[] {
  return [
    { titulo: '1. Quiénes somos y qué aceptas', parrafos: [
      `Estos Términos regulan el uso de Walkan, servicio prestado por ${responsable} (contacto: ${correo}). Al crear tu cuenta o contratar un plan aceptas estos Términos y la Política de Privacidad. Si actúas por un negocio, declaras que puedes aceptarlos en su nombre.`,
    ] },
    { titulo: '2. El servicio', parrafos: [
      'Walkan es un sistema de punto de venta para comercios: una caja instalada en tu local para buscar productos, cobrar, descontar stock y emitir el comprobante de venta, y un panel en la nube para ver ventas, inventario, compras, proveedores y cajas.',
      'La caja trabaja con o sin conexión a internet: guarda las ventas en el equipo y las sincroniza con tu panel cuando hay conexión.',
      'Importante: hoy el comprobante de venta de Walkan es un documento interno y no reemplaza a la boleta o factura electrónica del Servicio de Impuestos Internos (SII). Tu negocio sigue siendo responsable de cumplir sus obligaciones tributarias. Te avisaremos cuando la emisión electrónica ante el SII esté disponible.',
    ] },
    { titulo: '3. Planes y precios', parrafos: [
      'Los planes (Esencial, Profesional y Empresa), lo que incluye cada uno y sus precios mensuales son los publicados en walkan.cl al momento de contratar. La primera caja va incluida en el plan.',
      'Desde la segunda caja, cada caja adicional se arrienda por $5.990 al mes, que se suman al pago de tu renovación, hasta completar 20 cuotas; pagadas las 20, la caja queda para tu negocio. Si cancelas o eliminas tu cuenta antes, debes devolver las cajas con cuotas pendientes o pagar el saldo.',
      'Puedes cambiar de plan cuando quieras desde "Mi cuenta → Mi plan". Si subes de plan, el cambio rige de inmediato y pagas solo la diferencia de precio por los días que quedan de tu mes. Si bajas de plan, el cambio rige desde tu renovación siguiente y lo ya pagado no se devuelve; para bajar, tus cajas y cajeros deben caber en el plan nuevo.',
      'Si cambiamos un precio, te avisaremos por correo con al menos 30 días de anticipación; el nuevo valor se aplica desde la renovación siguiente y puedes cancelar antes si no estás de acuerdo.',
    ] },
    { titulo: '4. Pago y renovación', parrafos: [
      'El plan se paga por mes adelantado en línea a través de Flow (tarjeta o transferencia). Cada pago cubre 30 días. Tienes dos formas de pagar: pagar cada renovación desde "Mi cuenta → Mi plan" (te avisamos por correo y en tu panel antes de que venza), o inscribir una tarjeta para el pago automático.',
      'Si inscribes una tarjeta, nos autorizas a cobrarle, por medio de Flow, el valor de tu plan (más las cuotas de cajas adicionales que correspondan) un día antes de cada vencimiento. Te avisamos por correo antes del cobro. Si el cobro falla, lo reintentamos una vez al día durante los días de gracia y te avisamos. Puedes quitar o cambiar la tarjeta cuando quieras desde "Mi plan"; cancelar el plan también detiene los cobros. La tarjeta la guarda Flow: Walkan solo conoce la marca y los 4 últimos dígitos.',
      'Si el plan vence y no pagas la renovación dentro de los 5 días siguientes, la cuenta queda en pausa: se suspende el acceso al panel y la sincronización. La caja sigue funcionando en el local y sus ventas se sincronizan cuando la cuenta vuelve a estar activa. Con la cuenta en pausa puedes seguir entrando a "Mi cuenta" para pagar, descargar tus datos o eliminar tu cuenta.',
    ] },
    { titulo: '5. Equipo instalado en tu local', parrafos: [
      'La caja que instalamos se entrega para usarla con el servicio mientras tu plan esté vigente. Las condiciones del equipo (propiedad, garantía y devolución al terminar) se acuerdan por escrito al momento de la instalación.',
      'Cuida el equipo y no lo modifiques ni instales otros programas en él: puede dejar de funcionar o perder ventas que aún no se sincronizan.',
    ] },
    { titulo: '6. Tu cuenta y tus usuarios', parrafos: [
      'Eres responsable de lo que se haga con tu cuenta y con los cajeros que crees. Mantén en reserva tu contraseña y los PIN de tus cajeros, y avísanos de inmediato si crees que alguien entró sin permiso.',
      'No uses Walkan para actividades ilegales ni intentes acceder a datos de otros negocios o afectar el funcionamiento del servicio.',
    ] },
    { titulo: '7. Tus datos', parrafos: [
      'Los datos de tu negocio (productos, ventas, compras, proveedores) son tuyos. Walkan los trata solo para prestarte el servicio, según la Política de Privacidad, y puedes descargarlos cuando quieras desde "Mi cuenta": un archivo con tus productos, ventas, compras y proveedores, que se abre en Excel.',
    ] },
    { titulo: '8. Disponibilidad y soporte', parrafos: [
      'Hacemos lo razonable para que el panel esté disponible siempre, pero puede haber interrupciones por mantenimiento o fallas de terceros (internet, proveedores de nube o de pago). La caja de tu local sigue vendiendo durante esas interrupciones.',
      `El soporte se presta por correo (${correo}). Respondemos dentro de 1 día hábil.`,
    ] },
    { titulo: '9. Cancelación', parrafos: [
      'Puedes cancelar tu plan cuando quieras desde "Mi cuenta → Mi plan", sin escribirnos ni dar explicaciones. No se cobran nuevos períodos desde la cancelación y mantienes acceso hasta el fin del período ya pagado. Si cambias de idea, puedes reactivarlo ahí mismo.',
      `También puedes eliminar tu cuenta desde "Mi cuenta": queda cerrada de inmediato y tus datos se borran a los 30 días; hasta ese día puedes descargarlos o recuperar la cuenta. Después del borrado solo conservamos lo que la ley nos obliga a guardar: el registro de los pagos de tu plan y el de tus consentimientos. Si prefieres que lo hagamos nosotros, escríbenos a ${correo} desde el correo de tu cuenta.`,
      'Podemos suspender o terminar el servicio si incumples gravemente estos Términos, avisándote antes cuando sea posible.',
    ] },
    { titulo: '10. Responsabilidad', parrafos: [
      'Walkan se entrega con el cuidado razonable de un servicio profesional. En la medida que la ley lo permita, no respondemos por daños indirectos ni por pérdidas causadas por un mal uso del sistema o del equipo.',
      'Nada de estos Términos limita los derechos que te reconocen la Ley N° 19.496 sobre Protección de los Derechos de los Consumidores y, si tu negocio es una micro o pequeña empresa, la Ley N° 20.416.',
    ] },
    { titulo: '11. Cambios a estos Términos', parrafos: [
      'Si cambiamos estos Términos, actualizaremos la versión y te pediremos aceptarlos de nuevo al ingresar a tu cuenta.',
    ] },
    { titulo: '12. Ley aplicable', parrafos: [
      'Estos Términos se rigen por las leyes de la República de Chile. Cualquier controversia se someterá a los tribunales competentes de Santiago, sin perjuicio de los derechos que la ley te otorga como consumidor.',
    ] },
  ];
}
