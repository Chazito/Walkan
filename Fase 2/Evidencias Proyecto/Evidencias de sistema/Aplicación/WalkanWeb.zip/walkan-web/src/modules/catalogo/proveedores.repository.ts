// Acceso a la tabla proveedores, siempre filtrado por el negocio de la sesión.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { Proveedor } from './tipos';

type Fila = Record<string, any>;
const map = (r: Fila): Proveedor => ({
  id: r.id, nombre: r.nombre, tel: r.tel ?? '', email: r.email ?? '', rubro: r.rubro ?? '', lead: r.lead_time_dias ?? 3, visita: r.dias_visita ?? '',
});

// Todas las queries llevan cliente_id=@clienteId, sacado del contexto de la sesión. Los archivados (activo=0)
// no se listan ni se pueden usar, pero siguen en la tabla para que los pedidos viejos muestren su nombre.
// lead_time_dias null en la BD se muestra como 3 días, igual que en la predicción.
@Injectable()
export class ProveedoresRepository {
  private ins!: Database.Statement;
  private list!: Database.Statement;
  private byId!: Database.Statement;
  private upd!: Database.Statement;
  private del!: Database.Statement;

  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly ctx: ContextoTenant,
  ) {
    this.ins = db.prepare(`INSERT INTO proveedores (id,nombre,tel,email,rubro,lead_time_dias,dias_visita,cliente_id,created_at,updated_at)
      VALUES (@id,@nombre,@tel,@email,@rubro,@lead,@visita,@clienteId,@createdAt,@updatedAt)`);
    this.list = db.prepare('SELECT * FROM proveedores WHERE cliente_id=@clienteId AND activo=1 ORDER BY created_at ASC');
    this.byId = db.prepare('SELECT * FROM proveedores WHERE id=@id AND cliente_id=@clienteId AND activo=1');
    this.upd = db.prepare('UPDATE proveedores SET nombre=@nombre, tel=@tel, email=@email, rubro=@rubro, lead_time_dias=@lead, dias_visita=@visita, updated_at=@updatedAt WHERE id=@id AND cliente_id=@clienteId');
    this.del = db.prepare('DELETE FROM proveedores WHERE id=@id AND cliente_id=@clienteId');
  }

  crear(p: any): void { this.ins.run({ ...p, clienteId: this.ctx.clienteId }); }
  listar(): Proveedor[] { return (this.list.all({ clienteId: this.ctx.clienteId }) as Fila[]).map(map); }
  obtener(id: string): Proveedor | undefined { const r = this.byId.get({ id, clienteId: this.ctx.clienteId }) as Fila | undefined; return r ? map(r) : undefined; }
  actualizar(p: any): void { this.upd.run({ ...p, clienteId: this.ctx.clienteId }); }
  eliminar(id: string): void { this.del.run({ id, clienteId: this.ctx.clienteId }); }
  /** ¿Tiene pedidos? Entonces se archiva en vez de borrarse. */
  tienePedidos(id: string): boolean {
    return !!this.db.prepare('SELECT 1 FROM pedidos WHERE proveedor_id=? AND cliente_id=? LIMIT 1').get(id, this.ctx.clienteId);
  }
  /** Archiva y suelta sus productos (quedan "sin proveedor", igual que al borrarlo). */
  archivar(id: string, now: string): void {
    const c = this.ctx.clienteId;
    this.db.transaction(() => {
      this.db.prepare('UPDATE proveedores SET activo=0, updated_at=? WHERE id=? AND cliente_id=?').run(now, id, c);
      this.db.prepare('UPDATE productos SET proveedor_id=NULL WHERE proveedor_id=? AND cliente_id=?').run(id, c);
    })();
  }
}
