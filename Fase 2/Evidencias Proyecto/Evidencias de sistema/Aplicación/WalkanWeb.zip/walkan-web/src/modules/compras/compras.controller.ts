// Endpoints de /api/compras: historial, detalle, registrar compras y devoluciones.
import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { ComprasService } from './compras.service';
import { CrearCompraBody, CrearDevolucionBody } from './dto/compras.dto';

// Compras = mercadería que entra y suma stock. Toda la lógica está en ComprasService.
@Controller('api/compras')
@UseGuards(SesionGuard)
export class ComprasController {
  constructor(private readonly srv: ComprasService) {}
  @Get() listar() { return this.srv.listarCompras(); }
  @Get(':id') detalle(@Param('id') id: string) { return this.srv.detalleCompra(id); }
  // Devolución al proveedor: saca stock y queda en el historial con total negativo.
  @Post('devolucion') devolver(@Body() dto: CrearDevolucionBody) { return this.srv.crearDevolucion(dto); }
  @Post() crear(@Body() dto: CrearCompraBody) { return this.srv.crearCompra(dto); }
}
