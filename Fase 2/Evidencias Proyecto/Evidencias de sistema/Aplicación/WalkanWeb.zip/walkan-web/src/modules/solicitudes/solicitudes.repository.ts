// Acceso a la tabla solicitudes (prospectos que llenan el formulario del sitio).
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { Solicitud } from './tipos';

type Fila = Record<string, any>;
const map = (r: Fila): Solicitud => ({
  id: r.id, negocio: r.negocio, contacto: r.contacto, email: r.email, telefono: r.telefono,
  comuna: r.comuna, plan: r.plan, mensaje: r.mensaje, estado: r.estado, pagoEstado: r.pago_estado,
  flowOrder: r.flow_order, flowToken: r.flow_token, monto: r.monto, createdAt: r.created_at, updatedAt: r.updated_at,
});

// Solicitudes no son de ningún tenant todavía (son prospectos), así que no se filtra por cliente_id.
// obtenerPorToken es lo que usa el webhook de Flow para encontrar a quién corresponde el pago.
@Injectable()
export class SolicitudesRepository {
  private ins: Database.Statement; private list: Database.Statement; private byId: Database.Statement;
  private byToken: Database.Statement; private updEstado: Database.Statement; private updPago: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this.ins = db.prepare(`INSERT INTO solicitudes
      (id,negocio,contacto,email,telefono,comuna,plan,mensaje,estado,pago_estado,flow_order,flow_token,monto,created_at,updated_at)
      VALUES (@id,@negocio,@contacto,@email,@telefono,@comuna,@plan,@mensaje,@estado,@pagoEstado,@flowOrder,@flowToken,@monto,@createdAt,@updatedAt)`);
    this.list = db.prepare('SELECT * FROM solicitudes ORDER BY created_at DESC LIMIT 200');
    this.byId = db.prepare('SELECT * FROM solicitudes WHERE id=?');
    this.byToken = db.prepare('SELECT * FROM solicitudes WHERE flow_token=?');
    this.updEstado = db.prepare('UPDATE solicitudes SET estado=@estado, updated_at=@now WHERE id=@id');
    this.updPago = db.prepare('UPDATE solicitudes SET pago_estado=@pagoEstado, flow_order=@flowOrder, flow_token=@flowToken, updated_at=@now WHERE id=@id');
  }
  crear(s: Solicitud): void { this.ins.run(s); }
  // Las 200 más nuevas.
  listar(): Solicitud[] { return (this.list.all() as Fila[]).map(map); }
  obtener(id: string): Solicitud | undefined { const r = this.byId.get(id) as Fila | undefined; return r ? map(r) : undefined; }
  obtenerPorToken(token: string): Solicitud | undefined { const r = this.byToken.get(token) as Fila | undefined; return r ? map(r) : undefined; }
  setEstado(id: string, estado: string, now: string): void { this.updEstado.run({ id, estado, now }); }
  setPago(id: string, pagoEstado: string, flowOrder: string | null, flowToken: string | null, now: string): void {
    this.updPago.run({ id, pagoEstado, flowOrder, flowToken, now });
  }
}
