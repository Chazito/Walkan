// Lógica del embudo de solicitudes: crear desde el formulario, avanzar o descartar (staff) y confirmar pagos que avisa Flow.
import { ConflictException, Inject, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { PASARELA, PasarelaPago, pagoCalza } from '../pagos/pasarela.interface';
import { ahora, nuevoId } from '../../common/util/id';
import { SolicitudesRepository } from './solicitudes.repository';
import { Solicitud, ESTADOS } from './tipos';
import { CrearSolicitudDto } from './dto/crear-solicitud.dto';
import { MetaPeticion, PrivacidadService } from '../privacidad/privacidad.service';
import { TEXTO_CASILLA_CONTACTO, TEXTO_CASILLA_MARKETING } from '../privacidad/politica';
import { planCanon } from '../../common/util/planes';

// Embudo de altas: alguien llena el formulario, se le genera el cobro en Flow y después el
// staff va avanzando la solicitud por los pasos de ESTADOS hasta dejarla 'Activa'.
@Injectable()
export class SolicitudesService {
  private readonly logger = new Logger('Solicitudes');
  constructor(
    private readonly repo: SolicitudesRepository,
    @Inject(PASARELA) private readonly pasarela: PasarelaPago,
    @Inject(CONFIG) private readonly cfg: AppConfig,
    private readonly privacidad: PrivacidadService,
  ) {}

  async crear(dto: CrearSolicitudDto, meta: MetaPeticion = {}) {
    const now = ahora();
    // El formulario de contacto es solo contacto: guarda el plan de interés pero no cobra. Contratar (crear la
    // cuenta y pagar) se hace en /registro. Antes cobraba por Flow sin crear la cuenta (U6).
    const plan = dto.plan && this.cfg.planMonto[planCanon(dto.plan)] ? planCanon(dto.plan) : (dto.plan ?? '');
    const monto = 0;
    const s: Solicitud = {
      id: nuevoId(), negocio: dto.negocio, contacto: dto.nombre, email: dto.email,
      telefono: dto.telefono ?? null, comuna: dto.comuna ?? null, plan: plan || 'Sin definir',
      mensaje: dto.mensaje ?? null, estado: 'Nueva', pagoEstado: 'Pendiente',
      flowOrder: null, flowToken: null, monto, createdAt: now, updatedAt: now,
    };
    this.repo.crear(s);
    // Prueba del consentimiento del formulario de contacto (Ley 21.719).
    this.privacidad.registrar({ email: dto.email }, 'privacidad', true, TEXTO_CASILLA_CONTACTO, 'contacto', meta);
    this.privacidad.registrar({ email: dto.email }, 'marketing', !!dto.aceptaMarketing, TEXTO_CASILLA_MARKETING, 'contacto', meta);

    return { solicitud: s };
  }

  listar(): Solicitud[] { return this.repo.listar(); }

  // Pasa la solicitud al siguiente paso de ESTADOS.
  avanzar(id: string): Solicitud {
    const s = this.repo.obtener(id); if (!s) throw new NotFoundException('Solicitud no encontrada.');
    if (s.estado === 'Descartada') throw new ConflictException('La solicitud está descartada.');
    const i = ESTADOS.indexOf(s.estado);
    if (i < 0 || i >= ESTADOS.length - 1) throw new ConflictException('No hay estado siguiente.');
    // Regla de negocio: no se activa a nadie que deba plata (salvo planes sin monto).
    if (ESTADOS[i + 1] === 'Activa' && s.pagoEstado !== 'Pagado' && s.monto > 0)
      throw new ConflictException('No se puede activar: el pago no está confirmado.');
    this.repo.setEstado(id, ESTADOS[i + 1], ahora());
    return this.repo.obtener(id) as Solicitud;
  }
  descartar(id: string): Solicitud {
    const s = this.repo.obtener(id); if (!s) throw new NotFoundException('Solicitud no encontrada.');
    this.repo.setEstado(id, 'Descartada', ahora());
    return this.repo.obtener(id) as Solicitud;
  }

  /**
   * Webhook de Flow: confirma el estado del pago por token. El estado se le pregunta a
   * Flow directo (llamada firmada), así que un POST falso a este endpoint no marca nada como pagado.
   * Flow: 3 = rechazado, 4 = anulado; cualquier otro no pagado queda 'Pendiente'.
   */
  async confirmarPorToken(token: string): Promise<string> {
    const s = this.repo.obtenerPorToken(token);
    if (!s) return 'sin-solicitud';
    const est = await this.pasarela.estadoPago(token);
    const calza = pagoCalza(est, s.id, s.monto);
    if (est.pagado && !calza) this.logger.warn(`Pago Flow no calza con la solicitud ${s.id} (orden ${est.orden}, monto ${est.monto})`);
    const nuevo = calza ? 'Pagado' : (est.estado === '3' || est.estado === '4' ? 'Rechazado' : 'Pendiente');
    this.repo.setPago(s.id, nuevo, s.flowOrder, token, ahora());
    this.logger.log(`Pago de solicitud ${s.id} → ${nuevo}`);
    return nuevo;
  }
}
