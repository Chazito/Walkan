// Acceso a la tabla productos, siempre filtrado por el negocio de la sesión.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { Producto } from './tipos';

type Fila = Record<string, any>;
const map = (r: Fila): Producto => ({
  id: r.id,
  nombre: r.nombre,
  sku: r.sku ?? '',
  cat: r.categoria,
  precio: r.precio,
  costo: r.costo,
  stock: r.stock,
  stockMin: r.stock_minimo ?? null,
  vence: r.vence ?? '',
  controlaVence: !!r.controla_vence,
  unidad: r.unidad === 'kg' ? 'kg' : 'un',
  plu: r.plu ?? null,
  vidaUtil: r.vida_util_dias ?? null,
  prov: r.proveedor_id ?? '',
  emoji: r.emoji ?? '📦',
  // La imagen no viaja en la lista (pesaba hasta ~200 KB por producto cada 30 s): va una URL versionada
  // por updated_at, que el navegador guarda en caché hasta que el producto cambie.
  img: r.img ? `/api/productos/${encodeURIComponent(r.id)}/img?v=${encodeURIComponent(r.updated_at)}` : '',
});

// Productos del negocio de la sesión. Todo filtra por cliente_id y las lecturas solo ven
// activo=1, así los archivados desaparecen del panel pero su kardex sigue ahí.
@Injectable()
export class ProductosRepository {
  private ins!: Database.Statement;
  private list!: Database.Statement;
  private byId!: Database.Statement;
  private upd!: Database.Statement;
  private del!: Database.Statement;
  private archivo!: Database.Statement;

  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly ctx: ContextoTenant,
  ) {
    // El stock nace en 0: el stock inicial entra como movimiento (StockService).
    // vence no se escribe acá: lo deriva StockService de los lotes.
    this.ins = db.prepare(`INSERT INTO productos
      (id,nombre,sku,categoria,precio,costo,stock,stock_minimo,controla_vence,unidad,plu,vida_util_dias,proveedor_id,emoji,img,cliente_id,created_at,updated_at)
      VALUES (@id,@nombre,@sku,@categoria,@precio,@costo,0,@stock_minimo,@controla_vence,@unidad,@plu,@vida_util_dias,@proveedor_id,@emoji,@img,@clienteId,@createdAt,@updatedAt)`);
    this.list = db.prepare('SELECT * FROM productos WHERE cliente_id=@clienteId AND activo=1 ORDER BY created_at ASC');
    this.byId = db.prepare('SELECT * FROM productos WHERE id=@id AND cliente_id=@clienteId AND activo=1');
    this.upd = db.prepare(`UPDATE productos SET
      nombre=@nombre, sku=@sku, categoria=@categoria, precio=@precio, costo=@costo, stock_minimo=@stock_minimo,
      controla_vence=@controla_vence, unidad=@unidad, plu=@plu, vida_util_dias=@vida_util_dias, proveedor_id=@proveedor_id, emoji=@emoji,
      img=CASE WHEN @mantenerImg=1 THEN img ELSE @img END, updated_at=@updatedAt
      WHERE id=@id AND cliente_id=@clienteId`);
    this.del = db.prepare('DELETE FROM productos WHERE id=@id AND cliente_id=@clienteId');
    // Archivar conserva el historial; se libera el SKU para poder reutilizarlo.
    this.archivo = db.prepare('UPDATE productos SET activo=0, sku_archivado=sku, sku=NULL, updated_at=@now WHERE id=@id AND cliente_id=@clienteId');
  }

  crear(p: any): void { this.ins.run({ ...p, clienteId: this.ctx.clienteId }); }
  listar(): Producto[] { return (this.list.all({ clienteId: this.ctx.clienteId }) as Fila[]).map(map); }
  obtener(id: string): Producto | undefined { const r = this.byId.get({ id, clienteId: this.ctx.clienteId }) as Fila | undefined; return r ? map(r) : undefined; }
  actualizar(p: any): void { this.upd.run({ mantenerImg: 0, ...p, clienteId: this.ctx.clienteId }); }
  /** La imagen guardada (data URL) del producto del negocio, o undefined. */
  imagen(id: string): string | undefined {
    return (this.db.prepare('SELECT img FROM productos WHERE id=? AND cliente_id=?').get(id, this.ctx.clienteId) as { img: string | null } | undefined)?.img ?? undefined;
  }
  eliminar(id: string): void { this.del.run({ id, clienteId: this.ctx.clienteId }); }
  archivar(id: string, now: string): void { this.archivo.run({ id, now, clienteId: this.ctx.clienteId }); }
  /** Archivados del negocio (los más recientes primero), con el SKU que tenían. */
  archivados() {
    return (this.db.prepare('SELECT * FROM productos WHERE cliente_id=? AND activo=0 ORDER BY updated_at DESC LIMIT 200').all(this.ctx.clienteId) as Fila[])
      .map((r) => ({ ...map(r), sku: r.sku_archivado ?? '' }));
  }
  /** Vuelve a activar un archivado. Recupera su SKU solo si ningún producto activo lo tomó mientras tanto. Devuelve si lo recuperó. */
  restaurar(id: string, now: string): { ok: boolean; skuRecuperado: boolean; skuTomado: boolean } {
    const r = this.db.prepare('SELECT sku_archivado AS sku FROM productos WHERE id=? AND cliente_id=? AND activo=0').get(id, this.ctx.clienteId) as { sku: string | null } | undefined;
    if (!r) return { ok: false, skuRecuperado: false, skuTomado: false };
    const libre = !!r.sku && !this.db.prepare('SELECT 1 FROM productos WHERE cliente_id=? AND sku=?').get(this.ctx.clienteId, r.sku);
    this.db.prepare('UPDATE productos SET activo=1, sku=?, sku_archivado=NULL, updated_at=? WHERE id=? AND cliente_id=?').run(libre ? r.sku : null, now, id, this.ctx.clienteId);
    return { ok: true, skuRecuperado: libre, skuTomado: !!r.sku && !libre }; // sin sku_archivado = archivado antes de la migración 013
  }
}
