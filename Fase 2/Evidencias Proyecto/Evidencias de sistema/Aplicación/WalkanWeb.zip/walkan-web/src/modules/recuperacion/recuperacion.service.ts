// Lógica de contraseñas: enlaces de recuperación, invitaciones desde /admin y cambio de clave con código de verificación.
import { BadRequestException, HttpException, HttpStatus, Inject, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { createHash, randomBytes, randomInt } from 'crypto';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { ahora, nuevoId } from '../../common/util/id';
import { AuthService } from '../auth/auth.service';
import { UsuariosRepository } from '../auth/usuarios.repository';
import { CorreoService } from '../sync/correo.service';
import { DosPasosService } from '../auth/dos-pasos.service';

const VIGENCIA_MS = 30 * 60_000;     // el enlace sirve 30 minutos
const VIGENCIA_ACCESO_MS = 72 * 3600_000; // enlace de invitación o de acceso restablecido desde /admin: 72 horas
const CODIGO_MS = 10 * 60_000;           // código por correo para cambiar la contraseña: 10 minutos
const MAX_POR_HORA = 3;              // enlaces por correo y hora (frena que alguien le llene la bandeja a otro)
const hashToken = (t: string) => createHash('sha256').update(t).digest('hex');
/** 12.345.678-k → 12345678K, para comparar RUT escritos con o sin puntos y guion. */
const normalizarRut = (r?: string | null) => String(r ?? '').replace(/[.\-\s]/g, '').toUpperCase();
/** a****z@dominio.cl: para decir a dónde llegó el código sin mostrar el correo completo. */
const enmascarar = (email: string) => String(email).replace(/^(.)(.*)(.@)/, (_m, a: string, b: string, c: string) => a + '*'.repeat(Math.min(b.length, 6)) + c);
const esc = (s: string) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

/**
 * "¿Olvidaste tu contraseña?": se manda un enlace de un solo uso al correo; con él se elige una contraseña nueva.
 * - La respuesta es siempre la misma, exista o no el correo (no se revela quién tiene cuenta).
 * - Se guarda solo el hash del token; vence a los 30 minutos y pedir otro anula el anterior.
 * - Al cambiar la clave se cierran todas las sesiones. La verificación en dos pasos sigue pidiéndose al entrar.
 */
@Injectable()
export class RecuperacionService {
  private readonly logger = new Logger('Recuperacion');
  private readonly envios = new Map<string, number[]>(); // correo → horas de los últimos envíos (en memoria)
  // Códigos para cambiar la contraseña (cuentas sin dos pasos). En memoria: si el servidor se reinicia, se pide otro.
  private readonly codigos = new Map<string, { hash: string; expira: number; intentos: number; enviado: number }>();

  constructor(
    private readonly usuarios: UsuariosRepository,
    private readonly auth: AuthService,
    private readonly correo: CorreoService,
    @Inject(CONFIG) private readonly cfg: AppConfig,
    private readonly dos?: DosPasosService,
  ) {}

  /** Enlace para crear la contraseña, enviado desde /admin: invitación a una cuenta nueva o acceso restablecido.
   *  Vale 72 horas y una sola vez; uno nuevo anula el anterior. Nadie ve una clave temporal. */
  async enviarAcceso(usuarioId: string, motivo: 'invitacion' | 'restablecer'): Promise<'enviado' | 'simulado' | 'error'> {
    const u = this.usuarios.porId(usuarioId);
    if (!u) throw new BadRequestException('Usuario no encontrado.');
    const now = ahora(), ms = Date.now();
    this.usuarios.borrarRecuperacionesViejas(new Date(ms - 86400_000).toISOString());
    this.usuarios.cerrarRecuperaciones(u.id, now);
    const token = randomBytes(32).toString('base64url');
    this.usuarios.crearRecuperacion({ id: nuevoId(), usuarioId: u.id, tokenHash: hashToken(token), expira: new Date(ms + VIGENCIA_ACCESO_MS).toISOString(), now });
    const url = `${this.cfg.appUrl.replace(/\/$/, '')}/restablecer?t=${token}`;
    const equipo = u.rol === 'staff';
    const asunto = motivo === 'invitacion' ? (equipo ? 'Te dieron acceso al equipo Walkan' : 'Tu cuenta Walkan está lista') : 'Crea una contraseña nueva para Walkan';
    const intro = motivo === 'invitacion'
      ? (equipo ? 'Te crearon una cuenta en el panel del equipo Walkan.' : `Tu negocio${u.negocio ? ' <b>' + esc(u.negocio) + '</b>' : ''} ya tiene su cuenta en Walkan.`)
      : 'El equipo Walkan restableció el acceso a tu cuenta.';
    const despues = equipo ? '<p style="font-size:13px;color:#555">Al entrar te pediremos activar la verificación en dos pasos con una app del celular (Google Authenticator o Microsoft Authenticator).</p>' : '';
    const r = await this.correo.enviarAviso(u.email, asunto, this.marco(`<p>Hola ${esc(u.nombre || '')}:</p><p>${intro} Para entrar, crea tu contraseña con este botón (sirve una sola vez y vence en 72 horas):</p>
  <p style="margin:20px 0"><a href="${esc(url)}" style="display:inline-block;background:#0B7C4E;color:#fff;text-decoration:none;font-weight:700;padding:12px 20px;border-radius:6px">Crear mi contraseña</a></p>
  <p style="font-size:13px;color:#555">Si el botón no funciona, copia este enlace en el navegador:<br><span style="word-break:break-all">${esc(url)}</span></p>${despues}
  <p style="font-size:13px;color:#555">Tu usuario es este mismo correo: ${esc(u.email)}</p>`));
    if (r === 'simulado') this.logger.log(`[simulado] Enlace de acceso (${motivo}) generado para el usuario ${u.id}: configura SMTP_* para enviarlo`);
    return r;
  }

  /** Paso 1 para cambiar la contraseña en Mi cuenta: quien tiene dos pasos usa su app (no se manda nada);
   *  el resto recibe un código de 6 dígitos en su correo (vale 10 minutos; se puede pedir otro al minuto). */
  async pedirCodigoCambio(usuarioId: string): Promise<{ metodo: 'app' | 'correo'; destino?: string; estado?: string }> {
    const u = this.usuarios.porId(usuarioId);
    if (!u) throw new UnauthorizedException('Sesión inválida.');
    if (u.totp_secreto) return { metodo: 'app' };
    const destino = enmascarar(u.email);
    const prev = this.codigos.get(usuarioId);
    if (prev && Date.now() - prev.enviado < 60_000) {
      throw new HttpException('Ya te enviamos un código. Espera un minuto para pedir otro.', HttpStatus.TOO_MANY_REQUESTS);
    }
    const codigo = String(randomInt(0, 1_000_000)).padStart(6, '0');
    this.codigos.set(usuarioId, { hash: hashToken(codigo), expira: Date.now() + CODIGO_MS, intentos: 0, enviado: Date.now() });
    const estado = await this.correo.enviarAviso(u.email, `Tu código para cambiar la contraseña de Walkan: ${codigo}`,
      this.marco(`<p>Hola ${esc(u.nombre || '')}:</p><p>Para cambiar la contraseña de tu cuenta Walkan, escribe este código (vale 10 minutos):</p>
  <p style="margin:18px 0;font-size:28px;font-weight:800;letter-spacing:6px">${codigo}</p>
  <p style="font-size:13px;color:#555">Si no estás cambiando tu contraseña, ignora este correo y cámbiala apenas puedas: alguien sabe tu contraseña actual.</p>`));
    if (estado === 'simulado') this.logger.log('[simulado] Código para cambiar la contraseña generado (configura SMTP_* para enviarlo)');
    return { metodo: 'correo', destino, estado };
  }

  /** Paso 2: contraseña actual + código (de la app, de respaldo o del correo) + la nueva. */
  async cambiarPassword(usuarioId: string, actual: string, nueva: string, codigo: string): Promise<{ ok: true }> {
    const u = this.usuarios.porId(usuarioId);
    if (!u) throw new UnauthorizedException('Sesión inválida.');
    if (!(await this.auth.claveCorrecta(usuarioId, actual))) throw new UnauthorizedException('La contraseña actual no es correcta.');
    const limpio = String(codigo ?? '').trim();
    if (!limpio) throw new BadRequestException(u.totp_secreto ? 'Escribe el código de tu app de verificación.' : 'Escribe el código que te enviamos por correo.');
    if (u.totp_secreto) {
      if (!this.dos?.usarCodigo(usuarioId, limpio)) throw new BadRequestException('El código no es correcto. Usa el de tu app (o uno de respaldo).');
    } else {
      const c = this.codigos.get(usuarioId);
      if (!c || c.expira <= Date.now()) { this.codigos.delete(usuarioId); throw new BadRequestException('El código venció o no lo has pedido. Pide uno nuevo.'); }
      if (hashToken(limpio) !== c.hash) {
        if (++c.intentos >= 5) { this.codigos.delete(usuarioId); throw new BadRequestException('Demasiados intentos. Pide un código nuevo.'); }
        throw new BadRequestException('El código no es correcto.');
      }
    }
    const r = await this.auth.cambiarPassword(usuarioId, actual, nueva);
    this.codigos.delete(usuarioId);
    void this.correo.enviarAviso(u.email, 'Tu contraseña de Walkan cambió',
      this.marco(`<p>Hola ${esc(u.nombre || '')}:</p><p>La contraseña de tu cuenta Walkan se cambió recién desde Mi cuenta, y se cerraron las sesiones abiertas en otros equipos.</p>
      <p>Si no fuiste tú, escríbenos de inmediato respondiendo este correo.</p>`));
    return r;
  }

  /** "¿Olvidaste tu contraseña?": genera el enlace y lo manda por correo. Responde igual exista o no la cuenta. */
  async pedir(email: string, rut?: string): Promise<{ ok: true; mensaje: string }> {
    const mensaje = 'Si los datos coinciden con una cuenta en Walkan, te enviamos un enlace para crear una contraseña nueva. Llega desde walkan.pos@gmail.com: si no lo ves en unos minutos, revisa la carpeta de spam o correo no deseado.';
    const correo = String(email).toLowerCase().trim();
    const ahoraMs = Date.now();
    const previos = (this.envios.get(correo) ?? []).filter((t) => t > ahoraMs - 3600_000);
    if (previos.length >= MAX_POR_HORA) { this.logger.warn('Recuperación: tope de enlaces por hora alcanzado'); return { ok: true, mensaje }; }
    const u = this.usuarios.porEmail(correo);
    if (!u || u.desactivado_en) return { ok: true, mensaje }; // una cuenta desactivada no recupera la clave
    this.envios.set(correo, [...previos, ahoraMs]); // también cuenta un RUT equivocado: frena que se pruebe RUT tras RUT
    // Precaución extra para dueños: si su negocio tiene RUT registrado, debe coincidir. Si no coincide no se manda
    // nada, pero la respuesta es la misma (no se revela si el correo existe ni si el RUT era el correcto).
    const rutCuenta = u.rol === 'admin' && u.cliente_id ? this.usuarios.rutDeCliente(u.cliente_id) : null;
    if (rutCuenta && normalizarRut(rut) !== normalizarRut(rutCuenta)) {
      this.logger.warn('Recuperación: el RUT no coincide con el del negocio, no se envía el enlace');
      return { ok: true, mensaje };
    }
    const now = ahora();
    this.usuarios.borrarRecuperacionesViejas(new Date(ahoraMs - 86400_000).toISOString());
    this.usuarios.cerrarRecuperaciones(u.id, now); // solo sirve el último enlace
    const token = randomBytes(32).toString('base64url');
    this.usuarios.crearRecuperacion({ id: nuevoId(), usuarioId: u.id, tokenHash: hashToken(token), expira: new Date(ahoraMs + VIGENCIA_MS).toISOString(), now });
    const url = `${this.cfg.appUrl.replace(/\/$/, '')}/restablecer?t=${token}`;
    // Sin esperar el envío: así la respuesta tarda lo mismo exista o no la cuenta (el tiempo no delata quién tiene cuenta).
    void this.correo.enviarAviso(u.email, 'Crea una contraseña nueva para Walkan', this.html(u.nombre, url)).then((r) => {
      if (r === 'simulado') this.logger.log('[simulado] Enlace de recuperación generado (configura SMTP_* para enviarlo de verdad)');
    });
    return { ok: true, mensaje };
  }

  /** ¿El enlace sigue sirviendo? (la página lo revisa antes de mostrar el formulario). */
  vigente(token: string): boolean {
    const r = token ? this.usuarios.recuperacionPorHash(hashToken(token)) : undefined;
    return !!r && !r.usado_en && Date.parse(r.expira) > Date.now();
  }

  // Usa el enlace del correo: pone la contraseña nueva, lo deja gastado y avisa al dueño por correo.
  async restablecer(token: string, password: string): Promise<{ ok: true }> {
    const r = this.usuarios.recuperacionPorHash(hashToken(token));
    if (!r || r.usado_en || Date.parse(r.expira) <= Date.now()) {
      throw new BadRequestException('El enlace ya no sirve: venció o ya se usó. Pide uno nuevo.');
    }
    this.auth.establecerPassword(r.usuario_id, password);
    this.usuarios.cerrarRecuperaciones(r.usuario_id, ahora());
    const u = this.usuarios.porId(r.usuario_id);
    if (u) {
      await this.correo.enviarAviso(u.email, 'Tu contraseña de Walkan cambió',
        this.marco(`<p>Hola ${esc(u.nombre || '')}:</p><p>La contraseña de tu cuenta Walkan se cambió recién con un enlace de recuperación, y se cerraron las sesiones abiertas.</p>
        <p>Si no fuiste tú, escríbenos de inmediato respondiendo este correo.</p>`));
    }
    return { ok: true };
  }

  // Envoltorio común de todos los correos de acá: logo de texto, el cuerpo y el pie.
  private marco(cuerpo: string): string {
    return `<!doctype html><html lang="es"><body style="margin:0;background:#f4f6f5;font-family:Arial,Helvetica,sans-serif;color:#111">
<div style="max-width:460px;margin:24px auto;background:#fff;border-radius:12px;padding:24px;border:1px solid #e3e7e5">
  <p style="margin:0 0 16px;font-weight:800;font-size:18px;color:#0B7C4E">Walkan</p>${cuerpo}
  <p style="font-size:12px;color:#888;margin:20px 0 0">Walkan · Tu negocio siempre funcionando.</p>
</div></body></html>`;
  }
  // Cuerpo del correo de "¿Olvidaste tu contraseña?".
  private html(nombre: string, url: string): string {
    return this.marco(`<p>Hola ${esc(nombre || '')}:</p>
  <p>Pediste crear una contraseña nueva para tu cuenta Walkan. Usa este botón (sirve una sola vez y vence en 30 minutos):</p>
  <p style="margin:20px 0"><a href="${esc(url)}" style="display:inline-block;background:#0B7C4E;color:#fff;text-decoration:none;font-weight:700;padding:12px 20px;border-radius:6px">Crear contraseña nueva</a></p>
  <p style="font-size:13px;color:#555">Si el botón no funciona, copia este enlace en el navegador:<br><span style="word-break:break-all">${esc(url)}</span></p>
  <p style="font-size:13px;color:#555">Si no lo pediste tú, ignora este correo: tu contraseña sigue igual.</p>`);
  }
}
