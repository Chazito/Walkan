import { firmarParams } from './firma';

export interface CredencialesFlow { apiUrl: string; apiKey: string; secretKey: string }
// FLOW_QR_API_URL solo para pruebas automáticas (un Flow simulado); en uso normal no se define.
export const FLOW_API = {
  sandbox: process.env.FLOW_QR_API_URL || 'https://sandbox.flow.cl/api',
  produccion: process.env.FLOW_QR_API_URL || 'https://www.flow.cl/api',
} as const;

/**
 * Cliente de la API de Flow con credenciales explícitas (las de cada negocio, para el cobro con QR).
 * Las suscripciones de Walkan siguen usando FlowPasarela con las llaves del .env.
 */
export class FlowCliente {
  constructor(private readonly c: CredencialesFlow) {}

  private firmados(p: Record<string, string | number>) {
    const params: Record<string, string | number> = { apiKey: this.c.apiKey, ...p };
    params.s = firmarParams(params, this.c.secretKey);
    return new URLSearchParams(params as Record<string, string>).toString();
  }

  async crearPago(i: { orden: string; asunto: string; monto: number; email: string; urlConfirmacion: string; urlRetorno: string }) {
    const r = await fetch(`${this.c.apiUrl}/payment/create`, {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: this.firmados({ commerceOrder: i.orden, subject: i.asunto, currency: 'CLP', amount: i.monto, email: i.email,
        urlConfirmation: i.urlConfirmacion, urlReturn: i.urlRetorno }),
      signal: AbortSignal.timeout(15_000),
    });
    const data: any = await r.json().catch(() => ({}));
    if (!r.ok || !data.url || !data.token) throw new Error(data?.message || `Flow respondió ${r.status}`);
    return { url: `${data.url}?token=${data.token}`, token: String(data.token), flowOrder: String(data.flowOrder ?? '') };
  }

  /** status Flow: 1 pendiente, 2 pagado, 3 rechazado, 4 anulado. */
  async estado(token: string) {
    const r = await fetch(`${this.c.apiUrl}/payment/getStatus?${this.firmados({ token })}`, { signal: AbortSignal.timeout(15_000) });
    const data: any = await r.json().catch(() => ({}));
    return { status: Number(data.status ?? 0), flowOrder: String(data.flowOrder ?? ''), medio: String(data.paymentData?.media ?? ''), orden: String(data.commerceOrder ?? ''), monto: Number(data.amount ?? 0), raw: data };
  }

  /** Prueba las llaves: consulta una orden que no existe. Si Flow reclama por la llave o la firma, son inválidas. */
  async probar(): Promise<{ ok: boolean; detalle: string }> {
    try {
      const r = await fetch(`${this.c.apiUrl}/payment/getStatusByCommerceId?${this.firmados({ commerceId: 'walkan-prueba-' + Date.now() })}`,
        { signal: AbortSignal.timeout(15_000) });
      const data: any = await r.json().catch(() => ({}));
      const msg = String(data?.message ?? '');
      if (r.status === 401 || /api ?key|apikey|firma|sign|unauthori|credencial/i.test(msg)) return { ok: false, detalle: msg || `HTTP ${r.status}` };
      return { ok: true, detalle: msg };
    } catch (e) {
      return { ok: false, detalle: 'No se pudo contactar a Flow: ' + (e as Error).message };
    }
  }
}
