// Módulo de soporte: controller y servicio de tickets.
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { SyncModule } from '../sync/sync.module';
import { SoporteController } from './soporte.controller';
import { SoporteService } from './soporte.service';

// Soporte: centro de ayuda (/ayuda, en views) y tickets. Importa sync por el servicio de correo.
@Module({
  imports: [AuthModule, SyncModule],
  controllers: [SoporteController],
  providers: [SoporteService],
  exports: [SoporteService],
})
export class SoporteModule {}
