// Acceso a la tabla ventas: guardar lo que sube la caja y consultar las ventas del negocio para el panel.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';

type Fila = Record<string, any>;

@Injectable()
export class VentasRepository {
  // Este repo no usa ContextoTenant: la sync entra con token de caja (sin sesión), así que
  // el clienteId se pasa explícito desde el servicio.
  private ins!: Database.Statement;
  private existe!: Database.Statement;
  private recientes!: Database.Statement;
  private rango!: Database.Statement;
  private totalCaja!: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this.ins = db.prepare(`INSERT INTO ventas
      (id,caja_id,cliente_id,seq,folio,fecha,cajero,medio_pago,neto,iva,total,sii_estado,items_json,created_at,pago_json,uid)
      VALUES (@id,@cajaId,@clienteId,@seq,@folio,@fecha,@cajero,@medioPago,@neto,@iva,@total,@siiEstado,@itemsJson,@createdAt,@pagoJson,@uid)`);
    // (caja, seq) identifica una venta: si la caja reintenta un envío, no se duplica.
    this.existe = db.prepare('SELECT 1 FROM ventas WHERE caja_id=? AND seq=?');
    this.recientes = db.prepare(`SELECT v.*, c.nombre AS caja_nombre FROM ventas v
      JOIN cajas c ON c.id=v.caja_id WHERE v.cliente_id=? ORDER BY v.fecha DESC LIMIT 100`);
    // Rango amplio en UTC (±1 día); el servicio recorta por día de Chile.
    this.rango = db.prepare(`SELECT v.*, c.nombre AS caja_nombre FROM ventas v
      JOIN cajas c ON c.id=v.caja_id WHERE v.cliente_id=@clienteId
      AND v.fecha >= date(@desde, '-1 day') AND v.fecha < date(@hasta, '+2 day') ORDER BY v.fecha DESC LIMIT 5000`);
    this.totalCaja = db.prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS monto FROM ventas WHERE caja_id=?");
  }
  yaExiste(cajaId: string, seq: number): boolean { return !!this.existe.get(cajaId, seq); }
  /** ¿Ya llegó la venta con este id de la caja? (C3: distingue un reenvío de una caja que reinició su numeración). */
  existeUid(cajaId: string, uid: string): boolean { return !!this.db.prepare('SELECT 1 FROM ventas WHERE caja_id=? AND uid=?').get(cajaId, uid); }
  /** uid guardado para ese seq: undefined = no hay venta con ese seq; null = venta de antes de la migración 029. */
  uidDeSeq(cajaId: string, seq: number): string | null | undefined {
    const r = this.db.prepare('SELECT uid FROM ventas WHERE caja_id=? AND seq=?').get(cajaId, seq) as { uid: string | null } | undefined;
    return r ? r.uid : undefined;
  }
  // uid es opcional: las cajas antiguas no lo mandan y queda en null.
  insertar(v: any): void { this.ins.run({ uid: null, ...v }); }
  listarRecientes(clienteId: string): Fila[] { return this.recientes.all(clienteId) as Fila[]; }
  listarRango(clienteId: string, desde: string, hasta: string): Fila[] { return this.rango.all({ clienteId, desde, hasta }) as Fila[]; }
  totalesPorCaja(cajaId: string): Fila { return this.totalCaja.get(cajaId) as Fila; }
}
