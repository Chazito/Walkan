// Lógica de login y sesiones: contraseñas (scrypt), bloqueo por intentos fallidos, dispositivos recordados y vigencia del plan.
import { BadRequestException, ConflictException, ForbiddenException, HttpException, HttpStatus, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { createHash, randomBytes, randomInt, scrypt, scryptSync, timingSafeEqual } from 'crypto';
import { promisify } from 'util';
import { ahora, nuevoId } from '../../common/util/id';
import { claveIp } from '../../common/util/ip';
import { calcularVigencia, Vigencia } from '../../common/util/vigencia';
import { UsuariosRepository } from './usuarios.repository';
import { LoginDto } from './dto/login.dto';
import { Usuario } from './tipos';

// Límite de intentos fallidos de login: 5 fallos desde una IP para un correo → 15 minutos de espera para esa
// IP (así un tercero no puede bloquearle la cuenta al dueño desde otro lado). Además, 50 fallos para un
// mismo correo sumando todas las IP lo bloquean entero (frena el ataque repartido en muchas IP).
const MAX_FALLOS = 5;
const MAX_FALLOS_CORREO = 50;
const BLOQUEO_MS = 15 * 60_000;
const scryptAsync = promisify(scrypt) as (p: string, s: Buffer, n: number) => Promise<Buffer>;
// Hash de relleno: con un correo que no existe igual se corre scrypt, para que el tiempo de respuesta no
// delate qué correos están registrados.
const hashToken = (t: string) => createHash('sha256').update(t).digest('hex');
const HASH_RELLENO = `${randomBytes(16).toString('hex')}:${randomBytes(64).toString('hex')}`;

@Injectable()
export class AuthService {
  private readonly logger = new Logger('Auth');
  private readonly fallos = new Map<string, { n: number; hasta: number }>();
  constructor(private readonly repo: UsuariosRepository) {}

  // "ip" acá es la clave del cliente (claveIp): la IPv4, o la red /64 si es IPv6. Con la dirección exacta, una sola
  // conexión IPv6 juntaba los 50 fallos "de muchas IP" y dejaba la cuenta bloqueada para todos.
  private revisarBloqueo(email: string, ip: string): void {
    for (const k of [email + '|' + ip, email]) {
      const f = this.fallos.get(k);
      if (f && f.hasta > Date.now()) {
        const min = Math.ceil((f.hasta - Date.now()) / 60_000);
        throw new HttpException(`Demasiados intentos fallidos. Espera ${min} minuto(s) e inténtalo de nuevo.`, HttpStatus.TOO_MANY_REQUESTS);
      }
    }
  }
  private registrarFallo(email: string, ip: string): void {
    // ponytail: contadores en memoria (se pierden al reiniciar); a una tabla si hay más de un proceso.
    if (this.fallos.size > 10_000) for (const [k, f] of this.fallos) if (f.hasta <= Date.now()) this.fallos.delete(k);
    for (const [k, max] of [[email + '|' + ip, MAX_FALLOS], [email, MAX_FALLOS_CORREO]] as const) {
      const f = this.fallos.get(k);
      const n = (f && f.hasta && f.hasta <= Date.now() ? 0 : f?.n ?? 0) + 1;
      this.fallos.set(k, { n, hasta: n >= max ? Date.now() + BLOQUEO_MS : 0 });
      if (n === max) this.logger.warn(`Login bloqueado 15 min por intentos fallidos (${k === email ? 'todas las IP' : 'una IP'})`);
    }
  }

  // ---- Sesiones por dispositivo ----
  // La cookie lleva un identificador aleatorio de la sesión (firmado), nunca el id del usuario.
  static readonly DURACION_RECORDAR_MS = 30 * 86400_000; // 30 días, se renueva al usarla
  static readonly DURACION_CORTA_MS = 12 * 3600_000;     // 12 horas sin "Recordarme"

  /** Abre una sesión nueva para este dispositivo y devuelve su identificador. */
  abrirSesion(usuarioId: string, recordar: boolean): string {
    const now = new Date();
    this.repo.borrarVencidas(now.toISOString());
    const id = randomBytes(32).toString('base64url');
    const dur = recordar ? AuthService.DURACION_RECORDAR_MS : AuthService.DURACION_CORTA_MS;
    this.repo.crearSesion({ id, usuarioId, recordar, now: now.toISOString(), expira: new Date(now.getTime() + dur).toISOString() });
    return id;
  }

  /** Usuario de una sesión vigente, o undefined si no existe, venció o fue cerrada.
   *  `renovada` = true cuando una sesión con "Recordarme" se extendió otros 30 días (hay que reenviar la cookie). */
  usuarioDeSesion(sesionId: string): (Usuario & { renovada?: boolean }) | undefined {
    const s = this.repo.sesion(sesionId);
    if (!s) return undefined;
    const now = Date.now();
    if (Date.parse(s.expira) <= now) { this.repo.borrarSesion(sesionId); return undefined; }
    const r = this.repo.porId(s.usuario_id);
    if (!r) return undefined;
    if (r.desactivado_en) { this.repo.borrarSesion(sesionId); return undefined; }
    let renovada = false;
    // Renovación deslizante: si a una sesión recordada le quedan menos de 25 días, vuelve a 30.
    if (s.recordar && Date.parse(s.expira) - now < 25 * 86400_000) {
      this.repo.renovarSesion(sesionId, new Date(now + AuthService.DURACION_RECORDAR_MS).toISOString(), new Date(now).toISOString());
      renovada = true;
    }
    return { ...this.publico(r), renovada };
  }

  cerrarSesion(sesionId: string): void { this.repo.borrarSesion(sesionId); }

  // ---- "Recordar este dispositivo" (solo dueños): el navegador guarda un token y al entrar no se pide el código
  // de la app (la contraseña sí). Se olvida al cambiar la clave o la verificación en dos pasos. ----
  static readonly DISPOSITIVO_MS = 30 * 86400_000;
  puedeRecordarDispositivo(u: Usuario): boolean { return u.rol !== 'staff'; }
  recordarDispositivo(usuarioId: string): string {
    const token = randomBytes(32).toString('base64url');
    const now = new Date();
    this.repo.recordarDispositivo({ id: nuevoId(), usuarioId, tokenHash: hashToken(token), expira: new Date(now.getTime() + AuthService.DISPOSITIVO_MS).toISOString(), now: now.toISOString() });
    return token;
  }
  dispositivoRecordado(u: Usuario, token: string | undefined): boolean {
    return !!token && this.puedeRecordarDispositivo(u) && this.repo.dispositivoVigente(u.id, hashToken(token), new Date().toISOString());
  }
  olvidarDispositivos(usuarioId: string): void { this.repo.olvidarDispositivos(usuarioId); }
  dispositivosRecordados(usuarioId: string): number { return this.repo.contarDispositivos(usuarioId, new Date().toISOString()); }
  /** Cierra las sesiones del usuario en los demás dispositivos (o todas, sin `excepto`). */
  cerrarOtrasSesiones(usuarioId: string, excepto?: string): void { this.repo.borrarSesionesDe(usuarioId, excepto); }

  /** Crea un usuario (dueño de cliente, cajero o staff). Lanza si el email ya existe. */
  crearUsuario(dto: {
    email: string; nombre: string; password?: string;
    rol?: string; clienteId?: string | null; negocio?: string | null;
  }): Usuario {
    // Sin contraseña: cuenta invitada. Se guarda una clave aleatoria que nadie conoce; la persona crea la suya con
    // el enlace que le llega por correo (ver RecuperacionService.enviarAcceso).
    const email = dto.email.toLowerCase().trim();
    if (this.repo.porEmail(email)) throw new ConflictException('Ya existe un usuario con ese correo.');
    const now = ahora();
    const id = nuevoId();
    this.repo.crear({
      id, email, nombre: dto.nombre, negocio: dto.negocio ?? null,
      clienteId: dto.clienteId ?? null, passwordHash: this.hash(dto.password ?? randomBytes(32).toString('base64url')),
      rol: dto.rol ?? 'admin', createdAt: now, updatedAt: now,
    });
    if (dto.password === undefined) this.repo.setClavePendiente(id, true);
    return this.publico(this.repo.porId(id)!);
  }

  /** Deja la cuenta sin una contraseña que alguien conozca (para mandarle un enlace nuevo) y cierra sus sesiones. */
  anularPassword(id: string): void {
    this.repo.setPassword(id, this.hash(randomBytes(32).toString('base64url')), ahora());
    this.repo.setClavePendiente(id, true);
    this.repo.borrarSesionesDe(id);
  }

  // scrypt con salt aleatorio, guardado como "salt:hash" en hex. Nada de librerías extra, viene en Node.
  private hash(pass: string): string {
    const salt = randomBytes(16);
    const dk = scryptSync(pass, salt, 64);
    return `${salt.toString('hex')}:${dk.toString('hex')}`;
  }
  // Asíncrono: scryptSync bloqueaba el servidor entero en cada login (una ráfaga de logins frenaba todo).
  private async verificar(pass: string, stored: string): Promise<boolean> {
    const [s, h] = (stored || '').split(':');
    if (!s || !h) return false;
    const dk = await scryptAsync(pass, Buffer.from(s, 'hex'), 64);
    const hb = Buffer.from(h, 'hex');
    // timingSafeEqual para que no se pueda adivinar el hash midiendo cuánto demora la comparación.
    return dk.length === hb.length && timingSafeEqual(dk, hb);
  }
  // Lo único que sale de este servicio hacia afuera: la fila sin password_hash.
  private publico(r: Record<string, any>): Usuario {
    return { id: r.id, email: r.email, nombre: r.nombre, negocio: r.negocio ?? null, rol: r.rol, clienteId: r.cliente_id ?? null, dosPasos: !!r.totp_secreto,
      ...(r.rol === 'staff' ? { superAdmin: !!r.super_admin } : {}) };
  }

  /** Valida correo + contraseña SIN mirar el estado del negocio (lo usa el reintento de pago). */
  async validarCredenciales(email: string, password: string, ipCliente = ''): Promise<Usuario> {
    const correo = email.toLowerCase().trim();
    const ip = claveIp(ipCliente);
    this.revisarBloqueo(correo, ip);
    const r = this.repo.porEmail(correo);
    // Mismo mensaje (y mismo tiempo) si no existe el correo o si la clave está mala, para no regalar qué
    // correos están registrados.
    const ok = await this.verificar(password, r ? r.password_hash : HASH_RELLENO);
    if (!r || !ok) {
      this.registrarFallo(correo, ip);
      throw new UnauthorizedException('Correo o contraseña incorrectos.');
    }
    this.fallos.delete(correo + '|' + ip);
    // Solo después de validar la clave: a un tercero no le dice si la cuenta existe.
    if (r.desactivado_en) throw new ForbiddenException('Esta cuenta está desactivada. Pide a un administrador del equipo Walkan que la reactive.');
    return this.publico(r);
  }

  async login(dto: LoginDto, ip = ''): Promise<Usuario> {
    const usuario = await this.validarCredenciales(dto.email, dto.password, ip);
    this.verificarCuentaActiva(usuario);
    return usuario;
  }

  /** Bloquea a usuarios cuyo negocio (tenant) no está activo. El staff Walkan no tiene tenant.
   *  Devuelve la vigencia del plan (undefined para el staff): con el plan vencido la sesión sigue abierta, pero el
   *  SesionGuard solo deja pasar las rutas de Mi cuenta (ver permitidaEnPausa). */
  verificarCuentaActiva(u: Usuario): Vigencia | undefined {
    if (u.rol === 'staff' || !u.clienteId) return undefined;
    const d = this.repo.vigenciaCliente(u.clienteId);
    if (d?.estado === 'pendiente') {
      throw new ForbiddenException('Tu cuenta está pendiente de pago. Completa el pago del plan para activarla.');
    }
    if (d?.estado !== 'activo') {
      throw new ForbiddenException('La cuenta de este negocio está suspendida. Contacta al equipo Walkan.');
    }
    return calcularVigencia(d);
  }

  /** Estado del cliente (para el sync de cajas). */
  estadoCliente(clienteId: string): string | undefined {
    return this.repo.estadoCliente(clienteId);
  }

  /** Vigencia del plan de un negocio (undefined si el negocio no existe). */
  vigencia(clienteId: string): Vigencia | undefined {
    const d = this.repo.vigenciaCliente(clienteId);
    return d ? calcularVigencia(d) : undefined;
  }

  /** ¿El negocio puede operar (panel y sincronización de cajas)? Activo y con el plan al día o en días de gracia. */
  cuentaOperativa(clienteId: string): boolean {
    const d = this.repo.vigenciaCliente(clienteId);
    return !!d && d.estado === 'activo' && calcularVigencia(d).operativa;
  }

  /** Genera una contraseña temporal legible que cumple la política (mayúscula, minúscula, número y
   *  símbolo; sin 0/O ni 1/l/I para no confundirse al dictarla). */
  generarClaveTemporal(largo = 12): string {
    const grupos = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghjkmnpqrstuvwxyz', '23456789', '!@#$%&*?-'];
    const todos = grupos.join('');
    const c = grupos.map((g) => g[randomInt(g.length)]); // uno de cada tipo
    while (c.length < largo) c.push(todos[randomInt(todos.length)]);
    for (let i = c.length - 1; i > 0; i--) { const j = randomInt(i + 1); [c[i], c[j]] = [c[j], c[i]]; }
    return c.join('');
  }

  /** Restablece la contraseña de un usuario con una temporal y la devuelve (solo la usa el staff). */
  restablecerPassword(id: string): string {
    const r = this.repo.porId(id);
    if (!r) throw new BadRequestException('Usuario no encontrado.');
    const temporal = this.generarClaveTemporal();
    this.repo.setPassword(id, this.hash(temporal), ahora());
    this.repo.borrarSesionesDe(id); // la clave anterior y todas sus sesiones dejan de servir
    return temporal;
  }

  /** Cambia la contraseña del usuario en sesión, verificando la actual. */
  async cambiarPassword(id: string, actual: string, nueva: string): Promise<{ ok: true }> {
    const r = this.repo.porId(id);
    if (!r || !(await this.verificar(actual, r.password_hash))) {
      throw new UnauthorizedException('La contraseña actual no es correcta.');
    }
    if (actual === nueva) throw new BadRequestException('La nueva contraseña debe ser distinta de la actual.');
    this.repo.setPassword(id, this.hash(nueva), ahora());
    this.logger.log(`Contraseña actualizada: usuario ${id}`);
    return { ok: true };
  }
  /** ¿La contraseña es la del usuario? (para confirmar acciones sensibles, como apagar la verificación en dos pasos). */
  async claveCorrecta(id: string, pass: string): Promise<boolean> {
    const r = this.repo.porId(id);
    return !!r && (await this.verificar(String(pass ?? ''), r.password_hash));
  }

  /** Fija una contraseña nueva (enlace de recuperación): cierra todas las sesiones y borra los bloqueos por intentos. */
  establecerPassword(id: string, nueva: string): void {
    const r = this.repo.porId(id);
    if (!r) throw new BadRequestException('Usuario no encontrado.');
    this.repo.setPassword(id, this.hash(nueva), ahora());
    this.repo.setClavePendiente(id, false);
    this.repo.borrarSesionesDe(id);
    for (const k of [...this.fallos.keys()]) if (k === r.email || k.startsWith(r.email + '|')) this.fallos.delete(k);
    this.logger.log(`Contraseña restablecida con enlace de recuperación: usuario ${id}`);
  }

  porId(id: string): Usuario | undefined {
    const r = this.repo.porId(id);
    return r ? this.publico(r) : undefined;
  }
}
