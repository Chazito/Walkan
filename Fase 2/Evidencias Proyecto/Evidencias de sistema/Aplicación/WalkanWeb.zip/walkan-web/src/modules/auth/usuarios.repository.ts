// Acceso a la base para usuarios, sesiones, dos pasos, recuperación de clave y dispositivos recordados.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';

type Fila = Record<string, any>;

// Usuarios es tabla global (no se filtra por tenant): el login busca por email antes de saber
// de qué tienda es la persona. Devuelve filas crudas, con password_hash incluido, así que no
// mandar esto directo al front.
@Injectable()
export class UsuariosRepository {
  private ins!: Database.Statement;
  private byEmail!: Database.Statement;
  private byId!: Database.Statement;
  private count!: Database.Statement;
  private countStaff!: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this.ins = db.prepare(`INSERT INTO usuarios (id,email,nombre,negocio,cliente_id,password_hash,rol,created_at,updated_at)
      VALUES (@id,@email,@nombre,@negocio,@clienteId,@passwordHash,@rol,@createdAt,@updatedAt)`);
    this.byEmail = db.prepare('SELECT * FROM usuarios WHERE email=?');
    this.byId = db.prepare('SELECT * FROM usuarios WHERE id=?');
    this.count = db.prepare('SELECT COUNT(*) AS n FROM usuarios');
    this.countStaff = db.prepare("SELECT COUNT(*) AS n FROM usuarios WHERE rol='staff'");
  }
  crear(u: any): void { this.ins.run(u); }
  asignarCliente(id: string, clienteId: string, now: string): void {
    this.db.prepare('UPDATE usuarios SET cliente_id=@clienteId, updated_at=@now WHERE id=@id').run({ id, clienteId, now });
  }
  /** Cambiar la contraseña (por cualquier vía) también olvida los dispositivos recordados. */
  setPassword(id: string, passwordHash: string, now: string): void {
    this.olvidarDispositivos(id);
    this.db.prepare('UPDATE usuarios SET password_hash=@passwordHash, updated_at=@now WHERE id=@id').run({ id, passwordHash, now });
  }
  // ---- sesiones por dispositivo (tabla sesiones, migración 016) ----
  crearSesion(s: { id: string; usuarioId: string; recordar: boolean; now: string; expira: string }): void {
    this.db.prepare(`INSERT INTO sesiones (id,usuario_id,recordar,creada,expira,ultimo_uso)
      VALUES (@id,@usuarioId,@recordar,@now,@expira,@now)`).run({ ...s, recordar: s.recordar ? 1 : 0 });
  }
  sesion(id: string): Fila | undefined {
    return this.db.prepare('SELECT * FROM sesiones WHERE id=?').get(id) as Fila | undefined;
  }
  renovarSesion(id: string, expira: string, now: string): void {
    this.db.prepare('UPDATE sesiones SET expira=@expira, ultimo_uso=@now WHERE id=@id').run({ id, expira, now });
  }
  borrarSesion(id: string): void { this.db.prepare('DELETE FROM sesiones WHERE id=?').run(id); }
  borrarSesionesDe(usuarioId: string, excepto?: string): void {
    this.db.prepare('DELETE FROM sesiones WHERE usuario_id=@usuarioId AND id<>@excepto').run({ usuarioId, excepto: excepto ?? '' });
  }
  borrarVencidas(now: string): void { this.db.prepare('DELETE FROM sesiones WHERE expira<?').run(now); }
  /** Dueño(s) de un negocio: usuarios con rol 'admin' de ese cliente (el más antiguo primero). */
  duenosDeCliente(clienteId: string): Fila[] {
    return this.db.prepare("SELECT * FROM usuarios WHERE cliente_id=? AND rol='admin' ORDER BY created_at").all(clienteId) as Fila[];
  }
  /** Estado del cliente y las fechas que definen la vigencia de su plan (ver common/util/vigencia.ts).
   *  periodoFin = fin del último período pagado. Se consulta en cada request con sesión: una sola lectura. */
  private stVigencia?: Database.Statement;
  vigenciaCliente(clienteId: string): { estado: string; periodoFin: string | null; canceladoEn: string | null; eliminarEn: string | null } | undefined {
    // Se prepara al primer uso y no en el constructor: los scripts de verificación arman este repositorio sobre
    // bases con migraciones parciales.
    this.stVigencia ??= this.db.prepare(`SELECT c.estado, c.cancelado_en, c.eliminar_en,
        (SELECT MAX(s.periodo_fin) FROM suscripciones s WHERE s.cliente_id=c.id AND s.estado='pagada') AS periodo_fin
      FROM clientes c WHERE c.id=?`);
    const r = this.stVigencia.get(clienteId) as Fila | undefined;
    return r ? { estado: r.estado, periodoFin: r.periodo_fin ?? null, canceladoEn: r.cancelado_en ?? null, eliminarEn: r.eliminar_en ?? null } : undefined;
  }
  /** Estado del cliente (tenant): 'activo' | 'suspendido' | 'pendiente' | undefined si no existe. */
  estadoCliente(clienteId: string): string | undefined {
    const r = this.db.prepare('SELECT estado FROM clientes WHERE id=?').get(clienteId) as Fila | undefined;
    return r?.estado as string | undefined;
  }
  // ---- Verificación en dos pasos (migración 032). Los secretos llegan ya cifrados. ----
  setTotpPendiente(id: string, cifrado: string | null): void {
    this.db.prepare('UPDATE usuarios SET totp_pendiente=? WHERE id=?').run(cifrado, id);
  }
  activarTotp(id: string, cifrado: string, respaldoJson: string, paso: number, now: string): void {
    this.olvidarDispositivos(id);
    this.db.prepare(`UPDATE usuarios SET totp_secreto=@cifrado, totp_pendiente=NULL, totp_desde=@now, totp_ultimo_paso=@paso,
      totp_respaldo=@respaldoJson, updated_at=@now WHERE id=@id`).run({ id, cifrado, respaldoJson, paso, now });
  }
  desactivarTotp(id: string, now: string): void {
    this.olvidarDispositivos(id);
    this.db.prepare(`UPDATE usuarios SET totp_secreto=NULL, totp_pendiente=NULL, totp_desde=NULL, totp_ultimo_paso=NULL,
      totp_respaldo=NULL, updated_at=? WHERE id=?`).run(now, id);
  }
  setTotpUltimoPaso(id: string, paso: number): void { this.db.prepare('UPDATE usuarios SET totp_ultimo_paso=? WHERE id=?').run(paso, id); }
  setTotpRespaldo(id: string, respaldoJson: string): void { this.db.prepare('UPDATE usuarios SET totp_respaldo=? WHERE id=?').run(respaldoJson, id); }

  // ---- Recuperar la contraseña (migración 032): solo se guarda el hash del token ----
  crearRecuperacion(r: { id: string; usuarioId: string; tokenHash: string; expira: string; now: string }): void {
    this.db.prepare(`INSERT INTO recuperaciones (id,usuario_id,token_hash,expira,creado_en) VALUES (@id,@usuarioId,@tokenHash,@expira,@now)`).run(r);
  }
  recuperacionPorHash(tokenHash: string): Fila | undefined {
    return this.db.prepare('SELECT * FROM recuperaciones WHERE token_hash=?').get(tokenHash) as Fila | undefined;
  }
  /** Marca como usados todos los enlaces sin usar del usuario (al pedir uno nuevo o al cambiar la clave). */
  cerrarRecuperaciones(usuarioId: string, now: string): void {
    this.db.prepare('UPDATE recuperaciones SET usado_en=? WHERE usuario_id=? AND usado_en IS NULL').run(now, usuarioId);
  }
  borrarRecuperacionesViejas(antesDe: string): void { this.db.prepare('DELETE FROM recuperaciones WHERE expira<?').run(antesDe); }

  // ---- Equipo Walkan (migración 033). Se preparan al usarse: los scripts de verificación arman este repositorio
  // sobre bases con migraciones parciales. ----
  listarStaff(): Fila[] {
    return this.db.prepare(`SELECT u.id, u.email, u.nombre, u.super_admin, u.desactivado_en, u.created_at, u.clave_pendiente,
        (u.totp_secreto IS NOT NULL) AS dos_pasos, (SELECT MAX(s.ultimo_uso) FROM sesiones s WHERE s.usuario_id = u.id) AS ultimo_uso
      FROM usuarios u WHERE u.rol = 'staff' ORDER BY u.created_at, u.id`).all() as Fila[];
  }
  setSuperAdmin(id: string, si: boolean, now: string): void {
    this.db.prepare('UPDATE usuarios SET super_admin=?, updated_at=? WHERE id=?').run(si ? 1 : 0, now, id);
  }
  setDesactivado(id: string, fecha: string | null, now: string): void {
    this.db.prepare('UPDATE usuarios SET desactivado_en=?, updated_at=? WHERE id=?').run(fecha, now, id);
  }
  // ---- Dispositivos recordados (migración 035): solo el hash del token ----
  recordarDispositivo(d: { id: string; usuarioId: string; tokenHash: string; expira: string; now: string }): void {
    this.db.prepare('INSERT INTO dispositivos_confiables (id,usuario_id,token_hash,expira,creado_en) VALUES (@id,@usuarioId,@tokenHash,@expira,@now)').run(d);
  }
  dispositivoVigente(usuarioId: string, tokenHash: string, now: string): boolean {
    return !!this.db.prepare('SELECT 1 FROM dispositivos_confiables WHERE usuario_id=? AND token_hash=? AND expira>?').get(usuarioId, tokenHash, now);
  }
  /** Olvida todos los dispositivos del usuario. Tolera bases sin la tabla (scripts con migraciones parciales). */
  olvidarDispositivos(usuarioId: string): void {
    try { this.db.prepare('DELETE FROM dispositivos_confiables WHERE usuario_id=?').run(usuarioId); } catch { /* tabla aún no creada */ }
  }
  contarDispositivos(usuarioId: string, now: string): number {
    return (this.db.prepare('SELECT COUNT(*) AS n FROM dispositivos_confiables WHERE usuario_id=? AND expira>?').get(usuarioId, now) as Fila).n as number;
  }

  /** RUT registrado del negocio (vacío o null si no tiene). Lo usa "¿Olvidaste tu contraseña?". */
  rutDeCliente(clienteId: string): string | null {
    const r = this.db.prepare('SELECT rut FROM clientes WHERE id=?').get(clienteId) as Fila | undefined;
    return r?.rut ? String(r.rut) : null;
  }
  /** Cuenta invitada que aún no crea su contraseña (migración 034). */
  setClavePendiente(id: string, si: boolean): void {
    this.db.prepare('UPDATE usuarios SET clave_pendiente=? WHERE id=?').run(si ? 1 : 0, id);
  }
  /** Super admin con la cuenta activa (nunca debe quedar en cero). */
  superAdminsActivos(): number {
    return (this.db.prepare("SELECT COUNT(*) AS n FROM usuarios WHERE rol='staff' AND super_admin=1 AND desactivado_en IS NULL").get() as Fila).n as number;
  }

  porEmail(email: string): Fila | undefined { return this.byEmail.get(email) as Fila | undefined; }
  porId(id: string): Fila | undefined { return this.byId.get(id) as Fila | undefined; }
  total(): number { return (this.count.get() as Fila).n as number; }
  hayStaff(): boolean { return ((this.countStaff.get() as Fila).n as number) > 0; }
}
