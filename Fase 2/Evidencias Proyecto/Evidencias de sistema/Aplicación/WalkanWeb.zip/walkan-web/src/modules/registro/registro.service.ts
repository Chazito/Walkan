// Lógica del plan: alta de la cuenta, pagos con Flow, renovación, cambio de plan, tarjeta con cobro automático y pagos manuales del staff.
import { BadRequestException, ConflictException, Inject, Injectable, Logger } from '@nestjs/common';
import { normalizarUbicacion } from '../../common/util/territorio';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { ahora, nuevoId } from '../../common/util/id';
import { fechaCL } from '../../common/util/fecha';
import { planCanon } from '../../common/util/planes';
import { DIAS_GRACIA, DIAS_PERIODO, DIAS_RENOVAR_ANTES, diferenciaProrrateada, Vigencia } from '../../common/util/vigencia';
import { AuthService } from '../auth/auth.service';
import { UsuariosRepository } from '../auth/usuarios.repository';
import { PASARELA, PasarelaPago, pagoCalza } from '../pagos/pasarela.interface';
import { MedioPago, RegistroRepository, Suscripcion, TipoCobro } from './registro.repository';
import { PLANES, RegistroDto, ReintentarPagoDto } from './dto/registro.dto';
import { MetaPeticion, PrivacidadService } from '../privacidad/privacidad.service';
import { contactoPrivacidad, TEXTO_CASILLA_MARKETING, TEXTO_CASILLA_PRIVACIDAD } from '../privacidad/politica';

export type ResultadoPago = 'pagada' | 'pendiente' | 'rechazada' | 'desconocida';

// AAAA-MM-DD (día de Chile) → DD-MM-AAAA para los mensajes.
const diaCorto = (iso: string): string => fechaCL(iso).split('-').reverse().join('-');

/** Qué pasa si el dueño elige un plan distinto del que tiene (lo mismo que se le muestra antes de confirmar). */
export interface CambioPlan {
  /** 'pago': sube y paga hoy la diferencia · 'gratis': sube sin costo (quedan pocos días) ·
   *  'programado': rige desde la próxima renovación · 'no': no se puede (ver motivo). */
  modo: 'pago' | 'gratis' | 'programado' | 'no';
  sube: boolean;
  pagarHoy: number;
  dias: number;
  motivo?: string;
}

/**
 * Registro autoservicio: el dueño crea su cuenta, elige plan y paga.
 *  1. POST /api/registro → cliente 'pendiente' + usuario dueño + suscripción 'pendiente' → URL de pago.
 *  2. Flow redirige a /registro/retorno (y llama al webhook) → se consulta el estado real a Flow.
 *  3. Pago confirmado → suscripción 'pagada' (30 días) + cliente 'activo' → ya puede entrar al panel.
 * Renovación mensual (pago manual): cada mes el dueño paga el período siguiente desde Mi cuenta → Mi plan
 * (POST /api/cuenta/renovar), con el mismo flujo de Flow. Las reglas de vencimiento están en common/util/vigencia.ts.
 * Cambio de plan (POST /api/cuenta/plan): subir se paga al tiro (solo la diferencia por los días que quedan) y
 * rige de inmediato; bajar queda programado para la renovación siguiente. Ver cambiarPlan().
 */
@Injectable()
export class RegistroService {
  private readonly logger = new Logger('Registro');
  constructor(
    private readonly repo: RegistroRepository,
    private readonly usuarios: UsuariosRepository,
    private readonly auth: AuthService,
    @Inject(PASARELA) private readonly pasarela: PasarelaPago,
    @Inject(CONFIG) private readonly cfg: AppConfig,
    private readonly privacidad: PrivacidadService,
  ) {}

  get simulado(): boolean { return this.cfg.pagosSimulados; }

  // Paso 1 del alta: crea cliente, dueño, consentimientos y suscripción en una transacción y devuelve la URL de pago.
  async registrar(dto: RegistroDto, meta: MetaPeticion = {}): Promise<{ ok: true; pagoUrl: string; simulado: boolean }> {
    const email = dto.email.toLowerCase().trim();
    const monto = this.cfg.planMonto[dto.plan];
    if (!monto) throw new BadRequestException('Elige un plan válido.');
    if (this.usuarios.porEmail(email)) {
      throw new ConflictException('Ya existe una cuenta con ese correo. Inicia sesión o reintenta el pago.');
    }

    const ubic = normalizarUbicacion(dto); // valida antes de crear nada
    const now = ahora();
    const clienteId = nuevoId();
    const suscId = nuevoId();
    // Cliente + dueño + suscripción en una sola transacción.
    this.repo.db.transaction(() => {
      this.repo.crearCliente({
        id: clienteId, negocio: dto.negocio.trim(), rut: dto.rut ?? '', ...ubic,
        email, telefono: dto.telefono ?? '', plan: dto.plan, now,
      });
      const dueno = this.auth.crearUsuario({
        email, nombre: dto.nombre.trim(), negocio: dto.negocio.trim(),
        password: dto.password, rol: 'admin', clienteId,
      });
      // Prueba del consentimiento (Ley 21.719), en la misma transacción: sin consentimiento no hay cuenta.
      const titular = { email, usuarioId: dueno.id, clienteId };
      this.privacidad.registrar(titular, 'privacidad', true, TEXTO_CASILLA_PRIVACIDAD, 'registro', meta);
      this.privacidad.registrar(titular, 'marketing', !!dto.aceptaMarketing, TEXTO_CASILLA_MARKETING, 'registro', meta);
      this.repo.crearSuscripcion({ id: suscId, clienteId, plan: dto.plan, monto, now });
    })();
    this.logger.log(`Registro: plan ${dto.plan} → cliente ${clienteId} pendiente de pago`);

    const pagoUrl = await this.iniciarPago(suscId, email);
    return { ok: true, pagoUrl, simulado: this.simulado };
  }

  /**
   * Consulta a Flow el último pago pendiente del cliente y, si ya está pagado, activa la cuenta.
   * Es el respaldo cuando Flow no pudo avisarnos (webhook inalcanzable) o el navegador no volvió
   * a /registro/retorno: el pago se reconoce igual al iniciar sesión o al reintentar.
   */
  async verificarPagoPendiente(clienteId: string, tipo: TipoCobro = 'periodo'): Promise<boolean> {
    const s = this.repo.pendienteDeCliente(clienteId, tipo);
    if (!s || this.simulado) return false;
    try {
      if (s.flowToken && (await this.confirmarPorToken(s.flowToken)).resultado === 'pagada') return true;
      // Sin token (o token reemplazado): se pregunta por nuestro número de orden.
      if (this.pasarela.estadoPorOrden && pagoCalza(await this.pasarela.estadoPorOrden(s.id), s.id, s.monto)) { this.activar(s); return true; }
      return false;
    } catch (e) {
      this.logger.warn(`No se pudo consultar el pago en Flow: ${(e as Error).message}`);
      return false;
    }
  }

  /** "Ya pagué": revisa con Flow el pago de la cuenta (correo + clave) y la activa si corresponde. */
  async verificar(dto: ReintentarPagoDto, ip = ''): Promise<{ activa: boolean }> {
    const u = await this.auth.validarCredenciales(dto.email, dto.password, ip);
    if (!u.clienteId) return { activa: false };
    const cli = this.repo.cliente(u.clienteId);
    if (cli?.estado === 'activo') return { activa: true };
    return { activa: await this.verificarPagoPendiente(u.clienteId) };
  }

  /** Para quien se registró pero no terminó de pagar (o el pago fue rechazado). */
  async reintentar(dto: ReintentarPagoDto, ip = ''): Promise<{ ok: true; pagoUrl: string; simulado: boolean; activa?: boolean }> {
    const u = await this.auth.validarCredenciales(dto.email, dto.password, ip);
    if (!u.clienteId) throw new BadRequestException('Esta cuenta no corresponde a un negocio.');
    const cli = this.repo.cliente(u.clienteId);
    if (!cli) throw new BadRequestException('Negocio no encontrado.');
    if (cli.estado === 'activo') throw new ConflictException('Tu cuenta ya está activa: inicia sesión.');
    if (cli.estado === 'suspendido') throw new ConflictException('Tu cuenta está suspendida. Contacta al equipo Walkan.');
    // Antes de cobrar de nuevo: ¿el pago anterior ya se hizo y Flow no alcanzó a avisarnos?
    if (await this.verificarPagoPendiente(u.clienteId)) return { ok: true, pagoUrl: '/mi-cuenta', simulado: this.simulado, activa: true };

    let s = this.repo.pendienteDeCliente(u.clienteId);
    if (!s) {
      const id = nuevoId();
      const monto = this.cfg.planMonto[cli.plan] ?? 0;
      this.repo.crearSuscripcion({ id, clienteId: u.clienteId, plan: cli.plan, monto, now: ahora() });
      s = this.repo.porId(id)!;
    }
    const pagoUrl = await this.iniciarPago(s.id, u.email);
    return { ok: true, pagoUrl, simulado: this.simulado };
  }

  /**
   * Renovación mensual: el dueño, con su sesión, paga el período siguiente. Se puede desde DIAS_RENOVAR_ANTES días
   * antes de vencer (así nadie paga dos meses por error) y en cualquier momento después.
   */
  async renovar(u: { clienteId: string | null; email: string }): Promise<{ ok: true; pagoUrl: string; simulado: boolean; activa?: boolean }> {
    const cli = u.clienteId ? this.repo.cliente(u.clienteId) : undefined;
    const v = cli ? this.auth.vigencia(cli.id) : undefined;
    if (!cli || !v) throw new BadRequestException('Esta cuenta no corresponde a un negocio.');
    if (v.situacion === 'cerrada') throw new ConflictException('Tu cuenta está cerrada. Recupérala antes de pagar.');
    if (v.situacion === 'sin-plan') throw new ConflictException('Tu cuenta no tiene un plan con pago en línea. Escríbenos y lo vemos contigo.');
    if (!v.puedeRenovar) {
      throw new ConflictException(`Tu plan está vigente hasta el ${diaCorto(v.vigenteHasta!)}. Podrás renovarlo desde ${DIAS_RENOVAR_ANTES} días antes de esa fecha.`);
    }
    // Antes de cobrar de nuevo: ¿el pago anterior ya se hizo y Flow no alcanzó a avisarnos?
    if (await this.verificarPagoPendiente(cli.id)) return { ok: true, pagoUrl: '/panel#plan', simulado: this.simulado, activa: true };

    const s = this.cobroPendienteDelMes(cli);
    return { ok: true, pagoUrl: await this.iniciarPago(s.id, u.email), simulado: this.simulado };
  }

  /**
   * El cobro (suscripción pendiente) del mes siguiente: se reutiliza el que quedó a medias si sigue igual, o se crea.
   * Se cobra el plan que regirá el mes que viene (el programado, si pidió cambiarlo) más la cuota de cada caja
   * adicional que siga en arriendo.
   */
  private cobroPendienteDelMes(cli: Record<string, any>, medio: MedioPago = 'flow', nota: string | null = null): Suscripcion {
    const plan = planCanon(cli.plan_siguiente ?? cli.plan);
    const { monto, cajas } = this.cobroDelMes(cli.id, plan);
    if (cli.plan_siguiente) this.exigirCupo(cli.id, plan); // por si sumó cajas o cajeros después de programar la baja
    let s = this.repo.pendienteDeCliente(cli.id);
    // Un cobro que quedó a medias antes de un cambio (otro plan, otro monto u otras cajas) ya no sirve.
    if (s && (planCanon(s.plan) !== plan || s.monto !== monto || s.cajas.join() !== cajas.join())) { this.repo.descartarPendientes(cli.id, 'periodo', ahora()); s = undefined; }
    if (s && s.medio !== medio) { this.repo.setMedio(s.id, medio); s = { ...s, medio }; }
    if (!s) {
      const id = nuevoId();
      this.repo.crearSuscripcion({ id, clienteId: cli.id, plan, monto, now: ahora(), cajas, medio, nota });
      s = this.repo.porId(id)!;
    }
    return s;
  }

  // ================= Cobro automático con tarjeta inscrita =================

  /** Inscribir (o cambiar) la tarjeta: devuelve la URL de Flow donde el dueño la ingresa. Walkan nunca ve el número. */
  async inscribirTarjeta(u: { clienteId: string | null; email: string; nombre?: string }): Promise<{ ok: true; url: string; simulado: boolean }> {
    const cli = u.clienteId ? this.repo.cliente(u.clienteId) : undefined;
    const v = cli ? this.auth.vigencia(cli.id) : undefined;
    if (!cli || !v) throw new BadRequestException('Esta cuenta no corresponde a un negocio.');
    if (v.situacion === 'cerrada') throw new ConflictException('Tu cuenta está cerrada. Recupérala antes de inscribir una tarjeta.');
    if (v.situacion === 'sin-plan') throw new ConflictException('Tu cuenta la administra el equipo Walkan y no paga en línea.');
    if (this.simulado) return { ok: true, url: `/cuenta/tarjeta/retorno?sim=${encodeURIComponent(cli.id)}`, simulado: true };
    if (!this.pasarela.crearCliente || !this.pasarela.inscribirTarjeta) throw new BadRequestException('El pago automático no está disponible.');
    try {
      let customerId: string = cli.flow_customer_id;
      if (!customerId) {
        customerId = await this.pasarela.crearCliente({ nombre: cli.negocio || u.nombre || u.email, email: u.email, externoId: cli.id });
        this.repo.setFlowCustomer(cli.id, customerId);
      }
      const r = await this.pasarela.inscribirTarjeta(customerId, `${this.cfg.appUrl}/cuenta/tarjeta/retorno`);
      return { ok: true, url: r.url, simulado: false };
    } catch (e) {
      this.logger.error(`Flow no pudo iniciar la inscripción de tarjeta: ${(e as Error).message}`);
      throw new BadRequestException('No se pudo iniciar la inscripción de tu tarjeta. Inténtalo de nuevo en unos minutos.');
    }
  }

  /** Vuelta desde Flow: confirma la inscripción con el token y guarda solo la marca y los 4 últimos dígitos. */
  async retornoTarjeta(token?: string, sim?: string): Promise<'ok' | 'error'> {
    if (sim) {
      if (!this.simulado || !this.repo.cliente(sim)) return 'error';
      this.repo.setTarjeta(sim, { marca: 'Visa', ultimos4: '4242' }, ahora());
      return 'ok';
    }
    if (!token || !this.pasarela.estadoInscripcion) return 'error';
    try {
      const r = await this.pasarela.estadoInscripcion(token);
      const cli = r.clienteId ? this.repo.clientePorFlowCustomer(r.clienteId) : undefined;
      if (!r.inscrita || !cli) return 'error';
      this.repo.setTarjeta(cli.id, { marca: r.marca || 'Tarjeta', ultimos4: r.ultimos4.slice(-4) }, ahora());
      this.logger.log(`Tarjeta inscrita para el cobro automático: cliente ${cli.id}`);
      return 'ok';
    } catch (e) {
      this.logger.warn(`No se pudo confirmar la inscripción de tarjeta: ${(e as Error).message}`);
      return 'error';
    }
  }

  // Desinscribe la tarjeta en Flow y la borra de acá; si Flow falla, no se borra.
  async quitarTarjeta(clienteId: string): Promise<{ ok: true }> {
    const cli = this.repo.cliente(clienteId);
    if (!cli?.tarjeta_ultimos4) return { ok: true };
    if (!this.simulado && cli.flow_customer_id && this.pasarela.quitarTarjeta) {
      try { await this.pasarela.quitarTarjeta(cli.flow_customer_id); } catch (e) {
        this.logger.error(`Flow no pudo quitar la tarjeta: ${(e as Error).message}`);
        throw new BadRequestException('No se pudo quitar la tarjeta en este momento. Inténtalo de nuevo en unos minutos.');
      }
    }
    this.repo.setTarjeta(clienteId, null, ahora());
    this.logger.log(`Tarjeta quitada: cliente ${clienteId}`);
    return { ok: true };
  }

  /**
   * Cobra el mes siguiente a la tarjeta inscrita (lo llama la pasada de mantenimiento cerca del vencimiento).
   * 'pagado' = período renovado · 'pendiente' = Flow aún no confirma (se concilia después) · 'rechazado' / 'error'.
   */
  async cobrarAutomatico(clienteId: string): Promise<'pagado' | 'pendiente' | 'rechazado' | 'error' | 'omitido'> {
    const cli = this.repo.cliente(clienteId);
    const v = this.auth.vigencia(clienteId);
    if (!cli?.tarjeta_ultimos4 || !v || cli.estado !== 'activo' || v.cancelado || !v.puedeRenovar || v.situacion === 'cerrada' || v.situacion === 'sin-plan') return 'omitido';
    const now = ahora();
    if (await this.verificarPagoPendiente(clienteId)) { this.repo.setIntentoCobro(clienteId, now, null); return 'pagado'; }
    let s: Suscripcion;
    try { s = this.cobroPendienteDelMes(cli, 'tarjeta'); } catch (e) {
      // P. ej. bajó de plan y ya no cabe: no se cobra hasta que lo resuelva (el aviso por correo se lo explica).
      this.repo.setIntentoCobro(clienteId, now, (e as Error).message); return 'error';
    }
    if (this.simulado) { this.activar(s); this.repo.setIntentoCobro(clienteId, now, null); return 'pagado'; }
    if (!this.pasarela.cobrarTarjeta || !cli.flow_customer_id) { this.repo.setIntentoCobro(clienteId, now, 'Cobro automático no disponible.'); return 'error'; }
    try {
      const est = await this.pasarela.cobrarTarjeta({ clienteId: cli.flow_customer_id, orden: s.id, asunto: `Walkan · Plan ${s.plan} (30 días)`, monto: s.monto });
      if (pagoCalza(est, s.id, s.monto)) { this.activar(s); this.repo.setIntentoCobro(clienteId, now, null); return 'pagado'; }
      if (est.estado === '1' || (est.pagado && !pagoCalza(est, s.id, s.monto))) { this.repo.setIntentoCobro(clienteId, now, null); return 'pendiente'; }
      this.repo.marcarRechazada(s.id, now);
      this.repo.setIntentoCobro(clienteId, now, 'La tarjeta rechazó el cobro.');
      return 'rechazado';
    } catch (e) {
      this.logger.warn(`Cobro automático falló (cliente ${clienteId}): ${(e as Error).message}`);
      this.repo.setIntentoCobro(clienteId, now, 'No se pudo cobrar a la tarjeta.');
      return 'error';
    }
  }

  // ================= Pagos registrados por el staff y conciliación =================

  /**
   * El staff registra un pago hecho por fuera (transferencia, efectivo): suma `meses` períodos como si se hubieran
   * pagado en línea (con las cuotas de cajas que correspondan). También activa una cuenta pendiente de pago.
   */
  registrarPagoManual(clienteId: string, meses: number, nota: string, staffEmail = 'staff') {
    const cli = this.repo.cliente(clienteId);
    if (!cli) throw new BadRequestException('Negocio no encontrado.');
    if (cli.eliminado_en || cli.eliminar_en) throw new ConflictException('La cuenta está cerrada por su dueño.');
    const n = Math.trunc(Number(meses));
    if (!(n >= 1 && n <= 12)) throw new BadRequestException('Indica entre 1 y 12 meses.');
    const detalle = `${String(nota ?? '').trim().slice(0, 120) || 'Pago registrado por Walkan'} · ${staffEmail}`;
    for (let i = 0; i < n; i++) {
      this.repo.descartarPendientes(clienteId, 'periodo', ahora()); // un cobro en línea a medias ya no corresponde
      this.activar(this.cobroPendienteDelMes(this.repo.cliente(clienteId)!, 'manual', detalle));
    }
    this.logger.log(`Pago manual: cliente ${clienteId}, ${n} mes(es), por ${staffEmail}`);
    return { ok: true, vigenteHasta: this.auth.vigencia(clienteId)?.vigenteHasta ?? null };
  }

  /** Revisa con Flow los pagos en línea que quedaron pendientes (si su aviso se perdió). Devuelve cuántos activó. */
  async conciliarPendientes(ahoraMs = Date.now()): Promise<number> {
    if (this.simulado) return 0;
    // Entre 10 minutos (para no pisar a quien está pagando) y 7 días.
    const lista = this.repo.pendientesPorConciliar(new Date(ahoraMs - 7 * 86400000).toISOString(), new Date(ahoraMs - 600000).toISOString());
    let n = 0;
    for (const p of lista) if (await this.verificarPagoPendiente(p.clienteId, p.tipo)) n++;
    return n;
  }

  /** Lo que cuesta el mes siguiente: el plan más la cuota de cada caja adicional con cuotas pendientes. */
  private cobroDelMes(clienteId: string, plan: string): { monto: number; cajas: string[] } {
    const { cuota, cuotas } = this.cfg.cajaAdicional;
    const cajas = this.repo.cajasAdicionales(clienteId).filter((c) => c.cuotasPagadas < cuotas).map((c) => c.id);
    return { monto: (this.cfg.planMonto[plan] ?? 0) + cuota * cajas.length, cajas };
  }

  /** El negocio debe caber en el plan al que baja: cajas registradas y cajeros activos dentro de su cupo. */
  private excesoDeCupo(clienteId: string, plan: string): string | undefined {
    const uso = this.repo.uso(clienteId);
    const cajas = this.cfg.planCajas[plan] ?? 1;
    const cajeros = this.cfg.planCajeros[plan] ?? 1;
    if (uso.cajas > cajas) return `El plan ${plan} permite hasta ${cajas} caja(s) y tienes ${uso.cajas} registradas. Escríbenos a ${contactoPrivacidad()} para dar de baja las que no uses.`;
    if (uso.cajeros > cajeros) return `El plan ${plan} incluye ${cajeros} cajero(s) activo(s) y tienes ${uso.cajeros}. Desactiva los que sobren en Mis cajas y vuelve a intentarlo.`;
    // Productos: el plan menor no borra nada; para bajar hay que caber (archivar lo que ya no se vende).
    const productos = this.cfg.planes[plan]?.productos ?? null;
    if (productos != null && uso.productos > productos) {
      const f = (x: number) => x.toLocaleString('es-CL');
      return `El plan ${plan} permite hasta ${f(productos)} productos y tienes ${f(uso.productos)}. Archiva ${f(uso.productos - productos)} que ya no vendas (Inventario › ⋯ › Eliminar) y vuelve a intentarlo.`;
    }
    return undefined;
  }
  // Lo mismo que excesoDeCupo, pero lanzando el error.
  private exigirCupo(clienteId: string, plan: string): void {
    const exceso = this.excesoDeCupo(clienteId, plan);
    if (exceso) throw new ConflictException(exceso);
  }

  /**
   * Qué pasaría al cambiar a `plan`. Una sola regla para lo que se muestra en Mi plan y para lo que se ejecuta:
   *  - Subir con el mes vigente → paga hoy la diferencia por los días que quedan y cambia al tiro
   *    (si la diferencia es mínima, cambia sin costo).
   *  - Bajar, o cualquier cambio con el mes ya vencido → rige desde la próxima renovación, sin devoluciones.
   */
  private evaluarCambio(cli: Record<string, any>, v: Vigencia, plan: string): CambioPlan {
    const mActual = this.cfg.planMonto[planCanon(cli.plan)] ?? 0;
    const mNuevo = this.cfg.planMonto[plan] ?? 0;
    const sube = mNuevo > mActual;
    const base = { sube, pagarHoy: 0, dias: 0 };
    if (v.situacion === 'cerrada') return { ...base, modo: 'no', motivo: 'Tu cuenta está cerrada. Recupérala antes de cambiar de plan.' };
    if (v.situacion === 'sin-plan') return { ...base, modo: 'no', motivo: `Tu cuenta la administra el equipo Walkan. Para cambiar de plan escríbenos a ${contactoPrivacidad()}.` };
    if (v.situacion === 'cancelada') return { ...base, modo: 'no', motivo: 'Tu plan está cancelado. Reactívalo antes de cambiarlo.' };
    const mesVigente = !!v.vigenteHasta && Date.parse(v.vigenteHasta) > Date.now();
    if (sube && mesVigente) {
      const d = diferenciaProrrateada(mActual, mNuevo, v.vigenteHasta!);
      return { ...base, modo: d.monto ? 'pago' : 'gratis', pagarHoy: d.monto, dias: d.dias };
    }
    const exceso = sube ? undefined : this.excesoDeCupo(cli.id, plan);
    return exceso ? { ...base, modo: 'no', motivo: exceso } : { ...base, modo: 'programado' };
  }

  /**
   * Cambio de plan pedido por el dueño desde Mi plan. Elegir el plan que ya tiene deshace un cambio programado.
   * resultado: 'pago' (ir a pagoUrl), 'aplicado' (ya cambió), 'programado' (cambia al renovar) o 'sin-cambio'.
   */
  async cambiarPlan(u: { clienteId: string | null; email: string }, planPedido: string): Promise<{
    ok: true; resultado: 'pago' | 'aplicado' | 'programado' | 'sin-cambio'; plan: string; pagoUrl?: string; simulado?: boolean; monto?: number; desde?: string | null;
  }> {
    const cli = u.clienteId ? this.repo.cliente(u.clienteId) : undefined;
    const v = cli ? this.auth.vigencia(cli.id) : undefined;
    if (!cli || !v) throw new BadRequestException('Esta cuenta no corresponde a un negocio.');
    const actual = planCanon(cli.plan);
    if (planPedido === actual) {
      if (cli.plan_siguiente) { this.repo.setPlanSiguiente(cli.id, null, ahora()); this.logger.log(`Cambio de plan programado deshecho: cliente ${cli.id}`); }
      return { ok: true, resultado: 'sin-cambio', plan: actual };
    }
    const c = this.evaluarCambio(cli, v, planPedido);
    if (c.modo === 'no') throw new ConflictException(c.motivo);
    if (c.modo === 'programado') {
      this.repo.setPlanSiguiente(cli.id, planPedido, ahora());
      this.logger.log(`Cambio de plan programado: cliente ${cli.id}, ${actual} → ${planPedido} desde la próxima renovación`);
      return { ok: true, resultado: 'programado', plan: planPedido, desde: v.vigenteHasta };
    }
    if (c.modo === 'gratis') {
      this.repo.setPlan(cli.id, planPedido, ahora());
      this.logger.log(`Cambio de plan sin costo (quedaban ${c.dias} día(s)): cliente ${cli.id}, ${actual} → ${planPedido}`);
      return { ok: true, resultado: 'aplicado', plan: planPedido };
    }
    // Subida con pago. Antes de cobrar: ¿ya pagó un cambio anterior y Flow no alcanzó a avisarnos?
    if (await this.verificarPagoPendiente(cli.id, 'cambio')) return { ok: true, resultado: 'aplicado', plan: planCanon(this.repo.cliente(cli.id)?.plan) };
    // La diferencia depende de los días que quedan: un cobro de cambio de otro día queda sin efecto y se crea uno nuevo.
    this.repo.descartarPendientes(cli.id, 'cambio', ahora());
    const id = nuevoId();
    this.repo.crearSuscripcion({ id, clienteId: cli.id, plan: planPedido, monto: c.pagarHoy, now: ahora(), tipo: 'cambio' });
    this.logger.log(`Cambio de plan: cliente ${cli.id}, ${actual} → ${planPedido}; diferencia por ${c.dias} día(s) pendiente de pago`);
    return { ok: true, resultado: 'pago', plan: planPedido, monto: c.pagarHoy, pagoUrl: await this.iniciarPago(id, u.email), simulado: this.simulado };
  }

  // Crea el pago en Flow (o la página simulada) y guarda el token para poder confirmarlo después.
  private async iniciarPago(suscId: string, email: string): Promise<string> {
    const s = this.repo.porId(suscId)!;
    if (this.simulado) {
      // Plan B de la demo: sin Flow, el "pago" es una página de confirmación local.
      return `/registro/retorno?sim=${encodeURIComponent(s.id)}`;
    }
    try {
      const res = await this.pasarela.crearPago({
        orden: s.id, asunto: s.tipo === 'cambio' ? `Walkan · Cambio a plan ${s.plan}` : `Walkan · Plan ${s.plan} (30 días)`, monto: s.monto, email,
        urlConfirmacion: `${this.cfg.appUrl}/api/registro/confirmar`,
        urlRetorno: `${this.cfg.appUrl}/registro/retorno`,
      });
      this.repo.setPago(s.id, res.token, res.ordenFlow ?? null, ahora());
      return res.url;
    } catch (e) {
      // Flow 1605 = esa orden ya está pagada (el aviso nunca nos llegó): se activa en vez de cobrar de nuevo.
      if (/1605|previously paid/i.test((e as Error).message)) {
        this.activar(s);
        throw new ConflictException('Tu pago ya estaba registrado y tu cuenta quedó activa: inicia sesión.');
      }
      this.logger.error(`Flow no pudo crear el pago: ${(e as Error).message}`);
      throw new BadRequestException('No se pudo iniciar el pago en este momento. Tu cuenta quedó creada: reintenta el pago en unos minutos.');
    }
  }

  /** Confirma por token de Flow (webhook o retorno). Idempotente. */
  async confirmarPorToken(token: string): Promise<{ resultado: ResultadoPago; s?: Suscripcion }> {
    const s = token ? this.repo.porToken(token) : undefined;
    if (!s) return { resultado: 'desconocida' };
    if (s.estado === 'pagada') return { resultado: 'pagada', s };
    const est = await this.pasarela.estadoPago(token);
    if (pagoCalza(est, s.id, s.monto)) { this.activar(s); return { resultado: 'pagada', s }; }
    if (est.pagado) { this.logger.warn(`Pago Flow no calza con la suscripción ${s.id} (orden ${est.orden}, monto ${est.monto})`); return { resultado: 'pendiente', s }; }
    if (est.estado === '3' || est.estado === '4') { this.repo.marcarRechazada(s.id, ahora()); return { resultado: 'rechazada', s }; }
    return { resultado: 'pendiente', s };
  }

  /** Plan B: confirma un pago simulado (solo si los pagos simulados están activos). */
  confirmarSimulado(id: string): { resultado: ResultadoPago; s?: Suscripcion } {
    if (!this.simulado) return { resultado: 'desconocida' };
    const s = this.repo.porId(id);
    if (!s) return { resultado: 'desconocida' };
    if (s.estado !== 'pagada') this.activar(s);
    return { resultado: 'pagada', s };
  }

  // Deja la suscripción como pagada y al cliente activo. Las fechas del período se calculan según sea cambio de plan, primer pago o renovación.
  private activar(s: Suscripcion): void {
    const now = new Date();
    if (s.tipo === 'cambio') {
      // Diferencia por subir de plan: el plan cambia ahora y el vencimiento queda donde estaba
      // (por eso la fila lleva como fin el del período que ya estaba pagado).
      const fin = this.auth.vigencia(s.clienteId)?.vigenteHasta ?? now.toISOString();
      this.repo.db.transaction(() => {
        this.repo.marcarPagada(s.id, now.toISOString(), fin, now.toISOString());
        this.repo.setPlan(s.clienteId, s.plan, now.toISOString());
      })();
      this.logger.log(`Cambio de plan pagado (${s.id}) → cliente ${s.clienteId} pasa a ${s.plan}`);
      return;
    }
    // Primer pago, o renovación de una cuenta que ya estaba en pausa: el período parte hoy.
    // Renovación con el plan vigente o en días de gracia: parte donde termina el período anterior (pagar antes no
    // regala ni quita días, y los días de gracia no son gratis).
    const v = this.auth.vigencia(s.clienteId);
    const inicio = v && v.operativa && v.vigenteHasta ? new Date(v.vigenteHasta) : now;
    const fin = new Date(inicio.getTime() + DIAS_PERIODO * 86400000);
    this.repo.db.transaction(() => {
      this.repo.marcarPagada(s.id, inicio.toISOString(), fin.toISOString(), now.toISOString());
      this.repo.activarCliente(s.clienteId, s.plan, now.toISOString());
      this.repo.sumarCuota(s.cajas, this.cfg.cajaAdicional.cuotas); // cuotas de arriendo que iban en este pago
    })();
    this.logger.log(`Suscripción ${s.id} pagada → cliente ${s.clienteId} activo (plan ${s.plan}, hasta ${fin.toISOString().slice(0, 10)})`);
  }

  negocioDe(s?: Suscripcion): string {
    return s ? (this.repo.cliente(s.clienteId)?.negocio ?? '') : '';
  }

  /** ¿Este pago es una renovación? (el negocio ya tenía otro período pagado). Cambia el texto de la página de retorno. */
  esRenovacion(s?: Suscripcion): boolean {
    return !!s && this.repo.pagadas(s.clienteId).some((p) => p.id !== s.id);
  }
  /** Fin del período pagado más reciente (DD-MM-AAAA), para la página de retorno del pago. */
  vigenteHastaDe(s?: Suscripcion): string {
    const fin = s ? this.auth.vigencia(s.clienteId)?.vigenteHasta : null;
    return fin ? diaCorto(fin) : '';
  }

  /** Datos de "Mi plan" del cliente en sesión: plan, situación del pago, opciones de cambio de plan e historial de cobros. */
  miPlan(clienteId: string) {
    const cli = this.repo.cliente(clienteId);
    const v = this.auth.vigencia(clienteId);
    const actual = planCanon(cli?.plan);
    const siguiente = cli?.plan_siguiente ? planCanon(cli.plan_siguiente) : null;
    return {
      negocio: cli?.negocio ?? '', plan: actual, estado: cli?.estado ?? '',
      monto: this.cfg.planMonto[actual] ?? 0, cajasIncluidas: this.cfg.planes[actual]?.cajasIncluidas ?? 1,
      // Límites y funciones del plan actual (los módulos de cada área los aplican; ver configuracion.ts).
      limites: this.cfg.planes[actual] ?? null,
      // Cajas adicionales en arriendo: cuota mensual que se suma a la renovación hasta completar el total.
      cajaAdicional: { ...this.cfg.cajaAdicional, cajas: this.repo.cajasAdicionales(clienteId) },
      vigenteHasta: v?.vigenteHasta ?? null,
      situacion: v?.situacion ?? 'sin-plan', pausaEl: v?.pausaEl ?? null, eliminarEn: v?.eliminarEn ?? null,
      cancelado: !!v?.cancelado, puedeRenovar: !!v?.puedeRenovar,
      diasGracia: DIAS_GRACIA, diasRenovarAntes: DIAS_RENOVAR_ANTES,
      // Cambio de plan: el programado (si hay), lo que se pagará en la próxima renovación y qué pasa al elegir cada plan.
      planSiguiente: siguiente, montoRenovacion: this.cobroDelMes(clienteId, siguiente ?? actual).monto, contacto: contactoPrivacidad(),
      planes: PLANES.map((p) => ({
        nombre: p, monto: this.cfg.planMonto[p] ?? 0, cajas: this.cfg.planCajas[p] ?? 1, cajeros: this.cfg.planCajeros[p] ?? 1,
        productos: this.cfg.planes[p]?.productos ?? null, historialMeses: this.cfg.planes[p]?.historialMeses ?? null,
        funciones: this.cfg.planes[p]?.funciones,
        actual: p === actual, cambio: p === actual || !cli || !v ? null : this.evaluarCambio(cli, v, p),
      })),
      cobros: this.repo.pagadas(clienteId).map((s) => ({ fecha: s.actualizada, plan: s.plan, monto: s.monto, desde: s.periodoInicio, hasta: s.periodoFin, tipo: s.tipo, cajas: s.cajas.length, medio: s.medio })),
      // Cobro automático: tarjeta inscrita (solo marca y 4 últimos dígitos) y el último intento.
      tarjeta: cli?.tarjeta_ultimos4 ? { marca: cli.tarjeta_marca, ultimos4: cli.tarjeta_ultimos4, desde: cli.tarjeta_desde } : null,
      cobroAuto: cli?.cobro_auto_intento ? { intento: cli.cobro_auto_intento, error: cli.cobro_auto_error ?? null } : null,
    };
  }
}
