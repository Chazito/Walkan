// Módulo de pedidos a proveedores y compras (ingreso de mercadería).
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { CatalogoModule } from '../catalogo/catalogo.module';
import { ComprasService } from './compras.service';
import { PedidosRepository } from './pedidos.repository';
import { ComprasRepository } from './compras.repository';
import { PedidosController } from './pedidos.controller';
import { ComprasController } from './compras.controller';

// Pedidos y compras comparten un solo servicio; necesita catálogo para mover stock.
@Module({
  imports: [AuthModule, CatalogoModule],
  controllers: [PedidosController, ComprasController],
  providers: [ComprasService, PedidosRepository, ComprasRepository],
})
export class ComprasModule {}
