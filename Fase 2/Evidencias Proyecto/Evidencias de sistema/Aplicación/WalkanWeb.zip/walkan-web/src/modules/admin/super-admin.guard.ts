import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';

// Va después del StaffGuard (de la clase), que ya dejó al usuario en req.usuario.
// Solo deja pasar a un super admin: administrar el equipo Walkan y ver la bitácora.
@Injectable()
export class SuperAdminGuard implements CanActivate {
  canActivate(ctx: ExecutionContext): boolean {
    const req: any = ctx.switchToHttp().getRequest();
    if (!req.usuario?.superAdmin) throw new ForbiddenException('Solo un super admin puede administrar el equipo Walkan.');
    return true;
  }
}
