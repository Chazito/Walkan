// Formas que consume el panel (nombres de campo alineados con el front).
export interface Proveedor {
  id: string;
  nombre: string;
  tel: string;
  email: string;
  rubro: string;
  lead: number; // días de entrega (lead time)
  visita: string; // días que pasa el preventista: "1,4" (0 = domingo)
}

export interface Producto {
  id: string;
  nombre: string;
  sku: string;
  cat: string;
  precio: number;
  costo: number;
  stock: number;
  stockMin: number | null; // null = umbral por defecto de la tienda
  vence: string; // derivado: vencimiento más próximo entre los lotes con saldo
  controlaVence: boolean;
  unidad: 'un' | 'kg';
  plu: number | null; // código de balanza (solo productos por kg)
  vidaUtil: number | null; // días desde que entra; calcula el vencimiento del lote
  prov: string;
  emoji: string;
  img: string;
  valorCosto?: number; // stock valorizado por FIFO (ver ProductosService.conValor)
}
