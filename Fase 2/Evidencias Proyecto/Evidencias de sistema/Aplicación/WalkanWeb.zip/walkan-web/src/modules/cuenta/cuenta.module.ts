// Módulo de cuenta: junta el controller de baja voluntaria con el servicio de mantenimiento (tareas por calendario).
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { SyncModule } from '../sync/sync.module';
import { RegistroModule } from '../registro/registro.module';
import { CuentaController } from './cuenta.controller';
import { CuentaService } from './cuenta.service';
import { MantenimientoService } from './mantenimiento.service';

// Baja voluntaria (cancelar plan, descargar datos, eliminar cuenta) y las tareas de calendario del plan
// (avisos de vencimiento y borrado de cuentas cerradas). Importa sync por el servicio de correo.
@Module({
  imports: [AuthModule, SyncModule, RegistroModule], // registro: cobro automático y conciliación de pagos
  controllers: [CuentaController],
  providers: [CuentaService, MantenimientoService],
})
export class CuentaModule {}
