// Endpoints que usa la caja contra la nube: mandar lo vendido (api/sync) y bajar el catálogo (api/catalogo).
import { Body, Controller, Get, Headers, Post } from '@nestjs/common';
import { SyncService } from './sync.service';
import { SyncBody } from './dto/sync.dto';
import { Limite } from '../../common/limite';

// Endpoint que consume la caja. Autenticación por token de dispositivo (no sesión de usuario).
@Controller('api/sync')
export class SyncController {
  constructor(private readonly srv: SyncService) {}

  @Post()
  @Limite(300)
  recibir(@Headers('x-caja-token') token: string, @Body() body: SyncBody) {
    return this.srv.recibir(token, body);
  }
}

// Catálogo nube → caja. Misma autenticación por token de dispositivo.
@Controller('api/catalogo')
export class CatalogoCajaController {
  constructor(private readonly srv: SyncService) {}

  @Get()
  @Limite(300)
  catalogo(@Headers('x-caja-token') token: string) {
    return this.srv.catalogoParaCaja(token);
  }
}
