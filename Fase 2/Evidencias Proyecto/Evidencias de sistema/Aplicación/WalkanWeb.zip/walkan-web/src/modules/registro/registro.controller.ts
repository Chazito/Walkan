// Alta autoservicio, pago del plan con Flow (alta, renovación, cambio de plan), tarjeta para el cobro automático y páginas de retorno.
import { Body, Controller, ForbiddenException, Get, Ip, Post, Query, Redirect, Render, Req, UseGuards } from '@nestjs/common';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { Inject } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { RegistroService, ResultadoPago } from './registro.service';
import { CambiarPlanDto, RegistroDto, ReintentarPagoDto, PLANES } from './dto/registro.dto';
import { planCanon } from '../../common/util/planes';
import { meta } from '../privacidad/privacidad.controller';
import { TEXTO_CASILLA_MARKETING, TEXTO_CASILLA_PRIVACIDAD } from '../privacidad/politica';
import { Limite } from '../../common/limite';

@Controller()
export class RegistroController {
  constructor(private readonly srv: RegistroService, @Inject(CONFIG) private readonly cfg: AppConfig) {}

  /** Página de registro (crear cuenta + elegir plan). */
  @Get('registro')
  @Render('pages/registro.ejs')
  pagina(@Query('plan') plan?: string) {
    return {
      planes: PLANES.map((p) => ({ nombre: p, monto: this.cfg.planMonto[p], cajeros: this.cfg.planCajeros[p] })),
      planSel: PLANES.includes(planCanon(plan)) ? planCanon(plan) : 'Profesional',
      simulado: this.srv.simulado,
      casillaPrivacidad: TEXTO_CASILLA_PRIVACIDAD, casillaMarketing: TEXTO_CASILLA_MARKETING,
    };
  }

  // Crea la cuenta y devuelve la URL de pago de Flow para el primer mes.
  @Post('api/registro')
  @Limite(5)
  registrar(@Body() dto: RegistroDto, @Req() req: any) { return this.srv.registrar(dto, meta(req)); }

  @Post('api/registro/reintentar')
  @Limite(10)
  reintentar(@Body() dto: ReintentarPagoDto, @Ip() ip: string) { return this.srv.reintentar(dto, ip); }

  /** "Ya pagué": consulta el pago a Flow y activa la cuenta si está pagado (no cobra de nuevo). */
  @Post('api/registro/verificar')
  @Limite(10)
  verificar(@Body() dto: ReintentarPagoDto, @Ip() ip: string) { return this.srv.verificar(dto, ip); }

  /** Webhook de Flow (form-urlencoded con 'token'). */
  @Post('api/registro/confirmar')
  @Limite(60)
  async confirmar(@Body('token') token: string) { await this.srv.confirmarPorToken(token); return 'OK'; }

  /** "Mi plan" del dueño en sesión. */
  @Get('api/mi-plan')
  @UseGuards(SesionGuard)
  miPlan(@Req() req: any) { return this.srv.miPlan(req.usuario.clienteId); }

  /** Renovación mensual: crea el pago del período siguiente y devuelve la URL de Flow. Solo el dueño del negocio. */
  @Post('api/cuenta/renovar')
  @Limite(10)
  @UseGuards(SesionGuard)
  renovar(@Req() req: any) {
    if (req.usuario.rol !== 'admin') throw new ForbiddenException('Solo el dueño del negocio puede pagar el plan.');
    return this.srv.renovar(req.usuario);
  }

  /** Cambio de plan: subir se paga al tiro (devuelve la URL de Flow) y bajar queda para la renovación. Solo el dueño. */
  @Post('api/cuenta/plan')
  @Limite(10)
  @UseGuards(SesionGuard)
  cambiarPlan(@Req() req: any, @Body() dto: CambiarPlanDto) {
    if (req.usuario.rol !== 'admin') throw new ForbiddenException('Solo el dueño del negocio puede cambiar el plan.');
    return this.srv.cambiarPlan(req.usuario, dto.plan);
  }

  // Retorno desde Flow: Flow redirige al navegador con POST (form con 'token'); se acepta también GET.
  // ---- Cobro automático: inscribir o quitar la tarjeta (solo el dueño) ----
  @Post('api/cuenta/tarjeta')
  @Limite(10)
  @UseGuards(SesionGuard)
  inscribirTarjeta(@Req() req: any) {
    if (req.usuario.rol !== 'admin') throw new ForbiddenException('Solo el dueño del negocio puede inscribir una tarjeta.');
    return this.srv.inscribirTarjeta(req.usuario);
  }

  @Post('api/cuenta/tarjeta/quitar')
  @Limite(10)
  @UseGuards(SesionGuard)
  quitarTarjeta(@Req() req: any) {
    if (req.usuario.rol !== 'admin' || !req.usuario.clienteId) throw new ForbiddenException('Solo el dueño del negocio puede quitar la tarjeta.');
    return this.srv.quitarTarjeta(req.usuario.clienteId);
  }

  // Flow vuelve acá (POST con token) al terminar la inscripción. Sin sesión: la cookie no viaja en un POST que viene
  // de otro sitio; el negocio se identifica por el cliente de Flow que devuelve el token. Termina en Mi plan.
  @Post('cuenta/tarjeta/retorno')
  @Limite(30)
  @Redirect('/panel#plan', 302)
  async tarjetaRetornoPost(@Body('token') token: string) {
    return { url: `/panel?tarjeta=${await this.srv.retornoTarjeta(token)}#plan` };
  }

  @Get('cuenta/tarjeta/retorno')
  @Limite(30)
  @Redirect('/panel#plan', 302)
  async tarjetaRetornoGet(@Query('token') token?: string, @Query('sim') sim?: string) {
    return { url: `/panel?tarjeta=${await this.srv.retornoTarjeta(token, sim)}#plan` };
  }

  // Retorno del pago del plan: Flow vuelve con POST; en modo simulado se usa GET con ?sim=.
  @Post('registro/retorno')
  @Limite(30)
  @Render('pages/registro-retorno.ejs')
  retornoPost(@Body('token') token: string) { return this.retorno(token); }

  @Get('registro/retorno')
  @Limite(30)
  @Render('pages/registro-retorno.ejs')
  retornoGet(@Query('token') token?: string, @Query('sim') sim?: string) {
    if (sim) return this.vista(this.srv.confirmarSimulado(sim));
    return this.retorno(token ?? '');
  }

  // Si la consulta del pago falla, la página muestra 'pendiente' en vez de un error.
  private async retorno(token: string) {
    try { return this.vista(await this.srv.confirmarPorToken(token)); }
    catch { return this.vista({ resultado: 'pendiente' }); }
  }

  // Lo que pinta la página de retorno.
  private vista(r: { resultado: ResultadoPago; s?: any }) {
    return {
      resultado: r.resultado, negocio: this.srv.negocioDe(r.s), plan: r.s?.plan ?? '',
      renovacion: this.srv.esRenovacion(r.s), hasta: r.resultado === 'pagada' ? this.srv.vigenteHastaDe(r.s) : '',
      cambio: r.s?.tipo === 'cambio', // pago de la diferencia por subir de plan
    };
  }
}
