// Endpoints de la bandeja de ventas hechas en la caja sin producto en el catálogo (vincular, ignorar, revisar rechazos).
import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { IsString, Length } from 'class-validator';
import { SesionGuard } from '../auth/auth.guard';
import { VentasPendientesService } from './ventas-pendientes.service';

class VincularDto { @IsString() @Length(1, 64) productoId!: string; }

// Bandeja "Vendido sin catálogo" del panel (Ventas). Todo filtra por el negocio de la sesión dentro del servicio.
@Controller('api/ventas/pendientes')
@UseGuards(SesionGuard)
export class VentasPendientesController {
  constructor(private readonly srv: VentasPendientesService) {}

  @Get() listar() { return this.srv.listar(); }
  @Post(':id/vincular') vincular(@Param('id') id: string, @Body() dto: VincularDto) { return this.srv.vincular(id, dto.productoId); }
  @Post(':id/ignorar') ignorar(@Param('id') id: string) { return this.srv.ignorar(id); }
  @Post('rechazos/:id/revisado') revisado(@Param('id') id: string) { return this.srv.revisarRechazo(id); }
}
