import { Body, Controller, Get, Put, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { CobrosService, DatosTransferencia } from './cobros.service';

// Datos de cobro del negocio (panel › Mis cajas › Cobro por transferencia).
@Controller('api/negocio')
@UseGuards(SesionGuard)
export class CobrosController {
  constructor(private readonly srv: CobrosService) {}

  @Get('transferencia')
  obtener() { return this.srv.obtenerTransferencia(); }

  @Put('transferencia')
  guardar(@Body() body: Partial<DatosTransferencia>) { return this.srv.guardarTransferencia(body); }
}
