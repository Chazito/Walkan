import { Rut } from '../../../common/util/rut';
import { IsEmail, IsIn, IsOptional, IsString, Matches, MaxLength, MinLength } from 'class-validator';
import { ClaveSegura } from '../../../common/util/politica-clave';

// Alta manual de un cliente desde el panel de staff. Sin password se genera una al tiro.
// El plan acepta también los nombres antiguos (Kiosko, Minimarket, Minisúper): se guardan con el nombre actual.
export class ProvisionarClienteDto {
  @IsString() @MinLength(1) @MaxLength(80) negocio!: string;
  @IsEmail() email!: string;
  @IsOptional() @IsString() @MaxLength(80) nombre?: string;
  @IsOptional() @IsString() @MaxLength(20) @Rut() rut?: string;
  @IsOptional() @IsString() @MaxLength(60) comuna?: string;
  @IsOptional() @Matches(/^\d{5}$/, { message: 'Elige una comuna de la lista.' }) comunaCut?: string;
  @IsOptional() @IsString() @MaxLength(120, { message: 'La dirección es muy larga (máximo 120 caracteres).' }) direccion?: string;
  @IsOptional() @IsString() @MaxLength(30) telefono?: string;
  @IsOptional() @IsIn(['Esencial', 'Profesional', 'Empresa', 'Kiosko', 'Minimarket', 'Minisúper', 'Minisuper'], { message: 'Elige un plan válido.' }) plan?: string;
  @IsOptional() @IsString() @ClaveSegura() password?: string;
}
