// Categorías de soporte: las mismas en el centro de ayuda (/ayuda) y en los tickets.
export const CATEGORIAS: { id: string; nombre: string; descripcion: string }[] = [
  { id: 'acceso', nombre: 'Cuenta y acceso', descripcion: 'Contraseña, verificación en dos pasos y cómo entrar.' },
  { id: 'plan', nombre: 'Plan y pagos', descripcion: 'Precios, renovación, cambio de plan y pagos con Flow.' },
  { id: 'caja', nombre: 'Caja y equipo', descripcion: 'La caja de tu local, cajeros, cortes de internet y robo.' },
  { id: 'panel', nombre: 'Inventario y ventas', descripcion: 'Productos, stock, proveedores y lo que ves en tu panel.' },
  { id: 'privacidad', nombre: 'Privacidad y datos', descripcion: 'Tus datos, descargarlos y cerrar tu cuenta.' },
  { id: 'otro', nombre: 'Otro', descripcion: 'Cualquier otra consulta.' },
];
export const IDS_CATEGORIA = CATEGORIAS.map((c) => c.id);
export const nombreCategoria = (id: string) => CATEGORIAS.find((c) => c.id === id)?.nombre ?? 'Otro';
