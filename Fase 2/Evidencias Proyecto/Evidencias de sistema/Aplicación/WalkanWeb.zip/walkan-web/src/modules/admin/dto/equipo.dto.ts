import { IsBoolean, IsEmail, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

// Alta de una cuenta del equipo Walkan (solo super admin). La contraseña siempre la genera el servidor.
export class CrearStaffDto {
  @IsEmail({}, { message: 'Escribe un correo válido.' }) @MaxLength(120) email!: string;
  @IsString() @MinLength(2, { message: 'Escribe el nombre de la persona.' }) @MaxLength(80) nombre!: string;
  @IsOptional() @IsBoolean() superAdmin?: boolean;
}

export class NivelStaffDto {
  @IsBoolean() superAdmin!: boolean;
}
