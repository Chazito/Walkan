import { IsInt, IsOptional, IsString, Length, Matches, Max, Min } from 'class-validator';

// `lead` = días que demora el proveedor en entregar; la predicción lo usa para el punto de reorden.
export class ProveedorDto {
  @IsString() @Length(1, 120) nombre!: string;
  @IsOptional() @IsString() tel?: string;
  @IsOptional() @IsString() email?: string;
  @IsOptional() @IsString() rubro?: string;
  @IsOptional() @IsInt() @Min(0) @Max(60) lead?: number;
  /** Días de visita del preventista, "1,4" (0 = domingo). Vacío = no pasa. */
  @IsOptional() @IsString() @Matches(/^([0-6](,[0-6])*)?$/, { message: 'visita debe ser días 0-6 separados por coma' }) visita?: string;
}
