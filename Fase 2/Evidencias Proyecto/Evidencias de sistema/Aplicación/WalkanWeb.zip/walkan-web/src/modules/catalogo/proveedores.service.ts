// Lógica de proveedores: crear, editar y eliminar (o archivar si ya tienen pedidos).
import { Injectable, NotFoundException } from '@nestjs/common';
import { ahora, nuevoId } from '../../common/util/id';
import { ProveedoresRepository } from './proveedores.repository';
import { Proveedor } from './tipos';
import { ProveedorDto } from './dto/proveedor.dto';

// CRUD simple. Se busca el proveedor antes de editar/borrar para dar 404 claro; como el repo
// filtra por cliente, un id de otra tienda también cae en "no encontrado". Con pedidos se archiva, no se borra.
@Injectable()
export class ProveedoresService {
  constructor(private readonly repo: ProveedoresRepository) {}

  listar(): Proveedor[] { return this.repo.listar(); }

  crear(dto: ProveedorDto): Proveedor {
    const now = ahora();
    const id = nuevoId();
    this.repo.crear({
      id, nombre: dto.nombre, tel: dto.tel ?? null, email: dto.email ?? null,
      rubro: dto.rubro ?? null, lead: dto.lead ?? 3, visita: dto.visita || null, createdAt: now, updatedAt: now,
    });
    return this.repo.obtener(id) as Proveedor;
  }

  actualizar(id: string, dto: ProveedorDto): Proveedor {
    const p = this.repo.obtener(id);
    if (!p) throw new NotFoundException('Proveedor no encontrado.');
    this.repo.actualizar({
      id, nombre: dto.nombre, tel: dto.tel ?? null, email: dto.email ?? null,
      // si no mandan lead se conserva el que tenía, no se pisa con el default
      rubro: dto.rubro ?? null, lead: dto.lead ?? p.lead, visita: (dto.visita ?? p.visita) || null, updatedAt: ahora(),
    });
    return this.repo.obtener(id) as Proveedor;
  }

  eliminar(id: string): { ok: boolean; archivado: boolean } {
    const p = this.repo.obtener(id);
    if (!p) throw new NotFoundException('Proveedor no encontrado.');
    const archivar = this.repo.tienePedidos(id);
    if (archivar) this.repo.archivar(id, ahora()); else this.repo.eliminar(id);
    return { ok: true, archivado: archivar };
  }
}
