// Predicción de inventario y rotación ABC (plan de ítems, secciones I y K).
// Funciones puras: el servicio junta los datos y aquí solo se calcula.

export const VENTANA_DIAS = 28;
export const DIAS_SEGURIDAD = 2;
export const DIAS_COBERTURA = 7; // lo que debe cubrir un pedido además del lead time
export const MIN_DIAS_DATOS = 7;
const DIA_MS = 86_400_000;

export interface EntradaPrediccion {
  id: string;
  nombre: string;
  stock: number;
  stockMin: number | null;
  precio: number;
  lead: number; // días de entrega del proveedor
  unidades: number; // vendidas dentro de la ventana
  primerMovimiento: string | null; // ISO del primer movimiento del producto
}

export type EstadoPrediccion = 'insuficiente' | 'agotado' | 'reponer' | 'ok';

export interface Prediccion {
  id: string;
  nombre: string;
  stock: number;
  ventaDiaria: number;
  diasStock: number | null;
  puntoReorden: number;
  sugerida: number;
  estado: EstadoPrediccion;
  ingreso: number;
  abc: 'A' | 'B' | 'C';
}

/** Parámetros del negocio (ver config_inventario). Sin pasarlos se usan los valores por defecto. */
export interface ParametrosPrediccion { diasSeguridad: number; diasCobertura: number }

export function predecir(entradas: EntradaPrediccion[], ahoraMs: number, par: ParametrosPrediccion = { diasSeguridad: DIAS_SEGURIDAD, diasCobertura: DIAS_COBERTURA }): Prediccion[] {
  const filas: Prediccion[] = entradas.map((e) => {
    // Se divide por los días que el producto realmente lleva, no por 28 fijo: si entró hace
    // 10 días, dividir por 28 le bajaría la venta diaria a la mala.
    const dias = e.primerMovimiento
      ? Math.min(VENTANA_DIAS, Math.floor((ahoraMs - Date.parse(e.primerMovimiento)) / DIA_MS))
      : 0;
    const insuficiente = dias < MIN_DIAS_DATOS;
    const vd = insuficiente ? 0 : e.unidades / dias;
    // Punto de reorden = lo que se vende mientras llega el pedido + colchón; nunca bajo el mínimo manual.
    const reorden = Math.max(Math.ceil(vd * (e.lead + par.diasSeguridad)), e.stockMin ?? 0);
    const objetivo = Math.max(Math.ceil(vd * (e.lead + par.diasSeguridad + par.diasCobertura)), reorden);
    // 'agotado' va primero: aunque no haya historia, sin stock es sin stock.
    const estado: EstadoPrediccion = e.stock <= 0 ? 'agotado'
      : insuficiente ? 'insuficiente'
      : e.stock <= reorden ? 'reponer' : 'ok';
    return {
      id: e.id,
      nombre: e.nombre,
      stock: e.stock,
      ventaDiaria: Math.round(vd * 10) / 10,
      diasStock: vd > 0 ? Math.max(0, Math.floor(e.stock / vd)) : null,
      puntoReorden: reorden,
      // Stock negativo = ventas sin registro de entrada (dato a revisar), no deuda: en la góndola hay 0,
      // así que se pide como si hubiera 0 y no se infla el pedido con el déficit.
      sugerida: Math.max(0, objetivo - Math.max(0, e.stock)),
      estado,
      // ponytail: ingreso ≈ unidades × precio actual; guardar el precio en el movimiento si cambia seguido
      ingreso: e.unidades * e.precio,
      abc: 'C',
    };
  });

  // ABC por ingresos: A hasta el 80% acumulado, B hasta el 95%, el resto C.
  const total = filas.reduce((s, f) => s + f.ingreso, 0);
  let acumulado = 0;
  [...filas].sort((a, b) => b.ingreso - a.ingreso).forEach((f) => {
    if (!f.ingreso) return;
    const antes = acumulado / total;
    acumulado += f.ingreso;
    f.abc = antes < 0.8 ? 'A' : antes < 0.95 ? 'B' : 'C';
  });
  return filas;
}
