// Arma los datos de ventas y stock de cada producto para la predicción de reposición, y guarda los parámetros del negocio.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { ahora } from '../../common/util/id';
import { predecir, Prediccion, VENTANA_DIAS, DIAS_SEGURIDAD, DIAS_COBERTURA } from './prediccion';

// costoConIva: true si los costos se ingresan con IVA (boleta); false = netos (factura). Lo usa el panel para el margen.
export interface ConfigInventario { umbralBajo: number; diasSeguridad: number; diasCobertura: number; costoConIva?: boolean }
const DEFECTO: ConfigInventario = { umbralBajo: 10, diasSeguridad: DIAS_SEGURIDAD, diasCobertura: DIAS_COBERTURA, costoConIva: false };

@Injectable()
export class PrediccionService {
  private datos!: Database.Statement;
  private cfgGet!: Database.Statement;
  private cfgSet!: Database.Statement;

  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly ctx: ContextoTenant,
  ) {
    // Por producto activo: lead time del proveedor, unidades vendidas en la ventana
    // y fecha del primer movimiento (para saber cuántos días de historia hay).
    // Las ventas se guardan como movimientos negativos, por eso el -SUM para tener unidades positivas.
    // Sin proveedor (o sin lead) se asume 3 días.
    this.datos = db.prepare(`SELECT p.id, p.nombre, p.stock, p.stock_minimo AS stockMin, p.precio,
        COALESCE(pr.lead_time_dias, 3) AS lead,
        COALESCE((SELECT -SUM(m.cantidad) FROM movimientos_stock m
          WHERE m.cliente_id=p.cliente_id AND m.producto_id=p.id AND m.tipo='venta' AND m.fecha>=@desde), 0) AS unidades,
        (SELECT MIN(m.fecha) FROM movimientos_stock m
          WHERE m.cliente_id=p.cliente_id AND m.producto_id=p.id) AS primerMovimiento
      FROM productos p LEFT JOIN proveedores pr ON pr.id=p.proveedor_id
      WHERE p.cliente_id=@clienteId AND p.activo=1`);
    this.cfgGet = db.prepare('SELECT umbral_bajo AS umbralBajo, dias_seguridad AS diasSeguridad, dias_cobertura AS diasCobertura, costo_con_iva AS costoConIva FROM config_inventario WHERE cliente_id=?');
    this.cfgSet = db.prepare(`INSERT INTO config_inventario (cliente_id, umbral_bajo, dias_seguridad, dias_cobertura, costo_con_iva, updated_at)
      VALUES (@clienteId, @umbralBajo, @diasSeguridad, @diasCobertura, @costoConIva, @now)
      ON CONFLICT(cliente_id) DO UPDATE SET umbral_bajo=excluded.umbral_bajo, dias_seguridad=excluded.dias_seguridad,
        dias_cobertura=excluded.dias_cobertura, costo_con_iva=excluded.costo_con_iva, updated_at=excluded.updated_at`);
  }

  /** Parámetros del negocio de la sesión (o los por defecto si nunca los cambió). */
  config(): ConfigInventario {
    const c = this.cfgGet.get(this.ctx.clienteId) as ConfigInventario | undefined;
    return c ? { ...c, costoConIva: !!c.costoConIva } : { ...DEFECTO };
  }
  // Si no mandan costoConIva se conserva el que tenía (el formulario de parámetros viejo no lo envía).
  guardarConfig(c: ConfigInventario): ConfigInventario {
    this.cfgSet.run({ ...c, costoConIva: (c.costoConIva ?? this.config().costoConIva) ? 1 : 0, clienteId: this.ctx.clienteId, now: ahora() });
    return this.config();
  }

  // Acá se junta la data de la BD y se le pasa a predecir(), que es pura y fácil de testear.
  calcular(): Prediccion[] {
    const ahoraMs = Date.now();
    const desde = new Date(ahoraMs - VENTANA_DIAS * 86_400_000).toISOString();
    return predecir(this.datos.all({ clienteId: this.ctx.clienteId, desde }) as any[], ahoraMs, this.config());
  }
}
