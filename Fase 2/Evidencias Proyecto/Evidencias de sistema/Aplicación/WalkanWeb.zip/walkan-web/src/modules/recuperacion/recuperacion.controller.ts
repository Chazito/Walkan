// Endpoints de /api/auth para recuperar, restablecer y cambiar la contraseña.
import { Body, Controller, Post, Req, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { Limite } from '../../common/limite';
import { CambiarPasswordConCodigoDto, PedirRecuperacionDto, RestablecerDto } from './dto/recuperacion.dto';
import { RecuperacionService } from './recuperacion.service';
import { AuthService } from '../auth/auth.service';

// Recuperar y restablecer van sin sesión (la persona no puede entrar). Topes bajos por IP: es una puerta que cualquiera puede tocar.
@Controller('api/auth')
export class RecuperacionController {
  constructor(private readonly srv: RecuperacionService, private readonly auth: AuthService) {}

  @Post('recuperar')
  @Limite(5)
  pedir(@Body() dto: PedirRecuperacionDto) { return this.srv.pedir(dto.email, dto.rut); }

  @Post('restablecer')
  @Limite(10)
  restablecer(@Body() dto: RestablecerDto) { return this.srv.restablecer(dto.token, dto.password); }

  // Cambiar la contraseña en Mi cuenta: además de la actual, se pide un segundo factor (app de dos pasos o código
  // por correo). Se cierran las sesiones de los demás equipos; esta sigue abierta.
  @Post('password/codigo')
  @Limite(5)
  @UseGuards(SesionGuard)
  codigoCambio(@Req() req: any) { return this.srv.pedirCodigoCambio(req.usuario.id); }

  // Paso 2: con el código ya pedido, cambia la clave y cierra las otras sesiones.
  @Post('password')
  @Limite(10)
  @UseGuards(SesionGuard)
  async cambiarPassword(@Req() req: any, @Body() dto: CambiarPasswordConCodigoDto) {
    const r = await this.srv.cambiarPassword(req.usuario.id, dto.actual, dto.nueva, dto.codigo);
    this.auth.cerrarOtrasSesiones(req.usuario.id, req.sesionId);
    return r;
  }
}
