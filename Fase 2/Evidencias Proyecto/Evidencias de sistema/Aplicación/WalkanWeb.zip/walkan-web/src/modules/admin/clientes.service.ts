// Lógica de los clientes (negocios) para el staff: alta, estado, plan y KPIs del panel.
import { randomBytes } from 'crypto';
import { BadRequestException, ConflictException, Inject, Injectable, Logger, NotFoundException, OnModuleInit } from '@nestjs/common';
import { faltasClave } from '../../common/util/politica-clave';
import { normalizarUbicacion } from '../../common/util/territorio';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { ahora, nuevoId } from '../../common/util/id';
import { AuthService } from '../auth/auth.service';
import { UsuariosRepository } from '../auth/usuarios.repository';
import { ClientesRepository } from './clientes.repository';
import { ProvisionarClienteDto } from './dto/provisionar-cliente.dto';
import { planCanon } from '../../common/util/planes';
import { RecuperacionService } from '../recuperacion/recuperacion.service';

// Alta y gestión de tenants (los negocios que usan Walkan), solo para el staff.
// Además siembra los usuarios de demo la primera vez que levanta la app.
@Injectable()
export class ClientesService implements OnModuleInit {
  private readonly logger = new Logger('Clientes');
  constructor(
    private readonly repo: ClientesRepository,
    private readonly usuarios: UsuariosRepository,
    private readonly auth: AuthService,
    @Inject(CONFIG) private readonly cfg: AppConfig,
    private readonly acceso: RecuperacionService,
  ) {}

  // Semilla: staff Walkan + un cliente demo con su dueño, si aún no hay staff.
  // Defensivo: si algún usuario ya existe (p.ej. admin@walkan.cl de un seed viejo
  // previo al multi-tenant), no lo recrea — lo adopta al cliente demo.
  // En producción NO se siembra la demo ni la clave walkan123: solo el staff, con la clave de
  // STAFF_PASSWORD_INICIAL o una aleatoria que se muestra una sola vez en el log (cambiarla al entrar).
  onModuleInit(): void {
    if (this.usuarios.hayStaff()) return;
    if (this.cfg.produccion) {
      // 'Wk-9' asegura mayúscula, minúscula, número y especial (política de claves).
      const clave = process.env.STAFF_PASSWORD_INICIAL || 'Wk-9' + randomBytes(12).toString('base64url');
      if (faltasClave(clave).length) throw new Error('STAFF_PASSWORD_INICIAL no cumple la política de claves');
      const st = this.auth.crearUsuario({ email: 'staff@walkan.cl', nombre: 'Equipo Walkan', password: clave, rol: 'staff', clienteId: null });
      this.usuarios.setSuperAdmin(st.id, true, ahora()); // el primero del equipo administra a los demás
      this.logger.warn(process.env.STAFF_PASSWORD_INICIAL
        ? 'Staff inicial staff@walkan.cl creado con STAFF_PASSWORD_INICIAL. Cámbiala al entrar.'
        : `Staff inicial staff@walkan.cl creado con clave de un solo uso: ${clave} — cámbiala al entrar.`);
      return;
    }
    const now = ahora();

    if (!this.usuarios.porEmail('staff@walkan.cl')) {
      const st = this.auth.crearUsuario({
        email: 'staff@walkan.cl', nombre: 'Equipo Walkan', password: 'walkan123', rol: 'staff', clienteId: null,
      });
      this.usuarios.setSuperAdmin(st.id, true, ahora());
    }

    const cli = this.crearClienteRow({
      negocio: 'Almacén Barrera', comunaCut: '13125', email: 'admin@walkan.cl',
      telefono: '', rut: '', plan: 'Profesional', estado: 'activo',
    });
    const existente = this.usuarios.porEmail('admin@walkan.cl');
    if (existente) {
      this.usuarios.asignarCliente(existente.id, cli.id, now);
    } else {
      this.auth.crearUsuario({
        email: 'admin@walkan.cl', nombre: 'Álvaro Barrera', negocio: 'Almacén Barrera',
        password: 'walkan123', rol: 'admin', clienteId: cli.id,
      });
    }
    this.logger.log('Seed: staff@walkan.cl (staff) + admin@walkan.cl (dueño demo) — clave walkan123');
  }

  private crearClienteRow(d: {
    negocio: string; comuna?: string; comunaCut?: string; direccion?: string; email?: string; telefono?: string; rut?: string; plan?: string; estado?: string;
  }) {
    const now = ahora();
    const row = {
      id: nuevoId(), negocio: d.negocio, rut: d.rut ?? '', ...normalizarUbicacion(d),
      email: d.email ?? '', telefono: d.telefono ?? '',
      plan: planCanon(d.plan ?? 'Esencial'), estado: d.estado ?? 'activo', createdAt: now, updatedAt: now,
    };
    this.repo.crear(row);
    return row;
  }

  // Con la situación del plan de cada negocio (al día, por vencer, vencido, cancelado, cierre pedido), para /admin.
  /** Nombre del negocio (para la bitácora). */
  nombreDe(id: string): string { return String(this.repo.obtener(id)?.negocio ?? id); }

  listar() {
    return this.repo.listar().map((c) => {
      const v = this.auth.vigencia(c.id);
      return { ...c, situacion: v?.situacion ?? 'sin-plan', vigenteHasta: v?.vigenteHasta ?? null, eliminarEn: v?.eliminarEn ?? null };
    });
  }

  /** Provisiona un cliente nuevo: crea el tenant + su usuario dueño. Al dueño le llega por correo el enlace para
   *  crear su contraseña (nadie ve una clave temporal). La caja se enrola después desde el equipo con esas credenciales.
   *  `password` solo lo usan las pruebas y scripts: con ella no se manda correo. */
  async provisionar(dto: ProvisionarClienteDto) {
    const cli = this.crearClienteRow({
      negocio: dto.negocio, comuna: dto.comuna, comunaCut: dto.comunaCut, direccion: dto.direccion, email: dto.email, telefono: dto.telefono,
      rut: dto.rut, plan: dto.plan, estado: 'activo',
    });
    const dueno = this.auth.crearUsuario({
      email: dto.email, nombre: dto.nombre || dto.negocio, negocio: dto.negocio,
      password: dto.password || undefined, rol: 'admin', clienteId: cli.id,
    });
    this.logger.log(`Cliente provisionado: cliente ${cli.id}`);
    const envio = dto.password ? undefined : await this.acceso.enviarAcceso(dueno.id, 'invitacion');
    return { cliente: cli, owner: { email: dueno.email, envio } };
  }

  /** El staff le manda al dueño un enlace para crear una contraseña nueva (vale 72 h). Su clave actual sigue
   *  sirviendo hasta que use el enlace; nadie ve una clave temporal. */
  async restablecerClaveDueno(clienteId: string, staffEmail?: string) {
    const dueno = this.usuarios.duenosDeCliente(clienteId)[0];
    if (!dueno) throw new NotFoundException('Este negocio no tiene un usuario dueño.');
    const envio = await this.acceso.enviarAcceso(dueno.id as string, 'restablecer');
    this.logger.log(`Enlace de acceso enviado al usuario ${dueno.id} (cliente ${clienteId}) por ${staffEmail ?? 'staff'}`);
    return { email: dueno.email as string, envio };
  }

  setEstado(id: string, estado: string) {
    const actual = this.repo.obtener(id);
    if (!actual) throw new NotFoundException('Negocio no encontrado.');
    // U12: una cuenta que se registró y nunca pagó no se activa con un clic (quedaría gratis y sin vencimiento):
    // se usa "Registrar pago", que le da su período.
    if (actual.estado === 'pendiente' && estado === 'activo') {
      throw new ConflictException('Este negocio no ha pagado. Usa "Registrar pago" para activarlo con su período.');
    }
    this.repo.setEstado(id, estado, ahora());
    return { ok: true, id, estado };
  }

  /**
   * El staff cambia el plan de un negocio (cuentas que no pagan en línea, o un ajuste acordado con el dueño).
   * Rige de inmediato y sin cobro; el cupo de cajas y cajeros pasa a ser el del plan nuevo.
   */
  setPlan(id: string, planPedido: string, staffEmail?: string) {
    const plan = planCanon(planPedido);
    if (!this.cfg.planMonto[plan]) throw new BadRequestException('Elige un plan válido.');
    if (!this.repo.obtener(id)) throw new NotFoundException('Negocio no encontrado.');
    this.repo.setPlan(id, plan, ahora());
    this.logger.log(`Plan cambiado a ${plan}: cliente ${id}, por ${staffEmail ?? 'staff'}`);
    return { ok: true, id, plan };
  }

  /** KPIs de negocio para el panel del staff. */
  resumen() {
    const clientes = this.repo.listar();
    // Activo = puede operar (pagado o en días de gracia). Los vencidos y los que pidieron cerrar no cuentan en el MRR.
    const activos = clientes.filter((c) => c.estado === 'activo' && this.auth.cuentaOperativa(c.id));
    const enMora = clientes.filter((c) => c.estado === 'activo' && !this.auth.cuentaOperativa(c.id)).length;
    const suspendidos = clientes.filter((c) => c.estado === 'suspendido');
    // MRR = ingreso mensual recurrente: suma del plan de cada cliente activo según los montos de la config.
    const mrr = activos.reduce((s, c) => s + (this.cfg.planMonto[planCanon(c.plan)] ?? 0), 0);
    const porPlan: Record<string, number> = {};
    for (const c of clientes) porPlan[planCanon(c.plan)] = (porPlan[planCanon(c.plan)] ?? 0) + 1;
    return {
      clientes: clientes.length,
      activos: activos.length,
      suspendidos: suspendidos.length,
      enMora,
      mrr,
      porPlan,
    };
  }
}
