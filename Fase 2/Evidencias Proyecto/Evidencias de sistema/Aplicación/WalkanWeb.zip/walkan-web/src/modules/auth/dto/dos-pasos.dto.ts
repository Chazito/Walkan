import { IsBoolean, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

// Código de la app (6 dígitos) o de respaldo (xxxxx-xxxxx).
export class CodigoDosPasosDto {
  @IsString() @MinLength(6) @MaxLength(20) codigo!: string;
}
export class LoginCodigoDto extends CodigoDosPasosDto {
  @IsString() @MinLength(20) @MaxLength(100) desafio!: string;
  /** "Recordar este dispositivo por 30 días" (se ignora para el equipo Walkan). */
  @IsOptional() @IsBoolean() recordarDispositivo?: boolean;
}
export class DesactivarDosPasosDto extends CodigoDosPasosDto {
  @IsString() @MinLength(1) @MaxLength(100) password!: string;
}
