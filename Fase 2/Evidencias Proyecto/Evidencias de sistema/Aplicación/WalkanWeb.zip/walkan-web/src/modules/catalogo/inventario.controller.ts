// Endpoints de inventario: predicción de reposición, costos, mermas, alzas de costo y lotes por vencer.
import { BadRequestException, Body, Controller, Get, Param, Post, Put, Query, Res, UseGuards } from '@nestjs/common';
import { ConfigInventarioDto, LoteDto, RetirarLoteDto } from './dto/producto.dto';
import { SesionGuard } from '../auth/auth.guard';
import { ContextoTenant } from '../../common/contexto-tenant';
import { fechaCL, fechaValida } from '../../common/util/fecha';
import { PrediccionService } from './prediccion.service';
import { StockService } from './stock.service';
import { LimitesPlan } from './limites-plan.service';

// Endpoint de la predicción de inventario (cuánto reponer, ABC). El cálculo vive en prediccion.ts.
@Controller('api/inventario')
@UseGuards(SesionGuard)
export class InventarioController {
  constructor(
    private readonly prediccion: PrediccionService,
    private readonly stock: StockService,
    private readonly ctx: ContextoTenant,
    private readonly limites: LimitesPlan,
  ) {}

  // Qué reponer y rotación ABC: parte de las analíticas (planes Profesional y Empresa).
  @Get('prediccion')
  prediccionInventario() { this.limites.exigir('analiticas'); return this.prediccion.calcular(); }

  // Parámetros del negocio: umbral de stock bajo y días de seguridad/cobertura de la reposición.
  @Get('config')
  config() { return this.prediccion.config(); }

  // Descarga de todos los datos de inventario del negocio (JSON), para respaldarlos o llevarlos a otro sistema.
  @Get('exportar')
  exportar(@Res({ passthrough: true }) reply: any) {
    reply.header('Content-Disposition', `attachment; filename="walkan-inventario-${fechaCL()}.json"`).header('Cache-Control', 'no-store');
    return this.stock.exportar(this.ctx.clienteId);
  }
  // Un `desde` más antiguo que el historial del plan se sube al primer día permitido (solo si es una fecha válida;
  // si no, la validación de abajo responde 400 igual que antes).
  private alHistorial(d: string): string {
    const min = this.limites.historialDesde();
    return min && fechaValida(d) && d < min ? min : d;
  }

  @Put('config')
  guardarConfig(@Body() dto: ConfigInventarioDto) { return this.prediccion.guardarConfig(dto); }

  // Costo FIFO de lo vendido entre dos días de Chile (para la ganancia del día). Sin fechas: hoy.
  @Get('costo-ventas')
  costoVentas(@Query('desde') desde?: string, @Query('hasta') hasta?: string) {
    const d = this.alHistorial(desde || fechaCL()), h = hasta || d;
    if (!fechaValida(d) || !fechaValida(h) || d > h) throw new BadRequestException('Rango de fechas inválido (AAAA-MM-DD, desde ≤ hasta).');
    if (Date.parse(h) - Date.parse(d) > 366 * 86_400_000) throw new BadRequestException('El rango no puede superar un año.');
    return this.stock.costoVentas(this.ctx.clienteId, d, h);
  }

  // Productos cuyo costo subió en los últimos N días (por defecto 30), con su proveedor.
  @Get('alzas')
  alzas(@Query('dias') dias?: string) {
    const n = parseInt(dias ?? '', 10);
    return this.stock.alzasCosto(this.ctx.clienteId, Math.min(365, Math.max(1, Number.isNaN(n) ? 30 : n)));
  }

  // Mermas (ajustes negativos) entre dos días de Chile. Sin fechas: el mes en curso hasta hoy.
  @Get('mermas')
  mermas(@Query('desde') desde?: string, @Query('hasta') hasta?: string) {
    const hoy = fechaCL();
    const d = this.alHistorial(desde || hoy.slice(0, 8) + '01'), h = hasta || hoy;
    if (!fechaValida(d) || !fechaValida(h) || d > h) throw new BadRequestException('Rango de fechas inválido (AAAA-MM-DD, desde ≤ hasta).');
    // Tope de un año: el recorte por día de Chile se hace en memoria.
    if (Date.parse(h) - Date.parse(d) > 366 * 86_400_000) throw new BadRequestException('El rango no puede superar un año.');
    return this.stock.mermas(this.ctx.clienteId, d, h);
  }
}

// "Vender primero": lotes con saldo que vencen dentro de N días (por defecto 30), incluidos los vencidos.
@Controller('api/lotes')
@UseGuards(SesionGuard)
export class LotesController {
  constructor(private readonly stock: StockService, private readonly ctx: ContextoTenant) {}

  @Get('por-vencer')
  porVencer(@Query('dias') dias?: string) {
    const d = parseInt(dias ?? '', 10);
    const n = Math.min(365, Math.max(0, Number.isNaN(d) ? 30 : d));
    const hoy = fechaCL();
    const hasta = new Date(Date.parse(hoy + 'T00:00:00Z') + n * 86_400_000).toISOString().slice(0, 10);
    const dia = (f: string) => Math.round((Date.parse(f + 'T00:00:00Z') - Date.parse(hoy + 'T00:00:00Z')) / 86_400_000);
    return (this.stock.lotesPorVencer(this.ctx.clienteId, hasta) as any[]).map((l) => ({ ...l, dias: dia(l.vence) }));
  }

  // Corregir código o vencimiento de un lote (queda en el kardex con cantidad 0).
  @Put(':id')
  editar(@Param('id') id: string, @Body() dto: LoteDto) {
    return this.stock.editarLote(this.ctx.clienteId, id, dto.codigo?.trim() || null, dto.vence);
  }

  // Dar de baja todo el saldo del lote (merma con ese lote en el kardex).
  @Post(':id/retirar')
  retirar(@Param('id') id: string, @Body() dto: RetirarLoteDto) {
    return this.stock.retirarLote(this.ctx.clienteId, id, dto.motivo?.trim() || 'Retiro por vencimiento');
  }
}
