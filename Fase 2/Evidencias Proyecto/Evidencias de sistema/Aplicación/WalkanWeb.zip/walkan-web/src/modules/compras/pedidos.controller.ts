// Endpoints de /api/pedidos: armar, editar, enviar y recibir pedidos a proveedores.
import { Body, Controller, Delete, Get, Param, Post, Put, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { ComprasService } from './compras.service';
import { LimitesPlan } from '../catalogo/limites-plan.service';
import { CrearPedidoBody, RecibirPedidoBody } from './dto/compras.dto';

// Pedidos al proveedor: Borrador -> Enviado -> Recibido. Recién al "recibir" se crea el ingreso de mercadería y sube el stock.
@Controller('api/pedidos')
@UseGuards(SesionGuard)
export class PedidosController {
  constructor(private readonly srv: ComprasService, private readonly limites: LimitesPlan) {}
  // Pedidos al proveedor = planes Profesional y Empresa. Listar, borrar y recibir siguen abiertos para que un negocio
  // que bajó de plan pueda cerrar los pedidos que ya tenía; lo que se bloquea es armar y mandar pedidos nuevos.
  @Get() listar() { return this.srv.listarPedidos(); }
  @Post() crear(@Body() dto: CrearPedidoBody) { this.limites.exigir('pedidosProveedor'); return this.srv.crearPedido(dto); }
  // Solo en Borrador (409 si ya se envió o recibió).
  @Put(':id') editar(@Param('id') id: string, @Body() dto: CrearPedidoBody) { this.limites.exigir('pedidosProveedor'); return this.srv.editarPedido(id, dto); }
  @Delete(':id') borrar(@Param('id') id: string) { return this.srv.borrarPedido(id); }
  @Post(':id/enviar') enviar(@Param('id') id: string) { this.limites.exigir('pedidosProveedor'); return this.srv.enviarPedido(id); }
  @Post(':id/recibir') recibir(@Param('id') id: string, @Body() body: RecibirPedidoBody) { return this.srv.recibirPedido(id, body); }
}
