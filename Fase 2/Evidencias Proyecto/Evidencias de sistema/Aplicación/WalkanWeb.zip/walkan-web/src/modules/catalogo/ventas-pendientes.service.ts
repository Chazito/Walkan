// Lógica de la bandeja "Vendido sin catálogo": ventas de la caja con códigos que el catálogo aún no conoce.
import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { ahora, nuevoId } from '../../common/util/id';
import { StockService } from './stock.service';

export interface LineaPendiente { ventaId: string; cajaId: string; sku: string | null; nombre: string; cantidad: number; precio: number; fecha: string }

/**
 * Ventas de la caja con un código que el catálogo no conoce (B1: P5, P6, I1, I2). La venta queda registrada igual;
 * la línea espera acá hasta que el dueño crea el producto con ese código, la vincula a uno existente o la ignora.
 * Al resolverla se descuenta el stock UNA sola vez (el UPDATE ... WHERE estado='pendiente' es el candado) y con la
 * fecha de la venta, así el kardex y el costo FIFO quedan como si el producto hubiera existido.
 */
@Injectable()
export class VentasPendientesService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly stock: StockService,
    private readonly ctx: ContextoTenant,
  ) {}

  /** La llama la sync (sin sesión: clienteId explícito), dentro de la transacción de la venta. */
  registrar(clienteId: string, l: LineaPendiente, now: string): void {
    this.db.prepare(`INSERT INTO ventas_pendientes (id,cliente_id,venta_id,caja_id,sku,nombre,cantidad,precio,fecha,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?)`).run(nuevoId(), clienteId, l.ventaId, l.cajaId, l.sku, l.nombre || 'Producto sin código', l.cantidad, l.precio, l.fecha, now);
  }

  /** Bandeja del panel: pendientes agrupadas por código, con las unidades y cuántas ventas. Más rechazos de la caja. */
  listar() {
    const cid = this.ctx.clienteId;
    const grupos = this.db.prepare(`SELECT sku, MAX(nombre) AS nombre, MAX(precio) AS precio, ROUND(SUM(cantidad),3) AS unidades,
        COUNT(DISTINCT venta_id) AS ventas, MIN(fecha) AS desde, MAX(fecha) AS hasta, MIN(id) AS id
      FROM ventas_pendientes WHERE cliente_id=? AND estado='pendiente'
      GROUP BY COALESCE(sku, id) ORDER BY unidades DESC LIMIT 200`).all(cid);
    const rechazos = this.db.prepare(`SELECT id, caja_id AS caja, seq, tipo, motivo, folio, total, created_at AS fecha
      FROM sync_rechazos WHERE cliente_id=? AND revisado=0 ORDER BY created_at DESC LIMIT 50`).all(cid);
    return { grupos, rechazos };
  }

  /**
   * Aplica las pendientes de un código a un producto. Se llama al crear, editar, importar o restaurar un producto con
   * ese SKU, y al vincular desde la bandeja. Devuelve cuántas líneas aplicó. Idempotente.
   */
  aplicarSku(clienteId: string, sku: string | null | undefined, productoId: string, usuarioId: string | null = null): number {
    if (!sku) return 0;
    const filas = this.db.prepare(`SELECT id FROM ventas_pendientes WHERE cliente_id=? AND sku=? AND estado='pendiente'`).all(clienteId, sku) as { id: string }[];
    return this.aplicarFilas(clienteId, filas.map((f) => f.id), productoId, usuarioId);
  }

  /** Bandeja → "Vincular a un producto": la línea elegida y todas las pendientes con su mismo código. */
  vincular(id: string, productoId: string) {
    const cid = this.ctx.clienteId;
    const ids = this.grupo(cid, id); // primero la línea: si no es de este negocio, 404 sin revelar nada más
    const p = this.db.prepare('SELECT id FROM productos WHERE id=? AND cliente_id=? AND activo=1').get(productoId, cid);
    if (!p) throw new BadRequestException('Ese producto no existe o está archivado.');
    return { ok: true, aplicadas: this.aplicarFilas(cid, ids, productoId, this.ctx.userId) };
  }

  /** Bandeja → "Ignorar": no mueve stock (por ejemplo, una bolsa o un servicio que no se inventaría). */
  ignorar(id: string) {
    const cid = this.ctx.clienteId;
    const ids = this.grupo(cid, id);
    const upd = this.db.prepare(`UPDATE ventas_pendientes SET estado='ignorada', resuelta_en=?, resuelta_por=? WHERE id=? AND cliente_id=? AND estado='pendiente'`);
    const now = ahora();
    const n = this.db.transaction(() => ids.reduce((s, x) => s + upd.run(now, this.ctx.userId, x, cid).changes, 0))();
    return { ok: true, ignoradas: n };
  }

  /** Marca un rechazo de la caja como revisado. */
  revisarRechazo(id: string) {
    const r = this.db.prepare('UPDATE sync_rechazos SET revisado=1 WHERE id=? AND cliente_id=?').run(id, this.ctx.clienteId);
    if (!r.changes) throw new NotFoundException('Rechazo no encontrado.');
    return { ok: true };
  }

  // La línea y sus hermanas pendientes con el mismo código (sin código: solo esa línea). 404 si no es de este negocio.
  private grupo(cid: string, id: string): string[] {
    const f = this.db.prepare(`SELECT id, sku FROM ventas_pendientes WHERE id=? AND cliente_id=? AND estado='pendiente'`).get(id, cid) as { id: string; sku: string | null } | undefined;
    if (!f) throw new NotFoundException('Esa venta ya se resolvió o no existe.');
    if (!f.sku) return [f.id];
    return (this.db.prepare(`SELECT id FROM ventas_pendientes WHERE cliente_id=? AND sku=? AND estado='pendiente'`).all(cid, f.sku) as { id: string }[]).map((r) => r.id);
  }

  private aplicarFilas(clienteId: string, ids: string[], productoId: string, usuarioId: string | null): number {
    if (!ids.length) return 0;
    const leer = this.db.prepare(`SELECT venta_id, cantidad, fecha FROM ventas_pendientes WHERE id=? AND cliente_id=?`);
    const marcar = this.db.prepare(`UPDATE ventas_pendientes SET estado='aplicada', producto_id=?, resuelta_en=?, resuelta_por=?
      WHERE id=? AND cliente_id=? AND estado='pendiente'`);
    const now = ahora();
    // Todo o nada: si un movimiento falla, ninguna línea queda marcada como aplicada sin su descuento.
    return this.db.transaction(() => {
      let n = 0;
      for (const id of ids) {
        if (!marcar.run(productoId, now, usuarioId, id, clienteId).changes) continue; // otra pestaña ya la resolvió
        const f = leer.get(id, clienteId) as { venta_id: string; cantidad: number; fecha: string };
        if (f.cantidad) this.stock.mover({ clienteId, productoId, tipo: 'venta', cantidad: -f.cantidad, refId: f.venta_id, fecha: f.fecha, usuarioId });
        n++;
      }
      return n;
    })();
  }
}
