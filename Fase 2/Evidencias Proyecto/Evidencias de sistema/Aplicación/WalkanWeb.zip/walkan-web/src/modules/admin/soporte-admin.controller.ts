// Endpoints de la bandeja de soporte para el equipo Walkan: ver, responder, asignar y cerrar tickets.
import { Body, Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { StaffGuard } from './staff.guard';
import { BitacoraService } from './bitacora.service';
import { SoporteService } from '../soporte/soporte.service';
import { EstadoTicketDto, RespuestaEquipoDto } from '../soporte/dto/soporte.dto';

const actor = (req: any) => ({ id: req?.usuario?.id, email: req?.usuario?.email, nombre: req?.usuario?.nombre });

// Bandeja de soporte del equipo Walkan (todo el staff). Quitar los dos pasos de un dueño queda en la bitácora.
@Controller('api/admin/soporte')
@UseGuards(StaffGuard)
export class SoporteAdminController {
  constructor(private readonly srv: SoporteService, private readonly bitacora: BitacoraService) {}

  @Get()
  listar(@Query('estado') estado?: string) { return { tickets: this.srv.listar(estado), pendientes: this.srv.pendientes() }; }

  @Get(':id')
  detalle(@Param('id') id: string) { return this.srv.detalle(id); }

  @Post(':id/responder')
  async responder(@Param('id') id: string, @Body() dto: RespuestaEquipoDto, @Req() req: any) {
    const r = await this.srv.responderEquipo(actor(req), id, dto.texto, dto.estado);
    this.bitacora.registrar(actor(req), 'Respondió ticket', `${r.numero}${dto.estado === 'resuelto' ? ' (resuelto)' : ''}`);
    return r;
  }

  @Post(':id/estado')
  estado(@Param('id') id: string, @Body() dto: EstadoTicketDto, @Req() req: any) {
    const r = this.srv.setEstado(id, dto.estado as any);
    this.bitacora.registrar(actor(req), 'Cambió estado de ticket', `${r.numero} → ${r.estadoNombre}`);
    return r;
  }

  @Post(':id/asignarme')
  asignarme(@Param('id') id: string, @Req() req: any) { return this.srv.asignar(id, req.usuario.id); }

  @Post(':id/quitar-dos-pasos')
  async quitarDosPasos(@Param('id') id: string, @Req() req: any) {
    const r = await this.srv.quitarDosPasos(id);
    this.bitacora.registrar(actor(req), 'Quitó dos pasos de un dueño', `${r.email}${r.negocio ? ' (' + r.negocio + ')' : ''} · ${r.detalle.numero}`);
    return r.detalle;
  }
}
