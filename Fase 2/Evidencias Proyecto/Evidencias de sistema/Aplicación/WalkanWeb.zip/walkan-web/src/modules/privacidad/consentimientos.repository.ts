import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';

export type Consentimiento = {
  id: string; email: string; usuarioId: string | null; clienteId: string | null;
  tipo: 'privacidad' | 'marketing'; aceptado: boolean; version: string; textoHash: string;
  origen: string; ip: string | null; userAgent: string | null; createdAt: string;
};
type Fila = Record<string, any>;
// De la fila de la BD (snake_case) al objeto Consentimiento.
const map = (r: Fila): Consentimiento => ({
  id: r.id, email: r.email, usuarioId: r.usuario_id, clienteId: r.cliente_id, tipo: r.tipo,
  aceptado: !!r.aceptado, version: r.version, textoHash: r.texto_hash, origen: r.origen,
  ip: r.ip, userAgent: r.user_agent, createdAt: r.created_at,
});

// Historial de solo inserción (la BD lo impone con triggers). No es multi-tenant: lo usan el
// registro público, el formulario de contacto, el propio titular y el staff.
@Injectable()
export class ConsentimientosRepository {
  private ins: Database.Statement;
  private ultimoPorUsuario: Database.Statement;
  private resumen: Database.Statement;
  private lista: Database.Statement;

  constructor(@Inject(SQLITE) db: Database.Database) {
    this.ins = db.prepare(`INSERT INTO consentimientos
      (id,email,usuario_id,cliente_id,tipo,aceptado,version,texto_hash,origen,ip,user_agent,created_at)
      VALUES (@id,@email,@usuarioId,@clienteId,@tipo,@aceptado,@version,@textoHash,@origen,@ip,@userAgent,@createdAt)`);
    // Solo filas de la CUENTA (usuario_id). Antes también calzaba por email, y el formulario público de
    // contacto (sin login) podía dejar "aceptó la política" o cambiar el marketing a nombre de cualquier correo.
    this.ultimoPorUsuario = db.prepare(`SELECT * FROM consentimientos WHERE usuario_id=@usuarioId AND tipo=@tipo
      ORDER BY created_at DESC, rowid DESC LIMIT 1`);
    // Para el staff: el último consentimiento de privacidad de cada cuenta, calculado en SQL (antes salía de
    // las últimas 500 filas y las cuentas viejas aparecían "Pendiente"). Sin IP ni navegador: la vista no los usa.
    this.resumen = db.prepare(`SELECT email, usuario_id, cliente_id, tipo, aceptado, version, origen, created_at
      FROM consentimientos c WHERE tipo='privacidad' AND usuario_id IS NOT NULL
      AND rowid=(SELECT x.rowid FROM consentimientos x WHERE x.usuario_id=c.usuario_id AND x.tipo='privacidad'
                 ORDER BY x.created_at DESC, x.rowid DESC LIMIT 1)`);
    this.lista = db.prepare('SELECT * FROM consentimientos ORDER BY created_at DESC, rowid DESC LIMIT ?');
  }
  insertar(c: Omit<Consentimiento, 'aceptado'> & { aceptado: boolean }): void { this.ins.run({ ...c, aceptado: c.aceptado ? 1 : 0 }); }
  // Lo último que dijo ese usuario para ese tipo: manda la fila más nueva.
  ultimo(usuarioId: string, tipo: string) { const r = this.ultimoPorUsuario.get({ usuarioId, tipo }) as Fila | undefined; return r ? map(r) : undefined; }
  /** Historial para el staff (prueba de consentimiento), sin IP ni navegador: esos quedan solo en la BD. */
  listar(limite = 500) {
    return (this.lista.all(limite) as Fila[]).map((r) => { const { ip, userAgent, ...resto } = map(r); return resto; });
  }
  // Una fila por cuenta con su último consentimiento de privacidad (tabla de clientes del staff).
  resumenCuentas() {
    return (this.resumen.all() as Fila[]).map((r) => ({
      email: r.email, usuarioId: r.usuario_id, clienteId: r.cliente_id, tipo: r.tipo,
      aceptado: !!r.aceptado, version: r.version, origen: r.origen, createdAt: r.created_at,
    }));
  }
}
