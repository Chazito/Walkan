// Preguntas frecuentes del centro de ayuda (/ayuda). Cada respuesta es una lista de párrafos en texto plano
// (la vista los escapa). Si cambia un precio, un plazo o un límite en el código, actualízalo también acá:
// precios y límites en config/configuracion.ts (PLANES_DEF, cajaAdicional); plazos en common/util/vigencia.ts.
export interface Pregunta { id: string; categoria: string; pregunta: string; respuesta: string[] }

export const PREGUNTAS: Pregunta[] = [
  // ---------------- Cuenta y acceso ----------------
  { id: 'olvide-contrasena', categoria: 'acceso', pregunta: 'Olvidé mi contraseña, ¿cómo entro?', respuesta: [
    'En la pantalla de inicio de sesión toca "¿Olvidaste tu contraseña?". Escribe el correo con el que entras y, si tu negocio tiene RUT registrado en Walkan, también el RUT.',
    'Te llegará un correo de walkan.pos@gmail.com con un enlace para crear una contraseña nueva. El enlace sirve una sola vez y vence en 30 minutos. Si no lo ves, revisa la carpeta de spam.',
    'Por seguridad, la página siempre responde lo mismo: no te dice si el correo o el RUT estaban bien. Si no te llega nada, revisa que los datos sean los de tu cuenta.',
  ] },
  { id: 'que-es-dos-pasos', categoria: 'acceso', pregunta: '¿Qué es la verificación en dos pasos y cómo la activo?', respuesta: [
    'Es una segunda llave: además de la contraseña, al entrar se pide un código de 6 dígitos que genera una app en tu celular (Google Authenticator o Microsoft Authenticator). Así, aunque alguien sepa tu contraseña, no puede entrar.',
    'Actívala en Mi cuenta › Verificación en dos pasos: escaneas el código QR con la app y escribes el código que muestra. Guarda los 8 códigos de respaldo en un lugar seguro, fuera del celular.',
    'Para los dueños es opcional (la recomendamos). Para el equipo Walkan es obligatoria.',
  ] },
  { id: 'perdi-celular-dos-pasos', categoria: 'acceso', pregunta: 'Perdí el celular con la app de códigos, ¿qué hago?', respuesta: [
    'Si guardaste los códigos de respaldo, en la pantalla del código toca "Usar un código de respaldo". Cada uno sirve una vez. Después, en Mi cuenta, configura la app en tu celular nuevo.',
    'Si no tienes los códigos, escríbenos desde Contactar a soporte, en la categoría "Cuenta y acceso". Incluye el RUT de tu negocio y el número de orden de uno de tus pagos del plan (está en el comprobante de Flow que te llegó por correo).',
    'Con esos datos verificamos que eres el dueño, quitamos la verificación en dos pasos y te avisamos al correo de la cuenta. Nunca te pediremos tu contraseña.',
  ] },
  { id: 'recordar-dispositivo', categoria: 'acceso', pregunta: '¿Puedo no escribir el código cada vez que entro?', respuesta: [
    'Sí. Al escribir el código marca "Recordar este dispositivo por 30 días": en ese navegador solo se te pedirá la contraseña. En otro equipo se sigue pidiendo el código.',
    'Los dispositivos recordados se olvidan solos si cambias la contraseña o la verificación en dos pasos. También puedes olvidarlos todos en Mi cuenta (por ejemplo, si perdiste un notebook).',
    'Esta opción no existe para las cuentas del equipo Walkan.',
  ] },
  { id: 'cambiar-contrasena', categoria: 'acceso', pregunta: '¿Cómo cambio mi contraseña?', respuesta: [
    'En Mi cuenta › Cambiar contraseña escribe la actual y la nueva. Por seguridad también te pedimos un código: el de tu app de verificación o, si no la usas, uno que te enviamos al correo con "Enviarme el código".',
    'Al cambiarla se cierran las sesiones abiertas en otros equipos y te llega un aviso por correo.',
  ] },
  { id: 'nunca-pedimos-clave', categoria: 'acceso', pregunta: '¿Walkan me puede pedir mi contraseña?', respuesta: [
    'No. Nadie del equipo Walkan te pedirá tu contraseña ni los códigos de tu app de verificación, ni por correo, ni por WhatsApp, ni por teléfono.',
    'Si alguien te los pide, no los entregues y escríbenos desde Contactar a soporte.',
  ] },

  // ---------------- Plan y pagos ----------------
  { id: 'planes-precios', categoria: 'plan', pregunta: '¿Cuánto cuesta Walkan y qué incluye cada plan?', respuesta: [
    'Esencial: $12.990 al mes, hasta 2 cajas, 3 cajeros y 2.000 productos, con 12 meses de historial.',
    'Profesional: $22.990 al mes, hasta 4 cajas, 8 cajeros y 10.000 productos, 24 meses de historial, pedidos a proveedores, analíticas y cobro con QR.',
    'Empresa: $37.990 al mes, hasta 8 cajas y 20 cajeros, productos e historial sin límite.',
    'La primera caja va incluida en todos los planes. Desde la segunda, cada caja se paga en arriendo con una cuota de $5.990 al mes, hasta completar 20 cuotas.',
  ] },
  { id: 'como-pago', categoria: 'plan', pregunta: '¿Cómo pago y cada cuánto?', respuesta: [
    'Pagas en línea con Flow, la plataforma de pagos chilena. Cada pago cubre 30 días.',
    'Desde 7 días antes de que venza puedes pagar el mes siguiente en Mi cuenta › Mi plan, y 3 días antes te enviamos un recordatorio por correo.',
  ] },
  { id: 'no-pague-a-tiempo', categoria: 'plan', pregunta: '¿Qué pasa si no pago a tiempo?', respuesta: [
    'Tienes 5 días de gracia en que todo sigue funcionando. Después, el panel queda en pausa (solo puedes entrar a Mi cuenta para pagar) y las cajas dejan de enviar las ventas a la nube.',
    'La caja de tu local sigue vendiendo. Apenas pagas, todo se reactiva y las ventas pendientes se suben solas.',
  ] },
  { id: 'cambiar-plan', categoria: 'plan', pregunta: '¿Puedo cambiar de plan?', respuesta: [
    'Sí, en Mi cuenta › Mi plan. Si subes de plan a mitad de mes, pagas solo la diferencia por los días que te quedan pagados y el cambio rige de inmediato.',
    'Si bajas de plan, el cambio rige desde la próxima renovación. Tu negocio debe caber en el plan nuevo (cajas, cajeros y productos).',
  ] },
  { id: 'cancelar-plan', categoria: 'plan', pregunta: '¿Cómo cancelo?', respuesta: [
    'En Mi cuenta › Mi plan. Mantienes el acceso hasta el último día que pagaste y no se te vuelve a cobrar.',
    'Si además quieres borrar tus datos, revisa "¿Cómo elimino mi cuenta?" en Privacidad y datos.',
  ] },

  // ---------------- Caja y equipo ----------------
  { id: 'caja-sin-internet', categoria: 'caja', pregunta: '¿La caja funciona si se corta internet?', respuesta: [
    'Sí. La caja trabaja en tu local: cobra, descuenta stock e imprime el comprobante con o sin conexión.',
    'Cuando vuelve internet, sube las ventas y movimientos a tu panel en orden y sin perder nada.',
  ] },
  { id: 'instalacion-caja', categoria: 'caja', pregunta: '¿Quién instala la caja?', respuesta: [
    'Nosotros. Después de que creas tu cuenta y cargas tus productos, coordinamos contigo y dejamos el equipo funcionando en tu local, con tu catálogo cargado y probado.',
  ] },
  { id: 'cajeros', categoria: 'caja', pregunta: '¿Cómo agrego a mis cajeros?', respuesta: [
    'Desde el panel, en Mis cajas › Cajeros. Cada cajero abre y cierra su turno con su propio PIN, así sabes quién vendió qué.',
    'La cantidad de cajeros depende del plan: 3 en Esencial, 8 en Profesional y 20 en Empresa.',
  ] },
  { id: 'robo-caja', categoria: 'caja', pregunta: 'Me robaron la caja, ¿qué hago?', respuesta: [
    'En el panel, en Mis cajas, toca "Bloquear por robo" en esa caja. Quedará inutilizable en cuanto tenga señal y se protegen sus datos.',
    'Tus ventas ya sincronizadas siguen en tu panel. Escríbenos desde Contactar a soporte para reponer el equipo.',
  ] },

  // ---------------- Inventario y ventas ----------------
  { id: 'cargar-productos', categoria: 'panel', pregunta: '¿Cómo cargo mis productos?', respuesta: [
    'Uno a uno en Inventario › Nuevo producto, o muchos de una vez con Más acciones › Importar CSV (hasta 10.000 filas y 5 MB por archivo). La vista previa te muestra los errores antes de guardar.',
    'Si prefieres, te ayudamos a cargar el catálogo: escríbenos desde Contactar a soporte.',
  ] },
  { id: 'limite-productos', categoria: 'panel', pregunta: '¿Hay un límite de productos?', respuesta: [
    'Sí: 2.000 productos activos en Esencial, 10.000 en Profesional y sin límite en Empresa. Bajo la tabla del inventario ves cuántos llevas.',
    'Los productos archivados no cuentan. Si necesitas más, sube de plan en Mi cuenta › Mi plan.',
  ] },
  { id: 'vencimientos', categoria: 'panel', pregunta: '¿Walkan me avisa de productos por vencer?', respuesta: [
    'Sí. Si registras los lotes con su fecha de vencimiento, el inventario te marca los que están por vencer, y al vender se descuenta primero el lote que vence antes.',
  ] },
  { id: 'conteo', categoria: 'panel', pregunta: '¿Cómo hago un conteo de inventario?', respuesta: [
    'En Inventario › Conteo. Busca cada producto y anota lo que hay de verdad en la góndola. Al confirmar, Walkan registra la diferencia de cada producto como un ajuste «Conteo físico». Lo que dejes vacío no se toca.',
  ] },
  { id: 'pedidos-proveedores', categoria: 'panel', pregunta: '¿Puedo hacer pedidos a mis proveedores?', respuesta: [
    'Sí, en los planes Profesional y Empresa. En Proveedores armas el pedido (Walkan te sugiere qué reponer) y al recibir la mercadería la ingresas al stock.',
  ] },

  // ---------------- Privacidad y datos ----------------
  { id: 'descargar-datos', categoria: 'privacidad', pregunta: '¿Puedo descargar mis datos?', respuesta: [
    'Sí, cuando quieras, en Mi cuenta › Descargar mis datos. Recibes un archivo ZIP con una tabla por cada tipo de dato (productos, ventas, compras, etc.) que se abre con Excel.',
    'No incluye contraseñas, llaves de Flow ni las fotos de los productos.',
  ] },
  { id: 'eliminar-cuenta', categoria: 'privacidad', pregunta: '¿Cómo elimino mi cuenta?', respuesta: [
    'En Mi cuenta › Eliminar mi cuenta (te pedimos tu contraseña). La cuenta se cierra de inmediato y tienes 30 días para arrepentirte y recuperarla.',
    'Pasados los 30 días se borran los datos de tu negocio. Por ley conservamos los pagos del plan y el registro de que aceptaste la Política de Privacidad.',
  ] },
  { id: 'quien-ve-mis-datos', categoria: 'privacidad', pregunta: '¿El equipo Walkan ve mis ventas?', respuesta: [
    'No el detalle. El equipo Walkan administra cuentas, planes y pagos, y para dar soporte ve el estado de tus cajas (si están en línea y cuántas ventas sincronizaron), pero no tu inventario ni el detalle de tus ventas.',
    'El detalle está en la Política de Privacidad.',
  ] },
];
