import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { CajerosService } from './cajeros.service';

// Cajeros del negocio (panel › Mis cajas). Las respuestas nunca incluyen el hash del PIN.
@Controller('api/cajeros')
@UseGuards(SesionGuard)
export class CajerosController {
  constructor(private readonly srv: CajerosService) {}

  @Get()
  listar() { return this.srv.listar(); }

  @Post()
  crear(@Body() body: { nombre?: string; pin?: string }) { return this.srv.crear(body); }

  @Patch(':id')
  actualizar(@Param('id') id: string, @Body() body: { nombre?: string; pin?: string; activo?: boolean }) {
    return this.srv.actualizar(id, body);
  }
}
