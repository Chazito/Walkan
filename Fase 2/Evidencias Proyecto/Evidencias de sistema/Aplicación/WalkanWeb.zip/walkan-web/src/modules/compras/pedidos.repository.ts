// Acceso a la tabla de pedidos a proveedores, siempre filtrado por el negocio de la sesión.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';

type Fila = Record<string, any>;
const map = (r: Fila) => ({
  id: r.id, prov: r.proveedor_id ?? '', provNombre: r.prov_nombre ?? '', fecha: r.fecha, estado: r.estado,
  nota: r.nota ?? '', items: JSON.parse(r.items_json || '[]'), compraId: r.compra_id ?? null,
  actualizado: r.updated_at, // en un pedido Enviado es cuándo se envió (para avisar si se atrasa)
});

// Pedidos a proveedores, siempre filtrados por el cliente_id de la sesión (hasta el UPDATE,
// para que nadie marque como recibido el pedido de otra tienda adivinando el id).
// Los items van como JSON en items_json; `map` los devuelve ya parseados.
@Injectable()
export class PedidosRepository {
  private ins!: Database.Statement; private list!: Database.Statement;
  private byId!: Database.Statement; private setEstado!: Database.Statement; private enviado!: Database.Statement;
  private editar!: Database.Statement; private borrar!: Database.Statement;
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly ctx: ContextoTenant,
  ) {
    this.ins = db.prepare(`INSERT INTO pedidos (id,proveedor_id,fecha,estado,nota,items_json,cliente_id,created_at,updated_at)
      VALUES (@id,@proveedorId,@fecha,@estado,@nota,@itemsJson,@clienteId,@createdAt,@updatedAt)`);
    // prov_nombre: el nombre sale aunque el proveedor esté archivado.
    const sel = 'SELECT pe.*, pr.nombre AS prov_nombre FROM pedidos pe LEFT JOIN proveedores pr ON pr.id=pe.proveedor_id AND pr.cliente_id=pe.cliente_id';
    this.list = db.prepare(sel + ' WHERE pe.cliente_id=@clienteId ORDER BY pe.created_at DESC');
    this.byId = db.prepare(sel + ' WHERE pe.id=@id AND pe.cliente_id=@clienteId');
    this.setEstado = db.prepare(`UPDATE pedidos SET estado='Recibido', items_json=@itemsJson, compra_id=@compraId, updated_at=@now
      WHERE id=@id AND cliente_id=@clienteId`);
    this.enviado = db.prepare(`UPDATE pedidos SET estado='Enviado', updated_at=@now WHERE id=@id AND cliente_id=@clienteId AND estado='Borrador'`);
    // Editar y borrar solo tocan borradores: el estado va en el WHERE para que no se cuele uno ya enviado.
    this.editar = db.prepare(`UPDATE pedidos SET proveedor_id=@proveedorId, nota=@nota, items_json=@itemsJson, updated_at=@now
      WHERE id=@id AND cliente_id=@clienteId AND estado='Borrador'`);
    this.borrar = db.prepare(`DELETE FROM pedidos WHERE id=@id AND cliente_id=@clienteId AND estado='Borrador'`);
  }
  crear(p: any): void { this.ins.run({ ...p, clienteId: this.ctx.clienteId }); }
  listar() { return (this.list.all({ clienteId: this.ctx.clienteId }) as Fila[]).map(map); }
  obtener(id: string) { const r = this.byId.get({ id, clienteId: this.ctx.clienteId }) as Fila | undefined; return r ? map(r) : undefined; }
  // Guarda lo que realmente llegó (puede diferir de lo pedido) y el ingreso que generó.
  marcarRecibido(id: string, itemsJson: string, compraId: string, now: string): void { this.setEstado.run({ id, itemsJson, compraId, now, clienteId: this.ctx.clienteId }); }
  /** Borrador -> Enviado. Devuelve false si no era un borrador. */
  marcarEnviado(id: string, now: string): boolean { return this.enviado.run({ id, now, clienteId: this.ctx.clienteId }).changes > 0; }
  /** Reemplaza proveedor, nota e items de un borrador. Devuelve false si no era un borrador. */
  editarBorrador(id: string, d: { proveedorId: string | null; nota: string | null; itemsJson: string; now: string }): boolean {
    return this.editar.run({ ...d, id, clienteId: this.ctx.clienteId }).changes > 0;
  }
  /** Elimina un borrador. Devuelve false si no era un borrador. */
  borrarBorrador(id: string): boolean { return this.borrar.run({ id, clienteId: this.ctx.clienteId }).changes > 0; }
}
