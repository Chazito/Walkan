// Rutas de las páginas del sitio (landing, login, ayuda, panel, admin) y el armado del script del panel.
import { Controller, Get, Render, Req, Res } from '@nestjs/common';
import { createHash } from 'crypto';
import { readdir, readFile, stat } from 'fs/promises';
import { join } from 'path';
import { TEXTO_CASILLA_CONTACTO, TEXTO_CASILLA_MARKETING } from '../privacidad/politica';
import { AuthService } from '../auth/auth.service';
import { COOKIE_SESION, opcionesCookie } from '../auth/auth.guard';
import { dosPasosObligatorio } from '../auth/dos-pasos.service';
import { RecuperacionService } from '../recuperacion/recuperacion.service';
import { CATEGORIAS } from '../soporte/categorias';
import { PREGUNTAS } from '../soporte/ayuda';

const PANEL_DIR = join(process.cwd(), 'public', 'js', 'panel');
// panel.js ya armado, en memoria, con la firma de los archivos de la que salió (ver panelJs).
let panelCache = { firma: '', js: '', etag: '' };

/**
 * Sirve las páginas del sitio como vistas EJS (layout + parciales).
 * /panel y /admin revisan la sesión aquí, antes de mandar el HTML: sin sesión válida se redirige al login,
 * así no se alcanza a ver el panel vacío por un instante. Los datos igual se piden por /api/*, que tiene sus guards.
 */
@Controller()
export class ViewsController {
  constructor(private readonly auth: AuthService, private readonly recuperacion: RecuperacionService) {}

  /** Usuario de la cookie de sesión, o null. Reenvía la cookie si la sesión "Recordarme" se renovó. */
  private usuario(req: any, reply: any) {
    const raw = req.cookies?.[COOKIE_SESION];
    if (!raw) return null;
    const un = req.unsignCookie(raw);
    if (!un.valid || !un.value) return null;
    const u = this.auth.usuarioDeSesion(un.value);
    if (!u) return null;
    if (u.renovada) reply.setCookie(COOKIE_SESION, un.value, opcionesCookie(true));
    return u;
  }

  /** Muestra una página privada o redirige: sin sesión → login; con el rol equivocado → su propio panel. */
  private privada(req: any, reply: any, vista: string, rol: 'staff' | 'negocio') {
    const u = this.usuario(req, reply);
    // no-store: el botón Atrás después de cerrar sesión no muestra una copia guardada del panel.
    reply.header('Cache-Control', 'no-store');
    if (!u) return reply.redirect('/mi-cuenta', 302);
    const esStaff = u.rol === 'staff';
    if (rol === 'staff' && !esStaff) return reply.redirect('/panel', 302);
    if (rol === 'negocio' && esStaff) return reply.redirect('/admin', 302);
    // Equipo Walkan sin verificación en dos pasos: primero la configura.
    if (dosPasosObligatorio(u.rol) && !u.dosPasos) return reply.redirect('/dos-pasos', 302);
    return reply.view(vista, {});
  }

  @Get()
  @Render('pages/landing.ejs')
  landing() {
    // Los textos de las casillas salen de politica.ts: el hash que se guarda corresponde a lo que se ve.
    return { casillaContacto: TEXTO_CASILLA_CONTACTO, casillaMarketing: TEXTO_CASILLA_MARKETING };
  }

  // Con la sesión abierta, "Mi cuenta" lleva directo al panel que corresponde (sin pasar por el formulario).
  @Get('mi-cuenta')
  login(@Req() req: any, @Res() reply: any) {
    const u = this.usuario(req, reply);
    if (u) return reply.redirect(u.rol === 'staff' ? '/admin' : '/panel', 302);
    return reply.view('pages/login.ejs', {});
  }

  // "¿Olvidaste tu contraseña?" y el enlace que llega por correo. Sin sesión.
  @Get('recuperar')
  recuperar(@Res() reply: any) {
    reply.header('Cache-Control', 'no-store');
    return reply.view('pages/recuperar.ejs', {});
  }
  @Get('restablecer')
  restablecer(@Req() req: any, @Res() reply: any) {
    // no-referrer: el token del enlace no viaja a ningún otro sitio. no-store: no queda guardada la página.
    reply.header('Cache-Control', 'no-store').header('Referrer-Policy', 'no-referrer');
    return reply.view('pages/restablecer.ejs', { vigente: this.recuperacion.vigente(String(req.query?.t ?? '')) });
  }
  // Centro de ayuda y contacto con soporte (públicos).
  @Get('ayuda')
  @Render('pages/ayuda.ejs')
  ayuda() { return { categorias: CATEGORIAS, preguntas: PREGUNTAS }; }
  @Get('ayuda/contacto')
  @Render('pages/ayuda-contacto.ejs')
  ayudaContacto() { return { categorias: CATEGORIAS }; }

  // Configurar la verificación en dos pasos (con sesión). El staff llega aquí obligado.
  @Get('dos-pasos')
  dosPasos(@Req() req: any, @Res() reply: any) {
    reply.header('Cache-Control', 'no-store');
    if (!this.usuario(req, reply)) return reply.redirect('/mi-cuenta', 302);
    return reply.view('pages/dos-pasos.ejs', {});
  }

  // Panel del negocio. Si entra alguien del equipo, privada() lo manda a /admin.
  @Get('panel')
  panel(@Req() req: any, @Res() reply: any) {
    return this.privada(req, reply, 'pages/panel.ejs', 'negocio');
  }

  // El panel está repartido en public/js/panel/NN-seccion.js (una sección por archivo) pero corre como un solo
  // script con un solo scope: acá se juntan en orden. Queda en memoria y se vuelve a armar solo si cambió algún
  // archivo (fecha de modificación), así un cambio se ve al recargar sin paso de build. El ETag evita re-bajarlo.
  @Get('js/panel.js')
  async panelJs(@Req() req: { headers: Record<string, string | undefined> }, @Res({ passthrough: true }) reply: any): Promise<string> {
    const archivos = (await readdir(PANEL_DIR)).filter((f) => /^\d{2}-[\w-]+\.js$/.test(f)).sort();
    const firma = (await Promise.all(archivos.map(async (f) => f + (await stat(join(PANEL_DIR, f))).mtimeMs))).join('|');
    if (firma !== panelCache.firma) {
      // '\n' entre archivos: un archivo que termine en comentario // no se come la primera línea del siguiente.
      const js = (await Promise.all(archivos.map((f) => readFile(join(PANEL_DIR, f), 'utf8')))).join('\n');
      panelCache = { firma, js, etag: '"' + createHash('sha1').update(js).digest('base64url') + '"' };
    }
    reply.header('Content-Type', 'application/javascript; charset=utf-8').header('Cache-Control', 'no-cache').header('ETag', panelCache.etag);
    if (req.headers['if-none-match'] === panelCache.etag) { reply.status(304); return ''; }
    return panelCache.js;
  }

  // Panel del equipo Walkan. Un dueño que llegue acá va a /panel.
  @Get('admin')
  admin(@Req() req: any, @Res() reply: any) {
    return this.privada(req, reply, 'pages/admin.ejs', 'staff');
  }
}
