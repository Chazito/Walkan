// Todo el módulo de apariencia en un solo archivo: DTO, servicio, endpoints y módulo.
import { Body, Controller, ForbiddenException, Get, Inject, Injectable, Module, Put, Req, UseGuards } from '@nestjs/common';
import { IsIn, Matches } from 'class-validator';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { AuthModule } from '../auth/auth.module';
import { SesionGuard } from '../auth/auth.guard';

// Apariencia del panel (Mi cuenta › Apariencia): cada negocio elige estilo, modo y el color de su marca.
// Se guarda en `clientes` (migración 025). Solo cambia la vista: las funciones son las mismas en los tres estilos.
export const ESTILOS = ['nitido', 'suave', 'consola'];
export const MODOS = ['auto', 'claro', 'oscuro'];
export const POR_DEFECTO = { estilo: 'nitido', modo: 'auto', acento: '#0B7C4E' };

export class AparienciaDto {
  @IsIn(ESTILOS, { message: 'Estilo no válido.' }) estilo!: string;
  @IsIn(MODOS, { message: 'Modo no válido.' }) modo!: string;
  @Matches(/^#[0-9a-fA-F]{6}$/, { message: 'El color debe tener el formato #RRGGBB.' }) acento!: string;
}

@Injectable()
export class AparienciaService {
  private leer: Database.Statement;
  private guardarSt: Database.Statement;
  constructor(@Inject(SQLITE) db: Database.Database) {
    this.leer = db.prepare('SELECT apariencia_estilo AS estilo, apariencia_modo AS modo, apariencia_acento AS acento FROM clientes WHERE id=?');
    this.guardarSt = db.prepare('UPDATE clientes SET apariencia_estilo=@estilo, apariencia_modo=@modo, apariencia_acento=@acento, updated_at=@now WHERE id=@id');
  }
  /** El staff (sin negocio) ve la apariencia por defecto de Walkan. */
  obtener(clienteId: string | null) {
    const r = clienteId ? (this.leer.get(clienteId) as typeof POR_DEFECTO | undefined) : undefined;
    return { ...POR_DEFECTO, ...(r ?? {}), porDefecto: POR_DEFECTO };
  }
  guardar(clienteId: string, a: AparienciaDto) {
    this.guardarSt.run({ id: clienteId, estilo: a.estilo, modo: a.modo, acento: a.acento.toUpperCase(), now: new Date().toISOString() });
    return this.obtener(clienteId);
  }
}

@Controller('api/apariencia')
@UseGuards(SesionGuard)
export class AparienciaController {
  constructor(private readonly srv: AparienciaService) {}
  @Get() obtener(@Req() req: any) { return this.srv.obtener(req.usuario.clienteId ?? null); }
  @Put() guardar(@Req() req: any, @Body() dto: AparienciaDto) {
    // La apariencia es del negocio: la cambia su dueño (el staff no tiene negocio propio).
    if (req.usuario.rol !== 'admin' || !req.usuario.clienteId) throw new ForbiddenException('Solo el dueño del negocio puede cambiar la apariencia.');
    return this.srv.guardar(req.usuario.clienteId, dto);
  }
}

@Module({ imports: [AuthModule], controllers: [AparienciaController], providers: [AparienciaService] })
export class AparienciaModule {}
