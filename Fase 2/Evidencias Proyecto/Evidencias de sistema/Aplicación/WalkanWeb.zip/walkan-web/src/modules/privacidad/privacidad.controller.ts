import { Body, Controller, Get, Post, Render, Req, UseGuards } from '@nestjs/common';
import { IsBoolean, IsOptional } from 'class-validator';
import { SesionGuard } from '../auth/auth.guard';
import { StaffGuard } from '../admin/staff.guard';
import { politica, RESPONSABLE, VERSION, contactoPrivacidad, TEXTO_CASILLA_PRIVACIDAD, TEXTO_CASILLA_MARKETING } from './politica';
import { PrivacidadService } from './privacidad.service';
import { terminos } from './terminos';

// El marketing viene aparte y es opcional: aceptar la política no obliga a aceptarlo.
class AceptarDto { @IsOptional() @IsBoolean() marketing?: boolean; }
class MarketingDto { @IsBoolean() aceptado!: boolean; }

// IP y navegador de quien consiente: quedan en el historial como respaldo.
export const meta = (req: any) => ({ ip: req.ip ?? null, userAgent: req.headers?.['user-agent'] ?? null });

@Controller()
export class PrivacidadController {
  constructor(private readonly srv: PrivacidadService) {}

  /** Página pública con la política. /privacidad?aceptar=1 muestra además el botón para aceptarla. */
  @Get('privacidad')
  @Render('pages/privacidad.ejs')
  pagina() {
    return { secciones: politica(), version: VERSION, responsable: RESPONSABLE, correo: contactoPrivacidad(),
      casillaPrivacidad: TEXTO_CASILLA_PRIVACIDAD, casillaMarketing: TEXTO_CASILLA_MARKETING };
  }

  /** Página pública con los Términos y Condiciones (misma versión que la política). */
  @Get('terminos')
  @Render('pages/terminos.ejs')
  paginaTerminos() {
    return { secciones: terminos(RESPONSABLE, contactoPrivacidad()), version: VERSION, responsable: RESPONSABLE, correo: contactoPrivacidad() };
  }

  // El panel lo consulta al entrar para saber si hay que pedirle aceptar la política vigente.
  @Get('api/privacidad/estado')
  @UseGuards(SesionGuard)
  estado(@Req() req: any) { return this.srv.estado(req.usuario); }

  @Post('api/privacidad/aceptar')
  @UseGuards(SesionGuard)
  aceptar(@Req() req: any, @Body() dto: AceptarDto) {
    this.srv.aceptarPolitica(req.usuario, dto.marketing, meta(req));
    return this.srv.estado(req.usuario);
  }

  @Post('api/privacidad/marketing')
  @UseGuards(SesionGuard)
  marketing(@Req() req: any, @Body() dto: MarketingDto) {
    this.srv.cambiarMarketing(req.usuario, dto.aceptado, meta(req));
    return this.srv.estado(req.usuario);
  }

  /** Historial completo para el staff (prueba ante una fiscalización). */
  @Get('api/admin/consentimientos')
  @UseGuards(StaffGuard)
  listar() { return this.srv.listar(); }

  /** Último consentimiento de privacidad de cada cuenta (tabla de clientes del staff). */
  @Get('api/admin/consentimientos/resumen')
  @UseGuards(StaffGuard)
  resumen() { return this.srv.resumenCuentas(); }
}
