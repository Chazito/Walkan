// Aplica en el servidor los límites del plan del negocio: cupo de productos, historial y funciones incluidas.
import { ConflictException, ForbiddenException, Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { CONFIG } from '../../config/config.provider';
import { AppConfig, PlanDef } from '../../config/configuracion';
import { ContextoTenant } from '../../common/contexto-tenant';
import { planCanon } from '../../common/util/planes';

/**
 * Límites del plan del negocio logueado (productos, historial, analíticas, pedidos a proveedores).
 * Los valores viven en configuracion.ts → PLANES_DEF; acá solo se leen y se aplican EN EL SERVIDOR:
 * esconder un botón en el panel no basta, la API también tiene que negarse.
 */
@Injectable()
export class LimitesPlan {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    @Inject(CONFIG) private readonly cfg: AppConfig,
    private readonly ctx: ContextoTenant,
  ) {}

  /** Plan y límites del negocio. Plan desconocido (fila vieja o rara): sin límites, para no bloquear a nadie por un dato malo. */
  def(clienteId = this.ctx.clienteId): { plan: string; def: PlanDef | null } {
    const r = this.db.prepare('SELECT plan FROM clientes WHERE id=?').get(clienteId) as { plan: string | null } | undefined;
    const plan = planCanon(r?.plan);
    return { plan, def: this.cfg.planes[plan] ?? null };
  }

  /** 403 si el plan no incluye la función. */
  exigir(funcion: 'analiticas' | 'pedidosProveedor'): void {
    const { plan, def } = this.def();
    if (def && !def.funciones[funcion]) {
      const nombre = funcion === 'analiticas' ? 'Las analíticas (qué reponer y rotación ABC)' : 'Los pedidos a proveedores';
      throw new ForbiddenException(`${nombre} no están incluidos en el plan ${plan}. Puedes cambiar de plan en Mi cuenta → Mi plan.`);
    }
  }

  /** 403 si agregar `nuevos` productos activos supera el cupo del plan. */
  exigirCupoProductos(nuevos = 1): void {
    const { plan, def } = this.def();
    if (!def || def.productos == null) return;
    const n = (this.db.prepare('SELECT COUNT(*) AS n FROM productos WHERE cliente_id=? AND activo=1').get(this.ctx.clienteId) as { n: number }).n;
    if (n + nuevos > def.productos) {
      throw new ConflictException(`Tu plan ${plan} permite hasta ${def.productos.toLocaleString('es-CL')} productos y ya tienes ${n.toLocaleString('es-CL')}. Archiva los que no vendes o cambia de plan en Mi cuenta → Mi plan.`);
    }
  }

  /** Primer día (AAAA-MM-DD) que el plan deja consultar; null = historial completo. */
  historialDesde(): string | null {
    const { def } = this.def();
    if (!def || def.historialMeses == null) return null;
    const d = new Date();
    d.setUTCMonth(d.getUTCMonth() - def.historialMeses);
    return d.toISOString().slice(0, 10);
  }
}
