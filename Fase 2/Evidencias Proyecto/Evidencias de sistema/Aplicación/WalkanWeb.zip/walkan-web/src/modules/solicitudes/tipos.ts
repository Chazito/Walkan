// Una solicitud de alta que llega desde el formulario público del sitio.
export interface Solicitud {
  id: string; negocio: string; contacto: string; email: string;
  telefono: string | null; comuna: string | null; plan: string; mensaje: string | null;
  estado: string; pagoEstado: string; flowOrder: string | null; flowToken: string | null;
  monto: number; createdAt: string; updatedAt: string;
}
// Pasos del onboarding en orden; el panel de staff los usa para mover la solicitud hasta 'Activa'.
export const ESTADOS = ['Nueva','Contactada','En evaluación','Contrato firmado','Certificado cargado','CAF cargado','Activa'];
