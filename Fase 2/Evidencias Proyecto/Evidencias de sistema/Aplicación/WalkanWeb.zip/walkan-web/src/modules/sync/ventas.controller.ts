// GET /api/ventas: las ventas que subieron las cajas, para el panel del negocio.
import { BadRequestException, Controller, Get, Query, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { LimitesPlan } from '../catalogo/limites-plan.service';
import { SyncService } from './sync.service';

// Formato de día que aceptamos: AAAA-MM-DD.
const DIA = /^\d{4}-\d{2}-\d{2}$/;

// Ventas que ya subieron las cajas, para el panel. Se validan las fechas acá antes de que lleguen al SQL.
@Controller('api/ventas')
@UseGuards(SesionGuard)
export class VentasController {
  constructor(private readonly srv: SyncService, private readonly limites: LimitesPlan) {}

  /** ?desde=YYYY-MM-DD&hasta=YYYY-MM-DD (días de Chile, inclusive). Sin rango: últimas 100. */
  @Get()
  listar(@Query('desde') desde?: string, @Query('hasta') hasta?: string) {
    if ((desde && !DIA.test(desde)) || (hasta && !DIA.test(hasta))) {
      throw new BadRequestException('desde/hasta deben tener formato AAAA-MM-DD.');
    }
    // Historial del plan (Esencial 12 meses, Profesional 24, Empresa completo): lo más antiguo no se entrega.
    return this.srv.listarVentas(desde, hasta, this.limites.historialDesde());
  }
}
