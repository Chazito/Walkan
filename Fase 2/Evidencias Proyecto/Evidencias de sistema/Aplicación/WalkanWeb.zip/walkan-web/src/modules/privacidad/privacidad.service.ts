import { Injectable } from '@nestjs/common';
import { ahora, nuevoId } from '../../common/util/id';
import { ConsentimientosRepository } from './consentimientos.repository';
import { hashTexto, TEXTO_CASILLA_MARKETING, TEXTO_CASILLA_PRIVACIDAD, VERSION } from './politica';

export type MetaPeticion = { ip?: string | null; userAgent?: string | null };
type Titular = { email: string; usuarioId?: string | null; clienteId?: string | null };

@Injectable()
export class PrivacidadService {
  constructor(private readonly repo: ConsentimientosRepository) {}

  /** Agrega una fila al historial. `casilla` es el texto exacto que vio la persona. */
  registrar(t: Titular, tipo: 'privacidad' | 'marketing', aceptado: boolean, casilla: string, origen: string, meta: MetaPeticion = {}): void {
    this.repo.insertar({
      id: nuevoId(), email: t.email.trim().toLowerCase(), usuarioId: t.usuarioId ?? null, clienteId: t.clienteId ?? null,
      tipo, aceptado, version: VERSION, textoHash: hashTexto(casilla), origen,
      ip: meta.ip ?? null, userAgent: (meta.userAgent ?? '').slice(0, 300) || null, createdAt: ahora(),
    });
  }

  /** Estado del usuario en sesión: ¿aceptó la política VIGENTE? ¿acepta marketing? */
  estado(u: { id: string; email: string; rol: string }) {
    const p = this.repo.ultimo(u.id, 'privacidad');
    const m = this.repo.ultimo(u.id, 'marketing');
    // También el hash del texto: si alguien edita la política y olvida subir VERSION, igual se pide aceptar de nuevo.
    const vigente = !!p && p.aceptado && p.version === VERSION && p.textoHash === hashTexto(TEXTO_CASILLA_PRIVACIDAD);
    return {
      version: VERSION,
      // El staff (equipo Walkan) no es cliente: no se le pide aceptar la política de clientes.
      requiere: u.rol !== 'staff' && !vigente,
      privacidad: p ? { aceptado: p.aceptado, version: p.version, fecha: p.createdAt } : null,
      marketing: { aceptado: !!m && m.aceptado, fecha: m ? m.createdAt : null },
    };
  }

  // Acepta la política (obligatoria) y, si viene, deja también la decisión de marketing.
  aceptarPolitica(u: { id: string; email: string; clienteId?: string | null }, marketing: boolean | undefined, meta: MetaPeticion) {
    const t = { email: u.email, usuarioId: u.id, clienteId: u.clienteId ?? null };
    this.registrar(t, 'privacidad', true, TEXTO_CASILLA_PRIVACIDAD, 'ingreso', meta);
    if (marketing !== undefined) this.registrar(t, 'marketing', marketing, TEXTO_CASILLA_MARKETING, 'ingreso', meta);
  }

  // Prender o apagar el marketing desde Mi cuenta: no se edita la fila anterior, se agrega una nueva.
  cambiarMarketing(u: { id: string; email: string; clienteId?: string | null }, aceptado: boolean, meta: MetaPeticion) {
    this.registrar({ email: u.email, usuarioId: u.id, clienteId: u.clienteId ?? null }, 'marketing', aceptado, TEXTO_CASILLA_MARKETING, 'mi-cuenta', meta);
  }

  listar() { return this.repo.listar(); }
  resumenCuentas() { return this.repo.resumenCuentas(); }
}
