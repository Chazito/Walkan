// Módulo de recuperación de contraseña: controller y servicio de los enlaces y códigos.
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { SyncModule } from '../sync/sync.module';
import { RecuperacionController } from './recuperacion.controller';
import { RecuperacionService } from './recuperacion.service';

// "¿Olvidaste tu contraseña?". Importa sync por el servicio de correo (mismo SMTP que los avisos del plan).
@Module({
  imports: [AuthModule, SyncModule],
  controllers: [RecuperacionController],
  providers: [RecuperacionService],
  exports: [RecuperacionService],
})
export class RecuperacionModule {}
