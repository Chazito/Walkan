// Acceso a SQLite del alta y los planes: clientes, suscripciones (pagos del plan), tarjeta inscrita y uso del cupo.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';

type Fila = Record<string, any>;

export interface Suscripcion {
  id: string; clienteId: string; plan: string; monto: number; estado: string;
  flowToken: string | null; periodoInicio: string | null; periodoFin: string | null;
  /** Última modificación de la fila; en una suscripción pagada es el momento en que se confirmó el pago. */
  actualizada: string;
  /** 'periodo' = pago de un mes; 'cambio' = diferencia por subir de plan a mitad de mes (no mueve el vencimiento). */
  tipo: TipoCobro;
  /** Cajas adicionales cuya cuota de arriendo va en este cobro (solo en pagos de un mes). */
  cajas: string[];
  /** Cómo se pagó: en línea con Flow, cobro automático a la tarjeta inscrita o registrado por el staff. */
  medio: MedioPago;
  nota: string | null;
}
export type MedioPago = 'flow' | 'tarjeta' | 'manual';
export type TipoCobro = 'periodo' | 'cambio';
// De fila de BD a Suscripcion. cajas_json puede venir vacío o dañado: en ese caso queda lista vacía.
const mapS = (r: Fila): Suscripcion => ({
  id: r.id, clienteId: r.cliente_id, plan: r.plan, monto: r.monto, estado: r.estado,
  flowToken: r.flow_token ?? null, periodoInicio: r.periodo_inicio ?? null, periodoFin: r.periodo_fin ?? null,
  actualizada: r.updated_at, tipo: r.tipo === 'cambio' ? 'cambio' : 'periodo',
  medio: r.medio === 'tarjeta' || r.medio === 'manual' ? r.medio : 'flow', nota: r.nota ?? null,
  cajas: (() => { try { const a = JSON.parse(r.cajas_json ?? '[]'); return Array.isArray(a) ? a.map(String) : []; } catch { return []; } })(),
});

/** Persistencia del registro autoservicio: cliente (tenant) + suscripciones. */
@Injectable()
export class RegistroRepository {
  constructor(@Inject(SQLITE) readonly db: Database.Database) {}

  // El cliente nace 'pendiente' y pasa a 'activo' recién cuando se confirma el primer pago.
  crearCliente(c: { id: string; negocio: string; rut: string; comuna: string; comunaCut: string | null; region: string | null; direccion: string; email: string; telefono: string; plan: string; now: string }): void {
    this.db.prepare(`INSERT INTO clientes (id,negocio,rut,comuna,comuna_cut,region,direccion,email,telefono,plan,estado,created_at,updated_at)
      VALUES (@id,@negocio,@rut,@comuna,@comunaCut,@region,@direccion,@email,@telefono,@plan,'pendiente',@now,@now)`).run(c);
  }
  cliente(id: string): Fila | undefined {
    return this.db.prepare('SELECT * FROM clientes WHERE id=?').get(id) as Fila | undefined;
  }
  // Pagar es querer seguir: si el plan estaba cancelado, el pago lo deja corriendo de nuevo.
  // El pago de un mes se hace por el plan que corresponde (el actual o el programado), así que acá queda aplicado.
  activarCliente(id: string, plan: string, now: string): void {
    this.db.prepare("UPDATE clientes SET estado='activo', plan=@plan, plan_siguiente=NULL, cancelado_en=NULL, updated_at=@now WHERE id=@id").run({ id, plan, now });
  }
  /** Cambia el plan ya (subida pagada o sin costo). Cualquier cambio programado queda sin efecto. */
  setPlan(id: string, plan: string, now: string): void {
    this.db.prepare('UPDATE clientes SET plan=@plan, plan_siguiente=NULL, updated_at=@now WHERE id=@id').run({ id, plan, now });
  }
  /** Programa (o deshace, con null) el plan que regirá desde la próxima renovación. */
  setPlanSiguiente(id: string, plan: string | null, now: string): void {
    this.db.prepare('UPDATE clientes SET plan_siguiente=@plan, updated_at=@now WHERE id=@id').run({ id, plan, now });
  }
  /** Lo que el negocio ocupa hoy de su cupo: cajas registradas y cajeros activos (para saber si cabe en un plan menor). */
  uso(clienteId: string): { cajas: number; cajeros: number; productos: number } {
    const n = (sql: string) => (this.db.prepare(sql).get(clienteId) as { n: number }).n;
    return {
      cajas: n('SELECT COUNT(*) AS n FROM cajas WHERE cliente_id=?'),
      cajeros: n('SELECT COUNT(*) AS n FROM cajeros WHERE cliente_id=? AND activo=1'),
      productos: n('SELECT COUNT(*) AS n FROM productos WHERE cliente_id=? AND activo=1'), // los archivados no cuentan
    };
  }

  crearSuscripcion(s: { id: string; clienteId: string; plan: string; monto: number; now: string; tipo?: TipoCobro; cajas?: string[]; medio?: MedioPago; nota?: string | null }): void {
    this.db.prepare(`INSERT INTO suscripciones (id,cliente_id,plan,monto,estado,tipo,cajas_json,medio,nota,created_at,updated_at)
      VALUES (@id,@clienteId,@plan,@monto,'pendiente',@tipo,@cajas,@medio,@nota,@now,@now)`)
      .run({ id: s.id, clienteId: s.clienteId, plan: s.plan, monto: s.monto, now: s.now, tipo: s.tipo ?? 'periodo',
        cajas: s.cajas?.length ? JSON.stringify(s.cajas) : null, medio: s.medio ?? 'flow', nota: s.nota ?? null });
  }
  setMedio(id: string, medio: MedioPago): void { this.db.prepare('UPDATE suscripciones SET medio=? WHERE id=?').run(medio, id); }

  // ---- Tarjeta inscrita para el cobro automático ----
  setFlowCustomer(clienteId: string, customerId: string): void {
    this.db.prepare('UPDATE clientes SET flow_customer_id=? WHERE id=?').run(customerId, clienteId);
  }
  clientePorFlowCustomer(customerId: string): Fila | undefined {
    return this.db.prepare('SELECT * FROM clientes WHERE flow_customer_id=?').get(customerId) as Fila | undefined;
  }
  setTarjeta(clienteId: string, t: { marca: string; ultimos4: string } | null, now: string): void {
    this.db.prepare(`UPDATE clientes SET tarjeta_marca=@marca, tarjeta_ultimos4=@ultimos4, tarjeta_desde=@desde,
        cobro_auto_intento=NULL, cobro_auto_error=NULL, updated_at=@now WHERE id=@id`)
      .run({ id: clienteId, marca: t?.marca ?? null, ultimos4: t?.ultimos4 ?? null, desde: t ? now : null, now });
  }
  setIntentoCobro(clienteId: string, now: string, error: string | null): void {
    this.db.prepare('UPDATE clientes SET cobro_auto_intento=?, cobro_auto_error=? WHERE id=?').run(now, error, clienteId);
  }
  /** Pagos en línea que quedaron sin confirmar (Flow no avisó): para revisarlos en la pasada de mantenimiento. */
  pendientesPorConciliar(desde: string, hasta: string): { clienteId: string; tipo: TipoCobro }[] {
    return (this.db.prepare(`SELECT DISTINCT cliente_id, tipo FROM suscripciones
        WHERE estado='pendiente' AND medio<>'manual' AND created_at BETWEEN ? AND ?`).all(desde, hasta) as Fila[])
      .map((r) => ({ clienteId: r.cliente_id, tipo: r.tipo === 'cambio' ? 'cambio' : 'periodo' }));
  }
  /** Cajas adicionales del negocio (las en arriendo), con cuántas cuotas llevan pagadas. */
  cajasAdicionales(clienteId: string): { id: string; nombre: string; cuotasPagadas: number }[] {
    return (this.db.prepare('SELECT id, nombre, cuotas_pagadas FROM cajas WHERE cliente_id=? AND adicional=1 ORDER BY created_at, id')
      .all(clienteId) as Fila[]).map((r) => ({ id: r.id, nombre: r.nombre, cuotasPagadas: r.cuotas_pagadas }));
  }
  /** Al pagarse un mes: suma una cuota a cada caja que iba en ese cobro (sin pasar del total). */
  sumarCuota(ids: string[], total: number): void {
    const st = this.db.prepare('UPDATE cajas SET cuotas_pagadas = cuotas_pagadas + 1 WHERE id=? AND adicional=1 AND cuotas_pagadas < ?');
    for (const id of ids) st.run(id, total);
  }
  porId(id: string): Suscripcion | undefined {
    const r = this.db.prepare('SELECT * FROM suscripciones WHERE id=?').get(id) as Fila | undefined;
    return r ? mapS(r) : undefined;
  }
  // Con esto la confirmación de Flow ubica a qué pago corresponde.
  porToken(token: string): Suscripcion | undefined {
    const r = this.db.prepare('SELECT * FROM suscripciones WHERE flow_token=?').get(token) as Fila | undefined;
    return r ? mapS(r) : undefined;
  }
  // Por tipo: un cobro de cambio de plan a medio pagar no debe confundirse con el pago del mes (ni al revés).
  pendienteDeCliente(clienteId: string, tipo: TipoCobro = 'periodo'): Suscripcion | undefined {
    const r = this.db.prepare("SELECT * FROM suscripciones WHERE cliente_id=? AND estado='pendiente' AND tipo=? ORDER BY created_at DESC LIMIT 1")
      .get(clienteId, tipo) as Fila | undefined;
    return r ? mapS(r) : undefined;
  }
  /** Deja sin efecto los cobros pendientes de un tipo (p. ej. una diferencia de cambio de plan calculada otro día). */
  descartarPendientes(clienteId: string, tipo: TipoCobro, now: string): void {
    this.db.prepare("UPDATE suscripciones SET estado='rechazada', updated_at=? WHERE cliente_id=? AND estado='pendiente' AND tipo=?").run(now, clienteId, tipo);
  }
  setPago(id: string, token: string | null, flowOrder: string | null, now: string): void {
    this.db.prepare('UPDATE suscripciones SET flow_token=@token, flow_order=@flowOrder, updated_at=@now WHERE id=@id')
      .run({ id, token, flowOrder, now });
  }
  marcarPagada(id: string, inicio: string, fin: string, now: string): void {
    this.db.prepare("UPDATE suscripciones SET estado='pagada', periodo_inicio=@inicio, periodo_fin=@fin, updated_at=@now WHERE id=@id")
      .run({ id, inicio, fin, now });
  }
  marcarRechazada(id: string, now: string): void {
    this.db.prepare("UPDATE suscripciones SET estado='rechazada', updated_at=@now WHERE id=@id").run({ id, now });
  }
  /** Pagos del plan ya confirmados, del más nuevo al más antiguo (historial de cobros de "Mi plan"). */
  pagadas(clienteId: string, limite = 24): Suscripcion[] {
    return (this.db.prepare("SELECT * FROM suscripciones WHERE cliente_id=? AND estado='pagada' ORDER BY periodo_fin DESC, updated_at DESC LIMIT ?")
      .all(clienteId, limite) as Fila[]).map(mapS);
  }
}
