// Pasada horaria de mantenimiento: concilia pagos, cobra tarjetas inscritas, borra cuentas vencidas y manda avisos de vencimiento.
import { Inject, Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { fechaCL } from '../../common/util/fecha';
import { DIAS_AVISO_CORREO, DIAS_GRACIA } from '../../common/util/vigencia';
import { UsuariosRepository } from '../auth/usuarios.repository';
import { CorreoService } from '../sync/correo.service';
import { CuentaService } from './cuenta.service';
import { RegistroService } from '../registro/registro.service';

const DIA = 86_400_000;
const CADA_MS = 3_600_000; // una pasada por hora
const DIAS_COBRO_ANTES = 1; // el cobro automático parte un día antes de vencer
const REINTENTO_MS = 20 * 3_600_000; // un intento de cobro automático por día
const diaCorto = (iso: string | number): string => fechaCL(iso).split('-').reverse().join('-');
// Escapa HTML: el nombre del plan y la tarjeta se meten dentro del correo.
const esc = (s: unknown): string => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));

/**
 * Tareas que dependen del calendario y no de una petición: avisar por correo que el plan vence (o venció) y borrar
 * las cuentas cuyo plazo de eliminación se cumplió. Corre dentro de la app: una pasada poco después de arrancar y
 * luego una por hora. Cada aviso se manda una sola vez por período (clientes.aviso_renovacion).
 * ponytail: un setInterval en el proceso; pasarlo a una cola si algún día hay más de un proceso de la app.
 */
@Injectable()
export class MantenimientoService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger('Mantenimiento');
  private relojes: NodeJS.Timeout[] = [];
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly cuenta: CuentaService,
    private readonly usuarios: UsuariosRepository,
    private readonly correo: CorreoService,
    private readonly registro: RegistroService,
  ) {}

  onModuleInit(): void {
    // unref(): estos relojes no deben mantener vivo el proceso (pruebas, apagado).
    this.relojes = [setTimeout(() => void this.ejecutar(), 30_000), setInterval(() => void this.ejecutar(), CADA_MS)];
    this.relojes.forEach((r) => r.unref());
  }
  onModuleDestroy(): void { this.relojes.forEach((r) => clearTimeout(r)); }

  /** Una pasada completa. Nunca lanza: un error queda en el log y se reintenta en la siguiente. */
  async ejecutar(ahoraMs: number = Date.now()): Promise<{ eliminadas: number; avisos: number; conciliados: number; cobros: number }> {
    const r = { eliminadas: 0, avisos: 0, conciliados: 0, cobros: 0 };
    // Cada tarea por separado: si una falla, las demás igual corren.
    const paso = async (nombre: string, fn: () => Promise<number> | number) => {
      try { return await fn(); } catch (e) { this.logger.error(`Falló "${nombre}" en la pasada de mantenimiento: ${(e as Error).message}`); return 0; }
    };
    r.conciliados = await paso('conciliar pagos', () => this.registro.conciliarPendientes(ahoraMs));
    r.cobros = await paso('cobros automáticos', () => this.cobrosAutomaticos(ahoraMs));
    r.eliminadas = await paso('eliminar cuentas', () => this.cuenta.eliminarVencidas(ahoraMs));
    r.avisos = await paso('avisos de vencimiento', () => this.avisarVencimientos(ahoraMs));
    if (r.eliminadas || r.avisos || r.conciliados || r.cobros) {
      this.logger.log(`Pasada: ${r.conciliados} pago(s) conciliado(s), ${r.cobros} cobro(s) automático(s), ${r.eliminadas} cuenta(s) eliminada(s), ${r.avisos} aviso(s)`);
    }
    return r;
  }

  /**
   * Cobro automático: a quien tiene tarjeta inscrita se le cobra el mes siguiente desde 1 día antes de vencer.
   * Si falla, se reintenta una vez al día mientras duren los días de gracia, y se le avisa por correo (una vez).
   * Devuelve cuántos cobros resultaron pagados.
   */
  async cobrosAutomaticos(ahoraMs: number = Date.now()): Promise<number> {
    const filas = this.db.prepare(`SELECT c.id, c.plan, c.aviso_renovacion AS aviso, c.cobro_auto_intento AS intento,
        c.tarjeta_marca AS marca, c.tarjeta_ultimos4 AS ultimos4,
        (SELECT MAX(s.periodo_fin) FROM suscripciones s WHERE s.cliente_id=c.id AND s.estado='pagada') AS fin
      FROM clientes c
      WHERE c.estado='activo' AND c.tarjeta_ultimos4 IS NOT NULL AND c.cancelado_en IS NULL AND c.eliminar_en IS NULL AND c.eliminado_en IS NULL`)
      .all() as { id: string; plan: string; aviso: string | null; intento: string | null; marca: string; ultimos4: string; fin: string | null }[];
    let pagados = 0;
    for (const f of filas) {
      if (!f.fin) continue;
      const fin = Date.parse(f.fin);
      if (ahoraMs < fin - DIAS_COBRO_ANTES * DIA || ahoraMs > fin + DIAS_GRACIA * DIA) continue;
      if (f.intento && ahoraMs - Date.parse(f.intento) < REINTENTO_MS) continue; // un intento por día
      const res = await this.registro.cobrarAutomatico(f.id);
      if (res === 'pagado') { pagados++; continue; }
      if ((res === 'rechazado' || res === 'error') && f.aviso !== `${f.fin}|fallo` && f.aviso !== `${f.fin}|vencido`) {
        const dueno = this.usuarios.duenosDeCliente(f.id)[0];
        if (!dueno?.email) continue;
        await this.correo.enviarAviso(String(dueno.email), 'No pudimos cobrar tu plan Walkan',
          this.cuenta.plantilla('No pudimos cobrar tu plan',
            `Intentamos cobrar tu plan <b>${esc(f.plan)}</b> a tu tarjeta ${esc(f.marca)} terminada en <b>${esc(f.ultimos4)}</b> y no se pudo. Lo intentaremos de nuevo mañana. También puedes pagar ahora desde tu panel o cambiar la tarjeta.`,
            'Ir a Mi plan', '/panel#plan'));
        this.db.prepare('UPDATE clientes SET aviso_renovacion=? WHERE id=?').run(`${f.fin}|fallo`, f.id);
      }
    }
    return pagados;
  }

  /** Correo al dueño DIAS_AVISO_CORREO días antes de vencer ("previo") y otro al vencer ("vencido", ya en días de gracia). */
  async avisarVencimientos(ahoraMs: number = Date.now()): Promise<number> {
    const filas = this.db.prepare(`SELECT c.id, c.plan, c.aviso_renovacion AS aviso, c.tarjeta_marca AS marca, c.tarjeta_ultimos4 AS ultimos4,
        (SELECT MAX(s.periodo_fin) FROM suscripciones s WHERE s.cliente_id=c.id AND s.estado='pagada') AS fin
      FROM clientes c
      WHERE c.estado='activo' AND c.cancelado_en IS NULL AND c.eliminar_en IS NULL AND c.eliminado_en IS NULL`)
      .all() as { id: string; plan: string; aviso: string | null; marca: string | null; ultimos4: string | null; fin: string | null }[];
    let enviados = 0;
    for (const f of filas) {
      if (!f.fin) continue; // cuenta sin pagos en línea: no vence
      const resta = Date.parse(f.fin) - ahoraMs;
      const tipo = resta > 0 && resta <= DIAS_AVISO_CORREO * DIA ? 'previo' : resta <= 0 && resta > -DIAS_GRACIA * DIA ? 'vencido' : null;
      if (!tipo) continue;
      // Ya avisado para este período (y si ya salió el de "vencido", no se manda después el "previo").
      if (f.aviso === `${f.fin}|${tipo}` || f.aviso === `${f.fin}|vencido`) continue;
      // Con tarjeta inscrita, el aviso previo informa el cobro automático en vez de pedir que pague.
      if (tipo === 'previo' && f.ultimos4) {
        const dueno = this.usuarios.duenosDeCliente(f.id)[0];
        if (!dueno?.email) continue;
        const monto = this.registro.miPlan(f.id).montoRenovacion;
        await this.correo.enviarAviso(String(dueno.email), `Renovaremos tu plan Walkan el ${diaCorto(Date.parse(f.fin) - DIAS_COBRO_ANTES * DIA)}`,
          this.cuenta.plantilla('Tu plan se renueva solo',
            `Tu plan <b>${esc(f.plan)}</b> vence el <b>${diaCorto(f.fin)}</b>. Un día antes cobraremos <b>$${monto.toLocaleString('es-CL')}</b> a tu tarjeta ${esc(f.marca)} terminada en <b>${esc(f.ultimos4)}</b>. Si quieres cambiar la tarjeta o cancelar, hazlo desde tu panel.`,
            'Ver Mi plan', '/panel#plan'));
        this.db.prepare('UPDATE clientes SET aviso_renovacion=? WHERE id=?').run(`${f.fin}|previo`, f.id);
        enviados++;
        continue;
      }
      const dueno = this.usuarios.duenosDeCliente(f.id)[0];
      if (!dueno?.email) continue;
      const pausa = diaCorto(Date.parse(f.fin) + DIAS_GRACIA * DIA);
      const [asunto, titulo, texto] = tipo === 'previo'
        ? [`Tu plan Walkan vence el ${diaCorto(f.fin)}`, 'Tu plan está por vencer',
          `Tu plan <b>${esc(f.plan)}</b> vence el <b>${diaCorto(f.fin)}</b>. Paga la renovación desde tu panel para seguir sin interrupciones. Si prefieres no continuar, ahí mismo puedes cancelar el plan.`]
        : [`Tu plan Walkan venció: paga antes del ${pausa}`, 'Tu plan venció',
          `Tu plan <b>${esc(f.plan)}</b> venció el <b>${diaCorto(f.fin)}</b>. Tu panel sigue funcionando hasta el <b>${pausa}</b>; después queda en pausa hasta que pagues la renovación. Tu caja sigue vendiendo en el local y sus ventas se sincronizan al reactivar.`];
      await this.correo.enviarAviso(String(dueno.email), asunto, this.cuenta.plantilla(titulo, texto, 'Pagar la renovación', '/panel#plan'));
      this.db.prepare('UPDATE clientes SET aviso_renovacion=? WHERE id=?').run(`${f.fin}|${tipo}`, f.id);
      enviados++;
    }
    return enviados;
  }
}
