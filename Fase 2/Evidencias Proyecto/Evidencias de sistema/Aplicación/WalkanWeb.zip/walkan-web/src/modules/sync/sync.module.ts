// Módulo de sync: junta todo lo que habla con la caja (sync, catálogo, cajas, cajeros, cobros, correo y Flow QR).
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { CatalogoModule } from '../catalogo/catalogo.module';
import { SyncController, CatalogoCajaController } from './sync.controller';
import { CajasController } from './cajas.controller';
import { CajasRegistroController } from './cajas-registro.controller';
import { VentasController } from './ventas.controller';
import { CajerosController } from './cajeros.controller';
import { CajerosService } from './cajeros.service';
import { CobrosController } from './cobros.controller';
import { CobrosService } from './cobros.service';
import { CorreoService } from './correo.service';
import { FlowNegocioService } from './flow-negocio.service';
import { FlowNegocioController, CobroQrCajaController, FlowRetornoController } from './flow-negocio.controller';
import { SyncService } from './sync.service';
import { CajasRepository } from './cajas.repository';
import { VentasRepository } from './ventas.repository';

// Todo lo que conversa con la caja: registro, envío de ventas y su gestión desde el panel.
@Module({
  imports: [AuthModule, CatalogoModule],
  controllers: [SyncController, CatalogoCajaController, CajasController, CajasRegistroController, VentasController, CajerosController, CobrosController, FlowNegocioController, CobroQrCajaController, FlowRetornoController],
  providers: [SyncService, CajasRepository, VentasRepository, CajerosService, CobrosService, CorreoService, FlowNegocioService],
  exports: [SyncService, CorreoService], // CorreoService: los avisos del plan (módulo cuenta) salen por el mismo SMTP
})
export class SyncModule {}
