// Lógica del catálogo de productos: crear, editar, archivar, importar, cambiar precios y mover stock vía StockService.
import { BadRequestException, ConflictException, HttpException, Inject, Injectable, Logger, NotFoundException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { ahora, nuevoId } from '../../common/util/id';
import { ProductosRepository } from './productos.repository';
import { ProveedoresRepository } from './proveedores.repository';
import { StockService } from './stock.service';
import { LimitesPlan } from './limites-plan.service';
import { VentasPendientesService } from './ventas-pendientes.service';
import { Producto } from './tipos';
import { PrecioCambioDto, ProductoDto } from './dto/producto.dto';
import { verificadorEan } from '../../common/util/balanza';

export { verificadorEan }; // la usa scripts/check-lotes.js

// Catálogo del negocio logueado. Los datos del producto se editan acá, pero cualquier
// cambio de stock se delega a StockService para que quede en el kardex.
@Injectable()
export class ProductosService {
  private readonly log = new Logger('ProductosService');
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly repo: ProductosRepository,
    private readonly proveedores: ProveedoresRepository,
    private readonly stock: StockService,
    private readonly ctx: ContextoTenant,
    private readonly limites: LimitesPlan,
    private readonly pendientes: VentasPendientesService,
  ) {}

  listar(): Producto[] { return this.conValor(this.repo.listar()); }

  obtener(id: string): Producto {
    const p = this.repo.obtener(id);
    if (!p) throw new NotFoundException('Producto no encontrado.');
    return this.conValor([p], id)[0];
  }

  // Valor a costo del stock por FIFO (PEPS, aceptado por el SII): las unidades que quedan son las de las
  // últimas entradas, cada una a lo que costó. Así una alza de precio no revaloriza lo comprado antes.
  // Lo que el kardex no explica (stock anterior al kardex, devoluciones de caja) va al costo actual.
  private conValor(ps: Producto[], id?: string): Producto[] {
    const capas = new Map((this.stock.valorFifo(this.ctx.clienteId, id) as { pid: string; valor: number; entradas: number }[]).map((r) => [r.pid, r]));
    return ps.map((p) => {
      const c = capas.get(p.id), q = Math.max(p.stock, 0);
      return { ...p, valorCosto: q ? (c?.valor ?? 0) + Math.max(0, q - (c?.entradas ?? 0)) * (p.costo || 0) : 0 };
    });
  }

  // Pan, fruta y verdura no traen código de barras, pero la caja vende por código. Como en Odoo o Square,
  // si no traen SKU se les da uno interno: EAN-13 con prefijo GS1 20 (circulación restringida, ningún
  // producto del comercio lo usa) + correlativo del negocio, así se imprime en la etiqueta y se escanea.
  // Sin await entre esto y el INSERT/UPDATE, dos altas no pueden sacar el mismo número.
  private codigoInterno(): string {
    const cid = this.ctx.clienteId;
    const r = this.db.prepare(`SELECT MAX(CAST(substr(c,3,10) AS INTEGER)) AS n FROM (
        SELECT sku AS c FROM productos WHERE cliente_id=? UNION ALL SELECT sku_archivado FROM productos WHERE cliente_id=?)
      WHERE c GLOB '20[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'`).get(cid, cid) as { n: number | null };
    const n = (r.n ?? 0) + 1;
    if (n > 9_999_999_999) throw new BadRequestException('No quedan códigos internos: escribe un SKU a mano.');
    const d12 = '20' + String(n).padStart(10, '0');
    return d12 + verificadorEan(d12);
  }

  // Código de balanza para lo que va por kg: el siguiente libre del negocio (la balanza lo imprime dentro del código).
  private siguientePlu(): number {
    const r = this.db.prepare('SELECT MAX(plu) AS n FROM productos WHERE cliente_id=?').get(this.ctx.clienteId) as { n: number | null };
    const n = (r.n ?? 0) + 1;
    if (n > 99_999) throw new BadRequestException('No quedan códigos de balanza: indica uno a mano.');
    return n;
  }

  /** Campos editables (sin stock). Valida que el proveedor sea del mismo negocio. */
  private campos(dto: ProductoDto, p?: Producto) {
    const prov = dto.prov || null;
    if (prov && !this.proveedores.obtener(prov)) throw new BadRequestException('Ese proveedor ya no existe (se eliminó o se cambió de cuenta en otra pestaña). Recarga la página.');
    return {
      nombre: dto.nombre.trim(),
      // Al editar, un SKU borrado no se reemplaza: perder el código real rompería las ventas de la caja.
      sku: dto.sku?.trim() || p?.sku || this.codigoInterno(),
      categoria: dto.cat || 'General',
      precio: dto.precio ?? 0,
      costo: dto.costo ?? 0,
      stock_minimo: dto.stockMin ?? null,
      controla_vence: (dto.controlaVence ?? p?.controlaVence) ? 1 : 0,
      unidad: dto.unidad ?? p?.unidad ?? 'un',
      plu: (dto.unidad ?? p?.unidad) === 'kg' ? (dto.plu ?? p?.plu ?? this.siguientePlu()) : null,
      vida_util_dias: dto.vidaUtil === undefined ? (p?.vidaUtil ?? null) : dto.vidaUtil,
      proveedor_id: prov,
      emoji: dto.emoji || p?.emoji || '📦',
      ...this.imagen(dto.img, !!p),
    };
  }

  // La imagen llega como data URL (subida nueva), como la URL /api/productos/:id/img (sin cambios: se conserva) o vacía (se quita).
  // Solo se aceptan JPEG, PNG y WebP: así /img nunca sirve HTML ni SVG con scripts.
  private imagen(img: string | undefined, editando: boolean): { img: string | null; mantenerImg?: number } {
    if (editando && (img === undefined || img.startsWith('/api/productos/'))) return { img: null, mantenerImg: 1 };
    if (!img || img.startsWith('/api/productos/')) return { img: null };
    if (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(img)) throw new BadRequestException('La imagen debe ser JPEG, PNG o WebP.');
    return { img };
  }

  // El SKU es único por negocio en la BD; acá se traduce ese error de SQLite a un 409 entendible.
  private guardar(fn: () => void): void {
    try { fn(); } catch (e: any) {
      if (e?.code === 'SQLITE_CONSTRAINT_UNIQUE') {
        throw new ConflictException(String(e.message).includes('plu') ? 'Ya existe un producto con ese código de balanza.' : 'Ya existe un producto con ese SKU.');
      }
      throw e;
    }
  }

  crear(dto: ProductoDto): Producto {
    this.limites.exigirCupoProductos(); // cupo del plan (configuracion.ts → productos); también vale para importar
    const now = ahora();
    const id = nuevoId();
    const c = this.campos(dto);
    // Producto + movimiento inicial en la misma transacción, para no dejar un producto sin su stock.
    this.guardar(() => this.db.transaction(() => {
      this.repo.crear({ id, ...c, createdAt: now, updatedAt: now });
      if (dto.stock) {
        this.stock.mover({ clienteId: this.ctx.clienteId, productoId: id, tipo: 'inicial', cantidad: dto.stock, costoUnit: c.costo, vence: dto.vence, lote: dto.lote });
      }
      // Lo que la caja ya vendió con este código antes de que existiera el producto se descuenta ahora (B1/I2).
      this.pendientes.aplicarSku(this.ctx.clienteId, c.sku, id, this.ctx.userId);
    })());
    return this.obtener(id);
  }

  /** El stock NO se edita aquí: se cambia con ajustar() para que quede registro. */
  actualizar(id: string, dto: ProductoDto): Producto {
    const p = this.obtener(id);
    const c = this.campos(dto, p);
    this.guardar(() => this.db.transaction(() => {
      this.repo.actualizar({ id, ...c, updatedAt: ahora() });
      // Corregir el SKU para que calce con lo que vende la caja aplica sus ventas pendientes (B1).
      this.pendientes.aplicarSku(this.ctx.clienteId, c.sku, id, this.ctx.userId);
    })());
    this.stock.invalidarValor(this.ctx.clienteId, id); // el costo puede valorizar capas sin costo
    return this.obtener(id);
  }

  /** Con historial se archiva (no se pierde el kardex); sin historial se borra. */
  eliminar(id: string): { ok: boolean; archivado: boolean } {
    this.obtener(id);
    const archivar = this.stock.tieneMovimientos(this.ctx.clienteId, id);
    if (archivar) this.repo.archivar(id, ahora()); else this.repo.eliminar(id);
    this.stock.invalidarValor(this.ctx.clienteId, id);
    return { ok: true, archivado: archivar };
  }

  archivados() { return this.repo.archivados(); }
  restaurar(id: string) {
    this.limites.exigirCupoProductos(); // restaurar vuelve a sumar un producto activo
    const r = this.repo.restaurar(id, ahora());
    this.stock.invalidarValor(this.ctx.clienteId, id);
    if (!r.ok) throw new NotFoundException('Producto archivado no encontrado.');
    if (r.skuRecuperado) this.pendientes.aplicarSku(this.ctx.clienteId, this.repo.obtener(id)?.sku, id, this.ctx.userId);
    return { producto: this.obtener(id), skuRecuperado: r.skuRecuperado, skuTomado: r.skuTomado };
  }

  ajustar(id: string, cantidad: number, motivo: string, vence?: string, lote?: string): Producto {
    // El costo queda en el kardex: así una merma de hoy no se revaloriza si el costo cambia mañana. Lo que sale
    // lo costea StockService por FIFO; lo que aparece (conteo con más) entra al costo actual.
    const { costo } = this.obtener(id);
    this.stock.mover({ clienteId: this.ctx.clienteId, productoId: id, tipo: 'ajuste', cantidad, costoUnit: cantidad > 0 ? costo : null, motivo: motivo.trim(), vence, lote });
    return this.obtener(id);
  }

  // Ingreso rápido desde la ficha del producto; cuenta como 'compra' y actualiza el costo si viene.
  ingresarStock(id: string, cantidad: number, costo?: number, vence?: string, lote?: string): Producto {
    this.obtener(id);
    this.stock.mover({ clienteId: this.ctx.clienteId, productoId: id, tipo: 'compra', cantidad, costoUnit: costo ?? null, vence, lote });
    return this.obtener(id);
  }

  movimientos(id: string) {
    this.obtener(id);
    return this.stock.movimientos(this.ctx.clienteId, id);
  }

  lotes(id: string) {
    this.obtener(id);
    return this.stock.lotes(this.ctx.clienteId, id);
  }

  imagenDe(id: string): string | undefined { return this.repo.imagen(id); }

  /** Último costo pagado a cada proveedor por este producto (el más barato primero). */
  costosProveedor(id: string) {
    this.obtener(id);
    return this.stock.costosPorProveedor(this.ctx.clienteId, id);
  }

  /**
   * Importar CSV en una sola request. Cada fila va en su propio savepoint: una fila mala (SKU repetido,
   * proveedor que no existe) no tumba las demás. Devuelve el resultado por fila, en el mismo orden.
   */
  importar(dtos: ProductoDto[]): { ok: boolean; error?: string; id?: string }[] {
    return this.db.transaction(() => dtos.map((dto) => {
      try { return { ok: true, id: this.crear(dto).id }; } catch (e: any) {
        // Solo los errores pensados para el usuario (HttpException); un error interno no se muestra tal cual.
        if (e instanceof HttpException) return { ok: false, error: e.message };
        this.log.error(`Importar: ${e?.message}`);
        return { ok: false, error: 'Error al crear la fila' };
      }
    }))();
  }

  /** Precios en bloque (％ Precios): todo o nada. Cada cambio queda en el historial por el trigger. */
  cambiarPrecios(cambios: PrecioCambioDto[]): { ok: boolean; cambiados: number } {
    const upd = this.db.prepare('UPDATE productos SET precio=?, updated_at=? WHERE id=? AND cliente_id=? AND activo=1');
    const now = ahora();
    const n = this.db.transaction(() => cambios.reduce((s, c) => s + upd.run(c.precio, now, c.id, this.ctx.clienteId).changes, 0))();
    return { ok: true, cambiados: n };
  }

  /** Últimos 30 cambios de precio o costo (los registra un trigger, ver migración 011), del más nuevo al más viejo. */
  precios(id: string) {
    this.obtener(id);
    return this.db.prepare(`SELECT precio, costo, fecha FROM precios_historial
      WHERE cliente_id=? AND producto_id=? ORDER BY id DESC LIMIT 30`).all(this.ctx.clienteId, id);
  }
}
