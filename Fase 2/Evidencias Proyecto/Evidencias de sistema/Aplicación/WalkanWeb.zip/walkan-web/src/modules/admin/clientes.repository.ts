// Acceso a la tabla clientes (los negocios que usan Walkan): alta, listado, estado y plan.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';

type Fila = Record<string, any>;
// Pasa la fila de la base (snake_case) al objeto que usa el resto del código.
const map = (r: Fila) => ({
  id: r.id, negocio: r.negocio, rut: r.rut ?? '', comuna: r.comuna ?? '',
  comunaCut: r.comuna_cut ?? '', region: r.region ?? '', direccion: r.direccion ?? '',
  email: r.email ?? '', telefono: r.telefono ?? '', plan: r.plan, planSiguiente: r.plan_siguiente ?? null, estado: r.estado,
  creado: r.created_at,
});

// clientes = tenants. Tabla administrada por el staff Walkan (no se filtra por tenant).
// Solo se debería usar detrás de StaffGuard, porque acá cualquiera vería todas las tiendas.
@Injectable()
export class ClientesRepository {
  private ins!: Database.Statement;
  private list!: Database.Statement;
  private byId!: Database.Statement;
  private stEstado!: Database.Statement;
  private count!: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this.ins = db.prepare(`INSERT INTO clientes (id,negocio,rut,comuna,comuna_cut,region,direccion,email,telefono,plan,estado,created_at,updated_at)
      VALUES (@id,@negocio,@rut,@comuna,@comunaCut,@region,@direccion,@email,@telefono,@plan,@estado,@createdAt,@updatedAt)`);
    // Sin las cuentas eliminadas por su dueño: de ellas queda una fila vacía solo para el registro de pagos.
    this.list = db.prepare('SELECT * FROM clientes WHERE eliminado_en IS NULL ORDER BY created_at DESC');
    this.byId = db.prepare('SELECT * FROM clientes WHERE id=?');
    this.stEstado = db.prepare('UPDATE clientes SET estado=@estado, updated_at=@now WHERE id=@id');
    this.count = db.prepare('SELECT COUNT(*) AS n FROM clientes WHERE eliminado_en IS NULL');
  }
  crear(c: any): void { this.ins.run(c); }
  listar() { return (this.list.all() as Fila[]).map(map); }
  obtener(id: string) { const r = this.byId.get(id) as Fila | undefined; return r ? map(r) : undefined; }
  setEstado(id: string, estado: string, now: string): void { this.stEstado.run({ id, estado, now }); }
  /** El staff fija el plan de un negocio; un cambio que el dueño tuviera programado queda sin efecto. */
  setPlan(id: string, plan: string, now: string): void {
    this.db.prepare('UPDATE clientes SET plan=@plan, plan_siguiente=NULL, updated_at=@now WHERE id=@id').run({ id, plan, now });
  }
  total(): number { return (this.count.get() as Fila).n as number; }
}
