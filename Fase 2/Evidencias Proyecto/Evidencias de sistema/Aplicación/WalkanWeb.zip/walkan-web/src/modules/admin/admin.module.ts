// Módulo del panel admin: junta el controlador, los guards del staff y los servicios de clientes, equipo y bitácora.
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { SolicitudesModule } from '../solicitudes/solicitudes.module';
import { SyncModule } from '../sync/sync.module';
import { RegistroModule } from '../registro/registro.module';
import { RecuperacionModule } from '../recuperacion/recuperacion.module';
import { SoporteModule } from '../soporte/soporte.module';
import { SoporteAdminController } from './soporte-admin.controller';
import { AdminController } from './admin.controller';
import { ClientesRepository } from './clientes.repository';
import { ClientesService } from './clientes.service';
import { StaffGuard } from './staff.guard';
import { SuperAdminGuard } from './super-admin.guard';
import { EquipoService } from './equipo.service';
import { BitacoraService } from './bitacora.service';

// Panel del equipo Walkan. Importa solicitudes y sync porque desde acá se ven las altas y las cajas de cada cliente.
@Module({
  imports: [AuthModule, SolicitudesModule, SyncModule, RegistroModule, RecuperacionModule, SoporteModule],
  controllers: [AdminController, SoporteAdminController],
  providers: [ClientesRepository, ClientesService, StaffGuard, SuperAdminGuard, EquipoService, BitacoraService],
})
export class AdminModule {}
