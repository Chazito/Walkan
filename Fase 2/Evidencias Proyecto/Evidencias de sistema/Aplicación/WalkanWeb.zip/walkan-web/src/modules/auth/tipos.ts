// Usuario ya sin el hash de la clave. clienteId null = staff de Walkan (no pertenece a ningún negocio).
export interface Usuario {
  id: string;
  email: string;
  nombre: string;
  negocio: string | null;
  rol: string;
  clienteId: string | null;
  /** Verificación en dos pasos (app de códigos) activa. */
  dosPasos?: boolean;
  /** Staff que además administra al equipo Walkan (crea y desactiva cuentas, ve la bitácora). */
  superAdmin?: boolean;
}
