// Gestión de las cuentas del equipo Walkan (staff): crear, desactivar, nivel de super admin y restablecer acceso.
import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { ahora } from '../../common/util/id';
import { AuthService } from '../auth/auth.service';
import { UsuariosRepository } from '../auth/usuarios.repository';
import { Actor, BitacoraService } from './bitacora.service';
import { RecuperacionService } from '../recuperacion/recuperacion.service';

/** Las cuentas del equipo usan el correo de la empresa: cada persona con el suyo, nada de cuentas personales. */
export const DOMINIO_EQUIPO = 'walkan.cl';

// Cuentas del equipo Walkan (rol 'staff'). Solo un super admin llega acá (SuperAdminGuard).
// Reglas: nadie se desactiva ni se quita el super admin a sí mismo, y siempre queda al menos un super admin activo.
@Injectable()
export class EquipoService {
  private readonly logger = new Logger('Equipo');
  constructor(
    private readonly usuarios: UsuariosRepository,
    private readonly auth: AuthService,
    private readonly bitacora: BitacoraService,
    private readonly acceso: RecuperacionService,
  ) {}

  listar() {
    return this.usuarios.listarStaff().map((r) => ({
      id: r.id, email: r.email, nombre: r.nombre, superAdmin: !!r.super_admin, activo: !r.desactivado_en,
      desactivadoEn: r.desactivado_en ?? null, invitacionPendiente: !!r.clave_pendiente, dosPasos: !!r.dos_pasos, creado: r.created_at, ultimoUso: r.ultimo_uso ?? null,
    }));
  }

  /** Crea una cuenta del equipo y le manda por correo el enlace para crear su contraseña (nadie ve una clave
   *  temporal). Al entrar debe activar los dos pasos. */
  async crear(actor: Actor, dto: { email: string; nombre: string; superAdmin?: boolean }) {
    const email = String(dto.email).toLowerCase().trim();
    if (!email.endsWith('@' + DOMINIO_EQUIPO)) throw new BadRequestException(`Usa el correo de la empresa (@${DOMINIO_EQUIPO}).`);
    const u = this.auth.crearUsuario({ email, nombre: dto.nombre.trim(), rol: 'staff', clienteId: null });
    if (dto.superAdmin) this.usuarios.setSuperAdmin(u.id, true, ahora());
    this.bitacora.registrar(actor, 'Creó cuenta del equipo', `${email}${dto.superAdmin ? ' (super admin)' : ''}`);
    this.logger.log(`Cuenta del equipo creada: ${u.id} por ${actor.email}`);
    const envio = await this.acceso.enviarAcceso(u.id, 'invitacion');
    return { email, nombre: u.nombre, superAdmin: !!dto.superAdmin, envio };
  }

  /** Vuelve a mandar la invitación a quien aún no crea su contraseña (el enlace anterior deja de servir). */
  async reenviar(actor: Actor, id: string) {
    const r = this.staff(id);
    if (r.desactivado_en) throw new BadRequestException('La cuenta está desactivada. Reactívala primero.');
    if (!r.clave_pendiente) throw new BadRequestException('Esta persona ya creó su contraseña. Usa "Restablecer acceso" si la perdió.');
    const envio = await this.acceso.enviarAcceso(id, 'invitacion');
    this.bitacora.registrar(actor, 'Reenvió invitación', r.email);
    return { email: r.email, envio };
  }

  private staff(id: string) {
    const r = this.usuarios.porId(id);
    if (!r || r.rol !== 'staff') throw new NotFoundException('Cuenta del equipo no encontrada.');
    return r;
  }
  private noASiMismo(actor: Actor, id: string, que: string) {
    if (actor.id === id) throw new ForbiddenException(`No puedes ${que} tu propia cuenta. Pídeselo a otro super admin.`);
  }
  private quedaOtroSuper(r: Record<string, any>) {
    if (r.super_admin && !r.desactivado_en && this.usuarios.superAdminsActivos() <= 1) {
      throw new ForbiddenException('Debe quedar al menos un super admin activo. Nombra a otro antes.');
    }
  }

  desactivar(actor: Actor, id: string) {
    this.noASiMismo(actor, id, 'desactivar');
    const r = this.staff(id);
    if (r.desactivado_en) return { ok: true };
    this.quedaOtroSuper(r);
    const now = ahora();
    this.usuarios.setDesactivado(id, now, now);
    this.auth.cerrarOtrasSesiones(id);        // sale de inmediato de todos sus dispositivos
    this.usuarios.cerrarRecuperaciones(id, now); // y un enlace de recuperación pendiente deja de servir
    this.bitacora.registrar(actor, 'Desactivó cuenta del equipo', r.email);
    return { ok: true };
  }

  reactivar(actor: Actor, id: string) {
    const r = this.staff(id);
    if (!r.desactivado_en) return { ok: true };
    this.usuarios.setDesactivado(id, null, ahora());
    this.bitacora.registrar(actor, 'Reactivó cuenta del equipo', r.email);
    return { ok: true };
  }

  setSuperAdmin(actor: Actor, id: string, si: boolean) {
    this.noASiMismo(actor, id, 'cambiar el nivel de');
    const r = this.staff(id);
    if (!!r.super_admin === si) return { ok: true };
    if (!si) this.quedaOtroSuper(r);
    if (si && r.desactivado_en) throw new BadRequestException('Reactiva la cuenta antes de nombrarla super admin.');
    this.usuarios.setSuperAdmin(id, si, ahora());
    this.bitacora.registrar(actor, si ? 'Nombró super admin' : 'Quitó super admin', r.email);
    return { ok: true };
  }

  /** Para quien perdió la clave o el celular: su contraseña deja de servir, se borra su verificación en dos pasos
   *  (la vuelve a configurar al entrar), se cierran sus sesiones y le llega un enlace para crear una clave nueva. */
  async restablecer(actor: Actor, id: string) {
    this.noASiMismo(actor, id, 'restablecer');
    const r = this.staff(id);
    if (r.desactivado_en) throw new BadRequestException('La cuenta está desactivada. Reactívala primero.');
    this.auth.anularPassword(id); // también cierra sus sesiones
    this.usuarios.desactivarTotp(id, ahora());
    this.bitacora.registrar(actor, 'Restableció clave y dos pasos', r.email);
    const envio = await this.acceso.enviarAcceso(id, 'restablecer');
    return { email: r.email, envio };
  }
}
