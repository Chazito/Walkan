// Endpoint público para dar de alta una caja nueva (api/cajas/registrar).
import { Body, Controller, Ip, Post } from '@nestjs/common';
import { SyncService } from './sync.service';
import { RegistroCajaDto } from './dto/registro-caja.dto';
import { Limite } from '../../common/limite';

// Enrolamiento de una caja nueva. SIN sesión: la caja es un dispositivo recién
// encendido que se autentica con las credenciales de la cuenta del dueño.
@Controller('api/cajas')
export class CajasRegistroController {
  constructor(private readonly srv: SyncService) {}

  // La caja manda correo y clave del dueño, más el nombre con que quiere quedar. Tope bajo por IP.
  @Post('registrar')
  @Limite(10)
  registrar(@Body() b: RegistroCajaDto, @Ip() ip: string) {
    return this.srv.registrarCaja(b.email, b.password, b.nombre, ip);
  }
}
