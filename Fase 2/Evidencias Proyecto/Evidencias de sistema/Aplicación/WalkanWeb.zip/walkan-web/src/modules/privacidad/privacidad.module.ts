// Módulo de privacidad: arma el controller, el servicio y el repositorio de consentimientos.
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { StaffGuard } from '../admin/staff.guard';
import { ConsentimientosRepository } from './consentimientos.repository';
import { PrivacidadController } from './privacidad.controller';
import { PrivacidadService } from './privacidad.service';

// Consentimientos (Ley 21.719) y página de política de privacidad. Exporta el servicio porque el
// registro y el formulario de contacto guardan el consentimiento en el mismo momento del alta.
@Module({
  imports: [AuthModule],
  controllers: [PrivacidadController],
  providers: [ConsentimientosRepository, PrivacidadService, StaffGuard],
  exports: [PrivacidadService],
})
export class PrivacidadModule {}
