// Guard de sesión del panel (SesionGuard) y las opciones de las cookies de sesión y de dispositivo recordado.
import { CanActivate, ExecutionContext, ForbiddenException, Injectable, UnauthorizedException } from '@nestjs/common';
import { ContextoTenant } from '../../common/contexto-tenant';
import { permitidaEnPausa } from '../../common/util/vigencia';
import { AuthService } from './auth.service';
import { dosPasosObligatorio } from './dos-pasos.service';

export const COOKIE_SESION = 'walkan_sesion';

/** Cookie de "Recordar este dispositivo" (solo la lee el login). */
export const COOKIE_DISPOSITIVO = 'walkan_disp';
export function opcionesCookieDispositivo() {
  return {
    signed: true, httpOnly: true, sameSite: 'lax' as const, path: '/api/auth',
    secure: (process.env.APP_URL || '').startsWith('https://'), maxAge: 30 * 24 * 3600,
  };
}

/** Opciones de la cookie de sesión (la usan el login y la renovación automática). */
export function opcionesCookie(recordar: boolean) {
  return {
    signed: true, httpOnly: true, sameSite: 'lax' as const, path: '/',
    secure: (process.env.APP_URL || '').startsWith('https://'),
    ...(recordar ? { maxAge: 30 * 24 * 3600 } : {}),
  };
}

// Guard de las rutas del panel. La cookie va firmada con SESSION_SECRET y solo trae el id del
// usuario; si alguien la edita a mano, unsignCookie la marca inválida y chao.
@Injectable()
export class SesionGuard implements CanActivate {
  constructor(private readonly auth: AuthService, private readonly ctx: ContextoTenant) {}

  canActivate(ctx: ExecutionContext): boolean {
    const req: any = ctx.switchToHttp().getRequest();
    const raw = req.cookies?.[COOKIE_SESION];
    if (!raw) throw new UnauthorizedException('Sesión requerida.');
    const un = req.unsignCookie(raw);
    if (!un.valid || !un.value) throw new UnauthorizedException('Sesión inválida.');
    // Se vuelve a buscar en la BD cada vez: si borran al usuario, cambia su clave o cierra sesión,
    // la cookie vieja muere al tiro (la cookie trae id + versión de sesión).
    const usuario = this.auth.usuarioDeSesion(un.value);
    if (!usuario) throw new UnauthorizedException('Sesión inválida.');
    // Sesión con "Recordarme" renovada: se reenvía la cookie para que dure otros 30 días.
    if (usuario.renovada) ctx.switchToHttp().getResponse().setCookie(COOKIE_SESION, un.value, opcionesCookie(true));
    req.sesionId = un.value;
    const vigencia = this.auth.verificarCuentaActiva(usuario); // 403 si el negocio está suspendido
    // Plan vencido (pasados los días de gracia) o cuenta cerrada: la sesión sirve solo para Mi cuenta
    // (pagar la renovación, descargar los datos, recuperar o eliminar la cuenta). El resto del panel queda en pausa.
    if (vigencia && !vigencia.operativa && !permitidaEnPausa(req.routeOptions?.url)) {
      throw new ForbiddenException(vigencia.situacion === 'cerrada'
        ? 'Tu cuenta está cerrada. Puedes recuperarla desde Mi cuenta.'
        : 'Tu plan está vencido: paga la renovación en Mi cuenta para reactivar el panel.');
    }
    // Equipo Walkan sin la verificación en dos pasos configurada: la sesión sirve solo para configurarla
    // (/api/auth/*). El resto del panel del staff (clientes, pagos, planes) queda cerrado hasta activarla.
    if (dosPasosObligatorio(usuario.rol) && !usuario.dosPasos) {
      if (!String(req.routeOptions?.url ?? '').startsWith('/api/auth/')) {
        throw new ForbiddenException('Activa la verificación en dos pasos para usar el panel del equipo Walkan.');
      }
      req.debeActivarDosPasos = true;
    }
    req.vigencia = vigencia ?? null;
    req.usuario = usuario;
    // Puebla el contexto de tenant para toda la request (repos filtran por cliente_id).
    this.ctx.set({ userId: usuario.id, clienteId: usuario.clienteId, rol: usuario.rol });
    return true;
  }
}
