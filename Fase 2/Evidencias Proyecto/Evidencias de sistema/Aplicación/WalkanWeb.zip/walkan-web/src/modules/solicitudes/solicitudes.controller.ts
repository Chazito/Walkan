// Rutas públicas de solicitudes: formulario de contacto, webhook de Flow y página de gracias.
import { Body, Controller, Get, Header, Post, Req } from '@nestjs/common';
import { meta } from '../privacidad/privacidad.controller';
import { SolicitudesService } from './solicitudes.service';
import { CrearSolicitudDto } from './dto/crear-solicitud.dto';
import { Limite } from '../../common/limite';

// Rutas públicas del flujo de alta: el formulario crea la solicitud y Flow avisa cuando se paga.
@Controller()
export class SolicitudesController {
  constructor(private readonly srv: SolicitudesService) {}

  // Formulario de contacto del sitio: deja la solicitud y el consentimiento del que escribe.
  @Post('api/solicitudes')
  @Limite(5)
  crear(@Body() dto: CrearSolicitudDto, @Req() req: any) { return this.srv.crear(dto, meta(req)); }

  // Listar / avanzar / descartar solicitudes es solo del staff: ver /api/admin/solicitudes
  // (protegido con StaffGuard). Aquí quedan públicos solo el formulario y el webhook de Flow.

  // Webhook de Flow (form-urlencoded con 'token'). No confiamos en lo que llega:
  // con el token se le pregunta a Flow el estado real del pago. Si el token no calza, igual se responde OK.
  @Post('api/pagos/confirmar')
  @Limite(60)
  async confirmar(@Body('token') token: string) { await this.srv.confirmarPorToken(token); return 'OK'; }

  // Página de retorno tras el pago. Es solo un "gracias": lo que vale es el webhook de arriba,
  // porque el usuario podría cerrar la pestaña antes de volver.
  @Get('pago/retorno')
  @Limite(30)
  @Header('Content-Type', 'text/html; charset=utf-8')
  retorno() {
    return `<!doctype html><meta charset="utf-8"><title>Walkan · Pago</title>
      <div style="font-family:system-ui;max-width:520px;margin:12vh auto;text-align:center">
      <h1 style="color:#0F5132">¡Gracias!</h1>
      <p>Recibimos tu pago. Un asesor de Walkan te contactará para activar tu cuenta.</p>
      <a href="/comercial-contacto.html" style="color:#129A63">Volver</a></div>`;
  }
}
