import { Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { SyncService } from './sync.service';

// Gestión de cajas desde el panel (requiere sesión de usuario).
// Bloquear sirve si se pierde o roban una caja: su token deja de servir para sincronizar.
@Controller('api/cajas')
@UseGuards(SesionGuard)
export class CajasController {
  constructor(private readonly srv: SyncService) {}

  @Get()
  listar() { return this.srv.listarCajas(); }

  @Post(':id/bloquear')
  bloquear(@Param('id') id: string) { return this.srv.bloquear(id); }

  @Post(':id/desbloquear')
  desbloquear(@Param('id') id: string) { return this.srv.desbloquear(id); }
}
