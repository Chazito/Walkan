import { BadRequestException, ConflictException, Inject, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { ahora } from '../../common/util/id';
import { fechaCL } from '../../common/util/fecha';
import { aCsv } from '../../common/util/csv';
import { ArchivoZip, crearZip } from '../../common/util/zip';
import { DIAS_PARA_ELIMINAR, Vigencia } from '../../common/util/vigencia';
import { AuthService } from '../auth/auth.service';
import { CorreoService } from '../sync/correo.service';

type Fila = Record<string, unknown>;
const DIA = 86_400_000;
const diaCorto = (iso: string): string => fechaCL(iso).split('-').reverse().join('-');

// Al eliminar una cuenta se borra todo lo del negocio MENOS estas tablas:
//  - clientes: la fila queda vacía (sin nombre, RUT, correo ni dirección) porque el registro de pagos la referencia.
//  - suscripciones: pagos del plan (obligación tributaria y contable).
//  - consentimientos: prueba de que el titular aceptó la política (Ley 21.719); la tabla es de solo inserción.
const SE_CONSERVAN = new Set(['clientes', 'suscripciones', 'consentimientos']);
// Columnas que nunca salen en la descarga de datos: claves, huellas y llaves, y las fotos (van como texto enorme).
const COLUMNA_PRIVADA = /password|hash|token|secret|cifrad|api_key|^img$|^cliente_id$|sesion_version/i;

/**
 * Baja voluntaria (Términos §9 y derechos de la Ley 21.719): el dueño puede cancelar su plan, descargar sus datos
 * y eliminar su cuenta sin escribirle a nadie.
 *  - Cancelar: no se le avisa ni se le cobra más; mantiene el acceso hasta el fin del período pagado.
 *  - Eliminar: la cuenta queda cerrada de inmediato y los datos se borran a los 30 días (puede recuperarla antes).
 */
@Injectable()
export class CuentaService {
  private readonly logger = new Logger('Cuenta');
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    @Inject(CONFIG) private readonly cfg: AppConfig,
    private readonly auth: AuthService,
    private readonly correo: CorreoService,
  ) {}

  // Estado del plan del negocio (vigente, en pausa, cerrada...) calculado en auth.
  private vigencia(clienteId: string): Vigencia {
    const v = this.auth.vigencia(clienteId);
    if (!v) throw new BadRequestException('Negocio no encontrado.');
    return v;
  }

  /** Marca el plan como cancelado: no se cobra más, pero el acceso sigue hasta que termine lo pagado. */
  cancelarPlan(clienteId: string) {
    const v = this.vigencia(clienteId);
    if (v.situacion === 'cerrada') throw new ConflictException('Tu cuenta ya está cerrada.');
    if (v.situacion === 'sin-plan') throw new ConflictException('Tu cuenta no tiene un plan con pago en línea que cancelar. Si quieres dejar Walkan, puedes eliminar tu cuenta.');
    if (!v.cancelado) {
      this.db.prepare('UPDATE clientes SET cancelado_en=@now, updated_at=@now WHERE id=@id').run({ id: clienteId, now: ahora() });
      this.logger.log(`Plan cancelado por el dueño: cliente ${clienteId}`);
    }
    return { ok: true, ...this.vigencia(clienteId) };
  }

  /** Deshace la cancelación. Si el período ya terminó, la cuenta sigue en pausa hasta que pague la renovación. */
  reactivarPlan(clienteId: string) {
    const v = this.vigencia(clienteId);
    if (v.situacion === 'cerrada') throw new ConflictException('Tu cuenta está cerrada. Recupérala primero.');
    if (v.cancelado) {
      this.db.prepare('UPDATE clientes SET cancelado_en=NULL, updated_at=@now WHERE id=@id').run({ id: clienteId, now: ahora() });
      this.logger.log(`Plan reactivado por el dueño: cliente ${clienteId}`);
    }
    return { ok: true, ...this.vigencia(clienteId) };
  }

  /** Cierra la cuenta y programa el borrado de los datos. Pide la contraseña: es la acción más delicada del panel. */
  async solicitarEliminacion(u: { email: string; clienteId: string }, password: string, ip: string) {
    try {
      await this.auth.validarCredenciales(u.email, password, ip);
    } catch (e) {
      // 400 y no 401: la sesión sigue siendo válida, lo que está mal es la clave escrita. (El 429 por demasiados intentos pasa tal cual.)
      if (e instanceof UnauthorizedException) throw new BadRequestException('La contraseña no es correcta.');
      throw e;
    }
    const v = this.vigencia(u.clienteId);
    if (v.situacion === 'cerrada') return { ok: true, eliminarEn: v.eliminarEn };
    const now = new Date();
    const eliminarEn = new Date(now.getTime() + DIAS_PARA_ELIMINAR * DIA).toISOString();
    this.db.prepare('UPDATE clientes SET eliminar_en=@eliminarEn, cancelado_en=COALESCE(cancelado_en, @now), updated_at=@now WHERE id=@id')
      .run({ id: u.clienteId, eliminarEn, now: now.toISOString() });
    this.logger.log(`Cuenta cerrada por el dueño: cliente ${u.clienteId}; sus datos se borran el ${eliminarEn.slice(0, 10)}`);
    void this.correo.enviarAviso(u.email, 'Cerraste tu cuenta de Walkan', this.plantilla('Tu cuenta quedó cerrada',
      `Recibimos tu solicitud para eliminar la cuenta. Tus datos se borrarán el <b>${diaCorto(eliminarEn)}</b>. Hasta ese día puedes entrar con tu correo y contraseña para descargar tus datos o recuperar la cuenta. Si no fuiste tú, entra ahora, recupérala y cambia tu contraseña.`,
      'Ir a mi cuenta', '/panel#cuenta'));
    return { ok: true, eliminarEn };
  }

  /** El dueño se arrepintió dentro del plazo: la cuenta vuelve a como estaba (si el plan venció, deberá pagar). */
  recuperar(clienteId: string) {
    const v = this.vigencia(clienteId);
    if (v.situacion !== 'cerrada') throw new ConflictException('Tu cuenta no está cerrada.');
    this.db.prepare('UPDATE clientes SET eliminar_en=NULL, cancelado_en=NULL, updated_at=@now WHERE id=@id').run({ id: clienteId, now: ahora() });
    this.logger.log(`Cuenta recuperada por el dueño: cliente ${clienteId}`);
    return { ok: true, ...this.vigencia(clienteId) };
  }

  /** Tablas con datos del negocio: todas las que tienen cliente_id. Se descubren del esquema, así una tabla nueva
   *  queda cubierta por la descarga y por el borrado sin acordarse de sumarla acá. */
  private tablasDelNegocio(): { tabla: string; columnas: string[] }[] {
    const tablas = this.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all() as { name: string }[];
    return tablas
      .map((t) => ({ tabla: t.name, columnas: (this.db.pragma(`table_info(${t.name})`) as { name: string }[]).map((c) => c.name) }))
      .filter((t) => t.columnas.includes('cliente_id'));
  }

  /**
   * "Descargar mis datos" (portabilidad): un ZIP con un CSV por tabla, listo para Excel. No incluye claves, llaves
   * de Flow ni las fotos de los productos.
   */
  exportar(clienteId: string): { nombre: string; zip: Buffer } {
    const archivos: ArchivoZip[] = [];
    const agregar = (nombre: string, columnas: string[], filas: Fila[]) => {
      const cols = columnas.filter((c) => !COLUMNA_PRIVADA.test(c));
      archivos.push({ nombre: nombre + '.csv', contenido: aCsv(cols, filas) });
    };
    const negocio = this.db.prepare('SELECT * FROM clientes WHERE id=?').get(clienteId) as Fila | undefined;
    if (!negocio) throw new BadRequestException('Negocio no encontrado.');
    agregar('negocio', Object.keys(negocio).filter((c) => !/^(apariencia_|aviso_|flow_)/.test(c) && c !== 'id'), [negocio]);
    for (const t of this.tablasDelNegocio()) {
      const filas = this.db.prepare(`SELECT * FROM ${t.tabla} WHERE cliente_id=?`).all(clienteId) as Fila[];
      agregar(t.tabla === 'suscripciones' ? 'pagos_del_plan' : t.tabla, t.columnas, filas);
      // Las ventas guardan sus productos como una lista dentro de una celda: además va un CSV con una fila por producto vendido.
      if (t.tabla === 'ventas') {
        const detalle: Fila[] = [];
        for (const v of filas) {
          let items: unknown = [];
          try { items = JSON.parse(String(v.items_json ?? '[]')); } catch { /* fila antigua con el detalle dañado: se omite */ }
          for (const it of Array.isArray(items) ? items : []) {
            const [producto, cantidad, precio] = Array.isArray(it) ? it : [];
            detalle.push({ folio: v.folio, fecha: v.fecha, producto, cantidad, precio, subtotal: (Number(cantidad) || 0) * (Number(precio) || 0) });
          }
        }
        agregar('ventas_detalle', ['folio', 'fecha', 'producto', 'cantidad', 'precio', 'subtotal'], detalle);
      }
    }
    const hoy = fechaCL();
    archivos.unshift({ nombre: 'LEEME.txt', contenido:
      `Datos de ${String(negocio.negocio ?? '')} en Walkan, descargados el ${diaCorto(new Date().toISOString())}.\r\n\r\n` +
      'Cada archivo .csv es una tabla y se abre con Excel, LibreOffice o Google Sheets.\r\n' +
      'Formato: separador punto y coma, coma decimal, texto en UTF-8. Las fechas con hora están en hora universal (UTC).\r\n\r\n' +
      'ventas.csv tiene una fila por venta y ventas_detalle.csv una fila por producto vendido.\r\n' +
      'No se incluyen contraseñas, llaves de Flow ni las fotos de los productos.\r\n' });
    this.logger.log(`Descarga de datos: cliente ${clienteId} (${archivos.length} archivos)`);
    return { nombre: `walkan-mis-datos-${hoy}.zip`, zip: crearZip(archivos) };
  }

  /** Borra los datos de las cuentas cuyo plazo de eliminación ya se cumplió. Devuelve cuántas borró. */
  eliminarVencidas(ahoraMs: number = Date.now()): number {
    const filas = this.db.prepare('SELECT id FROM clientes WHERE eliminar_en IS NOT NULL AND eliminar_en<=? AND eliminado_en IS NULL')
      .all(new Date(ahoraMs).toISOString()) as { id: string }[];
    let borradas = 0;
    for (const f of filas) {
      // Una cuenta que falle no debe frenar a las demás: queda en el log y se reintenta en la próxima pasada.
      try { this.eliminarDatos(f.id); borradas++; } catch (e) { this.logger.error(`No se pudo eliminar la cuenta ${f.id}: ${(e as Error).message}`); }
    }
    return borradas;
  }

  /** Borrado definitivo de un negocio: usuarios, sesiones, productos, ventas, cajas, etc. Ver SE_CONSERVAN. */
  eliminarDatos(clienteId: string): void {
    const now = ahora();
    const tablas = this.tablasDelNegocio().filter((t) => !SE_CONSERVAN.has(t.tabla));
    this.db.transaction(() => {
      // Las claves foráneas se revisan recién al confirmar: así no importa el orden en que se vacían las tablas.
      this.db.pragma('defer_foreign_keys = ON');
      // Las sesiones no tienen cliente_id: se van con sus usuarios (ON DELETE CASCADE).
      // Ventas antiguas que apunten a una caja del negocio sin llevar su cliente_id: también se van (si quedaran,
      // la clave foránea ventas → cajas haría fallar todo el borrado).
      this.db.prepare('DELETE FROM ventas WHERE caja_id IN (SELECT id FROM cajas WHERE cliente_id=?)').run(clienteId);
      for (const t of tablas) this.db.prepare(`DELETE FROM ${t.tabla} WHERE cliente_id=?`).run(clienteId);
      this.db.prepare(`UPDATE clientes SET negocio='Cuenta eliminada', rut=NULL, comuna=NULL, comuna_cut=NULL, region=NULL, direccion=NULL,
          email=NULL, telefono=NULL, transferencia_json=NULL, flow_api_key=NULL, flow_secret_cifrada=NULL,
          estado='suspendido', eliminar_en=NULL, eliminado_en=@now, updated_at=@now WHERE id=@id`).run({ id: clienteId, now });
    })();
    this.logger.log(`Cuenta eliminada: cliente ${clienteId} (${tablas.length} tablas vaciadas; se conservan pagos y consentimientos)`);
  }

  /** Correo simple de Walkan: título, un párrafo y un botón. El texto llega ya armado por el servidor (sin datos del usuario sin escapar). */
  plantilla(titulo: string, parrafoHtml: string, boton: string, ruta: string): string {
    return `<!doctype html><html lang="es"><body style="margin:0;background:#f4f6f5;font-family:Arial,Helvetica,sans-serif;color:#111">
<div style="max-width:440px;margin:24px auto;background:#fff;border-radius:8px;padding:24px;border:1px solid #e3e7e5">
  <div style="font-weight:700;color:#0B7C4E;margin-bottom:12px">Walkan</div>
  <h2 style="margin:0 0 10px;font-size:20px">${titulo}</h2>
  <p style="font-size:15px;line-height:1.5;margin:0 0 18px">${parrafoHtml}</p>
  <a href="${this.cfg.appUrl}${ruta}" style="display:inline-block;background:#0B7C4E;color:#fff;text-decoration:none;font-weight:700;padding:11px 18px;border-radius:6px">${boton}</a>
  <p style="font-size:12px;color:#888;margin:20px 0 0">Walkan, tu negocio siempre funcionando.</p>
</div></body></html>`;
  }
}
