// Datos que llegan al cambiar la contraseña: la actual y la nueva (la nueva debe cumplir la política de claves).
import { IsString, MaxLength, MinLength } from 'class-validator';
import { ClaveSegura } from '../../../common/util/politica-clave';

export class CambiarPasswordDto {
  @IsString() @MinLength(1) @MaxLength(100) actual!: string;
  @IsString() @ClaveSegura() nueva!: string;
}
