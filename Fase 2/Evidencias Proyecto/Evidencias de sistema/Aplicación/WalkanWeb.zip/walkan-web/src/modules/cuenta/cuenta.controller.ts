import { Body, Controller, ForbiddenException, Get, Ip, Post, Req, Res, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { Limite } from '../../common/limite';
import { CuentaService } from './cuenta.service';
import { EliminarCuentaDto } from './dto/eliminar-cuenta.dto';

/**
 * Acciones del dueño sobre su propia cuenta: cancelar o reactivar el plan, descargar sus datos y eliminar o
 * recuperar la cuenta. Siguen disponibles con la cuenta en pausa (ver permitidaEnPausa en common/util/vigencia.ts).
 * El pago de la renovación (POST /api/cuenta/renovar) vive en RegistroController, junto al resto del flujo de Flow.
 */
@Controller('api/cuenta')
@UseGuards(SesionGuard)
export class CuentaController {
  constructor(private readonly srv: CuentaService) {}

  // Solo el dueño (rol 'admin' de un negocio): ni un cajero ni el staff cancelan o borran una cuenta desde acá.
  private dueno(req: any): { id: string; email: string; clienteId: string } {
    const u = req.usuario;
    if (u?.rol !== 'admin' || !u.clienteId) throw new ForbiddenException('Solo el dueño del negocio puede hacer esto.');
    return u;
  }

  // Cancelar no corta el acceso: sigue hasta el fin del período pagado (ver CuentaService).
  @Post('cancelar')
  @Limite(10)
  cancelar(@Req() req: any) { return this.srv.cancelarPlan(this.dueno(req).clienteId); }

  @Post('reactivar')
  @Limite(10)
  reactivar(@Req() req: any) { return this.srv.reactivarPlan(this.dueno(req).clienteId); }

  /** "Descargar mis datos": ZIP con un CSV por tabla. */
  @Get('exportar')
  @Limite(6)
  exportar(@Req() req: any, @Res({ passthrough: true }) reply: any) {
    const { nombre, zip } = this.srv.exportar(this.dueno(req).clienteId);
    reply.header('Content-Type', 'application/zip').header('Content-Disposition', `attachment; filename="${nombre}"`).header('Cache-Control', 'no-store');
    return zip;
  }

  // Pide la contraseña de nuevo: cierra la cuenta y los datos se borran a los 30 días.
  @Post('eliminar')
  @Limite(5)
  eliminar(@Req() req: any, @Body() dto: EliminarCuentaDto, @Ip() ip: string) {
    return this.srv.solicitarEliminacion(this.dueno(req), dto.password, ip);
  }

  // Arrepentimiento: reabre una cuenta cerrada mientras no se cumpla el plazo de borrado.
  @Post('recuperar')
  @Limite(10)
  recuperar(@Req() req: any) { return this.srv.recuperar(this.dueno(req).clienteId); }
}
