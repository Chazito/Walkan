// Guard que deja pasar solo al equipo Walkan (rol staff, con dos pasos activos) a las rutas de /api/admin.
import { CanActivate, ExecutionContext, ForbiddenException, Injectable, UnauthorizedException } from '@nestjs/common';
import { ContextoTenant } from '../../common/contexto-tenant';
import { AuthService } from '../auth/auth.service';
import { COOKIE_SESION, opcionesCookie } from '../auth/auth.guard';
import { dosPasosObligatorio } from '../auth/dos-pasos.service';

// Protege las rutas del panel de administración: requiere sesión de un usuario
// con rol 'staff' (equipo Walkan). Ojo que deja clienteId en null: el staff no
// "pertenece" a ninguna tienda, así que los repos multi-tenant no le sirven tal cual.
@Injectable()
export class StaffGuard implements CanActivate {
  constructor(private readonly auth: AuthService, private readonly ctx: ContextoTenant) {}

  canActivate(ctx: ExecutionContext): boolean {
    const req: any = ctx.switchToHttp().getRequest();
    const raw = req.cookies?.[COOKIE_SESION];
    if (!raw) throw new UnauthorizedException('Sesión requerida.');
    const un = req.unsignCookie(raw);
    if (!un.valid || !un.value) throw new UnauthorizedException('Sesión inválida.');
    const usuario = this.auth.usuarioDeSesion(un.value);
    if (!usuario) throw new UnauthorizedException('Sesión inválida.');
    if (usuario.renovada) ctx.switchToHttp().getResponse().setCookie(COOKIE_SESION, un.value, opcionesCookie(true));
    req.sesionId = un.value;
    if (usuario.rol !== 'staff') throw new ForbiddenException('Solo el equipo Walkan puede acceder a administración.');
    // Sin la verificación en dos pasos configurada, la administración queda cerrada (se configura en /dos-pasos).
    if (dosPasosObligatorio(usuario.rol) && !usuario.dosPasos) throw new ForbiddenException('Activa la verificación en dos pasos para usar el panel del equipo Walkan.');
    req.usuario = usuario;
    this.ctx.set({ userId: usuario.id, clienteId: null, rol: 'staff' });
    return true;
  }
}
