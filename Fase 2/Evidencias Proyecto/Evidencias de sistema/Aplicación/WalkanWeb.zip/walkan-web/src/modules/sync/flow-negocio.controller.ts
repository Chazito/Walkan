// Controllers del cobro con QR de Flow: conexión desde el panel, cobros desde la caja y retorno/confirmación de Flow.
import { Body, Controller, Delete, Get, Header, Headers, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { SesionGuard } from '../auth/auth.guard';
import { FlowNegocioService } from './flow-negocio.service';
import { Limite } from '../../common/limite';

// Panel: conectar la cuenta Flow del negocio (opcional).
@Controller('api/negocio/flow')
@UseGuards(SesionGuard)
export class FlowNegocioController {
  constructor(private readonly srv: FlowNegocioService) {}
  @Get() estado() { return this.srv.estadoConexion(); }
  @Put() conectar(@Body() body: { apiKey?: string; secretKey?: string; entorno?: string }) { return this.srv.conectar(body); }
  @Delete() desconectar() { return this.srv.desconectar(); }
}

// Caja: crear un cobro con QR, consultar su estado y anularlo (autenticada con el token del dispositivo).
@Controller('api/caja/cobro-qr')
export class CobroQrCajaController {
  constructor(private readonly srv: FlowNegocioService) {}
  @Post() @Limite(300) crear(@Headers('x-caja-token') t: string, @Body('monto') monto: number) { return this.srv.crearCobro(t, monto); }
  @Get(':id') @Limite(300) estado(@Headers('x-caja-token') t: string, @Param('id') id: string) { return this.srv.estadoCobro(t, id); }
  @Post(':id/anular') @Limite(300) anular(@Headers('x-caja-token') t: string, @Param('id') id: string) { return this.srv.anularCobro(t, id); }
}

// Flow: confirmación del pago (servidor a servidor) y página de retorno para el celular del comprador.
@Controller()
export class FlowRetornoController {
  constructor(private readonly srv: FlowNegocioService) {}
  @Post('api/flow/cobro-qr/confirmacion') @Limite(60) confirmacion(@Body('token') token: string) { return this.srv.confirmacion(token); }

  @Post('pago-qr') @Limite(30) @Header('Content-Type', 'text/html; charset=utf-8') retornoPost(@Body('token') token: string) { void this.srv.confirmacion(token); return PAGINA; }
  @Get('pago-qr') @Limite(30) @Header('Content-Type', 'text/html; charset=utf-8') retornoGet(@Query('token') token?: string) { if (token) void this.srv.confirmacion(token); return PAGINA; }
}

// Página que ve el comprador en su celular al volver de Flow: solo un "gracias", la caja confirma el pago por su lado.
const PAGINA = `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pago recibido</title></head><body style="font-family:Arial,sans-serif;text-align:center;padding:48px 20px;color:#0B7C4E">
<svg viewBox="0 0 24 24" width="56" height="56" aria-hidden="true" style="fill:none;stroke:#0B7C4E;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round"><path d="M20 6 9 17l-5-5"/></svg><h1 style="margin:8px 0">¡Gracias por tu pago!</h1>
<p style="color:#444">La caja confirmará la compra en unos segundos. Ya puedes cerrar esta página.</p></body></html>`;
