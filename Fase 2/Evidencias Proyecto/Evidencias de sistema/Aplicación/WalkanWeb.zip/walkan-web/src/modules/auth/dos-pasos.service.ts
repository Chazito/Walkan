// Verificación en dos pasos (TOTP): activar con QR, códigos de respaldo y el desafío del login.
import { BadRequestException, ConflictException, ForbiddenException, HttpException, HttpStatus, Inject, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { randomBytes } from 'crypto';
import * as QRCode from 'qrcode';
import { CONFIG } from '../../config/config.provider';
import type { AppConfig } from '../../config/configuracion';
import { ahora } from '../../common/util/id';
import { cifrar, codigosRespaldo, descifrar, hashRespaldo, nuevoSecreto, uriOtpauth, verificarCodigo } from '../../common/util/totp';
import { UsuariosRepository } from './usuarios.repository';

/** ¿Este rol está obligado a usar la verificación en dos pasos? El equipo Walkan (staff) sí; los dueños la eligen.
 *  STAFF_2FA_OBLIGATORIO=0 lo apaga (solo para las pruebas automáticas, que entran como staff sin celular). */
export const dosPasosObligatorio = (rol: string | undefined): boolean => rol === 'staff' && process.env.STAFF_2FA_OBLIGATORIO !== '0';

const DESAFIO_MS = 5 * 60_000;   // tiempo para escribir el código después de la contraseña
const MAX_INTENTOS = 5;          // códigos malos por desafío; después hay que volver a poner la contraseña
const MAX_FALLOS_USUARIO = 10;   // códigos malos de un usuario sumando desafíos → 15 min de espera
const BLOQUEO_MS = 15 * 60_000;  // (con la contraseña robada no se puede probar el millón de códigos de a 5)

/**
 * Verificación en dos pasos con app de códigos (Google Authenticator, Microsoft Authenticator, Authy…).
 * - Configurar: se genera un secreto (queda "pendiente"), se muestra como QR y se activa al escribir un código bueno.
 *   Se entregan 8 códigos de respaldo de un solo uso, para cuando no se tiene el celular.
 * - Iniciar sesión: correo + contraseña correctos → un "desafío" de 5 minutos; con el código de la app se abre la sesión.
 */
@Injectable()
export class DosPasosService {
  private readonly logger = new Logger('DosPasos');
  // ponytail: desafíos en memoria (un solo proceso); si se reinicia la app, se vuelve a poner la contraseña.
  private readonly desafios = new Map<string, { usuarioId: string; recordar: boolean; expira: number; intentos: number }>();
  private readonly fallos = new Map<string, { n: number; hasta: number }>();

  constructor(private readonly repo: UsuariosRepository, @Inject(CONFIG) private readonly cfg: AppConfig) {}

  private secretoDe(cifrado: string | null | undefined): string | null {
    return cifrado ? descifrar(cifrado, this.cfg.sessionSecret) : null;
  }
  private respaldos(r: Record<string, any>): string[] {
    try { return JSON.parse(r.totp_respaldo || '[]'); } catch { return []; }
  }

  estado(usuarioId: string, rol: string) {
    const r = this.repo.porId(usuarioId);
    return {
      activo: !!r?.totp_secreto,
      desde: r?.totp_desde ?? null,
      respaldosRestantes: r ? this.respaldos(r).length : 0,
      obligatorio: dosPasosObligatorio(rol),
    };
  }

  /** Paso 1 de la configuración: secreto nuevo (pendiente) y su QR. Repetirlo reemplaza el pendiente anterior. */
  async iniciar(usuarioId: string, email: string) {
    const r = this.repo.porId(usuarioId);
    if (!r) throw new UnauthorizedException('Sesión inválida.');
    if (r.totp_secreto) throw new ConflictException('La verificación en dos pasos ya está activa.');
    const secreto = nuevoSecreto();
    this.repo.setTotpPendiente(usuarioId, cifrar(secreto, this.cfg.sessionSecret));
    const uri = uriOtpauth(email, secreto);
    const qr = await QRCode.toString(uri, { type: 'svg', margin: 1, errorCorrectionLevel: 'M', color: { dark: '#000000', light: '#ffffff' } });
    // El secreto en grupos de 4 por si la persona prefiere escribirlo a mano en la app.
    return { secreto: secreto.match(/.{1,4}/g)!.join(' '), uri, qr };
  }

  /** Paso 2: con un código bueno de la app, queda activa. Devuelve los códigos de respaldo (se muestran una sola vez). */
  activar(usuarioId: string, codigo: string): { respaldo: string[] } {
    const r = this.repo.porId(usuarioId);
    if (!r) throw new UnauthorizedException('Sesión inválida.');
    if (r.totp_secreto) throw new ConflictException('La verificación en dos pasos ya está activa.');
    const secreto = this.secretoDe(r.totp_pendiente);
    if (!secreto) throw new BadRequestException('Primero escanea el código QR con la app.');
    const paso = verificarCodigo(secreto, codigo, null);
    if (paso == null) throw new BadRequestException('El código no es correcto. Revisa que la hora del celular esté al día y escribe el código que se ve ahora.');
    const respaldo = codigosRespaldo();
    this.repo.activarTotp(usuarioId, r.totp_pendiente, JSON.stringify(respaldo.map(hashRespaldo)), paso, ahora());
    this.logger.log(`Verificación en dos pasos activada: usuario ${usuarioId}`);
    return { respaldo };
  }

  /**
   * Revisa un código de la app o de respaldo de un usuario con la verificación activa y lo "gasta"
   * (el de la app no sirve dos veces; el de respaldo se borra). true si sirvió.
   */
  usarCodigo(usuarioId: string, entrada: string): boolean {
    const r = this.repo.porId(usuarioId);
    const secreto = this.secretoDe(r?.totp_secreto);
    if (!r || !secreto) return false;
    const limpio = String(entrada ?? '').trim();
    if (/^\d[\d\s]{5,7}$/.test(limpio)) {
      const paso = verificarCodigo(secreto, limpio, r.totp_ultimo_paso ?? null);
      if (paso == null) return false;
      this.repo.setTotpUltimoPaso(usuarioId, paso);
      return true;
    }
    const lista = this.respaldos(r), h = hashRespaldo(limpio), i = lista.indexOf(h);
    if (i < 0) return false;
    lista.splice(i, 1);
    this.repo.setTotpRespaldo(usuarioId, JSON.stringify(lista));
    this.logger.log(`Código de respaldo usado: usuario ${usuarioId} (quedan ${lista.length})`);
    return true;
  }

  /** Apagar: pide un código (de la app o de respaldo). La contraseña la revisa quien llama. El staff no puede. */
  desactivar(usuarioId: string, rol: string, codigo: string): void {
    if (dosPasosObligatorio(rol)) throw new ForbiddenException('Para el equipo Walkan la verificación en dos pasos es obligatoria.');
    if (!this.repo.porId(usuarioId)?.totp_secreto) throw new ConflictException('La verificación en dos pasos no está activa.');
    if (!this.usarCodigo(usuarioId, codigo)) throw new BadRequestException('El código no es correcto.');
    this.repo.desactivarTotp(usuarioId, ahora());
    this.logger.log(`Verificación en dos pasos desactivada: usuario ${usuarioId}`);
  }

  /** Códigos de respaldo nuevos (los anteriores dejan de servir). Pide un código válido. */
  nuevosRespaldos(usuarioId: string, codigo: string): { respaldo: string[] } {
    if (!this.usarCodigo(usuarioId, codigo)) throw new BadRequestException('El código no es correcto.');
    const respaldo = codigosRespaldo();
    this.repo.setTotpRespaldo(usuarioId, JSON.stringify(respaldo.map(hashRespaldo)));
    return { respaldo };
  }

  // ---- Inicio de sesión en dos pasos ----
  crearDesafio(usuarioId: string, recordar: boolean): string {
    const ahoraMs = Date.now();
    for (const [k, d] of this.desafios) if (d.expira <= ahoraMs) this.desafios.delete(k);
    const id = randomBytes(32).toString('base64url');
    this.desafios.set(id, { usuarioId, recordar, expira: ahoraMs + DESAFIO_MS, intentos: 0 });
    return id;
  }

  /** Completa el inicio de sesión con el código. Devuelve a quién y si "Recordarme"; lanza si no sirve. */
  completar(desafio: string, codigo: string): { usuarioId: string; recordar: boolean } {
    const d = this.desafios.get(String(desafio ?? ''));
    if (!d || d.expira <= Date.now()) {
      this.desafios.delete(String(desafio ?? ''));
      throw new UnauthorizedException('Pasó mucho tiempo. Vuelve a escribir tu correo y contraseña.');
    }
    const f = this.fallos.get(d.usuarioId);
    if (f && f.hasta > Date.now()) {
      this.desafios.delete(desafio);
      throw new HttpException(`Demasiados códigos incorrectos. Espera ${Math.ceil((f.hasta - Date.now()) / 60_000)} minuto(s) y vuelve a intentarlo.`, HttpStatus.TOO_MANY_REQUESTS);
    }
    if (!this.usarCodigo(d.usuarioId, codigo)) {
      d.intentos++;
      const n = (f && f.hasta && f.hasta <= Date.now() ? 0 : f?.n ?? 0) + 1;
      this.fallos.set(d.usuarioId, { n, hasta: n >= MAX_FALLOS_USUARIO ? Date.now() + BLOQUEO_MS : 0 });
      if (n >= MAX_FALLOS_USUARIO) {
        this.desafios.delete(desafio);
        this.logger.warn(`Verificación en dos pasos bloqueada 15 min por códigos incorrectos: usuario ${d.usuarioId}`);
        throw new HttpException('Demasiados códigos incorrectos. Espera 15 minutos y vuelve a intentarlo.', HttpStatus.TOO_MANY_REQUESTS);
      }
      if (d.intentos >= MAX_INTENTOS) {
        this.desafios.delete(desafio);
        this.logger.warn(`Demasiados códigos incorrectos: usuario ${d.usuarioId}`);
        throw new HttpException('Demasiados códigos incorrectos. Vuelve a escribir tu correo y contraseña.', HttpStatus.TOO_MANY_REQUESTS);
      }
      throw new UnauthorizedException('El código no es correcto.');
    }
    this.desafios.delete(desafio);
    this.fallos.delete(d.usuarioId);
    return { usuarioId: d.usuarioId, recordar: d.recordar };
  }
}
