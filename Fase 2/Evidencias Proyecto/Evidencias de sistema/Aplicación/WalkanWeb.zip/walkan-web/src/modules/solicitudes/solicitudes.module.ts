// Módulo de solicitudes: embudo de altas que llegan desde el formulario del sitio.
import { Module } from '@nestjs/common';
import { SolicitudesController } from './solicitudes.controller';
import { SolicitudesService } from './solicitudes.service';
import { SolicitudesRepository } from './solicitudes.repository';
import { PagosModule } from '../pagos/pagos.module';
import { PrivacidadModule } from '../privacidad/privacidad.module';

// Altas desde el sitio público + cobro con Flow (por eso importa PagosModule).
@Module({
  imports: [PagosModule, PrivacidadModule],
  controllers: [SolicitudesController],
  providers: [SolicitudesService, SolicitudesRepository],
  exports: [SolicitudesService],
})
export class SolicitudesModule {}
