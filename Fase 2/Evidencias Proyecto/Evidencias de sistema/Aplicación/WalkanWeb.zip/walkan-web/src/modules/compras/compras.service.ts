// Lógica de pedidos a proveedores, compras y devoluciones; al recibir mercadería mueve el stock.
import { BadRequestException, ConflictException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { ahora, nuevoId } from '../../common/util/id';
import { fechaCL, fechaValida } from '../../common/util/fecha';
import { ProductosService } from '../catalogo/productos.service';
import { ProveedoresRepository } from '../catalogo/proveedores.repository';
import { StockService } from '../catalogo/stock.service';
import { PedidosRepository } from './pedidos.repository';
import { ComprasRepository } from './compras.repository';
import { CrearPedidoBody, CrearCompraBody, CrearDevolucionBody, ItemPedido, RecibirPedidoBody } from './dto/compras.dto';

// Dos caminos para que entre mercadería:
//  - Pedido: se arma la lista al proveedor (Borrador -> Enviado) y no toca stock hasta recibirlo.
//  - Ingreso directo (sin pedido): entra al tiro (manual o "externa", ej. fuiste al mayorista).
// En ambos casos queda una fila en compras (= "ingreso de mercadería" en la UI) y el stock pasa
// por StockService, que crea los lotes y exige vencimiento si el producto lo controla.
// Como los bodies son interfaces, toda la validación de líneas está acá en lineas().
@Injectable()
export class ComprasService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly pedidos: PedidosRepository,
    private readonly compras: ComprasRepository,
    private readonly productos: ProductosService,
    private readonly proveedores: ProveedoresRepository,
    private readonly stock: StockService,
    private readonly ctx: ContextoTenant,
  ) {}

  private nombreProv(id?: string | null): string {
    if (!id) return 'Sin proveedor';
    const p = this.proveedores.obtener(id);
    return p ? p.nombre : 'Sin proveedor';
  }

  // El repo filtra por tenant, así que un proveedor de otra tienda cae acá como "no existe".
  private validarProv(id?: string | null): string | null {
    if (!id) return null;
    if (!this.proveedores.obtener(id)) throw new BadRequestException('Ese proveedor ya no existe (se eliminó o se cambió de cuenta en otra pestaña). Recarga la página.');
    return id;
  }

  /** Líneas de pedido/compra: cantidad > 0 (hasta 3 decimales: el granel va en kg), costo entero ≥ 0 y producto del mismo negocio. */
  private lineas(items: unknown, vacio: string): ItemPedido[] {
    if (!Array.isArray(items) || !items.length) throw new BadRequestException(vacio);
    if (items.length > 200) throw new BadRequestException('Máximo 200 líneas por documento.'); // cada línea mueve stock en la misma transacción
    return items.map((it: any) => {
      const qty = Number(it?.qty);
      const costo = Number(it?.costo ?? 0);
      // Que sea entera en los productos por unidad lo revisa StockService al mover el stock.
      if (!Number.isFinite(qty) || qty <= 0 || qty > 1_000_000 || Math.abs(qty * 1000 - Math.round(qty * 1000)) > 1e-6) throw new BadRequestException('Cada línea debe tener una cantidad mayor a 0 (hasta 3 decimales).');
      if (!Number.isInteger(costo) || costo < 0 || costo > 100_000_000) throw new BadRequestException('Cada línea debe tener un costo entero mayor o igual a 0.');
      const prod: string | null = it?.prod || null;
      const p = prod ? this.productos.obtener(prod) : null; // 404 si no es de este negocio
      const nombre = String(it?.nombre || p?.nombre || '').trim().slice(0, 120);
      if (!nombre) throw new BadRequestException('Cada línea debe indicar un producto.');
      const vence: string | null = it?.vence || null;
      if (vence && !fechaValida(vence)) throw new BadRequestException(`Vencimiento inválido en "${nombre}" (usa una fecha real AAAA-MM-DD).`);
      const lote: string | null = String(it?.lote ?? '').trim().slice(0, 40) || null;
      return { prod, nombre, qty, costo, lote, vence };
    });
  }

  /**
   * Lo que entra al stock no puede venir ya vencido: FEFO lo vendería primero. Casi siempre es un error de tipeo
   * (año o mes). Solo en ingresos y recepciones; una devolución sí puede ser de mercadería vencida.
   */
  private sinVencidos(lineas: ItemPedido[]): void {
    const hoy = fechaCL(ahora());
    const v = lineas.find((l) => l.vence && l.vence < hoy);
    if (v) throw new BadRequestException(`"${v.nombre}" vence el ${v.vence}, que ya pasó. Revisa la fecha de vencimiento.`);
  }

  // ---- Pedidos (lista de compra) ----
  listarPedidos() { return this.pedidos.listar(); }

  crearPedido(dto: CrearPedidoBody) {
    const items = this.lineas(dto?.items, 'El pedido no tiene items.');
    const prov = this.validarProv(dto?.prov);
    const now = ahora();
    const id = nuevoId();
    this.pedidos.crear({
      id, proveedorId: prov, fecha: fechaCL(now), estado: dto?.borrador ? 'Borrador' : 'Enviado',
      nota: typeof dto?.nota === 'string' && dto.nota ? dto.nota.slice(0, 500) : null, itemsJson: JSON.stringify(items), createdAt: now, updatedAt: now,
    });
    return this.pedidos.obtener(id);
  }

  enviarPedido(id: string) {
    const p = this.pedidos.obtener(id);
    if (!p) throw new NotFoundException('Pedido no encontrado.');
    // Proveedor archivado: el borrador queda como historial, pero ya no se le envía (validarProv solo ve activos).
    this.validarProv(p.prov);
    if (!this.pedidos.marcarEnviado(id, ahora())) throw new ConflictException('Solo un borrador se puede enviar al proveedor.');
    return this.pedidos.obtener(id);
  }

  // Solo un borrador se edita o elimina: uno enviado ya está en manos del proveedor.
  private soloBorrador(id: string): void {
    const p = this.pedidos.obtener(id);
    if (!p) throw new NotFoundException('Pedido no encontrado.');
    if (p.estado !== 'Borrador') throw new ConflictException('Solo un pedido en borrador se puede editar o eliminar.');
  }

  editarPedido(id: string, dto: CrearPedidoBody) {
    this.soloBorrador(id);
    const items = this.lineas(dto?.items, 'El pedido no tiene items.');
    const prov = this.validarProv(dto?.prov);
    const nota = typeof dto?.nota === 'string' && dto.nota ? dto.nota.slice(0, 500) : null;
    // El WHERE estado='Borrador' del repo cubre la carrera con un "marcar enviado" simultáneo.
    if (!this.pedidos.editarBorrador(id, { proveedorId: prov, nota, itemsJson: JSON.stringify(items), now: ahora() })) {
      throw new ConflictException('Solo un pedido en borrador se puede editar o eliminar.');
    }
    return this.pedidos.obtener(id);
  }

  borrarPedido(id: string) {
    this.soloBorrador(id);
    if (!this.pedidos.borrarBorrador(id)) throw new ConflictException('Solo un pedido en borrador se puede editar o eliminar.');
    return { ok: true };
  }

  /**
   * Recepción: por defecto ingresa lo pedido; si el body trae items se usan esas
   * cantidades y costos (lo que realmente llegó). Líneas en 0 = no llegaron.
   * Las líneas sin producto del catálogo suman al total pero no mueven stock.
   */
  recibirPedido(id: string, body?: RecibirPedidoBody) {
    const p = this.pedidos.obtener(id);
    if (!p) throw new NotFoundException('Pedido no encontrado.');
    if (p.estado === 'Recibido') throw new ConflictException('El pedido ya fue recibido.');
    const recibidas = Array.isArray(body?.items) ? body.items.filter((it) => Number(it?.qty) !== 0) : p.items;
    const items = this.lineas(recibidas, 'No hay líneas recibidas.');
    this.sinVencidos(items);
    const now = ahora();
    const clienteId = this.ctx.clienteId;
    const compraId = nuevoId();
    let total = 0;
    // Stock + pedido marcado + fila de compra van juntos: o se recibe todo o nada.
    this.db.transaction(() => {
      for (const it of items) {
        total += it.qty * it.costo;
        if (it.prod) this.stock.mover({ clienteId, productoId: it.prod, tipo: 'recepcion', cantidad: it.qty, costoUnit: it.costo, refId: id, lote: it.lote, vence: it.vence });
      }
      this.pedidos.marcarRecibido(id, JSON.stringify(items), compraId, now);
      this.compras.crear({
        id: compraId, proveedor: this.nombreProv(p.prov), tipo: 'Pedido',
        fecha: fechaCL(now), items: items.length, total: Math.round(total), createdAt: now,
      });
    })();
    return { pedido: this.pedidos.obtener(id), compraId, ok: true };
  }

  // ---- Compras ----
  listarCompras() { return this.compras.listar(); }

  /**
   * Detalle de un ingreso: las líneas del kardex que generó (producto, cantidad, costo, lote y vencimiento).
   * Un ingreso directo deja su id como ref; uno que viene de un pedido deja el id del pedido.
   */
  detalleCompra(id: string) {
    const c = this.compras.listar().find((x) => x.id === id);
    if (!c) throw new NotFoundException('Ingreso no encontrado.');
    const ped = this.db.prepare('SELECT id FROM pedidos WHERE compra_id=? AND cliente_id=?').get(id, this.ctx.clienteId) as { id: string } | undefined;
    const lineas = this.db.prepare(`SELECT p.nombre, m.cantidad, m.costo_unit AS costo, l.codigo AS lote, l.vence
      FROM movimientos_stock m JOIN productos p ON p.id=m.producto_id AND p.cliente_id=m.cliente_id
      LEFT JOIN lotes l ON l.id=m.lote_id AND l.cliente_id=m.cliente_id
      WHERE m.cliente_id=? AND m.tipo IN ('compra','recepcion','devolucion') AND m.ref_id=? ORDER BY m.rowid`).all(this.ctx.clienteId, ped ? ped.id : id);
    return { ...c, lineas };
  }

  crearCompra(dto: CrearCompraBody) {
    const lineas = this.lineas(dto?.items, 'El ingreso no tiene líneas.');
    // A diferencia del pedido, acá no se aceptan productos "sueltos": todo tiene que mover stock.
    if (lineas.some((l) => !l.prod)) throw new BadRequestException('Cada línea del ingreso debe ser un producto del catálogo.');
    this.sinVencidos(lineas);
    const externa = dto.prov === 'externa';
    const prov = externa ? null : this.validarProv(dto.prov);
    const now = ahora();
    const compraId = nuevoId();
    const clienteId = this.ctx.clienteId;
    let total = 0;
    this.db.transaction(() => {
      for (const l of lineas) {
        total += l.qty * l.costo;
        this.stock.mover({ clienteId, productoId: l.prod as string, tipo: 'compra', cantidad: l.qty, costoUnit: l.costo, refId: compraId, lote: l.lote, vence: l.vence });
      }
      this.compras.crear({
        id: compraId, proveedor: externa ? 'Compra externa' : this.nombreProv(prov),
        tipo: externa ? 'Externa' : 'Manual', fecha: fechaCL(now),
        items: lineas.length, total: Math.round(total), createdAt: now,
      });
    })();
    return { ok: true, total: Math.round(total) };
  }

  /**
   * Devolución al proveedor (vencido, dañado, error del pedido): saca stock con tipo 'devolucion' (no es merma:
   * el proveedor la repone o la abona) y queda en Ingresos como "Devolucion" con total negativo = crédito a favor.
   * Cada línea sale a su costo FIFO (lo calcula StockService).
   */
  crearDevolucion(dto: CrearDevolucionBody) {
    const lineas = this.lineas(dto?.items, 'La devolución no tiene líneas.');
    if (lineas.some((l) => !l.prod)) throw new BadRequestException('Cada línea de la devolución debe ser un producto del catálogo.');
    const prov = this.validarProv(dto?.prov);
    if (!prov) throw new BadRequestException('Indica a qué proveedor se devuelve.');
    const motivo = (typeof dto?.motivo === 'string' && dto.motivo.trim()) ? dto.motivo.trim().slice(0, 200) : 'Devolución a proveedor';
    const now = ahora();
    const id = nuevoId();
    const clienteId = this.ctx.clienteId;
    let total = 0;
    this.db.transaction(() => {
      for (const l of lineas) {
        // No se devuelve más de lo que hay: eso dejaría un crédito por mercadería que no existe.
        const p = this.productos.obtener(l.prod as string);
        if (l.qty > Math.max(p.stock, 0)) throw new BadRequestException(`No puedes devolver más "${p.nombre}" del que tienes (${Math.max(p.stock, 0)}).`);
        this.stock.mover({ clienteId, productoId: l.prod as string, tipo: 'devolucion', cantidad: -l.qty, refId: id, motivo });
      }
      total = Math.round((this.db.prepare('SELECT COALESCE(SUM(-cantidad*costo_unit),0) AS t FROM movimientos_stock WHERE cliente_id=? AND ref_id=? AND tipo=?')
        .get(clienteId, id, 'devolucion') as { t: number }).t);
      this.compras.crear({ id, proveedor: this.nombreProv(prov), tipo: 'Devolucion', fecha: fechaCL(now), items: lineas.length, total: -total, createdAt: now });
    })();
    return { ok: true, id, total };
  }
}
