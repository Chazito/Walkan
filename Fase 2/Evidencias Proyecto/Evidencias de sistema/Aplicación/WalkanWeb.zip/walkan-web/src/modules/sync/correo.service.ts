// Envío de correos por SMTP: comprobantes de venta para el cliente final y avisos de Walkan a los dueños.
import { Inject, Injectable, Logger } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ahora, nuevoId } from '../../common/util/id';
import { fechaCL, horaCL } from '../../common/util/fecha';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';

// Correos de comprobante por negocio en una hora (un almacén normal manda unos pocos).
const MAX_CORREOS_HORA = 60;
const MEDIOS: Record<string, string> = { EFECTIVO: 'Efectivo', TARJETA: 'Tarjeta', TRANSFERENCIA: 'Transferencia' };
// clp: formato de pesos chilenos. esc: escapa HTML, porque nombres de productos y negocio van dentro del correo.
const clp = (n: number) => '$' + Math.round(n || 0).toLocaleString('es-CL');
const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));

/**
 * Envío del comprobante por correo (como el "te lo mandamos al correo" de los supermercados).
 * La caja lo pide en su outbox ("correo_comprobante") y la nube lo envía al sincronizar.
 * Con SMTP_* en el .env se envía de verdad (nodemailer); sin eso queda registrado como "simulado".
 */
@Injectable()
export class CorreoService {
  private readonly logger = new Logger('Correo');
  private transporte: any = null;

  constructor(@Inject(SQLITE) private readonly db: Database.Database, @Inject(CONFIG) private readonly cfg: AppConfig) {
    const s = cfg.smtp;
    if (s.host && s.user && s.pass) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const nodemailer = require('nodemailer');
        this.transporte = nodemailer.createTransport({ host: s.host, port: s.port, secure: s.port === 465, auth: { user: s.user, pass: s.pass } });
      } catch {
        this.logger.warn('nodemailer no está instalado (npm install): los correos quedan como "simulado".');
      }
    }
  }

  /** Busca la venta por caja + folio y envía el comprobante. Nunca lanza: un correo fallido no frena la sincronización. */
  async enviarComprobante(cajaId: string, clienteId: string, folio: string, email: string): Promise<void> {
    const correo = String(email ?? '').trim().toLowerCase().slice(0, 120);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) return;
    const v = this.db.prepare('SELECT * FROM ventas WHERE caja_id=? AND folio=? ORDER BY created_at DESC LIMIT 1').get(cajaId, String(folio)) as any;
    const id = nuevoId();
    this.db.prepare('INSERT INTO comprobantes_correo (id, venta_id, cliente_id, email, estado, detalle, created_at) VALUES (?,?,?,?,?,?,?)')
      .run(id, v?.id ?? null, clienteId, correo, 'pendiente', v ? null : `Venta ${folio} no encontrada`, ahora());
    if (!v) return this.marcar(id, 'error', `Venta ${folio} no encontrada`);
    // Tope por negocio: un token de caja robado no debe poder usar nuestro SMTP para mandar spam (S11).
    const haceUnaHora = new Date(Date.now() - 3600_000).toISOString();
    const n = (this.db.prepare('SELECT COUNT(*) n FROM comprobantes_correo WHERE cliente_id=? AND created_at>?').get(clienteId, haceUnaHora) as { n: number }).n;
    if (n > MAX_CORREOS_HORA) return this.marcar(id, 'error', `Tope de ${MAX_CORREOS_HORA} correos por hora alcanzado`);
    const negocio = this.db.prepare('SELECT negocio, rut FROM clientes WHERE id=?').get(clienteId) as { negocio: string; rut: string | null } | undefined;
    const html = this.html(v, negocio);
    const asunto = `Tu comprobante de compra en ${negocio?.negocio ?? 'Walkan'} (N.º ${v.folio})`;
    if (!this.transporte) {
      this.logger.log(`[simulado] Comprobante ${v.folio} por correo`);
      return this.marcar(id, 'simulado', 'SMTP no configurado');
    }
    try {
      await this.transporte.sendMail({ from: this.cfg.smtp.from || this.cfg.smtp.user, to: correo, subject: asunto, html });
      this.logger.log(`Comprobante ${v.folio} enviado por correo`);
      this.marcar(id, 'enviado', null);
    } catch (e) {
      this.logger.warn(`No se pudo enviar el comprobante ${v.folio}: ${(e as Error).message}`);
      this.marcar(id, 'error', (e as Error).message.slice(0, 200));
    }
  }

  /**
   * Correo de Walkan a un dueño (aviso de vencimiento del plan, cierre de cuenta). Nunca lanza.
   * Sin SMTP configurado queda en el log como "simulado", igual que los comprobantes.
   */
  async enviarAviso(para: string, asunto: string, html: string): Promise<'enviado' | 'simulado' | 'error'> {
    if (!this.transporte) { this.logger.log(`[simulado] Aviso por correo: ${asunto}`); return 'simulado'; }
    try {
      await this.transporte.sendMail({ from: this.cfg.smtp.from || this.cfg.smtp.user, to: para, subject: asunto, html });
      this.logger.log(`Aviso enviado por correo: ${asunto}`);
      return 'enviado';
    } catch (e) {
      this.logger.warn(`No se pudo enviar el aviso "${asunto}": ${(e as Error).message}`);
      return 'error';
    }
  }

  // Deja en comprobantes_correo cómo terminó el envío (enviado, simulado o error).
  private marcar(id: string, estado: string, detalle: string | null) {
    this.db.prepare('UPDATE comprobantes_correo SET estado=?, detalle=? WHERE id=?').run(estado, detalle, id);
  }

  // Arma el comprobante en HTML: una línea por producto, neto, IVA y total, y cómo se pagó.
  private html(v: any, negocio?: { negocio: string; rut: string | null }) {
    const items: [string, number, number][] = JSON.parse(v.items_json || '[]');
    const pago = v.pago_json ? JSON.parse(v.pago_json) : {};
    const fila = (a: string, b: string, fuerte = false) =>
      `<tr><td style="padding:4px 0;${fuerte ? 'font-weight:700' : ''}">${a}</td><td style="padding:4px 0;text-align:right;${fuerte ? 'font-weight:700' : ''}">${b}</td></tr>`;
    const lineas = items.map(([n, q, p]) => fila(`${esc(n)} <span style="color:#666">× ${Number(q)}</span>`, clp(q * p))).join('');
    const extra = [
      /^Flow/.test(pago.terminal || '') ? esc(String(pago.terminal).replace('Flow QR', 'QR Flow')) : '',
      pago.autorizacion ? `${/^Flow/.test(pago.terminal || '') ? 'Orden' : 'Autorización'} ${esc(pago.autorizacion)}` : '',
      pago.recibido != null ? `Recibido ${clp(pago.recibido)} · Vuelto ${clp(pago.vuelto ?? 0)}` : '',
    ].filter(Boolean).join(' · ');
    return `<!doctype html><html lang="es"><body style="margin:0;background:#f4f6f5;font-family:Arial,Helvetica,sans-serif;color:#111">
<div style="max-width:440px;margin:24px auto;background:#fff;border-radius:12px;padding:24px;border:1px solid #e3e7e5">
  <h2 style="margin:0 0 2px">${esc(negocio?.negocio || 'Walkan')}</h2>
  ${negocio?.rut ? `<div style="color:#666;font-size:13px">RUT ${esc(negocio.rut)}</div>` : ''}
  <p style="margin:16px 0 4px;font-size:15px"><b>Comprobante de venta N.º ${esc(v.folio)}</b></p>
  <div style="color:#666;font-size:13px">${fechaCL(v.fecha).split('-').reverse().join('-')} ${horaCL(v.fecha)}${v.cajero ? ' · Atendido por ' + esc(v.cajero) : ''}</div>
  <table style="width:100%;border-collapse:collapse;margin:16px 0;border-top:1px dashed #ccc;border-bottom:1px dashed #ccc;font-size:14px">${lineas}</table>
  <table style="width:100%;border-collapse:collapse;font-size:14px">${fila('Neto', clp(v.neto))}${fila('IVA (19%)', clp(v.iva))}${fila('Total', clp(v.total), true)}</table>
  <p style="font-size:13px;color:#444;margin:14px 0 0">Pago: ${esc(MEDIOS[v.medio_pago] || v.medio_pago || '')}${extra ? ' · ' + extra : ''}</p>
  <p style="font-size:12px;color:#888;margin:18px 0 0">Gracias por tu compra. Comprobante enviado por Walkan.</p>
</div></body></html>`;
  }
}
