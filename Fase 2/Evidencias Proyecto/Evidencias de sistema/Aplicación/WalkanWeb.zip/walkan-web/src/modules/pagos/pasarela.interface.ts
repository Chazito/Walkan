// urlConfirmacion la llama la pasarela por detrás (servidor a servidor);
// urlRetorno es adonde vuelve el navegador del cliente después de pagar.
export interface CrearPagoInput {
  orden: string;
  asunto: string;
  monto: number;
  email: string;
  urlConfirmacion: string;
  urlRetorno: string;
}
export interface PagoCreado { url: string; token: string; ordenFlow?: string; }
export interface EstadoPago { pagado: boolean; estado: string; raw: unknown; orden?: string; monto?: number; }

/** Pagado Y por lo que cobramos: la orden y el monto que informa la pasarela calzan con los nuestros.
 *  Sin esto, un pago real pero de otra orden (o de $1) podría activar un plan. */
export function pagoCalza(e: EstadoPago, orden: string, monto: number): boolean {
  return e.pagado && e.orden === orden && Math.round(Number(e.monto)) === Math.round(monto);
}

/** Abstracción de la pasarela de pago (Flow ahora; intercambiable). */
export interface PasarelaPago {
  crearPago(i: CrearPagoInput): Promise<PagoCreado>;
  estadoPago(token: string): Promise<EstadoPago>;
  /** Estado por nuestro número de orden (sirve aunque no tengamos el token). */
  estadoPorOrden?(orden: string): Promise<EstadoPago>;

  // ---- Cobro automático con tarjeta inscrita (Flow "Cargo Automático"; hay que tenerlo contratado en Flow) ----
  /** Crea el cliente en la pasarela y devuelve su id (Flow: customerId). */
  crearCliente?(i: { nombre: string; email: string; externoId: string }): Promise<string>;
  /** Inicia la inscripción de tarjeta: URL a la que se manda al dueño. Al terminar, la pasarela llama a urlRetorno con un token. */
  inscribirTarjeta?(clienteId: string, urlRetorno: string): Promise<{ url: string; token: string }>;
  /** Resultado de la inscripción (con el token que llegó a urlRetorno). */
  estadoInscripcion?(token: string): Promise<{ inscrita: boolean; clienteId: string; marca: string; ultimos4: string }>;
  /** Cobra a la tarjeta inscrita. Lanza si el cliente no tiene tarjeta. */
  cobrarTarjeta?(i: { clienteId: string; orden: string; asunto: string; monto: number }): Promise<EstadoPago>;
  /** Quita la tarjeta inscrita (no se le cobra más automáticamente). */
  quitarTarjeta?(clienteId: string): Promise<void>;
}
export const PASARELA = Symbol('PASARELA');
