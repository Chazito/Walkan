// Cobro con QR vía la cuenta Flow del propio negocio: guarda sus llaves cifradas, crea los cobros y revisa si se pagaron.
import { BadRequestException, ForbiddenException, Inject, Injectable, Logger, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'crypto';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { ahora, nuevoId } from '../../common/util/id';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { FLOW_API, FlowCliente } from '../pagos/flow.cliente';
import { CajasRepository } from './cajas.repository';
import { AuthService } from '../auth/auth.service';
import { planCanon } from '../../common/util/planes';

type Entorno = 'sandbox' | 'produccion';
interface FilaCobro { id: string; cliente_id: string; caja_id: string; commerce_order: string; token: string | null; url: string | null; monto: number; estado: string; flow_order: string | null; medio: string | null }

/**
 * Pago automático con QR vía Flow, OPCIONAL por negocio. El dueño conecta su propia cuenta Flow en el panel
 * (la plata llega a su cuenta). La caja pide un cobro, muestra el QR con el enlace de pago y consulta el estado
 * hasta que Flow lo da por pagado. El comprador no necesita cuenta: paga en la página de Flow.
 */
@Injectable()
export class FlowNegocioService {
  private readonly logger = new Logger('FlowNegocio');
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly ctx: ContextoTenant,
    private readonly cajas: CajasRepository,
    @Inject(CONFIG) private readonly cfg: AppConfig,
    private readonly auth: AuthService,
  ) {}

  // ---- Cifrado de la secretKey (la llave sale de SESSION_SECRET, que no está en la base) ----
  private llave() { return createHash('sha256').update(this.cfg.sessionSecret + ':flow-negocio').digest(); }
  private cifrar(texto: string): string {
    const iv = randomBytes(12); const c = createCipheriv('aes-256-gcm', this.llave(), iv);
    const enc = Buffer.concat([c.update(texto, 'utf8'), c.final()]);
    return [iv, c.getAuthTag(), enc].map((b) => b.toString('base64')).join('.');
  }
  private descifrar(guardado: string): string {
    const [iv, tag, enc] = guardado.split('.').map((s) => Buffer.from(s, 'base64'));
    const d = createDecipheriv('aes-256-gcm', this.llave(), iv); d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
  }

  private admin(): string {
    if (this.ctx.rol !== 'admin') throw new ForbiddenException('Solo el dueño del negocio puede conectar Flow.');
    return this.ctx.clienteId;
  }

  // Arma el cliente de Flow con las llaves del negocio, o null si no conectó Flow.
  private cliente(clienteId: string): FlowCliente | null {
    const r = this.db.prepare('SELECT flow_api_key, flow_secret_cifrada, flow_entorno FROM clientes WHERE id=?').get(clienteId) as any;
    if (!r?.flow_api_key || !r?.flow_secret_cifrada) return null;
    try {
      const entorno: Entorno = r.flow_entorno === 'produccion' ? 'produccion' : 'sandbox';
      return new FlowCliente({ apiUrl: FLOW_API[entorno], apiKey: r.flow_api_key, secretKey: this.descifrar(r.flow_secret_cifrada) });
    } catch { return null; } // cambió SESSION_SECRET: hay que volver a conectar
  }

  /** Para la caja (con el catálogo): ¿este negocio cobra con QR de Flow? */
  activo(clienteId: string): boolean { return !!this.cliente(clienteId); }

  // ---- Panel ----
  // Nunca devuelve la secretKey; del apiKey solo muestra el comienzo y el final.
  estadoConexion() {
    const cid = this.admin();
    const r = this.db.prepare('SELECT flow_api_key, flow_entorno FROM clientes WHERE id=?').get(cid) as any;
    const k: string = r?.flow_api_key ?? '';
    return { conectado: !!this.cliente(cid), entorno: r?.flow_entorno || 'sandbox', apiKey: k ? k.slice(0, 6) + '…' + k.slice(-4) : '' };
  }

  // Antes de guardar las llaves se prueban contra Flow, así no queda guardada una conexión rota.
  async conectar(body: { apiKey?: string; secretKey?: string; entorno?: string }) {
    const cid = this.admin();
    const apiKey = String(body?.apiKey ?? '').trim(); const secretKey = String(body?.secretKey ?? '').trim();
    const entorno: Entorno = body?.entorno === 'produccion' ? 'produccion' : 'sandbox';
    if (!/^[A-Za-z0-9-]{10,80}$/.test(apiKey) || !/^[A-Za-z0-9]{10,80}$/.test(secretKey)) {
      throw new BadRequestException('Revisa las llaves: copia el API Key y el Secret Key tal como aparecen en tu cuenta Flow.');
    }
    const prueba = await new FlowCliente({ apiUrl: FLOW_API[entorno], apiKey, secretKey }).probar();
    if (!prueba.ok) throw new BadRequestException(`Flow no aceptó las llaves (${prueba.detalle}). Revisa que sean del entorno ${entorno}.`);
    this.db.prepare('UPDATE clientes SET flow_api_key=?, flow_secret_cifrada=?, flow_entorno=?, updated_at=? WHERE id=?')
      .run(apiKey, this.cifrar(secretKey), entorno, ahora(), cid);
    return this.estadoConexion();
  }

  desconectar() {
    const cid = this.admin();
    this.db.prepare('UPDATE clientes SET flow_api_key=NULL, flow_secret_cifrada=NULL, flow_entorno=NULL, updated_at=? WHERE id=?').run(ahora(), cid);
    return this.estadoConexion();
  }

  // ---- Caja (autenticada con su token) ----
  // Identifica la caja por su token; una caja bloqueada no puede cobrar.
  private caja(token: string) {
    const c = token ? this.cajas.porToken(token) : undefined;
    if (!c) throw new UnauthorizedException('Token de caja inválido.');
    if (c.estado === 'bloqueada') throw new ForbiddenException('Caja bloqueada.');
    return c;
  }

  // Crea el cobro en nuestra tabla y en Flow; devuelve la URL que la caja muestra como QR. Si Flow falla, el cobro queda anulado.
  async crearCobro(token: string, monto: number) {
    const caja = this.caja(token);
    // Cuenta en pausa o suspendida: no se cobra con QR (la caja sigue vendiendo con los otros medios de pago).
    if (!this.auth.cuentaOperativa(caja.cliente_id)) throw new ForbiddenException('La cuenta del negocio está en pausa: el cobro con QR no está disponible.');
    // El cobro con QR es parte de los planes Profesional y Empresa.
    const plan = planCanon((this.db.prepare('SELECT plan FROM clientes WHERE id=?').get(caja.cliente_id) as { plan: string } | undefined)?.plan);
    if (!this.cfg.planes[plan]?.funciones.cobroQr) throw new ForbiddenException(`El cobro con QR no está incluido en el plan ${plan}.`);
    const m = Math.round(Number(monto));
    if (!Number.isFinite(m) || m < 350 || m > 50_000_000) throw new BadRequestException('Monto fuera de rango para cobrar con Flow (mínimo $350).');
    const flow = this.cliente(caja.cliente_id);
    if (!flow) throw new BadRequestException('Este negocio no tiene Flow conectado.');
    const neg = this.db.prepare('SELECT negocio, email FROM clientes WHERE id=?').get(caja.cliente_id) as { negocio: string; email: string | null };
    const dueno = this.db.prepare("SELECT email FROM usuarios WHERE cliente_id=? AND rol='admin' ORDER BY created_at LIMIT 1").get(caja.cliente_id) as { email: string } | undefined;
    const email = neg?.email || dueno?.email;
    if (!email) throw new BadRequestException('El negocio no tiene correo registrado (Flow lo exige).');
    const id = nuevoId(); const orden = 'WKQ-' + id.replace(/-/g, '').slice(0, 16); const now = ahora();
    this.db.prepare(`INSERT INTO cobros_qr (id, cliente_id, caja_id, commerce_order, monto, estado, created_at, updated_at)
      VALUES (?,?,?,?,?,'pendiente',?,?)`).run(id, caja.cliente_id, caja.id, orden, m, now, now);
    try {
      const p = await flow.crearPago({
        orden, asunto: `Compra en ${neg?.negocio || 'Walkan'}`, monto: m, email,
        urlConfirmacion: `${this.cfg.appUrl}/api/flow/cobro-qr/confirmacion`, urlRetorno: `${this.cfg.appUrl}/pago-qr`,
      });
      this.db.prepare('UPDATE cobros_qr SET token=?, url=?, flow_order=?, updated_at=? WHERE id=?').run(p.token, p.url, p.flowOrder, ahora(), id);
      this.logger.log(`Cobro QR ${orden} por $${m} (caja ${caja.id})`);
      return { id, url: p.url, monto: m, estado: 'pendiente' };
    } catch (e) {
      this.db.prepare("UPDATE cobros_qr SET estado='anulado', updated_at=? WHERE id=?").run(ahora(), id);
      throw new BadRequestException('Flow no pudo crear el cobro: ' + (e as Error).message);
    }
  }

  private fila(cajaId: string, id: string): FilaCobro {
    const f = this.db.prepare('SELECT * FROM cobros_qr WHERE id=? AND caja_id=?').get(id, cajaId) as FilaCobro | undefined;
    if (!f) throw new NotFoundException('Cobro no encontrado.');
    return f;
  }

  /** Consulta el estado en Flow (si sigue pendiente) y lo devuelve. */
  async estadoCobro(token: string, id: string) {
    const caja = this.caja(token);
    const f = await this.actualizar(this.fila(caja.id, id));
    return { id: f.id, estado: f.estado, monto: f.monto, flowOrder: f.flow_order, medio: f.medio };
  }

  // Pregunta a Flow y, si el estado ya no es 'pendiente', lo guarda.
  private async actualizar(f: FilaCobro): Promise<FilaCobro> {
    if (f.estado !== 'pendiente' || !f.token) return f;
    const flow = this.cliente(f.cliente_id);
    if (!flow) return f;
    try {
      const e = await flow.estado(f.token);
      // Pagado solo si la orden y el monto que informa Flow son los del cobro (S9).
      const calza = e.orden === f.commerce_order && Math.round(e.monto) === Math.round(f.monto);
      if (e.status === 2 && !calza) { this.logger.warn(`Cobro QR ${f.commerce_order}: Flow informa otra orden o monto`); return f; }
      const estado = e.status === 2 ? 'pagado' : e.status === 3 ? 'rechazado' : e.status === 4 ? 'anulado' : 'pendiente';
      if (estado !== 'pendiente') {
        this.db.prepare('UPDATE cobros_qr SET estado=?, flow_order=COALESCE(?, flow_order), medio=?, updated_at=? WHERE id=?')
          .run(estado, e.flowOrder || null, e.medio || null, ahora(), f.id);
        this.logger.log(`Cobro QR ${f.commerce_order}: ${estado}`);
        return { ...f, estado, flow_order: e.flowOrder || f.flow_order, medio: e.medio || null };
      }
    } catch (err) { this.logger.warn(`No se pudo consultar Flow (${f.commerce_order}): ${(err as Error).message}`); }
    return f;
  }

  anularCobro(token: string, id: string) {
    const caja = this.caja(token);
    const f = this.fila(caja.id, id);
    if (f.estado === 'pendiente') this.db.prepare("UPDATE cobros_qr SET estado='anulado', updated_at=? WHERE id=?").run(ahora(), f.id);
    return { ok: true };
  }

  /** Confirmación de Flow (POST con token). Solo actualiza el estado consultando a Flow; no confía en el cuerpo. */
  async confirmacion(token: string) {
    const f = this.db.prepare('SELECT * FROM cobros_qr WHERE token=?').get(String(token ?? '')) as FilaCobro | undefined;
    if (f) await this.actualizar(f);
    return { ok: true };
  }
}
