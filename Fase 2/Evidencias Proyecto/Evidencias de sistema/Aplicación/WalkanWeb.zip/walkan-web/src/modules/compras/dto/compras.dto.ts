// Interfaces (sin validación de clase) para no recortar items anidados; se validan a mano
// en ComprasService. Un pedido es "lo que encargué", una compra es "lo que llegó y suma stock".
// En ItemPedido, prod null = producto que todavía no existe en el catálogo.
// lote/vence solo importan al recibir o ingresar: si el producto controla vencimiento, vence es obligatorio.
export interface ItemPedido { prod: string | null; nombre: string; qty: number; costo: number; lote?: string | null; vence?: string | null; }
export interface CrearPedidoBody { prov?: string; nota?: string; borrador?: boolean; items: ItemPedido[]; }
export interface RecibirPedidoBody { items?: ItemPedido[]; }
export interface LineaCompra { prod: string; qty: number; costo?: number; lote?: string; vence?: string; }
export interface CrearCompraBody { prov: string; items: LineaCompra[]; }
// Devolución al proveedor: qué productos vuelven y por qué (motivo común a todas las líneas).
export interface CrearDevolucionBody { prov: string; motivo?: string; items: { prod: string; qty: number }[]; }
