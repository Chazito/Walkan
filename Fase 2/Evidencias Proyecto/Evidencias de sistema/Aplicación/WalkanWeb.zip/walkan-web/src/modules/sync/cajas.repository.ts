// Acceso a la tabla cajas: enrolar una caja, encontrarla por su token y marcar hasta dónde sincronizó.
import { Inject, Injectable } from '@nestjs/common';
import { createHash } from 'crypto';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';

type Fila = Record<string, any>;

// La BD guarda sha256 del token de la caja, no el token (S10): si alguien copia la BD no puede hacerse
// pasar por una caja. El token tiene 192 bits aleatorios, así que un sha256 simple basta (no hace falta scrypt).
const hashToken = (t: string) => 'h:' + createHash('sha256').update(t).digest('hex');

@Injectable()
export class CajasRepository {
  // Igual que ventas: sin ContextoTenant, porque la caja se identifica por su token y no por sesión.
  // `listar` trae todas (vista de staff); el panel del cliente usa listarPorCliente.
  private list!: Database.Statement;
  private byToken!: Database.Statement;
  private byId!: Database.Statement;
  private setSync!: Database.Statement;
  private setEstado!: Database.Statement;
  private ins!: Database.Statement;

  private listCliente!: Database.Statement;

  constructor(@Inject(SQLITE) private readonly db: Database.Database) {
    this.list = db.prepare('SELECT * FROM cajas ORDER BY nombre ASC');
    this.listCliente = db.prepare('SELECT * FROM cajas WHERE cliente_id=? ORDER BY nombre ASC');
    this.byToken = db.prepare('SELECT * FROM cajas WHERE token=?');
    this.byId = db.prepare('SELECT * FROM cajas WHERE id=?');
    // ultimo_seq = hasta dónde llegó la caja; se le devuelve en cada sync para que sepa qué ya entró.
    this.setSync = db.prepare('UPDATE cajas SET ultimo_seq=@seq, ultima_sync=@now, updated_at=@now WHERE id=@id');
    this.setEstado = db.prepare('UPDATE cajas SET estado=@estado, updated_at=@now WHERE id=@id');
    this.ins = db.prepare(`INSERT INTO cajas (id,nombre,token,usuario_id,cliente_id,estado,ultimo_seq,ultima_sync,created_at,updated_at)
      VALUES (@id,@nombre,@token,@usuarioId,@clienteId,'activa',0,NULL,@now,@now)`);
    // Cajas enroladas antes de este cambio: su token en claro ('wk_...') pasa a hash una sola vez al arrancar.
    // La caja sigue mandando el mismo token, así que no hay que re-vincular nada.
    const viejas = db.prepare("SELECT id, token FROM cajas WHERE substr(token, 1, 3) = 'wk_'").all() as { id: string; token: string }[];
    if (viejas.length) {
      const up = db.prepare('UPDATE cajas SET token=? WHERE id=?');
      db.transaction(() => { for (const c of viejas) up.run(hashToken(c.token), c.id); })();
    }
  }
  // El token entra hasheado: en claro no se guarda nunca.
  crear(c: { id: string; nombre: string; token: string; usuarioId: string; clienteId: string; now: string }): void { this.ins.run({ ...c, token: hashToken(c.token) }); }
  existeId(id: string): boolean { return !!this.byId.get(id); }
  listar(): Fila[] { return this.list.all() as Fila[]; }
  listarPorCliente(clienteId: string): Fila[] { return this.listCliente.all(clienteId) as Fila[]; }
  // Hashea el token que manda la caja antes de buscarlo.
  porToken(token: string): Fila | undefined { return this.byToken.get(hashToken(String(token))) as Fila | undefined; }
  porId(id: string): Fila | undefined { return this.byId.get(id) as Fila | undefined; }
  marcarSync(id: string, seq: number, now: string): void { this.setSync.run({ id, seq, now }); }
  setEstadoCaja(id: string, estado: string, now: string): void { this.setEstado.run({ id, estado, now }); }
}
