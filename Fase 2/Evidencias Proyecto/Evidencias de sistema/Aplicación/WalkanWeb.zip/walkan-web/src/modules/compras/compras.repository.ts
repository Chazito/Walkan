// Acceso a la tabla de compras, siempre filtrado por el negocio de la sesión.
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';

// Historial de compras. `items` se guarda como texto (JSON) tal cual; acá no se interpreta.
// cliente_id siempre sale del contexto de la request, nunca del body: así nadie escribe en otra tienda.
type Fila = Record<string, any>;
const map = (r: Fila) => ({ id: r.id, prov: r.proveedor, tipo: r.tipo, fecha: r.fecha, items: r.items, total: r.total });

@Injectable()
export class ComprasRepository {
  private ins!: Database.Statement; private list!: Database.Statement;
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly ctx: ContextoTenant,
  ) {
    this.ins = db.prepare(`INSERT INTO compras (id,proveedor,tipo,fecha,items,total,cliente_id,created_at)
      VALUES (@id,@proveedor,@tipo,@fecha,@items,@total,@clienteId,@createdAt)`);
    this.list = db.prepare('SELECT * FROM compras WHERE cliente_id=@clienteId ORDER BY created_at DESC');
  }
  crear(c: any): void { this.ins.run({ ...c, clienteId: this.ctx.clienteId }); }
  listar() { return (this.list.all({ clienteId: this.ctx.clienteId }) as Fila[]).map(map); }
}
