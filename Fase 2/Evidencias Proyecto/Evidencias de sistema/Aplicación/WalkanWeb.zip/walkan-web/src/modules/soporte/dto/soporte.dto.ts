// Bodies de los tickets de soporte: los del panel, los públicos, las respuestas y el cambio de estado.
import { IsEmail, IsIn, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { Rut } from '../../../common/util/rut';
import { IDS_CATEGORIA } from '../categorias';

const msgCat = { message: 'Elige una categoría.' };

/** Ticket desde el panel (con sesión): el negocio y el correo salen de la sesión. */
export class NuevoTicketDto {
  @IsIn(IDS_CATEGORIA, msgCat) categoria!: string;
  @IsString() @MinLength(4, { message: 'Escribe un asunto (al menos 4 letras).' }) @MaxLength(120) asunto!: string;
  @IsString() @MinLength(10, { message: 'Cuéntanos un poco más (al menos 10 letras).' }) @MaxLength(4000, { message: 'El mensaje es muy largo (máximo 4.000 caracteres).' }) mensaje!: string;
}

/** Ticket sin sesión (/ayuda/contacto): para quien no puede entrar. RUT y orden de pago ayudan a verificar que es el dueño. */
export class TicketPublicoDto extends NuevoTicketDto {
  @IsString() @MinLength(2, { message: 'Escribe tu nombre.' }) @MaxLength(80) nombre!: string;
  @IsEmail({}, { message: 'Escribe un correo válido.' }) @MaxLength(120) email!: string;
  @IsOptional() @IsString() @MaxLength(20) @Rut() rut?: string;
  @IsOptional() @IsString() @MaxLength(40) ordenPago?: string;
  /** Campo trampa: invisible para las personas. Si viene lleno, es un robot. */
  @IsOptional() @IsString() @MaxLength(200) web?: string;
}

// Un mensaje dentro de la conversación de un ticket.
export class MensajeTicketDto {
  @IsString() @MinLength(2, { message: 'Escribe tu mensaje.' }) @MaxLength(4000, { message: 'El mensaje es muy largo (máximo 4.000 caracteres).' }) texto!: string;
}

// Respuesta del equipo Walkan: de paso puede cambiar el estado del ticket.
export class RespuestaEquipoDto extends MensajeTicketDto {
  @IsOptional() @IsIn(['abierto', 'en_curso', 'resuelto']) estado?: string;
}

export class EstadoTicketDto {
  @IsIn(['abierto', 'en_curso', 'resuelto']) estado!: string;
}
