// Endpoints de /api/soporte: crear tickets (con o sin sesión) y ver o responder los del negocio.
import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { Limite } from '../../common/limite';
import { SesionGuard } from '../auth/auth.guard';
import { MensajeTicketDto, NuevoTicketDto, TicketPublicoDto } from './dto/soporte.dto';
import { SoporteService } from './soporte.service';

// Soporte para los clientes. La bandeja del equipo Walkan está en admin/soporte-admin.controller.ts.
@Controller('api/soporte')
export class SoporteController {
  constructor(private readonly srv: SoporteService) {}

  // Sin sesión: para quien no puede entrar. Tope bajo por IP (cualquiera puede tocar esta puerta).
  @Post('publico')
  @Limite(5)
  publico(@Body() dto: TicketPublicoDto) { return this.srv.crearPublico(dto); }

  // ---- Con sesión: los tickets del negocio ----
  @Get('tickets')
  @UseGuards(SesionGuard)
  mios(@Req() req: any) { return this.srv.misTickets(req.usuario); }

  @Post('tickets')
  @Limite(10)
  @UseGuards(SesionGuard)
  crear(@Req() req: any, @Body() dto: NuevoTicketDto) { return this.srv.crearDesdePanel(req.usuario, dto); }

  @Get('tickets/:id')
  @UseGuards(SesionGuard)
  uno(@Req() req: any, @Param('id') id: string) { return this.srv.miTicket(req.usuario, id); }

  // El dueño contesta dentro del ticket (si estaba resuelto, se reabre).
  @Post('tickets/:id/responder')
  @Limite(20)
  @UseGuards(SesionGuard)
  responder(@Req() req: any, @Param('id') id: string, @Body() dto: MensajeTicketDto) { return this.srv.responderCliente(req.usuario, id, dto.texto); }
}
