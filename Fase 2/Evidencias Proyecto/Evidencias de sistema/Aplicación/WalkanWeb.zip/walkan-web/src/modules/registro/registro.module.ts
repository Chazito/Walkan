// Módulo del alta autoservicio y del pago del plan (importa Pagos para hablar con Flow).
import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { PagosModule } from '../pagos/pagos.module';
import { PrivacidadModule } from '../privacidad/privacidad.module';
import { RegistroController } from './registro.controller';
import { RegistroRepository } from './registro.repository';
import { RegistroService } from './registro.service';

@Module({
  imports: [AuthModule, PagosModule, PrivacidadModule],
  controllers: [RegistroController],
  providers: [RegistroService, RegistroRepository],
  // Cuenta (cobro automático y conciliación) y Admin (pagos registrados por el staff) usan el servicio.
  exports: [RegistroService],
})
export class RegistroModule {}
