// Módulo de las vistas: junta el ViewsController con auth y recuperación de contraseña.
import { Module } from '@nestjs/common';
import { ViewsController } from './views.controller';
import { AuthModule } from '../auth/auth.module';
import { RecuperacionModule } from '../recuperacion/recuperacion.module';

// Sirve las páginas HTML del sitio; /panel y /admin revisan la sesión (AuthService) antes de mostrarse.
@Module({ imports: [AuthModule, RecuperacionModule], controllers: [ViewsController] })
export class ViewsModule {}
