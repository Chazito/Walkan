// Administración de los cajeros del negocio (crear, renombrar, cambiar PIN, activar/desactivar) y su entrega a las cajas.
import { BadRequestException, ConflictException, ForbiddenException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { ahora, nuevoId } from '../../common/util/id';
import { hashPin, PIN_VALIDO } from '../../common/util/pin';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { planCanon } from '../../common/util/planes';

interface FilaCajero { id: string; cliente_id: string; nombre: string; pin_hash: string; activo: number; created_at: string; updated_at: string }

/**
 * Cajeros del negocio, administrados por el dueño desde el panel (Mis cajas › Cajeros).
 * Las cajas los reciben en cada sincronización del catálogo y validan el PIN sin internet.
 * Cupo por plan (planCajeros): cuentan solo los activos; desactivar libera el cupo y conserva el historial.
 */
@Injectable()
export class CajerosService {
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly ctx: ContextoTenant,
    @Inject(CONFIG) private readonly cfg: AppConfig,
  ) {}

  // Solo el dueño (rol admin del negocio) administra cajeros.
  private cliente(): string {
    if (this.ctx.rol !== 'admin') throw new ForbiddenException('Solo el dueño del negocio puede administrar cajeros.');
    return this.ctx.clienteId;
  }

  // Plan del negocio, máximo de cajeros activos que permite y cuántos hay activos hoy.
  private cupo(clienteId: string) {
    const cli = this.db.prepare('SELECT plan FROM clientes WHERE id=?').get(clienteId) as { plan: string } | undefined;
    const plan = planCanon(cli?.plan);
    const max = this.cfg.planCajeros[plan] ?? 1;
    const activos = (this.db.prepare('SELECT COUNT(*) AS n FROM cajeros WHERE cliente_id=? AND activo=1').get(clienteId) as { n: number }).n;
    return { plan, max, activos };
  }

  // Lo que sale hacia el panel: nunca el hash del PIN.
  private publico = (c: FilaCajero) => ({ id: c.id, nombre: c.nombre, activo: !!c.activo, createdAt: c.created_at, updatedAt: c.updated_at });

  listar() {
    const cid = this.cliente();
    const filas = this.db.prepare('SELECT * FROM cajeros WHERE cliente_id=? ORDER BY activo DESC, nombre').all(cid) as FilaCajero[];
    return { cajeros: filas.map(this.publico), cupo: this.cupo(cid) };
  }

  private nombreLimpio(nombre: unknown): string {
    const n = String(nombre ?? '').trim().replace(/\s+/g, ' ');
    if (!n || n.length > 60) throw new BadRequestException('El nombre del cajero debe tener entre 1 y 60 caracteres.');
    return n;
  }
  private pinValido(pin: unknown): string {
    const p = String(pin ?? '');
    if (!PIN_VALIDO.test(p)) throw new BadRequestException('El PIN debe tener entre 4 y 8 dígitos.');
    return p;
  }
  // No puede haber dos cajeros activos con el mismo nombre (sin importar mayúsculas).
  private nombreLibre(cid: string, nombre: string, excepto?: string) {
    const otro = this.db.prepare('SELECT id FROM cajeros WHERE cliente_id=? AND activo=1 AND lower(nombre)=lower(?) AND id<>?')
      .get(cid, nombre, excepto ?? '') as { id: string } | undefined;
    if (otro) throw new ConflictException(`Ya tienes un cajero activo llamado "${nombre}".`);
  }
  // Falla si ya se llenó el cupo de cajeros activos del plan.
  private sinCupo(cid: string) {
    const c = this.cupo(cid);
    if (c.activos >= c.max) {
      throw new ForbiddenException(`Tu plan ${c.plan} incluye ${c.max} cajero(s) activo(s). Desactiva uno o mejora tu plan para agregar más.`);
    }
  }

  crear(body: { nombre?: string; pin?: string }) {
    const cid = this.cliente();
    const nombre = this.nombreLimpio(body?.nombre);
    const pin = this.pinValido(body?.pin);
    this.sinCupo(cid);
    this.nombreLibre(cid, nombre);
    const now = ahora();
    const fila: FilaCajero = { id: nuevoId(), cliente_id: cid, nombre, pin_hash: hashPin(pin), activo: 1, created_at: now, updated_at: now };
    this.db.prepare(`INSERT INTO cajeros (id, cliente_id, nombre, pin_hash, activo, created_at, updated_at)
      VALUES (@id, @cliente_id, @nombre, @pin_hash, @activo, @created_at, @updated_at)`).run(fila);
    return this.publico(fila);
  }

  /** Renombrar, cambiar PIN, desactivar o reactivar (cada campo es opcional). */
  actualizar(id: string, body: { nombre?: string; pin?: string; activo?: boolean }) {
    const cid = this.cliente();
    const c = this.db.prepare('SELECT * FROM cajeros WHERE id=? AND cliente_id=?').get(id, cid) as FilaCajero | undefined;
    if (!c) throw new NotFoundException('Cajero no encontrado.');
    const cambios: Partial<FilaCajero> = {};
    if (body?.nombre !== undefined) cambios.nombre = this.nombreLimpio(body.nombre);
    if (body?.pin !== undefined && body.pin !== '') cambios.pin_hash = hashPin(this.pinValido(body.pin));
    if (body?.activo !== undefined) {
      const activo = body.activo ? 1 : 0;
      if (activo && !c.activo) this.sinCupo(cid);
      cambios.activo = activo;
    }
    const quedaActivo = cambios.activo ?? c.activo;
    if (quedaActivo) this.nombreLibre(cid, cambios.nombre ?? c.nombre, c.id);
    const fila = { ...c, ...cambios, updated_at: ahora() };
    this.db.prepare('UPDATE cajeros SET nombre=@nombre, pin_hash=@pin_hash, activo=@activo, updated_at=@updated_at WHERE id=@id')
      .run(fila);
    return this.publico(fila);
  }

  /** Para la caja (GET /api/catalogo): incluye inactivos para que la caja los desactive; el PIN va solo como hash. */
  paraCaja(clienteId: string) {
    return (this.db.prepare('SELECT id, nombre, pin_hash, activo FROM cajeros WHERE cliente_id=? ORDER BY nombre').all(clienteId) as FilaCajero[])
      .map((c) => ({ id: c.id, nombre: c.nombre, pinHash: c.pin_hash, activo: !!c.activo }));
  }
}
