import { ArrayMaxSize, IsArray, IsBoolean, IsIn, IsInt, IsNumber, IsOptional, IsString, Length, Max, MaxLength, Min, NotEquals, ValidateBy, ValidateNested } from 'class-validator';
import { Transform, Type } from 'class-transformer';
import { fechaValida } from '../../../common/util/fecha';

// Vacío = sin vencimiento. Si viene, debe ser una fecha real: una fecha basura desordena el FEFO y esconde vencidos.
const EsFecha = () => ValidateBy({
  name: 'esFecha',
  validator: { validate: (v) => v === '' || (typeof v === 'string' && fechaValida(v)), defaultMessage: () => 'vence debe ser una fecha real AAAA-MM-DD' },
});
// Topes sanos para un almacén; evitan desbordar stock y totales.
const MAX_QTY = 1_000_000;
const MAX_PESOS = 100_000_000;
// Cantidades: enteras para productos por unidad, hasta 3 decimales (gramos) para los que van por kg. StockService valida la unidad.
const Cantidad = () => IsNumber({ maxDecimalPlaces: 3, allowNaN: false, allowInfinity: false });

export class ProductoDto {
  @IsString() @Length(1, 120) nombre!: string;
  @IsOptional() @IsString() @MaxLength(64) sku?: string;
  @IsOptional() @IsString() cat?: string;
  @IsOptional() @IsInt() @Min(0) @Max(MAX_PESOS) precio?: number;
  @IsOptional() @IsInt() @Min(0) @Max(MAX_PESOS) costo?: number;
  /** Solo se usa al crear (movimiento inicial). Después el stock cambia con ajustes. */
  @IsOptional() @Cantidad() @Min(-MAX_QTY) @Max(MAX_QTY) stock?: number;
  @IsOptional() @Cantidad() @Min(0) @Max(MAX_QTY) stockMin?: number | null;
  /** 'un' = por unidad; 'kg' = a granel (se pesa). */
  @IsOptional() @IsIn(['un', 'kg']) unidad?: 'un' | 'kg';
  /** Código corto de balanza (1..99999). Si es por kg y no viene, se asigna solo. */
  @IsOptional() @IsInt() @Min(1) @Max(99_999) plu?: number | null;
  /** Días que dura desde que entra (pan = 1). Si está, el vencimiento del lote se calcula solo. */
  @IsOptional() @IsInt() @Min(1) @Max(3650) vidaUtil?: number | null;
  /** Si es true, cada entrada de stock pide vencimiento y crea un lote (FEFO). */
  @IsOptional() @IsBoolean() controlaVence?: boolean;
  /** Vencimiento y código del lote del stock inicial (solo al crear). productos.vence es derivado de los lotes. */
  @IsOptional() @EsFecha() vence?: string;
  @IsOptional() @IsString() @MaxLength(40) lote?: string;
  @IsOptional() @IsString() prov?: string;
  @IsOptional() @IsString() emoji?: string;
  // ~200 KB de imagen en base64 (el panel la reduce antes de enviarla).
  @IsOptional() @IsString() @MaxLength(280_000, { message: 'La imagen es muy grande (máx. ~200 KB).' }) img?: string;
}

// Entrada de mercadería: siempre suma. Si trae costo, actualiza el costo del producto.
export class IngresoDto {
  @Cantidad() @Min(0.001) @Max(MAX_QTY) cantidad!: number;
  @IsOptional() @IsInt() @Min(0) @Max(MAX_PESOS) costo?: number;
  @IsOptional() @EsFecha() vence?: string;
  @IsOptional() @IsString() @MaxLength(40) lote?: string;
}

// Ajuste manual (merma, conteo, etc.): puede ser negativo, pero nunca 0, y el motivo es obligatorio para la auditoría.
/** Parámetros de inventario del negocio (umbral de stock bajo y días de la reposición sugerida). */
export class ConfigInventarioDto {
  @IsInt() @Min(0) @Max(100_000) umbralBajo!: number;
  @IsInt() @Min(0) @Max(30) diasSeguridad!: number;
  @IsInt() @Min(1) @Max(60) diasCobertura!: number;
  @IsOptional() @IsBoolean() costoConIva?: boolean;
}

/** Corrección de un lote mal ingresado (código o vencimiento). No cambia cantidades. */
export class LoteDto {
  @IsOptional() @IsString() @MaxLength(40) codigo?: string;
  @EsFecha() vence!: string;
}

// Retirar un lote completo: el motivo es opcional (por defecto, vencimiento).
export class RetirarLoteDto {
  // Se recorta antes de validar: "   " no pasa como motivo (si no, caería al motivo por defecto sin avisar).
  @IsOptional() @Transform(({ value }) => typeof value === 'string' ? value.trim() : value) @IsString() @Length(3, 200) motivo?: string;
}

export class AjusteDto {
  @Cantidad() @NotEquals(0) @Min(-MAX_QTY) @Max(MAX_QTY) cantidad!: number;
  @IsString() @Length(3, 200) motivo!: string;
  // Solo para ajustes de entrada en productos que controlan vencimiento (crean un lote).
  @IsOptional() @EsFecha() vence?: string;
  @IsOptional() @IsString() @MaxLength(40) lote?: string;
}

// Carga masiva (importar CSV): hasta 500 productos por request (el panel manda en tandas), en una transacción.
export class ImportarDto {
  @IsArray() @ArrayMaxSize(500) @ValidateNested({ each: true }) @Type(() => ProductoDto) productos!: ProductoDto[];
}

// Cambio de precios en bloque (％ Precios): solo el precio de venta de cada producto.
export class PrecioCambioDto {
  @IsString() @MaxLength(64) id!: string;
  @IsInt() @Min(0) @Max(MAX_PESOS) precio!: number;
}
export class PreciosDto {
  @IsArray() @ArrayMaxSize(5000) @ValidateNested({ each: true }) @Type(() => PrecioCambioDto) cambios!: PrecioCambioDto[];
}
