// Endpoints del panel admin de Walkan: clientes, solicitudes, flota de cajas, equipo y bitácora.
import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { StaffGuard } from './staff.guard';
import { ClientesService } from './clientes.service';
import { SolicitudesService } from '../solicitudes/solicitudes.service';
import { SyncService } from '../sync/sync.service';
import { RegistroService } from '../registro/registro.service';
import { ProvisionarClienteDto } from './dto/provisionar-cliente.dto';
import { CrearStaffDto, NivelStaffDto } from './dto/equipo.dto';
import { SuperAdminGuard } from './super-admin.guard';
import { EquipoService } from './equipo.service';
import { BitacoraService } from './bitacora.service';

// Quién hace la acción (id y correo), para dejarlo anotado en la bitácora.
const actor = (req: any) => ({ id: req?.usuario?.id, email: req?.usuario?.email });

// Panel de administración de Walkan (staff). Todo bajo StaffGuard.
@Controller('api/admin')
@UseGuards(StaffGuard)
export class AdminController {
  constructor(
    private readonly clientes: ClientesService,
    private readonly solicitudes: SolicitudesService,
    private readonly sync: SyncService,
    private readonly registro: RegistroService,
    private readonly equipo: EquipoService,
    private readonly bitacora: BitacoraService,
  ) {}

  // KPIs de la portada del admin: clientes/solicitudes + estado de toda la flota de cajas.
  @Get('resumen')
  resumen() {
    const kpis = this.clientes.resumen();
    const cajas = this.sync.listarTodasLasCajas();
    return {
      ...kpis,
      cajas: cajas.length,
      cajasEnLinea: cajas.filter((c) => c.enLinea).length,
      cajasBloqueadas: cajas.filter((c) => c.estado === 'bloqueada').length,
    };
  }

  @Get('clientes')
  listarClientes() { return this.clientes.listar(); }

  // Alta de un negocio nuevo desde el panel: crea el cliente y su dueño, y queda en la bitácora.
  @Post('clientes')
  async provisionar(@Body() dto: ProvisionarClienteDto, @Req() req: any) {
    const r = await this.clientes.provisionar(dto);
    this.bitacora.registrar(actor(req), 'Provisionó cliente', `${dto.negocio} (${dto.email})`);
    return r;
  }

  // Cualquier cosa distinta de 'suspendido' se toma como 'activo', por si llega basura en el body.
  @Post('clientes/:id/estado')
  estadoCliente(@Param('id') id: string, @Body() b: { estado: string }, @Req() req: any) {
    const estado = b?.estado === 'suspendido' ? 'suspendido' : 'activo';
    const r = this.clientes.setEstado(id, estado);
    this.bitacora.registrar(actor(req), estado === 'suspendido' ? 'Suspendió cliente' : 'Activó cliente', this.nombreCliente(id));
    return r;
  }

  // Registrar un pago hecho por fuera (transferencia, efectivo): suma meses pagados y activa una cuenta pendiente.
  @Post('clientes/:id/pago')
  pagoCliente(@Param('id') id: string, @Body() b: { meses?: number; nota?: string }, @Req() req: any) {
    const r = this.registro.registrarPagoManual(id, Number(b?.meses ?? 1), String(b?.nota ?? ''), req?.usuario?.email);
    this.bitacora.registrar(actor(req), 'Registró pago manual', `${this.nombreCliente(id)}: ${Number(b?.meses ?? 1)} mes(es)`);
    return r;
  }

  // Cambiar el plan de un negocio (rige de inmediato, sin cobro).
  @Post('clientes/:id/plan')
  planCliente(@Param('id') id: string, @Body() b: { plan: string }, @Req() req: any) {
    const r = this.clientes.setPlan(id, String(b?.plan ?? ''), req?.usuario?.email);
    this.bitacora.registrar(actor(req), 'Cambió plan', `${this.nombreCliente(id)} → ${String(b?.plan ?? '')}`);
    return r;
  }

  // Mandarle al dueño un enlace para crear una contraseña nueva (solo staff, por el StaffGuard de la clase).
  @Post('clientes/:id/restablecer-clave')
  async restablecerClave(@Param('id') id: string, @Req() req: any) {
    const r = await this.clientes.restablecerClaveDueno(id, req?.usuario?.email);
    this.bitacora.registrar(actor(req), 'Envió enlace de acceso al dueño', this.nombreCliente(id));
    return r;
  }

  @Get('solicitudes')
  leads() { return this.solicitudes.listar(); }

  @Post('solicitudes/:id/avanzar')
  avanzar(@Param('id') id: string) { return this.solicitudes.avanzar(id); }

  // La flota completa: las cajas de todos los clientes.
  @Get('cajas')
  flota() { return this.sync.listarTodasLasCajas(); }

  // ---- Equipo Walkan y bitácora: solo super admin (StaffGuard de la clase + SuperAdminGuard) ----
  @Get('equipo') @UseGuards(SuperAdminGuard)
  listarEquipo() { return this.equipo.listar(); }

  @Post('equipo') @UseGuards(SuperAdminGuard)
  crearStaff(@Body() dto: CrearStaffDto, @Req() req: any) { return this.equipo.crear(actor(req), dto); }

  @Post('equipo/:id/desactivar') @UseGuards(SuperAdminGuard)
  desactivarStaff(@Param('id') id: string, @Req() req: any) { return this.equipo.desactivar(actor(req), id); }

  @Post('equipo/:id/reactivar') @UseGuards(SuperAdminGuard)
  reactivarStaff(@Param('id') id: string, @Req() req: any) { return this.equipo.reactivar(actor(req), id); }

  @Post('equipo/:id/nivel') @UseGuards(SuperAdminGuard)
  nivelStaff(@Param('id') id: string, @Body() dto: NivelStaffDto, @Req() req: any) { return this.equipo.setSuperAdmin(actor(req), id, dto.superAdmin); }

  @Post('equipo/:id/reenviar') @UseGuards(SuperAdminGuard)
  reenviarStaff(@Param('id') id: string, @Req() req: any) { return this.equipo.reenviar(actor(req), id); }

  @Post('equipo/:id/restablecer') @UseGuards(SuperAdminGuard)
  restablecerStaff(@Param('id') id: string, @Req() req: any) { return this.equipo.restablecer(actor(req), id); }

  @Get('bitacora') @UseGuards(SuperAdminGuard)
  verBitacora() { return this.bitacora.listar(); }

  private nombreCliente(id: string): string { return this.clientes.nombreDe(id); }
}
