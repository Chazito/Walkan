// Bodies del alta autoservicio: crear la cuenta, reintentar/verificar el pago y cambiar de plan.
import { Rut } from '../../../common/util/rut';
import { Equals, IsBoolean, IsEmail, IsIn, IsOptional, IsString, Matches, MaxLength, MinLength } from 'class-validator';
import { ClaveSegura } from '../../../common/util/politica-clave';

import { PLANES } from '../../../common/util/planes';
export { PLANES };

// Alta pública: datos del negocio y del dueño, plan elegido y consentimientos (la política es obligatoria, el marketing no).
export class RegistroDto {
  @IsString() @MinLength(2, { message: 'Ingresa el nombre del negocio.' }) @MaxLength(80) negocio!: string;
  @IsString() @MinLength(2, { message: 'Ingresa tu nombre.' }) @MaxLength(80) nombre!: string;
  @IsEmail({}, { message: 'Ingresa un correo válido.' }) @MaxLength(254) email!: string;
  @IsString() @ClaveSegura() password!: string;
  @IsIn(PLANES, { message: 'Elige un plan válido.' }) plan!: string;
  @IsOptional() @IsString() @MaxLength(20) @Rut() rut?: string;
  @IsOptional() @IsString() @MaxLength(60) comuna?: string;
  @IsOptional() @Matches(/^\d{5}$/, { message: 'Elige una comuna de la lista.' }) comunaCut?: string;
  @IsOptional() @IsString() @MaxLength(120, { message: 'La dirección es muy larga (máximo 120 caracteres).' }) direccion?: string;
  @IsOptional() @IsString() @MaxLength(30) telefono?: string;
  @Equals(true, { message: 'Debes aceptar la Política de Privacidad para continuar.' }) aceptaPrivacidad!: boolean;
  @IsOptional() @IsBoolean() aceptaMarketing?: boolean;
}

// Sin sesión todavía: el correo y la clave sirven para saber de qué cuenta se está hablando.
export class ReintentarPagoDto {
  @IsEmail({}, { message: 'Ingresa un correo válido.' }) @MaxLength(254) email!: string;
  @IsString() @MinLength(1) @MaxLength(100) password!: string;
}

export class CambiarPlanDto {
  @IsIn(PLANES, { message: 'Elige un plan válido.' }) plan!: string;
}
