// Lógica de sincronización con las cajas: enrolarlas, recibir su outbox de ventas, entregarles el catálogo y gestionarlas desde el panel.
import { BadRequestException, ForbiddenException, Inject, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { randomBytes } from 'crypto';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { leerBalanza } from '../../common/util/balanza';
import { planCanon } from '../../common/util/planes';
import { ahora, nuevoId } from '../../common/util/id';
import { fechaCL, horaCL } from '../../common/util/fecha';
import { StockService } from '../catalogo/stock.service';
import { VentasPendientesService } from '../catalogo/ventas-pendientes.service';
import { AuthService } from '../auth/auth.service';
import { CajasRepository } from './cajas.repository';
import { VentasRepository } from './ventas.repository';
import { CajerosService } from './cajeros.service';
import { CobrosService } from './cobros.service';
import { CorreoService } from './correo.service';
import { SyncBody, EventoSync } from './dto/sync.dto';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';

// El lado "nube" de la caja offline. La caja vende sin internet, guarda cada venta en un
// outbox con un seq correlativo y cuando hay red manda el lote acá. Ojo que no hay sesión:
// la caja se identifica con su token, y el cliente_id sale de la caja, nunca del payload.
@Injectable()
export class SyncService {
  private readonly logger = new Logger('Sync');
  constructor(
    @Inject(SQLITE) private readonly db: Database.Database,
    private readonly auth: AuthService,
    private readonly ctx: ContextoTenant,
    private readonly cajas: CajasRepository,
    private readonly ventas: VentasRepository,
    @Inject(CONFIG) private readonly cfg: AppConfig,
    private readonly stock: StockService,
    private readonly cajeros: CajerosService,
    private readonly cobros: CobrosService,
    private readonly correo: CorreoService,
    private readonly pendientes: VentasPendientesService,
  ) {}

  /**
   * Enrolamiento de una caja nueva. La caja envía las credenciales de la cuenta
   * UNA sola vez desde su pantalla de bienvenida; el servidor las valida, crea el
   * dispositivo y devuelve un token. La caja guarda solo el token (nunca la contraseña).
   */
  async registrarCaja(email: string, password: string, nombre?: string, ip = '') {
    const usuario = await this.auth.login({ email, password }, ip); // lanza 401 si son inválidas
    if (!usuario.clienteId) {
      throw new BadRequestException('Esta cuenta no está asociada a un negocio; usa las credenciales del dueño del local.');
    }
    // Cupo de cajas según el plan (configuracion.ts → planes). La primera va incluida; las siguientes, hasta el
    // máximo del plan, quedan como adicionales en arriendo: su cuota se suma a la renovación.
    const cli = this.db.prepare('SELECT plan FROM clientes WHERE id=?').get(usuario.clienteId) as { plan: string } | undefined;
    const plan = planCanon(cli?.plan);
    const def = this.cfg.planes[plan];
    const cupo = def?.cajasMax ?? 1;
    const usadas = (this.db.prepare('SELECT COUNT(*) AS n FROM cajas WHERE cliente_id=?').get(usuario.clienteId) as { n: number }).n;
    if (usadas >= cupo) {
      throw new ForbiddenException(`Tu plan ${plan} permite hasta ${cupo} caja(s) y ya las tienes registradas. Mejora tu plan para agregar más.`);
    }
    const adicional = usadas >= (def?.cajasIncluidas ?? 1);

    const now = ahora();
    const id = this.generarIdCaja();
    const token = 'wk_' + randomBytes(24).toString('hex');
    const nom = (nombre || '').trim() || 'Caja';
    this.cajas.crear({ id, nombre: nom, token, usuarioId: usuario.id, clienteId: usuario.clienteId, now });
    if (adicional) this.db.prepare('UPDATE cajas SET adicional=1 WHERE id=?').run(id);
    this.logger.log(`Caja ${id} ("${nom}") registrada (cliente ${usuario.clienteId}${adicional ? ', adicional en arriendo' : ''})`);
    return { ok: true, cajaId: id, nombre: nom, token, adicional };
  }

  // Ids cortitos tipo WK-1234 para que el dueño los lea en el panel. Si después de 25
  // intentos todos chocan (muchas cajas), se cae a uno basado en la hora.
  private generarIdCaja(): string {
    for (let i = 0; i < 25; i++) {
      const id = 'WK-' + Math.floor(1000 + Math.random() * 9000);
      if (!this.cajas.existeId(id)) return id;
    }
    return 'WK-' + Date.now().toString().slice(-6);
  }

  /**
   * Catálogo para la caja (nube → caja). La caja lo pide al arrancar y cada pocos minutos,
   * autenticada con su token. Solo productos activos con SKU (el SKU es la llave entre
   * la web y la caja). También sirve de "latido": marca la caja en línea y le avisa si
   * fue bloqueada o desbloqueada desde el panel. unidad 'kg' + plu: el producto se vende pesado y la balanza
   * imprime su código (ver common/util/balanza.ts); el precio va por kg.
   */
  catalogoParaCaja(token: string) {
    const caja = token ? this.cajas.porToken(token) : undefined;
    if (!caja) throw new UnauthorizedException('Token de caja inválido.');
    if (caja.estado === 'bloqueada') return { ok: false, bloqueada: true, productos: [] };
    if (caja.cliente_id && !this.auth.cuentaOperativa(caja.cliente_id)) {
      throw new ForbiddenException('Cuenta suspendida: sincronización en pausa.');
    }
    const now = ahora();
    this.cajas.marcarSync(caja.id, caja.ultimo_seq as number, now);
    const productos = this.db.prepare(
      `SELECT id, sku, nombre, precio, stock, unidad, plu FROM productos
        WHERE cliente_id=? AND activo=1 AND sku IS NOT NULL AND TRIM(sku)<>''
        ORDER BY nombre`,
    ).all(caja.cliente_id) as { id: string; sku: string; nombre: string; precio: number; stock: number; unidad: string; plu: number | null }[];
    // Cajeros del negocio (con hash del PIN, nunca en claro): la caja los aplica y valida el PIN sin internet.
    return { ok: true, bloqueada: false, generado: now, productos, cajeros: this.cajeros.paraCaja(caja.cliente_id),
      negocio: this.cobros.paraCaja(caja.cliente_id) };
  }

  /** Recibe el outbox de una caja (autenticada por token). FIFO + idempotente. */
  recibir(token: string, body: SyncBody) {
    const caja = token ? this.cajas.porToken(token) : undefined;
    if (!caja) throw new UnauthorizedException('Token de caja inválido.');

    // Kill-switch: si la caja está bloqueada (robo), se le ordena bloquearse.
    if (caja.estado === 'bloqueada') {
      this.logger.warn(`Caja ${caja.id} bloqueada: se envía señal de bloqueo.`);
      return { ok: false, bloqueada: true, ultimoSeq: caja.ultimo_seq };
    }

    // Cuenta suspendida o con el plan vencido (pasados los días de gracia): degradación suave. La caja sigue
    // vendiendo offline y acumula su outbox; solo se pausa la subida hasta que la cuenta se reactive.
    if (caja.cliente_id && !this.auth.cuentaOperativa(caja.cliente_id)) {
      throw new ForbiddenException('Cuenta suspendida: sincronización en pausa.');
    }

    // Solo eventos con forma mínima (objeto con seq entero positivo): un null o un seq raro antes reventaba el
    // lote entero con 500 y la caja quedaba reintentando el mismo lote para siempre (C1).
    const eventos = (Array.isArray(body?.eventos) ? body.eventos : [])
      .filter((e) => e && typeof e === 'object' && Number.isSafeInteger(e.seq) && e.seq > 0);
    eventos.sort((a, b) => a.seq - b.seq); // FIFO estricto por seq
    const now = ahora();
    let aplicados = 0;
    let noReconocidos = 0;
    // Tipos que la web todavía no aplica (ver docs/plan/propuestas-mejoras.md C1). Sin prototipo: el tipo viene de la caja
    // y un "__proto__" no debe tocar Object.prototype.
    const ignorados: Record<string, number> = Object.create(null);
    const correos: { folio: string; email: string }[] = []; // se envían después de confirmar el lote
    let ultimoSeq = caja.ultimo_seq as number;
    let atrasados = 0;
    const rechazados: { seq: number; motivo: string }[] = [];
    let reiniciados = 0;
    const insRechazo = this.db.prepare(`INSERT INTO sync_rechazos (id,cliente_id,caja_id,seq,tipo,motivo,folio,total,created_at)
      VALUES (?,?,?,?,?,?,?,?,?)`);

    // Todo el lote en una transacción: si algo revienta a la mitad, no queda nada a medias
    // y ultimo_seq no avanza, así que la caja lo reintenta completo.
    const tx = this.db.transaction(() => {
      for (const ev of eventos) {
        // uid = id de la venta en la caja (cajas desde nov-2026). Solo letras, números y guiones: viene de afuera.
        const uid = typeof ev.uid === 'string' && /^[\w-]{1,64}$/.test(ev.uid) ? ev.uid : null;
        if (ev.tipo === 'venta' && uid && this.ventas.existeUid(caja.id, uid)) { atrasados++; ultimoSeq = Math.max(ultimoSeq, ev.seq); continue; } // reenvío
        if (ev.seq <= ultimoSeq) {
          // Una venta con un seq ya usado pero con otro id es una caja que reinició su numeración (C3). Antes se
          // descartaba en silencio y la caja la daba por enviada; ahora se rechaza y la caja la conserva en su cola.
          // (Un reenvío de una venta que se rechazó antes no tiene fila en ventas, pero sí en sync_rechazos: no es reinicio.)
          const previo = ev.tipo === 'venta' && uid ? this.ventas.uidDeSeq(caja.id, ev.seq) : null;
          const fueRechazo = previo === undefined && !!this.db.prepare('SELECT 1 FROM sync_rechazos WHERE caja_id=? AND seq=?').get(caja.id, ev.seq);
          if (previo !== null && !fueRechazo) { reiniciados++; continue; }
          atrasados++; continue; // ya aplicado
        }
        // Doble seguro contra duplicados por si ultimo_seq quedó atrasado.
        if (this.ventas.yaExiste(caja.id, ev.seq)) { ultimoSeq = ev.seq; continue; }
        try {
          // Cada evento en su propio savepoint: si uno viene malo se deshace solo ese, se anota como rechazado
          // y el lote sigue. Así una venta corrupta no deja trabadas todas las que vienen detrás.
          this.db.transaction(() => {
            if (ev.tipo === 'venta') noReconocidos += this.aplicarVenta(caja.id, caja.cliente_id, ev, now, uid);
            // La caja pide enviar el comprobante de una venta por correo (la venta va antes en el mismo FIFO).
            else if (ev.tipo === 'correo_comprobante') correos.push({ folio: String(ev.payload?.folio ?? ''), email: String(ev.payload?.email ?? '') });
            // Otros tipos (movimiento_stock, producto, ...) aún no se aplican: aplicarlos tal cual duplicaría las ventas
            // (cada venta de la caja también trae su movimiento) y el AJUSTE de la caja es un stock absoluto. Se cuentan y se avisa.
            else { const t = String(ev.tipo).slice(0, 40); ignorados[t] = (ignorados[t] ?? 0) + 1; } // tipo acotado: viene de la caja
          })();
          aplicados++;
        } catch (e) {
          const motivo = String((e as Error)?.message ?? e).slice(0, 120);
          rechazados.push({ seq: ev.seq, motivo });
          // Queda guardado para el panel (I4/C4): antes solo iba al log y el evento se perdía. Sin datos del pago ni correos.
          const p = ev.tipo === 'venta' && ev.payload && typeof ev.payload === 'object' ? ev.payload : {};
          insRechazo.run(nuevoId(), caja.cliente_id ?? null, caja.id, ev.seq, String(ev.tipo).slice(0, 40), motivo,
            p.folio == null ? null : String(p.folio).slice(0, 20), Number.isSafeInteger(p.total) ? p.total : null, now);
        }
        ultimoSeq = ev.seq;
      }
      this.cajas.marcarSync(caja.id, ultimoSeq, now);
    });
    tx();
    for (const c of correos) void this.correo.enviarComprobante(caja.id, caja.cliente_id, c.folio, c.email);

    this.logger.log(`Caja ${caja.id}: ${aplicados} evento(s) aplicado(s), últimoSeq=${ultimoSeq}`);
    if (rechazados.length) this.logger.warn(`Caja ${caja.id}: ${rechazados.length} evento(s) rechazado(s): ${JSON.stringify(rechazados.slice(0, 5))}`);
    if (reiniciados) {
      this.logger.warn(`Caja ${caja.id}: ${reiniciados} venta(s) con seq ya usado y otro id: la caja reinició su numeración. Se rechazan para no perderlas.`);
      return { ok: false, bloqueada: false, reiniciada: true, aplicados, noReconocidos, ignorados, ultimoSeq, rechazados, atrasados, reiniciados,
        // La caja (versión nov-2026) renumera su cola sobre ultimoSeq y reintenta sola; una caja antigua queda reintentando
        // con este mensaje a la vista, sin perder nada.
        message: 'La caja reinició su numeración de ventas: renumera su cola de envío sobre el último número recibido y reintenta.' };
    }
    if (atrasados) this.logger.warn(`Caja ${caja.id}: ${atrasados} evento(s) con seq ≤ ${caja.ultimo_seq} ignorado(s) (¿la caja se reinstaló?).`);
    if (noReconocidos) this.logger.warn(`Caja ${caja.id}: ${noReconocidos} línea(s) con SKU no reconocido (quedan en la bandeja del panel).`);
    if (Object.keys(ignorados).length) this.logger.warn(`Caja ${caja.id}: eventos no aplicados por tipo ${JSON.stringify(ignorados)}.`);
    return { ok: true, bloqueada: false, aplicados, noReconocidos, ignorados, ultimoSeq, rechazados, atrasados };
  }

  /** Guarda la venta y descuenta stock por SKU vía kardex. Devuelve cuántas líneas no se reconocieron. */
  private aplicarVenta(cajaId: string, clienteId: string, ev: EventoSync, now: string, uid: string | null = null): number {
    const p = ev.payload || {};
    // Lo que manda la caja no se guarda tal cual: nombre como texto acotado y cantidad/precio como números sanos.
    // Antes un precio con HTML quedaba guardado y el panel lo escribía en "Imprimir copia" (inyección de código).
    const items: any[] = (Array.isArray(p.items) ? p.items : []).map((it: any) => ({
      ...it, nombre: String(it.nombre ?? '').slice(0, 120), sku: it.sku == null ? null : String(it.sku).slice(0, 64),
      // La cantidad solo se exige finita: el tope de ±1.000.000 lo aplica más abajo el descuento de stock.
      cantidad: numeroSano(it.cantidad, Number.MAX_VALUE), precio: numeroSano(it.precio, 1_000_000_000),
    }));
    const suma = Math.round(items.reduce((s, it) => s + (Number(it.cantidad) || 0) * (Number(it.precio) || 0), 0));
    // Total de la caja solo si es un entero sano (pesos, sin negativos ni absurdos); si no, la suma de las líneas (C3).
    const total = Number.isSafeInteger(p.total) && p.total >= 0 && p.total <= 1_000_000_000 ? p.total : suma;
    if (total !== p.total) this.logger.warn(`Caja ${cajaId} seq ${ev.seq}: total inválido (${String(p.total).slice(0, 20)}), se usa la suma de líneas.`);
    // Los precios en Chile vienen con IVA (19%) incluido: el neto se saca dividiendo y el IVA es la resta,
    // así neto + iva cuadra exacto con el total.
    const neto = Math.round(total / 1.19);
    // Items compactos como tuplas [nombre, cantidad, precio, sku] para no inflar la tabla.
    const itemsJson = JSON.stringify(items.map((it) => [it.nombre, it.cantidad, it.precio, it.sku ?? null]));
    const id = nuevoId();
    // Vale la fecha en que se vendió en la caja, no la de llegada (puede sincronizar horas después).
    const fecha = fechaSana(p.fecha || ev.fecha, now);
    this.ventas.insertar({
      id, cajaId, clienteId, seq: ev.seq, folio: String(p.folio ?? ev.seq),
      fecha, cajero: p.cajero ?? null, medioPago: p.medioPago ?? null,
      neto, iva: total - neto, total, siiEstado: p.sii || 'Emitida', itemsJson, createdAt: now,
      pagoJson: pagoSeguro(p.pago), uid,
    });
    // Descuenta stock del catálogo del MISMO cliente, por SKU. El stock puede quedar negativo.
    let noReconocidos = 0;
    for (const it of items) {
      let productoId = it.sku ? this.stock.productoPorSku(clienteId, String(it.sku)) : undefined;
      let qty = Number(it.cantidad) || 0;
      // Etiqueta de balanza: el código trae el PLU y el peso (o el precio). Lo vendido son esos kg, no "1".
      const b = !productoId && it.sku ? leerBalanza(String(it.sku)) : null;
      const pb = b ? this.stock.productoPorPlu(clienteId, b.plu) : undefined;
      if (b && pb) {
        productoId = pb.id;
        qty = b.gramos != null ? b.gramos / 1000 : (pb.precio ? Math.round((b.pesos as number) / pb.precio * 1000) / 1000 : 0);
      } else if (b && b.gramos != null) qty = b.gramos / 1000; // PLU desconocido: la bandeja guarda los kg de la etiqueta
      // Cantidad sana (finita, ±1.000.000, hasta gramos): una basura no debe corromper el stock. Si no, no se reconoce.
      if (!Number.isFinite(qty) || Math.abs(qty) > 1_000_000) { noReconocidos++; continue; }
      qty = Math.round(qty * 1000) / 1000;
      if (!productoId) {
        noReconocidos++;
        // Código que el catálogo no conoce: la línea queda en la bandeja del panel y se descuenta al crear o vincular
        // el producto (B1). Antes solo se contaba y ese stock nunca se descontaba.
        if (qty && clienteId) {
          this.pendientes.registrar(clienteId, { ventaId: id, cajaId, sku: it.sku ?? null, nombre: it.nombre, cantidad: qty, precio: it.precio, fecha }, now);
        }
        continue;
      }
      if (qty) this.stock.mover({ clienteId, productoId, tipo: 'venta', cantidad: -qty, refId: id, fecha, usuarioId: null }); // la caja no es un usuario
    }
    return noReconocidos;
  }

  /**
   * Ventas del cliente logueado (panel). Sin rango: las últimas 100. Con rango
   * (días YYYY-MM-DD, inclusive) se filtra por el día en hora de Chile.
   */
  listarVentas(desde?: string, hasta?: string, minimo?: string | null) {
    // minimo = primer día que permite el historial del plan: un `desde` anterior se sube a ese día.
    if (minimo && desde && desde < minimo) desde = minimo;
    // El SQL trae un rango holgado en UTC y acá se recorta con fechaCL: una venta a las 23:30 de
    // Chile ya es "mañana" en UTC, y sin esto se iría al día equivocado.
    const filas = (desde || hasta
      ? this.ventas.listarRango(this.ctx.clienteId, desde || minimo || '2000-01-01', hasta || '2999-12-31')
        .filter((r) => { const d = fechaCL(r.fecha); return (!desde || d >= desde) && (!hasta || d <= hasta); })
      : this.ventas.listarRecientes(this.ctx.clienteId))
      .filter((r) => !minimo || fechaCL(r.fecha) >= minimo);
    // Correos enviados de estas ventas (para mostrarlos en el comprobante del panel).
    const correosPor = new Map<string, { email: string; estado: string; fecha: string }[]>();
    if (filas.length) {
      const ids = new Set(filas.map((r) => r.id));
      for (const c of this.db.prepare('SELECT venta_id, email, estado, created_at FROM comprobantes_correo WHERE cliente_id=? ORDER BY created_at')
        .all(this.ctx.clienteId) as { venta_id: string; email: string; estado: string; created_at: string }[]) {
        if (!ids.has(c.venta_id)) continue;
        const l = correosPor.get(c.venta_id) ?? []; l.push({ email: c.email, estado: c.estado, fecha: c.created_at }); correosPor.set(c.venta_id, l);
      }
    }
    return filas.map((r) => {
      const items = JSON.parse(r.items_json || '[]');
      return { id: r.id, folio: '#' + r.folio, fecha: fechaCL(r.fecha), hora: horaCL(r.fecha), caja: r.caja_nombre, cajero: r.cajero, pago: r.medio_pago,
        estado: r.sii_estado, total: r.total, items, pagoDetalle: r.pago_json ? JSON.parse(r.pago_json) : null, correos: correosPor.get(r.id) ?? [] };
    });
  }

  // Caja en el formato del panel, con sus totales de ventas.
  private mapCaja = (c: any) => {
    const t = this.ventas.totalesPorCaja(c.id);
    // "En línea" = sincronizó en los últimos 2 minutos. No hay heartbeat aparte, se usa la última sync.
    const onlineReciente = c.ultima_sync ? (Date.now() - new Date(c.ultima_sync).getTime() < 120000) : false;
    return { id: c.id, nombre: c.nombre, estado: c.estado, ultimaSync: c.ultima_sync,
      enLinea: c.estado === 'activa' && onlineReciente, ventas: t.n, monto: t.monto,
      clienteId: c.cliente_id ?? null };
  };

  /** Cajas del cliente logueado (panel). */
  listarCajas() {
    return this.cajas.listarPorCliente(this.ctx.clienteId).map(this.mapCaja);
  }

  /** Flota completa (staff Walkan). */
  listarTodasLasCajas() {
    return this.cajas.listar().map(this.mapCaja);
  }

  private requerirAccesoCaja(id: string) {
    const c = this.cajas.porId(id);
    if (!c) throw new UnauthorizedException('Caja no encontrada.');
    // El staff puede sobre cualquier caja; un cliente, solo sobre las suyas.
    if (this.ctx.rol !== 'staff' && c.cliente_id !== this.ctx.clienteIdOpt) {
      throw new ForbiddenException('No puedes gestionar una caja de otro negocio.');
    }
    return c;
  }

  // Kill-switch desde el panel: la caja se entera la próxima vez que sincronice.
  bloquear(id: string) {
    this.requerirAccesoCaja(id);
    this.cajas.setEstadoCaja(id, 'bloqueada', ahora());
    return { ok: true, id, estado: 'bloqueada' };
  }
  desbloquear(id: string) {
    this.requerirAccesoCaja(id);
    this.cajas.setEstadoCaja(id, 'activa', ahora());
    return { ok: true, id, estado: 'activa' };
  }
}

/** Número finito dentro de ±tope; cualquier otra cosa (texto, objeto, NaN, infinito) queda en 0. */
export function numeroSano(v: unknown, tope: number): number {
  const n = typeof v === 'number' || (typeof v === 'string' && v.trim() !== '') ? Number(v) : NaN;
  return Number.isFinite(n) && Math.abs(n) <= tope ? n : 0;
}

/** Detalle del pago que manda la caja, acotado a campos conocidos (viene de afuera: no se guarda tal cual). */
function pagoSeguro(p: any): string | null {
  if (!p || typeof p !== 'object') return null;
  const num = (v: unknown) => (Number.isFinite(Number(v)) ? Math.max(0, Math.round(Number(v))) : undefined);
  const txt = (v: unknown, max: number) => (v == null ? undefined : String(v).slice(0, max));
  const d = {
    autorizacion: txt(p.autorizacion, 20), tarjeta: txt(p.tarjeta, 20), terminal: txt(p.terminal, 30),
    recibido: num(p.recibido), vuelto: num(p.vuelto), simulado: p.simulado === true ? true : undefined,
  };
  const limpio = Object.fromEntries(Object.entries(d).filter(([, v]) => v !== undefined));
  return Object.keys(limpio).length ? JSON.stringify(limpio) : null;
}

/** Fecha de la venta normalizada a ISO UTC (C2). Inválida, o más de 10 min en el futuro (reloj de la caja
 *  adelantado), se reemplaza por la hora de llegada: si no, rompía el orden, el corte del día y el costo FIFO. */
export function fechaSana(v: unknown, now: string): string {
  const t = typeof v === 'string' || typeof v === 'number' ? Date.parse(String(v)) : NaN;
  if (!Number.isFinite(t) || t > Date.parse(now) + 10 * 60_000 || t < Date.parse('2020-01-01')) return now;
  return new Date(t).toISOString();
}
