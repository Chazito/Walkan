// Datos de cobro del negocio (cuenta para transferencias) y lo que se le entrega a la caja para el comprobante.
import { BadRequestException, ForbiddenException, Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ContextoTenant } from '../../common/contexto-tenant';
import { ahora } from '../../common/util/id';
import { FlowNegocioService } from './flow-negocio.service';

export interface DatosTransferencia { banco: string; tipoCuenta: string; numero: string; titular: string; rut: string; email: string }
export const TIPOS_CUENTA = ['Cuenta Corriente', 'Cuenta Vista', 'Cuenta RUT', 'Cuenta de Ahorro'];
const VACIO: DatosTransferencia = { banco: '', tipoCuenta: '', numero: '', titular: '', rut: '', email: '' };

/** Datos del negocio que usa la caja al cobrar: nombre, RUT y cuenta para transferencias. */
@Injectable()
export class CobrosService {
  constructor(@Inject(SQLITE) private readonly db: Database.Database, private readonly ctx: ContextoTenant, private readonly flow: FlowNegocioService) {}

  private cliente(): string {
    if (this.ctx.rol !== 'admin') throw new ForbiddenException('Solo el dueño del negocio puede cambiar los datos de cobro.');
    return this.ctx.clienteId;
  }

  // Si el JSON viene vacío o dañado, devuelve los datos en blanco en vez de fallar.
  private leer(clienteId: string): DatosTransferencia {
    const r = this.db.prepare('SELECT transferencia_json FROM clientes WHERE id=?').get(clienteId) as { transferencia_json: string | null } | undefined;
    try { return { ...VACIO, ...(r?.transferencia_json ? JSON.parse(r.transferencia_json) : {}) }; } catch { return { ...VACIO }; }
  }

  obtenerTransferencia() { return this.leer(this.cliente()); }

  // Limpia y valida lo que escribió el dueño. Todo en blanco borra los datos; si pone algo, los campos obligatorios deben ir completos.
  guardarTransferencia(body: Partial<DatosTransferencia>) {
    const cid = this.cliente();
    const txt = (v: unknown, max: number) => String(v ?? '').trim().replace(/\s+/g, ' ').slice(0, max);
    const d: DatosTransferencia = {
      banco: txt(body?.banco, 60), tipoCuenta: txt(body?.tipoCuenta, 30), numero: txt(body?.numero, 30),
      titular: txt(body?.titular, 80), rut: txt(body?.rut, 12).toUpperCase(), email: txt(body?.email, 120).toLowerCase(),
    };
    if (d.tipoCuenta && !TIPOS_CUENTA.includes(d.tipoCuenta)) throw new BadRequestException('Tipo de cuenta no válido.');
    if (d.numero && !/^[0-9-]+$/.test(d.numero)) throw new BadRequestException('El número de cuenta solo puede tener números y guiones.');
    if (d.rut && !/^[0-9]{1,2}\.?[0-9]{3}\.?[0-9]{3}-[0-9K]$/.test(d.rut)) throw new BadRequestException('RUT no válido (ej: 12.345.678-9).');
    if (d.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) throw new BadRequestException('Correo no válido.');
    const algo = Object.values(d).some(Boolean);
    if (algo && (!d.banco || !d.tipoCuenta || !d.numero || !d.titular || !d.rut)) {
      throw new BadRequestException('Completa banco, tipo de cuenta, número, titular y RUT (el correo es opcional).');
    }
    this.db.prepare('UPDATE clientes SET transferencia_json=?, updated_at=? WHERE id=?').run(algo ? JSON.stringify(d) : null, ahora(), cid);
    return d;
  }

  /** Para la caja (GET /api/catalogo): encabezado del comprobante y datos de transferencia. */
  paraCaja(clienteId: string) {
    const c = this.db.prepare('SELECT negocio, rut FROM clientes WHERE id=?').get(clienteId) as { negocio: string; rut: string | null } | undefined;
    const t = this.leer(clienteId);
    return { nombre: c?.negocio ?? '', rut: c?.rut ?? '', transferencia: t.numero ? t : null, flowQr: this.flow.activo(clienteId) };
  }
}
