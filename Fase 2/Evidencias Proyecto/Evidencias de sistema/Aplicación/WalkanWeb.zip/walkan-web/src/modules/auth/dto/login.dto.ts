import { IsBoolean, IsEmail, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

// Body del login. Acá solo se valida la forma; si la clave es correcta lo ve AuthService.
export class LoginDto {
  @IsEmail({}, { message: 'Ingresa un correo válido.' }) @MaxLength(254) email!: string;
  // Tope de largo: la clave se pasa por scrypt, y una de megas gastaría CPU por nada.
  @IsString() @MinLength(1, { message: 'Ingresa tu contraseña.' }) @MaxLength(100) password!: string;
  @IsOptional() @IsBoolean() recordar?: boolean;
}
