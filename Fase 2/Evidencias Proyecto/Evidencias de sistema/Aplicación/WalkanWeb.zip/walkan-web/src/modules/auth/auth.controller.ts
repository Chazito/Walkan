// Endpoints de /api/auth: login (con segundo paso opcional), logout, dispositivos recordados y dos pasos.
import { Body, Controller, Get, Ip, Post, Req, Res, UnauthorizedException, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { DosPasosService } from './dos-pasos.service';
import { CodigoDosPasosDto, DesactivarDosPasosDto, LoginCodigoDto } from './dto/dos-pasos.dto';
import { LoginDto } from './dto/login.dto';
import { COOKIE_DISPOSITIVO, COOKIE_SESION, opcionesCookie, opcionesCookieDispositivo, SesionGuard } from './auth.guard';
import { Limite } from '../../common/limite';

@Controller('api/auth')
export class AuthController {
  constructor(private readonly auth: AuthService, private readonly dos: DosPasosService) {}

  // La cookie guarda solo el identificador aleatorio de la sesión, firmado. httpOnly para que el JS
  // del front no la pueda leer. "Recordarme": 30 días renovables; sin marcar, hasta cerrar el navegador.
  @Post('login')
  @Limite(10)
  async login(@Body() dto: LoginDto, @Ip() ip: string, @Req() req: any, @Res({ passthrough: true }) reply: any) {
    const usuario = await this.auth.login(dto, ip);
    const recordar = dto.recordar !== false;
    // Con verificación en dos pasos, la contraseña sola no abre sesión: falta el código de la app (POST login/codigo),
    // salvo que este navegador sea un dispositivo recordado del dueño (nunca para el equipo Walkan).
    if (usuario.dosPasos && !this.auth.dispositivoRecordado(usuario, this.tokenDispositivo(req))) {
      return { dosPasos: true, desafio: this.dos.crearDesafio(usuario.id, recordar), puedeRecordar: this.auth.puedeRecordarDispositivo(usuario) };
    }
    reply.setCookie(COOKIE_SESION, this.auth.abrirSesion(usuario.id, recordar), opcionesCookie(recordar));
    return { usuario };
  }

  // Segundo paso del inicio de sesión: el código de 6 dígitos de la app (o un código de respaldo).
  @Post('login/codigo')
  @Limite(10)
  loginCodigo(@Body() dto: LoginCodigoDto, @Res({ passthrough: true }) reply: any) {
    const { usuarioId, recordar } = this.dos.completar(dto.desafio, dto.codigo);
    const usuario = this.auth.porId(usuarioId);
    if (!usuario) throw new UnauthorizedException('Sesión inválida.');
    this.auth.verificarCuentaActiva(usuario);
    if (dto.recordarDispositivo && this.auth.puedeRecordarDispositivo(usuario)) {
      reply.setCookie(COOKIE_DISPOSITIVO, this.auth.recordarDispositivo(usuario.id), opcionesCookieDispositivo());
    }
    reply.setCookie(COOKIE_SESION, this.auth.abrirSesion(usuario.id, recordar), opcionesCookie(recordar));
    return { usuario };
  }

  private tokenDispositivo(req: any): string | undefined {
    const raw = req.cookies?.[COOKIE_DISPOSITIVO];
    const un = raw ? req.unsignCookie(raw) : null;
    return un?.valid && un.value ? un.value : undefined;
  }

  // Mi cuenta: cuántos dispositivos recordados hay y olvidarlos todos (por si pierde un equipo).
  @Get('dispositivos')
  @UseGuards(SesionGuard)
  dispositivos(@Req() req: any) { return { recordados: this.auth.dispositivosRecordados(req.usuario.id) }; }

  @Post('dispositivos/olvidar')
  @Limite(10)
  @UseGuards(SesionGuard)
  olvidarDispositivos(@Req() req: any, @Res({ passthrough: true }) reply: any) {
    this.auth.olvidarDispositivos(req.usuario.id);
    reply.clearCookie(COOKIE_DISPOSITIVO, { path: '/api/auth' });
    return { ok: true };
  }

  // ---- Configurar la verificación en dos pasos (Mi cuenta) ----
  @Get('dos-pasos')
  @UseGuards(SesionGuard)
  dosPasos(@Req() req: any) { return this.dos.estado(req.usuario.id, req.usuario.rol); }

  @Post('dos-pasos/iniciar')
  @Limite(10)
  @UseGuards(SesionGuard)
  dosPasosIniciar(@Req() req: any) { return this.dos.iniciar(req.usuario.id, req.usuario.email); }

  @Post('dos-pasos/activar')
  @Limite(10)
  @UseGuards(SesionGuard)
  dosPasosActivar(@Req() req: any, @Body() dto: CodigoDosPasosDto) {
    const r = this.dos.activar(req.usuario.id, dto.codigo);
    // Las sesiones abiertas en otros equipos se entraron sin el segundo paso: se cierran.
    this.auth.cerrarOtrasSesiones(req.usuario.id, req.sesionId);
    return r;
  }

  @Post('dos-pasos/respaldo')
  @Limite(10)
  @UseGuards(SesionGuard)
  dosPasosRespaldo(@Req() req: any, @Body() dto: CodigoDosPasosDto) { return this.dos.nuevosRespaldos(req.usuario.id, dto.codigo); }

  @Post('dos-pasos/desactivar')
  @Limite(10)
  @UseGuards(SesionGuard)
  async dosPasosDesactivar(@Req() req: any, @Body() dto: DesactivarDosPasosDto) {
    if (!(await this.auth.claveCorrecta(req.usuario.id, dto.password))) throw new UnauthorizedException('La contraseña no es correcta.');
    this.dos.desactivar(req.usuario.id, req.usuario.rol, dto.codigo);
    return { ok: true };
  }

  @Get('me')
  @UseGuards(SesionGuard)
  me(@Req() req: any) {
    // vigencia: situación del plan del negocio (null para el staff). El panel la usa para avisar que vence y para
    // quedarse solo en Mi cuenta cuando la cuenta está en pausa. debeActivarDosPasos: staff que aún no configura la app.
    return { usuario: req.usuario, vigencia: req.vigencia ?? null, debeActivarDosPasos: !!req.debeActivarDosPasos };
  }

  // Cambiar la contraseña: POST /api/auth/password vive en RecuperacionController (pide un código por correo o de la app).

  @Post('logout')
  logout(@Req() req: any, @Res({ passthrough: true }) reply: any) {
    // Cierra ESTA sesión también en el servidor (la cookie deja de servir aunque alguien la haya copiado).
    // Las sesiones del mismo usuario en otros equipos siguen abiertas.
    const raw = req.cookies?.[COOKIE_SESION];
    const un = raw ? req.unsignCookie(raw) : null;
    if (un?.valid && un.value) this.auth.cerrarSesion(un.value);
    reply.clearCookie(COOKIE_SESION, { path: '/' });
    return { ok: true };
  }
}
