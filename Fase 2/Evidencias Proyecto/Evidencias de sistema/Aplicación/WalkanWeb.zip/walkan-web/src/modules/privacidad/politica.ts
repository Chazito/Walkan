import { createHash } from 'crypto';
import { terminos } from './terminos';

// Política de privacidad de Walkan. Al cambiar CUALQUIER texto de este archivo o de terminos.ts hay que subir
// VERSION: los dueños deberán aceptar de nuevo al ingresar (el hash cambia solo). Una sola versión para los dos
// documentos: la casilla del registro acepta Términos + Política a la vez.
// Texto base redactado para el proyecto; antes de operar comercialmente conviene que lo revise un abogado.
export const VERSION = '2026-11-14.2';
export const RESPONSABLE = 'Walkan (proyecto en formación)';

export const contactoPrivacidad = (): string => process.env.CONTACTO_PRIVACIDAD || 'walkan.pos@gmail.com';

export const TEXTO_CASILLA_PRIVACIDAD = 'Leí y acepto los Términos y Condiciones y la Política de Privacidad de Walkan, y el tratamiento de mis datos personales para crear y administrar mi cuenta.';
export const TEXTO_CASILLA_CONTACTO = 'Leí y acepto la Política de Privacidad de Walkan y que usen mis datos para responder esta solicitud.';
export const TEXTO_CASILLA_MARKETING = 'Quiero recibir novedades y ofertas de Walkan por correo. Es opcional y puedo retirarlo cuando quiera.';

type Seccion = { titulo: string; parrafos: string[] };

export function politica(): Seccion[] {
  const correo = contactoPrivacidad();
  return [
    { titulo: '1. Quién es responsable de tus datos', parrafos: [
      `El responsable del tratamiento es ${RESPONSABLE}. Para cualquier consulta o solicitud sobre tus datos personales escríbenos a ${correo}.`,
      'Esta política se rige por la Ley N° 19.628 sobre Protección de los Datos Personales, modificada por la Ley N° 21.719, y por las instrucciones que dicte la Agencia de Protección de Datos Personales.',
    ] },
    { titulo: '2. Qué datos tratamos', parrafos: [
      'Datos de tu cuenta: nombre, correo, nombre del negocio, plan contratado y, si los entregas, teléfono, RUT y dirección del local (región, comuna y calle).',
      'Datos de uso del servicio: productos, ventas, compras, proveedores y cajas de tu negocio, que se sincronizan desde tu caja.',
      'Datos técnicos: dirección IP, navegador y fecha de acceso, para seguridad y para registrar tus consentimientos.',
      'Formulario de contacto: nombre, negocio, correo, teléfono, comuna y el mensaje que nos envíes.',
      'Ubicación: solo si tocas "Agregar dirección del local" y lo permites. Las coordenadas se envían a OpenStreetMap para obtener la dirección y no las guardamos; solo guardamos la dirección que confirmes.',
    ] },
    { titulo: '3. Para qué los usamos y con qué base', parrafos: [
      'Para prestarte el servicio contratado: crear y administrar tu cuenta, sincronizar tus cajas, darte soporte e instalar tu equipo (base: ejecución del contrato).',
      'Para cobrar tu plan a través de Flow y avisarte por correo cuando está por vencer (base: ejecución del contrato y obligaciones legales). Si eliges el pago automático, guardamos la marca y los 4 últimos dígitos de tu tarjeta para mostrártela; el número completo lo guarda Flow, no Walkan.',
      'Para proteger el servicio, prevenir fraudes y accesos indebidos (base: interés legítimo).',
      'Para enviarte novedades y ofertas solo si lo aceptas expresamente (base: tu consentimiento, que puedes retirar en cualquier momento desde "Mi cuenta").',
    ] },
    { titulo: '4. Datos de los clientes de tu negocio', parrafos: [
      'Si en tu caja registras datos de tus propios clientes (por ejemplo, un correo para enviar el comprobante), tu negocio es el responsable de esos datos y Walkan los trata solo por tu cuenta, para prestarte el servicio.',
    ] },
    { titulo: '5. Con quién los compartimos', parrafos: [
      'Flow (procesador de pagos), Cloudflare (red y seguridad del sitio), OpenStreetMap (solo si usas la detección de dirección) y nuestro proveedor de correo. No vendemos tus datos ni los cedemos para publicidad de terceros.',
    ] },
    { titulo: '6. Cuánto tiempo los guardamos', parrafos: [
      'Los datos de tu cuenta y de tu negocio, mientras la cuenta exista. Si la eliminas, se borran a los 30 días (plazo para que puedas arrepentirte) y desaparecen de nuestras copias de respaldo dentro de los 14 días siguientes.',
      'Después del borrado solo conservamos el registro de los pagos de tu plan, por el tiempo que exijan las obligaciones legales y tributarias, y el registro de tus consentimientos, mientras sea necesario para demostrar que los otorgaste. Las solicitudes de contacto que no terminan en contrato se guardan hasta 12 meses.',
    ] },
    { titulo: '7. Tus derechos', parrafos: [
      'Desde "Mi cuenta" puedes ejercer dos de tus derechos tú mismo, sin esperar a nadie: descargar tus datos (portabilidad) y eliminar tu cuenta (supresión).',
      `Para acceso, rectificación, oposición o bloqueo de tus datos, o si prefieres que hagamos nosotros la descarga o la eliminación, escríbenos a ${correo} desde el correo de tu cuenta. Responderemos dentro de los plazos que fija la ley. Si no quedas conforme, puedes reclamar ante la Agencia de Protección de Datos Personales.`,
    ] },
    { titulo: '8. Seguridad y cookies', parrafos: [
      'Las contraseñas se guardan cifradas (scrypt), el sitio usa HTTPS y los datos de cada negocio están aislados de los demás. Usamos solo una cookie esencial para mantener tu sesión; no usamos cookies de publicidad ni de seguimiento.',
    ] },
    { titulo: '9. Cambios a esta política', parrafos: [
      'Si cambiamos esta política, actualizaremos la versión y te pediremos aceptarla de nuevo al ingresar a tu cuenta.',
    ] },
  ];
}

/** Hash del texto exacto aceptado: política completa + términos + la casilla que vio la persona. */
export function hashTexto(casilla: string): string {
  return createHash('sha256').update(JSON.stringify({ version: VERSION, politica: politica(), terminos: terminos(RESPONSABLE, contactoPrivacidad()), casilla })).digest('hex');
}
