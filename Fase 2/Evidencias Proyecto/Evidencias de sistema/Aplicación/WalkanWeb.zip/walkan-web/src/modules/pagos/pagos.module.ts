import { Module } from '@nestjs/common';
import { PASARELA } from './pasarela.interface';
import { FlowPasarela } from './flow.pasarela';

// Se exporta la pasarela por token, no la clase: si mañana cambiamos Flow por otra, se toca solo acá.
@Module({
  providers: [{ provide: PASARELA, useClass: FlowPasarela }],
  exports: [PASARELA],
})
export class PagosModule {}
