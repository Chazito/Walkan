// Registra y lista las acciones del equipo Walkan en el panel admin (auditoría).
import { Inject, Injectable } from '@nestjs/common';
import type Database from 'better-sqlite3';
import { SQLITE } from '../../database/sqlite.provider';
import { ahora, nuevoId } from '../../common/util/id';

export interface Actor { id?: string; email?: string }

// Bitácora del panel de administración: quién del equipo Walkan hizo qué y cuándo (migración 033).
// Solo la ve un super admin. No guarda contraseñas ni claves temporales: solo la acción y a quién afectó.
@Injectable()
export class BitacoraService {
  constructor(@Inject(SQLITE) private readonly db: Database.Database) {}

  // Anota una acción. Sin actor queda como 'sistema' y el detalle se corta a 300 caracteres.
  registrar(actor: Actor | undefined, accion: string, detalle = ''): void {
    this.db.prepare(`INSERT INTO bitacora_staff (id,fecha,actor_id,actor_email,accion,detalle)
      VALUES (?,?,?,?,?,?)`).run(nuevoId(), ahora(), actor?.id ?? null, actor?.email ?? 'sistema', accion, detalle.slice(0, 300));
  }

  /** Últimas acciones, la más reciente primero. */
  listar(limite = 200): { fecha: string; actor: string; accion: string; detalle: string }[] {
    return (this.db.prepare('SELECT fecha, actor_email, accion, detalle FROM bitacora_staff ORDER BY fecha DESC, rowid DESC LIMIT ?')
      .all(Math.min(Math.max(limite, 1), 1000)) as any[])
      .map((r) => ({ fecha: r.fecha, actor: r.actor_email, accion: r.accion, detalle: r.detalle }));
  }
}
