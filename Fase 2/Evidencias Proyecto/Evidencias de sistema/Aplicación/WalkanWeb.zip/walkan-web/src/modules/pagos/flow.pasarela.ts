import { Inject, Injectable, Logger } from '@nestjs/common';
import { CONFIG } from '../../config/config.provider';
import { AppConfig } from '../../config/configuracion';
import { firmarParams } from './firma';
import { CrearPagoInput, EstadoPago, PagoCreado, PasarelaPago } from './pasarela.interface';

// Cliente de la API de Flow. Cada llamada va firmada (ver firma.ts) con la secretKey;
// sin las llaves en el .env, Flow responde error y crearPago revienta con el detalle.
@Injectable()
export class FlowPasarela implements PasarelaPago {
  private readonly logger = new Logger('FlowPasarela');
  constructor(@Inject(CONFIG) private readonly cfg: AppConfig) {}

  private firmar(p: Record<string, string | number>): string {
    return firmarParams(p, this.cfg.flow.secretKey);
  }

  // Pago único: Flow devuelve la URL a la que hay que mandar al cliente para que pague.
  async crearPago(i: CrearPagoInput): Promise<PagoCreado> {
    const params: Record<string, string | number> = {
      apiKey: this.cfg.flow.apiKey,
      commerceOrder: i.orden,
      subject: i.asunto,
      currency: 'CLP',
      amount: i.monto,
      email: i.email,
      urlConfirmation: i.urlConfirmacion,
      urlReturn: i.urlRetorno,
    };
    // La firma se calcula con todos los params y recién después se agrega 's'.
    params.s = this.firmar(params);
    const body = new URLSearchParams(params as Record<string, string>).toString();
    const r = await fetch(`${this.cfg.flow.apiUrl}/payment/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    });
    const data: any = await r.json().catch(() => ({}));
    if (!r.ok || !data.url || !data.token) {
      throw new Error(`Flow payment/create falló (${r.status}): ${JSON.stringify(data)}`);
    }
    // Flow devuelve url y token por separado; el navegador tiene que ir a url?token=...
    return { url: `${data.url}?token=${data.token}`, token: data.token, ordenFlow: String(data.flowOrder ?? '') };
  }

  // Consulta por nuestro número de orden (commerceOrder): sirve cuando no tenemos el token a mano.
  async estadoPorOrden(orden: string): Promise<EstadoPago> {
    const params: Record<string, string | number> = { apiKey: this.cfg.flow.apiKey, commerceId: orden };
    params.s = this.firmar(params);
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    const r = await fetch(`${this.cfg.flow.apiUrl}/payment/getStatusByCommerceId?${qs}`);
    const data: any = await r.json().catch(() => ({}));
    return { pagado: data.status === 2, estado: String(data.status ?? '?'), raw: data, orden: String(data.commerceOrder ?? ''), monto: Number(data.amount ?? 0) };
  }

  // Consulta por el token que Flow entrega en la confirmación y el retorno.
  async estadoPago(token: string): Promise<EstadoPago> {
    const params: Record<string, string | number> = { apiKey: this.cfg.flow.apiKey, token };
    params.s = this.firmar(params);
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    const r = await fetch(`${this.cfg.flow.apiUrl}/payment/getStatus?${qs}`);
    const data: any = await r.json().catch(() => ({}));
    // status Flow: 1 pendiente, 2 pagado, 3 rechazado, 4 anulado
    return { pagado: data.status === 2, estado: String(data.status ?? '?'), raw: data, orden: String(data.commerceOrder ?? ''), monto: Number(data.amount ?? 0) };
  }
  // ---- Cobro automático (customer/*). Requiere el medio "Cargo Automático" contratado en la cuenta de Flow. ----
  private async llamar(metodo: 'GET' | 'POST', ruta: string, p: Record<string, string | number>): Promise<any> {
    const params: Record<string, string | number> = { apiKey: this.cfg.flow.apiKey, ...p };
    params.s = this.firmar(params);
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    const r = metodo === 'GET'
      ? await fetch(`${this.cfg.flow.apiUrl}/${ruta}?${qs}`, { signal: AbortSignal.timeout(20_000) })
      : await fetch(`${this.cfg.flow.apiUrl}/${ruta}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: qs, signal: AbortSignal.timeout(20_000) });
    const data: any = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`Flow ${ruta} falló (${r.status}): ${data?.message ?? JSON.stringify(data)}`);
    return data;
  }

  async crearCliente(i: { nombre: string; email: string; externoId: string }): Promise<string> {
    const d = await this.llamar('POST', 'customer/create', { name: i.nombre, email: i.email, externalId: i.externoId });
    if (!d.customerId) throw new Error(`Flow customer/create no devolvió customerId: ${JSON.stringify(d)}`);
    return String(d.customerId);
  }

  // El cliente de Flow inscribe su tarjeta en la página de Flow y vuelve a urlRetorno.
  async inscribirTarjeta(clienteId: string, urlRetorno: string): Promise<{ url: string; token: string }> {
    const d = await this.llamar('POST', 'customer/register', { customerId: clienteId, url_return: urlRetorno });
    if (!d.url || !d.token) throw new Error(`Flow customer/register no devolvió url/token: ${JSON.stringify(d)}`);
    return { url: `${d.url}?token=${d.token}`, token: String(d.token) };
  }

  async estadoInscripcion(token: string) {
    const d = await this.llamar('GET', 'customer/getRegisterStatus', { token });
    // status 1 = tarjeta inscrita.
    return { inscrita: String(d.status) === '1', clienteId: String(d.customerId ?? ''), marca: String(d.creditCardType ?? ''), ultimos4: String(d.last4CardDigits ?? '') };
  }

  async cobrarTarjeta(i: { clienteId: string; orden: string; asunto: string; monto: number }): Promise<EstadoPago> {
    const d = await this.llamar('POST', 'customer/charge', { customerId: i.clienteId, commerceOrder: i.orden, subject: i.asunto, amount: i.monto, currency: 'CLP' });
    // Misma respuesta que payment/getStatus: 1 pendiente, 2 pagado, 3 rechazado, 4 anulado.
    return { pagado: Number(d.status) === 2, estado: String(d.status ?? '?'), raw: d, orden: String(d.commerceOrder ?? ''), monto: Number(d.amount ?? 0) };
  }

  async quitarTarjeta(clienteId: string): Promise<void> {
    await this.llamar('POST', 'customer/unRegister', { customerId: clienteId });
  }
}
