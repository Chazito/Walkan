// Configuración central: lee las variables de entorno y define los planes (precios, cupos, funciones).
import { resolve } from 'path';

export interface AppConfig {
  port: number;
  dbPath: string;
  migrationsDir: string;
  appUrl: string;
  sessionSecret: string;
  flow: { apiUrl: string; apiKey: string; secretKey: string };
  /** Planes: precio, cupos y funciones. Única fuente de verdad (la landing, el registro y Mi plan leen de acá). */
  planes: Record<string, PlanDef>;
  /** Cajas desde la segunda: arriendo mensual que se suma a la renovación hasta completar `cuotas` pagos. */
  cajaAdicional: { cuota: number; cuotas: number };
  // Atajos derivados de `planes` (los usa el código existente).
  planMonto: Record<string, number>;
  planCajas: Record<string, number>; // máximo de cajas registradas (incluida + adicionales)
  planCajeros: Record<string, number>;
  smtp: { host: string; port: number; user: string; pass: string; from: string };
  pagosSimulados: boolean;
  produccion: boolean;
}

export interface PlanDef {
  monto: number;            // mensual, CLP con IVA
  cajasIncluidas: number;   // sin costo
  cajasMax: number;         // incluidas + adicionales en arriendo
  cajeros: number;          // cajeros activos
  productos: number | null; // null = sin límite
  historialMeses: number | null; // null = completo
  funciones: { analiticas: boolean; pedidosProveedor: boolean; cobroQr: boolean };
}

// Planes (decididos el 14-nov-2026, apuntando a minimarkets y almacenes con equipo).
// Hoy se aplican: cajas, cajeros y cobro con QR. Límite de productos, historial, analíticas y pedidos a
// proveedores los aplica el módulo de cada área leyendo estos valores (ver docs/plan/coordinacion-franco-alvaro.md).
export const PLANES_DEF: Record<string, PlanDef> = {
  'Esencial':    { monto: 12990, cajasIncluidas: 1, cajasMax: 2, cajeros: 3,  productos: 2000,  historialMeses: 12,   funciones: { analiticas: false, pedidosProveedor: false, cobroQr: false } },
  'Profesional': { monto: 22990, cajasIncluidas: 1, cajasMax: 4, cajeros: 8,  productos: 10000, historialMeses: 24,   funciones: { analiticas: true,  pedidosProveedor: true,  cobroQr: true } },
  'Empresa':     { monto: 37990, cajasIncluidas: 1, cajasMax: 8, cajeros: 20, productos: null,  historialMeses: null, funciones: { analiticas: true,  pedidosProveedor: true,  cobroQr: true } },
};
// Saca de PLANES_DEF un mapa plan -> valor (por ejemplo el monto de cada plan).
const derivar = <K extends keyof PlanDef>(k: K) =>
  Object.fromEntries(Object.entries(PLANES_DEF).map(([n, p]) => [n, p[k]])) as Record<string, PlanDef[K]>;

// Todo sale de variables de entorno con defaults pensados para desarrollo local.
// Ojo en producción: SESSION_SECRET y las llaves de Flow sí o sí hay que setearlas,
// y FLOW_API_URL apunta al sandbox por defecto.
const SECRETO_DEV = 'walkan-dev-secret-cambiar-en-produccion';

// En producción (NODE_ENV=production) la app NO arranca con secretos de desarrollo: un secreto público
// firmaría las cookies de cualquiera y descifraría las llaves Flow de los negocios, y sin llaves de Flow
// los pagos quedarían simulados (planes gratis). Mejor caerse al partir que quedar abierta.
export function validarProduccion(c: AppConfig): void {
  if (!c.produccion) return;
  const fallas: string[] = [];
  if (c.sessionSecret === SECRETO_DEV || c.sessionSecret.length < 32) fallas.push('SESSION_SECRET (mínimo 32 caracteres, distinto al de desarrollo)');
  if (!c.flow.apiKey || !c.flow.secretKey) fallas.push('FLOW_API_KEY y FLOW_SECRET_KEY');
  if (process.env.PAGOS_SIMULADOS === '1') fallas.push('PAGOS_SIMULADOS=1 no se permite');
  if (!c.appUrl.startsWith('https://')) fallas.push('APP_URL debe ser https://');
  // Con el sandbox de Flow cualquiera "paga" un plan con una tarjeta de prueba. En producción solo se permite
  // a propósito (demo, defensa) con FLOW_SANDBOX_OK=1; main.ts lo avisa en el log al arrancar.
  if (/sandbox/i.test(c.flow.apiUrl) && process.env.FLOW_SANDBOX_OK !== '1') {
    fallas.push('FLOW_API_URL apunta al sandbox de Flow (pagos de prueba): usa https://www.flow.cl/api, o define FLOW_SANDBOX_OK=1 si es una demo');
  }
  if (fallas.length) throw new Error('Configuración de producción inválida: ' + fallas.join('; '));
}

export function cargarConfig(): AppConfig {
  const produccion = process.env.NODE_ENV === 'production';
  return {
    produccion,
    port: parseInt(process.env.PORT ?? '4000', 10),
    dbPath: resolve(process.env.DB_PATH ?? './data/walkan-web.db'),
    migrationsDir: resolve(process.env.MIGRATIONS_DIR ?? './migrations'),
    appUrl: process.env.APP_URL ?? 'http://localhost:4000',
    sessionSecret: process.env.SESSION_SECRET || SECRETO_DEV,
    flow: {
      apiUrl: process.env.FLOW_API_URL ?? 'https://sandbox.flow.cl/api',
      apiKey: process.env.FLOW_API_KEY ?? '',
      secretKey: process.env.FLOW_SECRET_KEY ?? '',
    },
    planes: PLANES_DEF,
    // Caja adicional: $5.990 al mes por 20 meses (≈ costo del kit); pagadas las cuotas, la caja queda del negocio.
    cajaAdicional: { cuota: 5990, cuotas: 20 },
    planMonto: derivar('monto'),
    planCajas: derivar('cajasMax'),
    planCajeros: derivar('cajeros'),
    // Correo saliente (comprobantes de venta). Sin SMTP_HOST/USER/PASS, los envíos quedan como "simulado".
    smtp: {
      host: process.env.SMTP_HOST ?? '', port: parseInt(process.env.SMTP_PORT ?? '587', 10),
      user: process.env.SMTP_USER ?? '', pass: process.env.SMTP_PASS ?? '', from: process.env.SMTP_FROM ?? '',
    },
    // Plan B de la demo: sin llaves de Flow (o PAGOS_SIMULADOS=1) el pago se simula.
    // Nunca en producción (validarProduccion además se niega a arrancar sin llaves).
    pagosSimulados: !produccion && (process.env.PAGOS_SIMULADOS === '1' || !process.env.FLOW_API_KEY),
  };
}
