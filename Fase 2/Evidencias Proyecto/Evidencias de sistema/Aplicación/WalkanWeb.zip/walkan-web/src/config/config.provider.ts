import { AppConfig, cargarConfig } from './configuracion';
// Token para inyectar la config con @Inject(CONFIG); se lee una sola vez al levantar la app.
export const CONFIG = Symbol('CONFIG');
export const configProvider = { provide: CONFIG, useFactory: (): AppConfig => cargarConfig() };
