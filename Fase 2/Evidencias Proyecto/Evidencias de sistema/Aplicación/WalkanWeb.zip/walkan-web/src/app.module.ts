// Acá se juntan todos los módulos de la web pública de Walkan (altas, pagos Flow, panel del cliente y del staff).
import { Module } from '@nestjs/common';
import { DatabaseModule } from './database/database.module';
import { ContextoTenantModule } from './common/contexto-tenant';
import { AuthModule } from './modules/auth/auth.module';
import { PagosModule } from './modules/pagos/pagos.module';
import { SolicitudesModule } from './modules/solicitudes/solicitudes.module';
import { ViewsModule } from './modules/views/views.module';
import { CatalogoModule } from './modules/catalogo/catalogo.module';
import { SyncModule } from './modules/sync/sync.module';
import { ComprasModule } from './modules/compras/compras.module';
import { AdminModule } from './modules/admin/admin.module';
import { RegistroModule } from './modules/registro/registro.module';
import { PrivacidadModule } from './modules/privacidad/privacidad.module';
import { AparienciaModule } from './modules/apariencia/apariencia';
import { CuentaModule } from './modules/cuenta/cuenta.module';
import { RecuperacionModule } from './modules/recuperacion/recuperacion.module';
import { SoporteModule } from './modules/soporte/soporte.module';

// Módulo raíz. DatabaseModule y ContextoTenantModule van primero porque el resto depende de ellos.
@Module({
  imports: [
    DatabaseModule, ContextoTenantModule, AuthModule, PagosModule, SolicitudesModule,
    ViewsModule, CatalogoModule, SyncModule, ComprasModule, AdminModule, RegistroModule, PrivacidadModule, AparienciaModule, CuentaModule, RecuperacionModule, SoporteModule,
  ],
})
export class AppModule {}
