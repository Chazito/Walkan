// Punto de entrada de walkan-web: arma Fastify con sus protecciones (tope por IP, CSRF, CSP), vistas EJS y levanta el servidor.
import 'reflect-metadata';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { NestFactory } from '@nestjs/core';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { HttpException, Logger, ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';
import { cargarConfig, validarProduccion } from './config/configuracion';
import { ContextoTenant } from './common/contexto-tenant';
import { rechazoCsrf, sinTopeGlobal } from './common/limite';
import { claveIp } from './common/util/ip';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const ejs = require('ejs');
// eslint-disable-next-line @typescript-eslint/no-var-requires
const fastifyCookie = require('@fastify/cookie');
// eslint-disable-next-line @typescript-eslint/no-var-requires
const rateLimit = require('@fastify/rate-limit');

// Lector de .env a mano para no meter dotenv. Lo que ya venga del entorno real (pm2, systemd)
// gana: solo rellena las variables que faltan.
// ponytail: no entiende comillas ni comentarios al final de la línea; usar dotenv si el .env se complica.
function cargarEnv(): void {
  if (!existsSync('.env')) return;
  for (const line of readFileSync('.env', 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].trim();
  }
}

async function bootstrap(): Promise<void> {
  cargarEnv();
  const config = cargarConfig();
  validarProduccion(config);
  if (config.produccion && /sandbox/i.test(config.flow.apiUrl)) {
    new Logger('Bootstrap').warn('Flow está en modo SANDBOX (FLOW_SANDBOX_OK=1): los pagos son de prueba y cualquiera puede activar un plan con una tarjeta de prueba. Solo para demos.');
  }
  const app = await NestFactory.create<NestFastifyApplication>(AppModule,
    // En el servidor la app va detrás de nginx en la misma máquina: solo se cree el X-Forwarded-For que pone ese
    // proxy (127.0.0.1), así el tope por IP ve la IP real y nadie lo salta inventando el encabezado.
    // Tiempos y tamaño acotados para que un cliente lento o un cuerpo gigante no amarren el servidor.
    new FastifyAdapter({
      trustProxy: process.env.TRUST_PROXY || '127.0.0.1',
      bodyLimit: 1024 * 1024, connectionTimeout: 30_000, requestTimeout: 30_000, keepAliveTimeout: 10_000,
    }));
  // whitelist bota los campos que no están en el DTO. Ojo: con body tipado como interface
  // (sync, compras) no hay nada que validar, por eso esos se revisan a mano en el servicio.
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  // Cada request corre en su propio store de tenant (lo llena el SesionGuard). Ver ContextoTenant.
  const ctx = app.get(ContextoTenant);
  const fastify = app.getHttpAdapter().getInstance();
  fastify.addHook('onRequest', (_req: unknown, _rep: unknown, done: () => void) => ctx.abrir(done));

  // Tope por IP para páginas y API (ISO 27001 A.8.6). Holgado: un local con varias pestañas detrás de la misma IP
  // no debe llegar. Las rutas públicas sensibles (login, registro, contacto, cajas) tienen su propio tope más
  // estricto con @Limite (common/limite.ts), con contador aparte.
  await app.register(rateLimit, {
    max: Number(process.env.RATE_LIMIT_MAX) || 600, timeWindow: '1 minute', // las pruebas e2e lo suben (todas desde una IP)
    // Las IPv6 se cuentan por red /64 (ver claveIp): rotar direcciones dentro de la misma conexión no salta el tope.
    keyGenerator: (req: { ip: string }) => claveIp(req.ip),
    // Fuera del tope: archivos estáticos (css/js/fuentes/geo, el navegador los cachea) y las imágenes de productos
    // (una por producto en cada carga del inventario). Se decide por la ruta que eligió el router (ver sinTopeGlobal).
    allowList: (req: { routeOptions?: { url?: string } }) => sinTopeGlobal(req.routeOptions?.url),
    // HttpException y no un objeto suelto: así Nest responde 429 sin escribir un ERROR en el log por cada rechazo
    // (bajo un ataque eso llenaba el disco).
    errorResponseBuilder: () => new HttpException('Demasiadas solicitudes: espera un minuto e intenta de nuevo.', 429),
  });

  // CSRF, segunda capa: en la API, lo que cambia datos no se acepta desde otro sitio ni como formulario
  // (salvo los avisos de Flow). Ver rechazoCsrf.
  fastify.addHook('onRequest', (req: { method: string; headers: Record<string, unknown>; routeOptions?: { url?: string } }, _rep: unknown, done: (e?: Error) => void) => {
    const r = rechazoCsrf(req.method, req.routeOptions?.url, req.headers);
    done(r ? new HttpException(r[1], r[0]) : undefined);
  });

  // Encabezados de seguridad en todas las respuestas (sin helmet: son pocas líneas). La CSP permite solo lo
  // propio + Google Fonts + Nominatim (autocompletar dirección del registro). Los hash son los dos scripts en
  // línea que quedan: head.ejs (clase 'js') y el botón "Revisar de nuevo" de registro-retorno.ejs.
  // style-src lleva 'unsafe-inline' porque las vistas usan atributos style; no habilita ejecutar código.
  const csp = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-hashes' 'sha256-Du+OJKJSbdUgz5nrHeWWINvez6XKDDU/tyj/5c2uvwo=' 'sha256-9gOBGqEQINNDuds+tkXbNzih6klbz+KeCyxEj4KRLeM='",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: blob:",
    "connect-src 'self' https://nominatim.openstreetmap.org",
    "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'none'",
  ].join('; ');
  const https = config.appUrl.startsWith('https://');
  fastify.addHook('onSend', (req: { url?: string }, rep: { header: (k: string, v: string) => void; getHeader: (k: string) => unknown }, payload: unknown, done: (e: null, p: unknown) => void) => {
    // Respuestas de la API (datos personales, claves temporales del staff): que ni el navegador ni un proxy
    // las guarden, salvo las rutas que ya fijan su propia caché (imágenes de productos, exportación).
    if (String(req.url ?? '').startsWith('/api/') && !rep.getHeader('cache-control')) rep.header('Cache-Control', 'no-store');
    rep.header('Content-Security-Policy', csp);
    rep.header('X-Content-Type-Options', 'nosniff');
    rep.header('X-Frame-Options', 'DENY');
    rep.header('Referrer-Policy', 'strict-origin-when-cross-origin');
    rep.header('Permissions-Policy', 'camera=(self), microphone=(), geolocation=(self), payment=()');
    rep.header('Cross-Origin-Opener-Policy', 'same-origin');
    if (https) rep.header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    done(null, payload);
  });

  // Cookies firmadas para la sesión.
  await app.register(fastifyCookie, { secret: config.sessionSecret });
  // /favicon.ico es un archivo real en public/ (logo Toldo); ya no se redirige al SVG.

  // Vistas EJS + estáticos (caché corta: el navegador no revalida cada archivo en cada carga).
  app.setViewEngine({ engine: { ejs }, templates: join(process.cwd(), 'views') });
  app.useStaticAssets({ root: join(process.cwd(), 'public'), prefix: '/', maxAge: '1h' });

  // Solo localhost por defecto: nginx y el túnel llegan por 127.0.0.1. Así la app no queda expuesta en la
  // LAN/VPN saltándose el proxy. HOST=0.0.0.0 para abrirla a propósito.
  const host = process.env.HOST || '127.0.0.1';
  await app.listen(config.port, host);
  new Logger('Bootstrap').log(`Walkan web en http://${host}:${config.port} (Flow: ${config.flow.apiUrl})`);
}
void bootstrap();
