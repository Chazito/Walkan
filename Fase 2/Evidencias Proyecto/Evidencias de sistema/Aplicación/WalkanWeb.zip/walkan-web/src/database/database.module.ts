import { Global, Module } from '@nestjs/common';
import { sqliteProvider, SQLITE } from './sqlite.provider';
import { configProvider, CONFIG } from '../config/config.provider';

// Global para que cualquier módulo pueda inyectar la BD y la config sin importarlo a mano.
@Global()
@Module({
  providers: [sqliteProvider, configProvider],
  exports: [SQLITE, CONFIG],
})
export class DatabaseModule {}
