import { readdirSync, readFileSync } from 'fs';
import { join } from 'path';
import type Database from 'better-sqlite3';

// Migrador casero: corre los .sql de la carpeta en orden alfabético (por eso van con prefijo
// numérico) y anota cada uno en _migraciones para no repetirlo.
// ponytail: sin rollback ni "down"; si una migración sale mala, se arregla con otra nueva.
const TABLA = '_migraciones';
export function ejecutarMigraciones(db: Database.Database, dir: string, log: (m: string) => void = () => {}): string[] {
  db.prepare(`CREATE TABLE IF NOT EXISTS ${TABLA} (nombre TEXT PRIMARY KEY, aplicada_en TEXT NOT NULL)`).run();
  const archivos = readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
  const ya = db.prepare(`SELECT 1 FROM ${TABLA} WHERE nombre=?`);
  const reg = db.prepare(`INSERT INTO ${TABLA} (nombre, aplicada_en) VALUES (?, ?)`);
  const aplicadas: string[] = [];
  for (const a of archivos) {
    if (ya.get(a)) continue;
    const sql = readFileSync(join(dir, a), 'utf8');
    // Archivo + registro en la misma transacción: o queda todo aplicado o nada.
    db.transaction(() => { db.exec(sql); reg.run(a, new Date().toISOString()); }).immediate();
    aplicadas.push(a); log(`migración aplicada: ${a}`);
  }
  return aplicadas;
}
