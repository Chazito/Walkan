// Abre la base SQLite y la deja lista (pragmas + migraciones) para inyectarla en el resto de la app.
import { mkdirSync } from 'fs';
import { dirname } from 'path';
import Database from 'better-sqlite3';
import { AppConfig, cargarConfig } from '../config/configuracion';
import { ejecutarMigraciones } from './migrator';

// Token de inyección: con esto los repositorios piden la conexión a la base.
export const SQLITE = Symbol('SQLITE');

export function abrirBaseDeDatos(config: AppConfig): Database.Database {
  mkdirSync(dirname(config.dbPath), { recursive: true });
  const db = new Database(config.dbPath);
  // WAL deja leer mientras alguien escribe (panel leyendo mientras la caja sincroniza);
  // busy_timeout espera hasta 5 s en vez de tirar SQLITE_BUSY al tiro.
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');
  return db;
}

export const sqliteProvider = {
  provide: SQLITE,
  useFactory: (): Database.Database => {
    const cfg = cargarConfig();
    const db = abrirBaseDeDatos(cfg);
    // FK apagadas SOLO durante las migraciones: permite recrear tablas referenciadas
    // (p.ej. usuarios, referida por cajas) sin violar constraints. Se reactivan después.
    db.pragma('foreign_keys = OFF');
    ejecutarMigraciones(db, cfg.migrationsDir, (m) => console.log(`[migrator] ${m}`));
    db.pragma('foreign_keys = ON');
    return db;
  },
};
