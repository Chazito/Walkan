// Parte de panel.js: el servidor junta public/js/panel/*.js en orden (ver views.controller.ts) dentro de un solo
// (function(){ … })(), así que todo comparte el mismo scope. No es un módulo suelto: no cargarlo solo.
  // ================= RESUMEN (alertas/KPIs derivados) =================
  // No llama a la API: todo se calcula con lo que ya está en `db`. Pinta los KPIs del día,
  // las campanitas del sidebar, la lista de alertas y los últimos 5 movimientos.
  // Se llama desde muchos lados (casi cada render), así que conviene que siga siendo liviano.
  function renderResumen(){
    var ventas=db.ventasHoy||[];
    var totalHoy=ventas.reduce(function(s,v){return s+(v.total||0);},0);
    var prom=ventas.length?Math.round(totalHoy/ventas.length):0;
    var ag=db.productos.filter(function(p){return p.stock===0||(estadoStock(p).c==='bad'&&p.stock>=0);}).length;
    var neg=db.productos.filter(function(p){return p.stock<0;}).length; // se vendió más de lo registrado: hay que contar
    var bj=db.productos.filter(function(p){return estadoStock(p).c==='warn';}).length;
    var vc=db.productos.filter(function(p){return venceInfo(p.vence).c==='bad';}).length;
    var vp=db.productos.filter(function(p){return venceInfo(p.vence).c==='warn';}).length;
    var pend=db.pedidos.filter(function(o){return o.estado==='Enviado';}).length;
    // Atrasado = enviado hace más días que la entrega del proveedor + 1 de gracia.
    var atr=db.pedidos.filter(function(o){ if(o.estado!=='Enviado'||!o.actualizado) return false; var pv=db.proveedores.find(function(x){return x.id===o.prov;}), lead=pv&&pv.lead!=null?pv.lead:3;
      return (Date.parse(hoyISO())-Date.parse(fechaCLde(o.actualizado)))/86400000>lead+1; }).length;
    if($('ventasHoy')) $('ventasHoy').textContent=clp(totalHoy);
    // Ganancia estimada = ventas de hoy − costo FIFO de lo vendido hoy (db.costoHoy, de /api/inventario/costo-ventas).
    // Costos netos (factura) se comparan con la venta neta (÷1,19); costos con IVA, con la venta bruta.
    var vendido=db.costoHoy>0?(db.config&&db.config.costoConIva?totalHoy:totalHoy/1.19):0, costo=db.costoHoy||0;
    // Contra el mismo día de la semana pasada hasta esta misma hora (de Chile): así se compara medio día con medio día.
    var cmp='';
    if(db.semanaPasada&&db.semanaPasada.length){
      var ahoraHM=new Date().toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit',hourCycle:'h23',timeZone:'America/Santiago'});
      var antes=db.semanaPasada.filter(function(v){ return (v.hora||'')<=ahoraHM; }).reduce(function(s,v){ return s+(v.total||0); },0);
      var dia=['domingo','lunes','martes','miércoles','jueves','viernes','sábado'][new Date(hoyISO()+'T12:00:00Z').getUTCDay()];
      if(antes) cmp=(totalHoy>=antes?'+':'−')+Math.abs(Math.round((totalHoy-antes)/antes*100))+'% vs el '+dia+' pasado a esta hora';
    }
    if($('gananciaHoy')) $('gananciaHoy').textContent=[vendido?'ganancia estimada '+clp(Math.round(vendido-costo))+' ('+Math.round((vendido-costo)/vendido*100)+'%)':'', cmp].filter(Boolean).join(' · ')||'sincronizadas desde la caja';
    if($('tickets')) $('tickets').textContent=ventas.length;
    if($('ticketProm')) $('ticketProm').textContent=clp(prom);
    if($('kpiBajo')) $('kpiBajo').textContent=ag+bj;
    $('bellInv').textContent=(ag+bj+neg)||''; $('bellInv').style.display=(ag+bj+neg)?'':'none';
    $('bellComp').textContent=pend||''; $('bellComp').style.display=pend?'':'none';
    var kp=$('kpiPed'); if(kp) kp.textContent=pend; var kpt=$('kpiPedTxt'); if(kpt){ kpt.className='delta'+(pend?' warn':''); kpt.innerHTML=pend?ico('alerta')+'por recibir':'nada por recibir'; } // el aviso ámbar solo si hay pedidos
    // Cada alerta lleva data-goto, así al hacer click te manda a la sección (ver el goto delegado más abajo).
    var li='';
    if(ag) li+='<li><a href="#inventario" data-goto="inventario" data-f="bad"><span class="d bad"></span> '+ag+' producto'+(ag>1?'s':'')+' agotado'+(ag>1?'s':'')+'</a></li>';
    if(bj) li+='<li><a href="#inventario" data-goto="inventario" data-f="warn"><span class="d warn"></span> '+bj+' con bajo stock</a></li>';
    if(neg) li+='<li><a href="#inventario" data-goto="inventario" data-f="bad"><span class="d bad"></span> '+neg+' con stock negativo: cuenta y ajusta</a></li>';
    if(vc) li+='<li><a href="#inventario" data-goto="inventario" data-f="vence"><span class="d bad"></span> '+vc+' producto'+(vc>1?'s':'')+' vencido'+(vc>1?'s':'')+'</a></li>';
    if(vp) li+='<li><a href="#inventario" data-goto="inventario" data-f="vence"><span class="d warn"></span> '+vp+' por vencer (30 días)</a></li>';
    // Preventistas que pasan hoy (día de Chile): recordar el pedido sugerido.
    var dHoy=String(new Date(hoyISO()+'T12:00:00Z').getUTCDay());
    db.proveedores.forEach(function(pv){ if((','+(pv.visita||'')+',').indexOf(','+dHoy+',')>-1) li+='<li><a href="#compras" data-goto="compras"><span class="d warn"></span> Hoy pasa el preventista de '+esc(pv.nombre)+': revisa el pedido sugerido</a></li>'; });
    if(atr) li+='<li><a href="#compras" data-goto="compras"><span class="d bad"></span> '+atr+' pedido'+(atr>1?'s':'')+' atrasado'+(atr>1?'s':'')+': llama al proveedor</a></li>';
    // Alzas de costo de los últimos 30 días (db.alzas): abre la lista para revisar precios.
    var na=(db.alzas||[]).length;
    if(na) li+='<li><a href="#inventario" data-goto="inventario" data-alzas="1"><span class="d warn"></span> Subió el costo de '+na+' producto'+(na>1?'s':'')+' este mes: revisa sus precios</a></li>';
    if(pend-atr>0) li+='<li><a href="#compras" data-goto="compras"><span class="d mut"></span> '+(pend-atr)+' pedido'+(pend-atr>1?'s':'')+' pendiente'+(pend-atr>1?'s':'')+' a proveedor</a></li>';
    var abox=$('alertsBox');
    if(li){ $('alertList').innerHTML=li; if(abox) abox.hidden=false; } else { if(abox) abox.hidden=true; }
    var mov=ventas.slice(0,5).map(function(v){ return '<tr><td>Comprobante '+esc(v.folio)+'</td><td class="muted">'+esc(v.hora)+'</td><td style="text-align:right">'+clp(v.total)+'</td></tr>'; }).join('');
    if($('movBody')) $('movBody').innerHTML=mov||'<tr><td class="muted" style="padding:14px">Sin movimientos todavía.</td></tr>';
    // "Vender primero": lotes vencidos o por vencer (la API ya los trae ordenados por vencimiento).
    var lp=db.porVencer||[];
    if($('venderPrimero')) $('venderPrimero').innerHTML=lp.length ? lp.slice(0,10).map(function(l){
      var vi=venceInfo(l.vence);
      return '<tr><td class="prin"><b>'+esc(l.nombre)+'</b></td><td data-l="Lote">'+esc(l.codigo||'Sin código')+'</td><td data-l="Cantidad">'+fmtCant(prodPorId(l.productoId), l.cantidad)+'</td><td data-l="Vence">'+esc(fmtFecha(l.vence))+'</td><td class="acc"><span class="tag '+vi.c+'">'+diasTxt(vi.dias)+'</span>'+(vi.dias!=null&&vi.dias<0?' <button class="mini" data-retirar="'+esc(l.id)+'">Retirar</button>':'')+'</td></tr>';
    }).join('')+(lp.length>10?'<tr><td colspan="5" class="muted small">y '+(lp.length-10)+' lote'+(lp.length-10>1?'s':'')+' más…</td></tr>':'')
      : '<tr><td colspan="5" class="muted" style="text-align:center;padding:16px">Nada vence en los próximos 30 días.</td></tr>';
    renderValor();
    renderChart(ventas);
    renderBienvenida();
  }

  // "Retirar" un lote vencido: da de baja todo el saldo de ese lote (ver retirarLote en inventario).
  if($('venderPrimero')) $('venderPrimero').addEventListener('click', function(e){
    var b=e.target.closest('[data-retirar]'); if(!b) return;
    var l=(db.porVencer||[]).find(function(x){return x.id===b.dataset.retirar;}), p=l&&prodPorId(l.productoId);
    if(p) retirarLote(p, l);
  });

