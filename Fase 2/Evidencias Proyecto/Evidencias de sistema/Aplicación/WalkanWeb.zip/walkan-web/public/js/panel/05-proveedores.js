// Parte de panel.js: el servidor junta public/js/panel/*.js en orden (ver views.controller.ts) dentro de un solo
// (function(){ … })(), así que todo comparte el mismo scope. No es un módulo suelto: no cargarlo solo.
  // ================= PROVEEDORES (CRUD + detalle + pedido) =================
  // API: /api/proveedores. Desde acá también se arma el pedido (formPedido), que termina en /api/pedidos.
  var provQ='';
  function renderProveedores(){
    $('provBody').innerHTML=db.proveedores.filter(function(p){ var hay=sinTildes(p.nombre+' '+p.rubro+' '+p.tel); return provQ.split(' ').every(function(w){ return hay.indexOf(w)>-1; }); }).map(function(p){
      return '<tr data-prov="'+esc(p.id)+'"><td class="prin"><b>'+esc(p.nombre)+'</b></td><td>'+esc(p.tel)+'<div class="muted small">'+esc(p.email)+'</div></td><td>'+esc(p.rubro)+(p.visita?'<div class="muted small">Pasa: '+esc(diasVisita(p.visita))+'</div>':'')+'</td>'+
        '<td class="acc" style="white-space:nowrap"><button class="mini" data-detalle-prov>Detalle</button> <button class="mini" data-pedido>Pedido</button> <button class="mini icon" data-edit-prov aria-label="Editar '+esc(p.nombre)+'">'+ico('editar')+'</button> <button class="mini icon del" data-del-prov aria-label="Eliminar '+esc(p.nombre)+'">'+ico('borrar')+'</button></td></tr>';
    }).join('');
    $('kpiProv').textContent=db.proveedores.length;
  }
  $('buscarProv').addEventListener('input', function(){ provQ=sinTildes(this.value); renderProveedores(); });

  // Crear/editar proveedor. `lead` = días que se demora en entregar (3 por defecto); lo usa la predicción.
  function formProveedor(p){
    p=p||{};
    abrirModal(p.id?'Editar proveedor':'Nuevo proveedor',
      '<div class="form-grid">'+
      '<div class="f full"><label>Nombre</label><input id="pvNombre" value="'+esc(p.nombre)+'"></div>'+
      '<div class="f"><label>Teléfono</label><input id="pvTel" value="'+esc(p.tel)+'"></div>'+
      '<div class="f"><label>Correo</label><input id="pvEmail" value="'+esc(p.email)+'"></div>'+
      '<div class="f"><label>Rubro / qué surte</label><input id="pvRubro" value="'+esc(p.rubro)+'"></div>'+
      '<div class="f"><label>Días de entrega '+ayuda('Cuántos días se demora en llegar un pedido. Se usa para sugerir cuándo y cuánto pedir.')+'</label><input id="pvLead" type="number" min="0" max="60" value="'+(p.lead!=null?Number(p.lead):3)+'"></div>'+
      '<fieldset class="f full" style="border:0;padding:0;margin:0"><legend class="small" style="font-weight:600;margin-bottom:6px">Días que pasa el preventista '+ayuda('Si el vendedor del proveedor pasa por tu local ciertos días, ese día el Resumen te recuerda revisar el pedido sugerido.')+'</legend><div style="display:flex;gap:10px;flex-wrap:wrap">'+
        DIAS_SEM.map(function(d){ return '<label class="check small"><input type="checkbox" class="pvDia" name="pvDia" value="'+d[0]+'"'+((','+(p.visita||'')+',').indexOf(','+d[0]+',')>-1?' checked':'')+'> '+d[1]+'</label>'; }).join('')+'</div></fieldset>'+
      '</div><div style="display:flex;gap:8px;margin-top:18px"><button class="btn btn-primary" id="guardarProv">'+(p.id?'Guardar cambios':'Crear proveedor')+'</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    $('guardarProv').addEventListener('click', function(){
      var nombre=$('pvNombre').value.trim(); if(!nombre){ $('pvNombre').focus(); return; }
      var datos={nombre:nombre, tel:$('pvTel').value.trim(), email:$('pvEmail').value.trim(), rubro:$('pvRubro').value.trim(), lead:$('pvLead').value===''?3:+$('pvLead').value, visita:[].slice.call(document.querySelectorAll('#modalBody .pvDia:checked')).map(function(c){ return c.value; }).join(',')};
      var req = p.id ? API.send('PUT','/api/proveedores/'+encodeURIComponent(p.id),datos) : API.send('POST','/api/proveedores',datos);
      req.then(function(saved){
        if(p.id){ var i=db.proveedores.findIndex(function(x){return x.id===p.id;}); if(i>-1) db.proveedores[i]=saved; }
        else { db.proveedores.push(saved); }
        renderProveedores(); renderResumen(); cerrarModal(); // los días de visita cambian las alertas
      }).catch(function(e){ aviso('No se pudo guardar: '+e.message); });
    });
  }
  $('nuevoProv').addEventListener('click', function(){ formProveedor(null); });

  function productosDeProv(id){ return db.productos.filter(function(p){return p.prov===id;}); }
  var soloDig=function(t){ return (t||'').replace(/\D/g,''); };
  // Link de WhatsApp. wa.me necesita el número con código de país (569...), si lo guardaron sin el 56 no va a funcionar.
  // Si lo guardaron sin el 56 (912345678 o 12345678) se completa como celular chileno.
  function waLink(tel, msg){ var d=soloDig(tel); if(d.length===9&&d[0]==='9') d='56'+d; else if(d.length===8) d='569'+d; return 'https://wa.me/'+d+'?text='+encodeURIComponent(msg); }
  // Ficha del proveedor: contacto, botones de WhatsApp/correo y los productos que tiene asociados.
  function detalleProv(id){
    var p=db.proveedores.find(function(x){return x.id===id;}); if(!p) return;
    var prods=productosDeProv(id); var pr=prods.length?prods.map(function(x){ var e=estadoStock(x); return '<tr><td>'+esc(x.nombre)+'</td><td style="text-align:right"><span class="tag '+e.c+'">'+fmtCant(x, x.stock)+(esKg(x)?'':' un')+'</span></td></tr>'; }).join(''):'<tr><td class="muted" colspan="2">Sin productos asociados.</td></tr>';
    var wa=p.tel?'<a class="btn btn-ghost" href="'+esc(waLink(p.tel,'Hola '+p.nombre+', te escribo de '+negocio()+'.'))+'" target="_blank" rel="noopener">'+ico('mensaje')+'WhatsApp</a>':'';
    var mail=p.email?'<a class="btn btn-ghost" href="mailto:'+esc(p.email)+'">'+ico('correo')+'Correo</a>':'';
    abrirModal(p.nombre,
      '<div class="mblock"><h4>Contacto</h4><div class="kv"><span class="muted">Teléfono</span><b>'+esc(p.tel)+'</b><span class="muted">Correo</span><b>'+esc(p.email)+'</b><span class="muted">Rubro</span><b>'+esc(p.rubro)+'</b></div><div style="display:flex;gap:8px;margin-top:12px">'+wa+mail+'</div></div>'+
      (function(){ var peds=db.pedidos.filter(function(o){return o.prov===id;}), abiertos=peds.filter(function(o){return o.estado!=='Recibido';}).length, m=hoyISO().slice(0,7);
        var mes=db.compras.filter(function(c){ return c.prov===p.nombre&&c.tipo!=='Devolucion'&&(c.fecha||'').slice(0,7)===m; }).reduce(function(s,c){return s+c.total;},0);
        return '<div class="mblock"><h4>Compras</h4><div class="kv"><span class="muted">Pedidos</span><b>'+peds.length+(abiertos?' ('+abiertos+' abierto'+(abiertos>1?'s':'')+')':'')+'</b><span class="muted">Ingresado este mes</span><b>'+clp(mes)+'</b><span class="muted">Días de entrega</span><b>'+Number(p.lead!=null?p.lead:3)+'</b></div></div>'; })()+
      '<div class="mblock"><h4>Productos que surte</h4><table><tbody>'+pr+'</tbody></table></div>'+
      '<button class="btn btn-primary" id="irPedido">Hacer pedido</button>');
    var ir=$('irPedido'); if(ir) ir.addEventListener('click', function(){ formPedido(id); });
  }
  // Armar pedido a un proveedor. Las cantidades parten con la `sugerida` de la predicción
  // (/api/inventario/prediccion) y se valorizan a costo. Además se pueden sumar líneas
  // del catálogo o productos que todavía no existen (prod:null).
  // Con `ped` (un borrador) el mismo formulario sirve para editarlo: parte con sus cantidades, costos y nota.
  function formPedido(id, ped){
    if(db.sinPedidos){ aviso('Los pedidos a proveedores son parte de los planes Profesional y Empresa. Anota lo que llega en Compras → Registrar ingreso sin pedido.'); return; }
    var p=db.proveedores.find(function(x){return x.id===id;}) || (ped?{id:'',nombre:'Sin proveedor',tel:''}:null); if(!p) return;
    var prods=productosDeProv(id);
    var itemDe=function(pid){ return ped&&ped.items.find(function(i){return i.prod===pid;}); };
    // Con proveedores de miles de productos el formulario se pegaba: la sugerencia se buscaba recorriendo toda la lista por
    // cada fila, y se pintaban todas. Ahora la sugerencia sale de un índice y, si son más de MAX_HAB, se muestran los que
    // más conviene reponer (y los que ya están en el pedido); el resto se busca en «Otros productos › Del catálogo».
    var predPor={}; db.prediccion.forEach(function(z){ predPor[z.id]=z; });
    var MAX_HAB=60, totalHab=prods.length;
    if(prods.length>MAX_HAB){
      var sugDe=function(x){ var pr=predPor[x.id]; return pr?pr.sugerida:0; };
      var enPed=prods.filter(function(x){ return itemDe(x.id); });
      var resto=ped?[]:prods.filter(function(x){ return !itemDe(x.id) && sugDe(x)>0; }).sort(function(a,b){ return sugDe(b)-sugDe(a); });
      prods=enPed.concat(resto.slice(0, Math.max(0, MAX_HAB-enPed.length)));
    }
    var visibles={}; prods.forEach(function(x){ visibles[x.id]=1; });
    var filas=prods.map(function(x){ var e=estadoStock(x); var pr=predPor[x.id]; var it=itemDe(x.id);
      var sug=ped?(it?it.qty:0):(pr?pr.sugerida:0), costo=it?it.costo:x.costo;
      return '<tr><td>'+esc(x.nombre)+'</td><td style="text-align:center"><span class="tag '+e.c+'">'+fmtCant(x, x.stock)+'</span></td><td style="text-align:right"><input class="qty" name="qty" type="number" min="0" step="'+paso(x)+'" data-costo="'+Number(costo)+'" data-prod="'+esc(x.id)+'" data-nombre="'+esc(x.nombre)+'" value="'+Number(sug)+'" aria-label="Cantidad a pedir de '+esc(x.nombre)+'"></td><td style="text-align:right" class="sub">'+clp(sug*costo)+'</td></tr>'; }).join('');
    var notaHab = totalHab>prods.length ? '<p class="small muted" style="margin:0 0 8px">Este proveedor tiene '+totalHab.toLocaleString('es-CL')+' productos: '+(prods.length?'te mostramos los '+prods.length+' que más conviene reponer':'ninguno necesita reposición según las ventas')+'. Los demás búscalos en «Otros productos › Del catálogo».</p>' : '';
    var habituales = prods.length
      ? '<h4 style="margin:0 0 8px; font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; color:var(--muted)">Productos habituales</h4>'+notaHab+'<table><thead><tr><th>Producto</th><th style="text-align:center">Stock</th><th style="text-align:right">Cantidad</th><th style="text-align:right">Subtotal</th></tr></thead><tbody id="ordBody">'+filas+'</tbody></table>'
      : '<tbody id="ordBody" hidden></tbody>'+(notaHab||'<p class="small muted">Este proveedor no tiene productos habituales. Agrega abajo lo que quieras pedirle.</p>');
    abrirModal(ped?'Editar pedido '+numPed(ped):'Pedido a '+p.nombre,
      '<p class="intro" style="margin:0 0 12px">Paso 1 de 3. Sugerimos cantidades según las ventas de las últimas 4 semanas y los días de entrega del proveedor (a precio de costo). El pedido no mueve stock: eso pasa al recibirlo.</p>'+
      habituales+
      '<h4 style="margin:16px 0 8px; font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; color:var(--muted)">Otros productos</h4>'+
      '<div id="extraLines"></div>'+
      '<div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:4px"><button class="mini" id="addCat">＋ Del catálogo</button><button class="mini" id="addNew">＋ Producto nuevo</button></div>'+
      '<div class="f full" style="margin-top:14px"><label>Nota para el proveedor (opcional)</label><input id="pedNota" value="'+esc(ped?ped.nota:'')+'" placeholder="Ej: entregar antes del viernes, factura a nombre de…"></div>'+
      '<div class="ord-total"><span>Total estimado</span><b id="ordTotal">$0</b></div>'+
      '<div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center"><button class="btn btn-primary" id="enviarPedido" style="flex:1">Enviar al proveedor</button><button class="btn btn-ghost" id="borradorPedido">Guardar borrador</button>'+ayuda('Borrador: lo guardas para terminarlo después y no cuenta como enviado. Enviar al proveedor: queda pendiente de recibir y te ofrece mandarlo por WhatsApp.')+'</div>');

    // Los habituales ya tienen su fila arriba: no se ofrecen de nuevo. Si un producto se repite en "otros", al enviar se suman las cantidades.
    var catProds=db.productos.filter(function(x){ return !visibles[x.id]; }); // todo lo que no tiene fila arriba
    // Recalcula subtotales y total cada vez que cambia una cantidad o costo.
    function recalc(){
      var tot=0;
      document.querySelectorAll('#ordBody tr').forEach(function(tr){ var inp=tr.querySelector('.qty'); var q=+inp.value||0; var c=+inp.dataset.costo||0; tr.querySelector('.sub').textContent=clp(q*c); tot+=q*c; });
      document.querySelectorAll('#extraLines .linea').forEach(function(l){ tot+=(+l.querySelector('.xq').value||0)*(+l.querySelector('.xc').value||0); });
      $('ordTotal').textContent=clp(tot);
    }
    // kind 'cat' = producto del catálogo (select), 'new' = nombre libre.
    // `it` = línea ya guardada (al editar un borrador). Los aria-label llevan el nombre del producto y se actualizan al elegirlo.
    function nuevaLinea(kind, it){
      var div=document.createElement('div'); div.className='linea'; div.dataset.kind=kind;
      // Del catálogo: buscador (escribir y elegir); el id queda en el input oculto .xsel.
      var first = kind==='cat' ? buscadorProd('xsel', 'Producto del catálogo') : '<input class="xname" name="xname" placeholder="Nombre del producto" aria-label="Nombre del producto nuevo">';
      div.innerHTML=first+'<input class="xq" name="xq" type="number" min="0" step="'+(kind==='cat'?'1':'any')+'" placeholder="Cant." value="1"><input class="xc" name="xc" type="number" min="0" placeholder="Costo"><button class="rm" title="Quitar" aria-label="Quitar línea">'+ico('x')+'</button>';
      $('extraLines').appendChild(div);
      function rotular(){
        var pe=kind==='cat'&&prodPorId(div.querySelector('.xsel').value), n=kind==='cat'?(pe?pe.nombre:''):div.querySelector('.xname').value.trim();
        n=n||(kind==='cat'?'producto sin elegir':'producto nuevo');
        div.querySelector('.xq').setAttribute('aria-label','Cantidad a pedir de '+n); div.querySelector('.xc').setAttribute('aria-label','Costo unitario de '+n);
      }
      var bp=kind==='cat'?activarBuscadorProd(div, { lista:function(){ return catProds; }, extra:function(p){ return p.costo?'costo '+clp(p.costo):''; },
        alElegir:function(p){ div.querySelector('.xc').value=p&&p.costo?p.costo:''; div.querySelector('.xq').step=paso(p); rotular(); recalc(); } }):null;
      if(it){ if(kind==='cat'){ var pr0=prodPorId(it.prod); if(pr0) bp.elegir(pr0); else div.querySelector('.xsel').value=it.prod; div.querySelector('.xq').step=paso(pr0); } else div.querySelector('.xname').value=it.nombre; div.querySelector('.xq').value=it.qty; div.querySelector('.xc').value=it.costo; }
      rotular();
      if(kind==='new') div.querySelector('.xname').addEventListener('input', rotular);
      div.querySelector('.xq').addEventListener('input', recalc);
      div.querySelector('.xc').addEventListener('input', recalc);
      div.querySelector('.rm').addEventListener('click', function(){ div.remove(); recalc(); });
    }
    document.querySelectorAll('#ordBody .qty').forEach(function(inp){ inp.addEventListener('input', recalc); });
    $('addCat').addEventListener('click', function(){ nuevaLinea('cat'); var l=$('extraLines').lastElementChild; if(l) l.querySelector('.bprod-q').focus(); });
    $('addNew').addEventListener('click', function(){ nuevaLinea('new'); });
    // Al editar: las líneas que no son productos habituales del proveedor van como "otros productos".
    if(ped) ped.items.forEach(function(it){ if(!it.prod) nuevaLinea('new', it); else if(!prods.some(function(x){return x.id===it.prod;})) nuevaLinea('cat', it); });
    recalc();

    // Enviar: junta las líneas con cantidad > 0, registra el pedido en la API y arma el mensaje de WhatsApp.
    // Borrador: lo mismo pero queda en estado 'Borrador' y todavía no se ofrece WhatsApp.
    // El mensaje de éxito se pinta recién cuando la API confirma.
    $('enviarPedido').addEventListener('click', function(){ enviar(false); });
    $('borradorPedido').addEventListener('click', function(){ enviar(true); });
    function enviar(borrador){
      var items=[];
      // Un mismo producto en dos líneas se suma en una (vale el costo de la primera).
      var sumar=function(it){ var y=it.prod&&items.find(function(x){return x.prod===it.prod;}); if(y) y.qty+=it.qty; else items.push(it); };
      document.querySelectorAll('#ordBody .qty').forEach(function(inp){ var q=+inp.value||0; if(q>0) sumar({prod:inp.dataset.prod,nombre:inp.dataset.nombre,qty:q,costo:+inp.dataset.costo||0}); });
      document.querySelectorAll('#extraLines .linea').forEach(function(l){
        var q=+l.querySelector('.xq').value||0, c=+l.querySelector('.xc').value||0; if(q<=0) return;
        if(l.dataset.kind==='cat'){ var sel=l.querySelector('.xsel'); var pid=sel.value; if(!pid) return; var pr=db.productos.find(function(x){return x.id===pid;}); sumar({prod:pid,nombre:pr.nombre,qty:q,costo:c||pr.costo}); }
        else { var nm=l.querySelector('.xname').value.trim(); if(!nm) return; sumar({prod:null,nombre:nm,qty:q,costo:c}); }
      });
      if(!items.length){ aviso('Indica una cantidad mayor a 0 en al menos un producto.'); return; }
      var nota=$('pedNota').value.trim();
      // Editar = PUT del borrador y, si se eligió enviar, después lo marca como enviado.
      var req = ped
        ? API.send('PUT','/api/pedidos/'+encodeURIComponent(ped.id),{prov:id,nota:nota,items:items}).then(function(s){ return borrador?s:API.send('POST','/api/pedidos/'+encodeURIComponent(ped.id)+'/enviar'); })
        : API.send('POST','/api/pedidos',{prov:id,nota:nota,items:items,borrador:borrador});
      req.then(function(saved){
      if(ped){ var i=db.pedidos.findIndex(function(x){return x.id===ped.id;}); if(i>-1) db.pedidos[i]=saved; } else db.pedidos.unshift(saved);
      renderPedidos(); renderResumen();
      if(borrador){ $('modalTitulo').textContent='Borrador guardado · '+numPed(saved); $('modalBody').innerHTML='<div class="ped-ok">'+ico('ok')+'Borrador '+(ped?'actualizado':'guardado')+' en Compras › 1. Pedidos. Cuando quieras mandarlo, presiona «Enviar al proveedor».</div><button class="btn btn-ghost" data-cerrar style="width:100%; margin-top:14px">Cerrar</button>'; return; }
      avisoEnviado(saved);
      }).catch(function(e){ aviso('No se pudo registrar el pedido: '+e.message); });
    }
  }
  // Pedido ya enviado (desde el formulario o desde la fila de un borrador): lo confirma y ofrece mandarlo por WhatsApp.
  function avisoEnviado(o){
    var p=db.proveedores.find(function(x){return x.id===o.prov;})||{nombre:o.provNombre||'proveedor',tel:''};
    var resumen=o.items.map(function(i){ return '• '+i.nombre+' x '+i.qty; }).join('\n');
    var msg='Hola '+p.nombre+', quisiera hacer este pedido para '+negocio()+':\n'+resumen+(o.nota?('\nNota: '+o.nota):'')+(totalPed(o)>0?'\nTotal estimado: '+clp(totalPed(o))+'.':'')+'\nQuedo atento, ¡gracias!'; // sin costos, no se manda "Total: $0"
    var waBtn=p.tel?'<a class="btn btn-primary" href="'+esc(waLink(p.tel,msg))+'" target="_blank" rel="noopener" style="width:100%; text-align:center; display:block">'+ico('mensaje')+'Enviar por WhatsApp</a>':'<p class="small muted">Agrega el teléfono del proveedor para enviarlo por WhatsApp.</p>';
    abrirModal('Pedido enviado · '+numPed(o),
      '<div class="ped-ok">'+ico('ok')+'Pedido enviado al proveedor. Mándaselo por WhatsApp si aún no lo tiene. Queda en Compras › 1. Pedidos como «por recibir»; cuando llegue, presiona "Recibir" para ingresar el stock.</div>'+
      '<div style="margin-top:14px">'+waBtn+'</div>'+
      '<div style="display:flex;gap:8px;margin-top:8px">'+(p.email?'<a class="btn btn-ghost" style="flex:1;text-align:center" href="'+esc('mailto:'+p.email+'?subject='+encodeURIComponent('Pedido de '+negocio())+'&body='+encodeURIComponent(msg))+'">'+ico('correo')+'Enviar por correo</a>':'')+
        '<button class="btn btn-ghost" id="imprimirPed" style="flex:1">'+ico('imprimir')+'Imprimir pedido</button></div>'+
      '<button class="btn btn-ghost" data-cerrar style="width:100%; margin-top:8px">Cerrar</button>');
    $('imprimirPed').addEventListener('click', function(){ imprimirPedido(o); });
  }
  // Hoja del pedido para imprimir o guardar en PDF (proveedores que piden la orden por escrito).
  function imprimirPedido(o){
    var p=db.proveedores.find(function(x){return x.id===o.prov;})||{nombre:o.provNombre||'Sin proveedor'}; // provNombre: también el de un proveedor archivado
    var w=window.open('','_blank'); if(!w){ aviso('El navegador bloqueó la ventana: permite ventanas emergentes para imprimir.'); return; }
    w.document.write('<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Pedido '+esc(numPed(o))+'</title><style>@page{size:A4;margin:16mm}body{font-family:system-ui,sans-serif;color:#000;font-size:11pt}h1{font-size:17pt;margin:0}p{margin:3px 0}table{width:100%;border-collapse:collapse;margin-top:14px}th,td{border-bottom:1px solid #ccc;padding:6px;text-align:left}th:not(:first-child),td:not(:first-child){text-align:right}tfoot td{font-weight:800;border-top:2px solid #000}</style></head><body>'+
      '<h1>Pedido a '+esc(p.nombre)+'</h1><p><b>'+esc(negocio())+'</b> · '+fmtFecha(hoyISO())+' · '+esc(numPed(o))+'</p>'+(o.nota?'<p>Nota: '+esc(o.nota)+'</p>':'')+
      '<table><thead><tr><th>Producto</th><th>Cantidad</th><th>Costo unit.</th><th>Subtotal</th></tr></thead><tbody>'+
      o.items.map(function(i){ return '<tr><td>'+esc(i.nombre)+'</td><td>'+Number(i.qty)+'</td><td>'+clp(i.costo)+'</td><td>'+clp(i.qty*i.costo)+'</td></tr>'; }).join('')+
      '</tbody><tfoot><tr><td colspan="3">Total estimado</td><td>'+clp(totalPed(o))+'</td></tr></tfoot></table></body></html>');
    w.document.close(); w.focus(); setTimeout(function(){ w.print(); }, 300);
  }
  // Botones de la tabla de proveedores. Al borrar uno, sus productos quedan con prov='' acá en memoria.
  $('provBody').addEventListener('click', function(e){
    var tr=e.target.closest('tr[data-prov]'); if(!tr) return; var id=tr.dataset.prov;
    if(e.target.closest('[data-detalle-prov]')) detalleProv(id);
    else if(e.target.closest('[data-pedido]')) formPedido(id);
    else if(e.target.closest('[data-edit-prov]')) formProveedor(db.proveedores.find(function(x){return x.id===id;}));
    else if(e.target.closest('[data-del-prov]')){
      var p=db.proveedores.find(function(x){return x.id===id;});
      abrirModal('Eliminar proveedor','<p>¿Eliminar <b>'+esc(p.nombre)+'</b>? Los productos asociados quedarán sin proveedor. Si ya tiene pedidos, se archiva: deja de aparecer, pero sus pedidos e ingresos conservan su nombre.</p><div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-danger" id="confDelP">Sí, eliminar</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
      $('confDelP').addEventListener('click', function(){ API.send('DELETE','/api/proveedores/'+encodeURIComponent(id)).then(function(r){ db.proveedores=db.proveedores.filter(function(x){return x.id!==id;}); db.productos.forEach(function(pr){ if(pr.prov===id) pr.prov=''; }); renderProveedores(); cerrarModal();
        if(r&&r.archivado) aviso('Proveedor archivado: tenía pedidos, así que se guarda su historial.'); }).catch(function(e){ aviso('No se pudo eliminar: '+e.message); }); });
    }
  });

