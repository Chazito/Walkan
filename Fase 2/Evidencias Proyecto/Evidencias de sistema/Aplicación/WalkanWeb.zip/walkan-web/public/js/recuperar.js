// recuperar.js — "¿Olvidaste tu contraseña?" (/recuperar) y la contraseña nueva (/restablecer?t=…).
// Los mensajes van dentro de la tarjeta, no con alert().
(function(){
  var $=function(id){ return document.getElementById(id); };
  var msg=$('rMsg');
  function mostrar(tipo, texto, accion){
    if(!msg) return;
    msg.className='msg msg-'+tipo; msg.innerHTML='';
    var ico=document.createElement('span'); ico.className='msg-ico'; ico.setAttribute('aria-hidden','true'); ico.textContent=tipo==='error'?'!':'i';
    var c=document.createElement('div'); c.className='msg-txt'; var p=document.createElement('div'); p.textContent=texto; c.appendChild(p);
    if(accion){ var a=document.createElement('a'); a.className='msg-accion'; a.href=accion.href; a.textContent=accion.texto; c.appendChild(a); }
    msg.appendChild(ico); msg.appendChild(c); msg.hidden=false;
  }
  function post(url, body){
    return fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body) })
      .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){
        if(!r.ok){ var m=d&&d.message; var e=new Error((Array.isArray(m)?m[0]:m)||'No se pudo completar.'); e.status=r.status; throw e; }
        return d; }); });
  }
  function errorDe(e){ return e instanceof TypeError ? 'No hay conexión con el servidor. Revisa tu internet e inténtalo de nuevo.' : e.message; }

  // Mismo cálculo que src/common/util/rut.ts (módulo 11), para avisar antes de enviar.
  function rutOk(v){
    var m=String(v).replace(/\./g,'').trim().toUpperCase().match(/^(\d{1,8})-?([\dK])$/); if(!m) return false;
    var s=0, mul=2; for(var i=m[1].length-1;i>=0;i--){ s+=Number(m[1][i])*mul; mul=mul===7?2:mul+1; }
    var dv=11-(s%11); return m[2]===(dv===11?'0':dv===10?'K':String(dv));
  }

  // ---- Pedir el enlace ----
  var fr=$('recuperar');
  if(fr){
    var em=$('rEmail'), ru=$('rRut'), b=fr.querySelector('button[type="submit"]');
    [em, ru].forEach(function(x){ if(x) x.addEventListener('input', function(){ msg.hidden=true; }); });
    fr.addEventListener('submit', function(ev){
      ev.preventDefault();
      if(!em.value.trim() || !em.checkValidity()){ mostrar('error', 'Escribe un correo válido.'); em.focus(); return; }
      var rut=ru ? ru.value.trim() : '';
      if(rut && !rutOk(rut)){ mostrar('error', 'Ese RUT no es válido: revisa el dígito verificador.'); ru.focus(); return; }
      b.disabled=true; b.textContent='Enviando…';
      var datos={ email: em.value.trim() }; if(rut) datos.rut=rut;
      post('/api/auth/recuperar', datos)
        .then(function(d){ mostrar('aviso', d.mensaje); b.textContent='Enlace enviado'; setTimeout(function(){ b.disabled=false; b.textContent='Enviar de nuevo'; }, 30000); })
        .catch(function(e){ b.disabled=false; b.textContent='Enviar enlace'; mostrar('error', e.status===429?'Demasiados intentos. Espera un minuto e inténtalo de nuevo.':errorDe(e)); });
    });
  }

  // ---- Contraseña nueva ----
  var fn=$('restablecer');
  if(fn){
    var token=new URLSearchParams(location.search).get('t')||'';
    // El token no queda en el historial ni se manda a otras páginas como "Referer".
    try { history.replaceState(null, '', '/restablecer'); } catch(e){}
    var p1=$('nPass'), p2=$('nPass2'), bn=fn.querySelector('button[type="submit"]');
    if(window.WalkanClave) WalkanClave.montar(p1, $('nReglas'));
    [p1,p2].forEach(function(i){ i.addEventListener('input', function(){ msg.hidden=true; i.classList.remove('invalido'); }); });
    fn.addEventListener('submit', function(ev){
      ev.preventDefault();
      var mc=window.WalkanClave?WalkanClave.mensaje(p1.value):'';
      if(mc){ p1.classList.add('invalido'); mostrar('error', mc); p1.focus(); return; }
      if(p1.value!==p2.value){ p2.classList.add('invalido'); mostrar('error', 'Las contraseñas no coinciden.'); p2.focus(); return; }
      bn.disabled=true; bn.textContent='Guardando…';
      post('/api/auth/restablecer', { token: token, password: p1.value })
        .then(function(){ fn.hidden=true; mostrar('aviso', 'Listo: tu contraseña quedó cambiada. Ya puedes entrar con ella.', { texto:'Iniciar sesión', href:'/mi-cuenta' }); })
        .catch(function(e){ bn.disabled=false; bn.textContent='Guardar contraseña';
          mostrar('error', errorDe(e), /ya no sirve/.test(e.message)?{ texto:'Pedir un enlace nuevo', href:'/recuperar' }:null); });
    });
  }
})();
