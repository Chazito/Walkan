// 08-soporte.js — va antes de 09-init.js, que cierra el scope común del panel (por eso comparte el número 08).
  // ---------------- Ayuda y soporte ----------------
  // Solicitudes del negocio al equipo Walkan (GET/POST /api/soporte/tickets). La conversación se abre en el modal.
  // Las categorías son las mismas del centro de ayuda (src/modules/soporte/categorias.ts).
  var SOP_CATS=[['acceso','Cuenta y acceso'],['plan','Plan y pagos'],['caja','Caja y equipo'],['panel','Inventario y ventas'],['privacidad','Privacidad y datos'],['otro','Otro']];
  var SOP_TAG={abierto:'warn',en_curso:'mut',resuelto:'ok'};
  var tickets=[];
  var abierto=null; // { id, firma } de la solicitud abierta en el modal: se refresca sola (ver más abajo)
  var firmaT=function(t){ return t.mensajes.length+'|'+t.estado; };
  var fechaHora=function(iso){ var d=new Date(iso); return fmtFecha(iso)+' '+('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2); };
  function tagTicket(t){
    if(t.estado!=='resuelto' && !t.esperaRespuesta) return '<span class="tag ok">Te respondimos</span>';
    return '<span class="tag '+(SOP_TAG[t.estado]||'mut')+'">'+esc(t.estadoNombre)+'</span>';
  }
  function pintarTickets(){
    var b=$('ticketsBody'); if(!b) return;
    var nuevas=tickets.filter(function(t){ return t.estado!=='resuelto' && !t.esperaRespuesta; }).length;
    var bell=$('bellSoporte'); if(bell){ bell.hidden=!nuevas; bell.textContent=nuevas||''; }
    if(!tickets.length){ b.innerHTML='<tr><td colspan="5" class="muted" style="padding:18px 8px">Aún no tienes solicitudes. Si algo no funciona o tienes una duda, toca «Nueva solicitud».</td></tr>'; return; }
    b.innerHTML=tickets.map(function(t){
      return '<tr><td class="muted">'+esc(t.numero)+'</td><td><b>'+esc(t.asunto)+'</b><div class="small muted">'+esc(t.categoriaNombre)+'</div></td><td>'+tagTicket(t)+'</td><td class="muted">'+esc(fechaHora(t.actualizado))+'</td><td style="text-align:right"><button class="btn btn-ghost" type="button" data-ticket="'+esc(t.id)+'">Ver</button></td></tr>';
    }).join('');
  }
  function cargarTickets(){
    return fetch('/api/soporte/tickets').then(function(r){ return r.ok ? r.json() : []; }).then(function(l){ tickets=Array.isArray(l)?l:[]; pintarTickets(); }).catch(function(){});
  }
  function hiloHtml(t){
    return '<div class="hilo">'+t.mensajes.map(function(m){
      var quien=m.autor==='equipo'?'Equipo Walkan':(m.autor==='sistema'?'Walkan':m.nombre);
      return '<div class="hilo-msg hilo-'+esc(m.autor)+'"><div class="hilo-cab"><b>'+esc(quien)+'</b> <span class="muted">'+esc(fechaHora(m.fecha))+'</span></div><div class="hilo-txt">'+esc(m.texto).replace(/\n/g,'<br>')+'</div></div>';
    }).join('')+'</div>';
  }
  function verTicket(id){
    fetch('/api/soporte/tickets/'+encodeURIComponent(id)).then(function(r){ if(!r.ok) throw new Error(); return r.json(); }).then(function(t){
      abrirModal(t.numero+' · '+t.asunto,
        '<p class="small muted" style="margin:0 0 10px">'+esc(t.categoriaNombre)+' · <span id="tkEstado">'+tagTicket(t)+'</span></p><div id="tkHilo">'+hiloHtml(t)+'</div>'+
        '<div class="f" style="margin-top:14px"><label for="tkResp">'+(t.estado==='resuelto'?'¿Necesitas algo más? Escribe y la reabrimos':'Responder')+'</label><textarea id="tkResp" class="ta" rows="3" maxlength="4000"></textarea></div>'+
        '<div class="btns" style="margin-top:10px;display:flex;gap:8px"><button class="btn btn-primary" type="button" id="tkEnviar">Enviar</button><button class="btn btn-ghost" type="button" data-cerrar>Cerrar</button></div>'+
        '<div class="small" id="tkErr" role="alert" style="color:var(--danger);margin-top:8px"></div>');
      abierto={ id:id, firma:firmaT(t) }; bajarHilo();
      $('tkEnviar').addEventListener('click', function(){
        var txt=$('tkResp').value.trim(), btn=this;
        if(txt.length<2){ $('tkErr').textContent='Escribe tu mensaje.'; $('tkResp').focus(); return; }
        btn.disabled=true;
        API.send('POST','/api/soporte/tickets/'+encodeURIComponent(id)+'/responder',{ texto:txt })
          .then(function(){ modalSucio=false; verTicket(id); cargarTickets(); })
          .catch(function(e){ btn.disabled=false; $('tkErr').textContent=e.message; });
      });
    }).catch(function(){ aviso('No se pudo abrir la solicitud. Inténtalo de nuevo.'); });
  }
  function nuevoTicket(){
    abrirModal('Nueva solicitud',
      '<div class="f"><label for="tkCat">Tema</label><select id="tkCat"><option value="">Elige un tema…</option>'+SOP_CATS.map(function(c){ return '<option value="'+c[0]+'">'+c[1]+'</option>'; }).join('')+'</select></div>'+
      '<div class="f" style="margin-top:10px"><label for="tkAsunto">Asunto</label><input id="tkAsunto" maxlength="120" placeholder="Ej.: La caja no sincroniza desde ayer"></div>'+
      '<div class="f" style="margin-top:10px"><label for="tkMsg">Cuéntanos qué pasó</label><textarea id="tkMsg" class="ta" rows="5" maxlength="4000" placeholder="Qué intentabas hacer, qué pasó y desde cuándo. Si es de una caja, dinos cuál."></textarea></div>'+
      '<p class="small muted" style="margin:8px 0 0">Te responderemos aquí y al correo de tu cuenta.</p>'+
      '<div class="btns" style="margin-top:12px;display:flex;gap:8px"><button class="btn btn-primary" type="button" id="tkCrear">Enviar solicitud</button><button class="btn btn-ghost" type="button" data-cerrar>Cancelar</button></div>'+
      '<div class="small" id="tkErr" role="alert" style="color:var(--danger);margin-top:8px"></div>');
    $('tkCrear').addEventListener('click', function(){
      var d={ categoria:$('tkCat').value, asunto:$('tkAsunto').value.trim(), mensaje:$('tkMsg').value.trim() }, btn=this;
      if(!d.categoria){ $('tkErr').textContent='Elige un tema.'; $('tkCat').focus(); return; }
      if(d.asunto.length<4){ $('tkErr').textContent='Escribe un asunto (al menos 4 letras).'; $('tkAsunto').focus(); return; }
      if(d.mensaje.length<10){ $('tkErr').textContent='Cuéntanos un poco más (al menos 10 letras).'; $('tkMsg').focus(); return; }
      btn.disabled=true;
      API.send('POST','/api/soporte/tickets', d)
        .then(function(t){ modalSucio=false; cargarTickets(); verTicket(t.id); aviso('Recibimos tu solicitud '+t.numero+'. Te avisaremos por correo cuando respondamos.'); })
        .catch(function(e){ btn.disabled=false; $('tkErr').textContent=e.message; });
    });
  }
  function bajarHilo(){ var h=document.querySelector('#tkHilo .hilo'); if(h) h.scrollTop=h.scrollHeight; }
  // Sin recargar la página: cada 15 s (solo con la pestaña a la vista) se trae la lista, y si hay una solicitud abierta
  // en el modal, sus mensajes nuevos o el cambio de estado. Lo que estés escribiendo en "Responder" no se toca.
  function refrescarSoporte(){
    if(document.hidden) return;
    var enModal=abierto && $('modal').classList.contains('open') && $('tkHilo');
    if(!enModal) abierto=null;
    if(location.hash==='#soporte' || enModal) cargarTickets();
    if(!enModal) return;
    var id=abierto.id;
    fetch('/api/soporte/tickets/'+encodeURIComponent(id)).then(function(r){ return r.ok ? r.json() : null; }).then(function(t){
      if(!t || !abierto || abierto.id!==id || !$('tkHilo') || firmaT(t)===abierto.firma) return;
      abierto.firma=firmaT(t);
      $('tkHilo').innerHTML=hiloHtml(t); $('tkEstado').innerHTML=tagTicket(t); bajarHilo();
      var l=document.querySelector('label[for="tkResp"]'); if(l) l.textContent=t.estado==='resuelto'?'¿Necesitas algo más? Escribe y la reabrimos':'Responder';
    }).catch(function(){});
  }
  setInterval(refrescarSoporte, 15000);
  setInterval(function(){ if(!document.hidden && location.hash!=='#soporte') cargarTickets(); }, 60000); // el globito del menú
  document.addEventListener('visibilitychange', function(){ if(!document.hidden) refrescarSoporte(); });
  if($('nuevoTicket')) $('nuevoTicket').addEventListener('click', nuevoTicket);
  if($('ticketsBody')) $('ticketsBody').addEventListener('click', function(e){ var b=e.target.closest('[data-ticket]'); if(b) verTicket(b.dataset.ticket); });
  // El enlace "Ayuda" vive fuera del menú principal (sigue visible con la cuenta en pausa).
  var navSop=$('navSoporte');
  function marcarSoporte(){ if(navSop){ var on=location.hash==='#soporte'; navSop.classList.toggle('active', on); if(on) navSop.setAttribute('aria-current','page'); else navSop.removeAttribute('aria-current'); } }
  if(navSop) navSop.addEventListener('click', function(e){ e.preventDefault(); ir('soporte'); marcarSoporte(); cargarTickets(); });
  window.addEventListener('hashchange', function(){ marcarSoporte(); if(location.hash==='#soporte') cargarTickets(); });
  marcarSoporte();
  cargarTickets();
