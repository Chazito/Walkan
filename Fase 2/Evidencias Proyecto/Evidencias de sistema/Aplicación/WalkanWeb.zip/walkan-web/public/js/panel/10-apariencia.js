// 10-apariencia.js — Mi cuenta › Apariencia. Cada cambio se ve al tiro (vista previa sobre todo el panel);
// "Guardar" lo deja para el negocio (PUT /api/apariencia). Si sales sin guardar, vuelve la apariencia guardada.
// El motor (colores derivados del acento, contraste, fuentes) está en public/js/apariencia.js.
(function(){
  var f = document.getElementById('apForm'), AP = window.WalkanApariencia;
  if(!f || !AP) return;
  var $ = function(id){ return document.getElementById(id); };
  var propio = null, sucio = false;

  function leer(){
    var e = f.querySelector('input[name="estilo"]:checked'), m = f.querySelector('input[name="modo"]:checked'), c = f.querySelector('input[name="acento"]:checked');
    return { estilo: e ? e.value : AP.DEF.estilo, modo: m ? m.value : AP.DEF.modo, acento: c ? c.value : (propio || AP.DEF.acento) };
  }
  function pintar(a){
    f.querySelectorAll('input[name="estilo"]').forEach(function(i){ i.checked = i.value === a.estilo; });
    f.querySelectorAll('input[name="modo"]').forEach(function(i){ i.checked = i.value === a.modo; });
    var hay = false;
    f.querySelectorAll('input[name="acento"]').forEach(function(i){ i.checked = i.value.toUpperCase() === String(a.acento).toUpperCase(); hay = hay || i.checked; });
    propio = hay ? null : a.acento;
    $('apPropio').value = String(a.acento).toLowerCase();
    nota(a.acento);
  }
  function nota(acento){
    var c = AP.contraste(acento), r = c.ratio.toFixed(1).replace('.', ','), ok = c.ratio >= 4.5;
    $('apHex').textContent = String(acento).toUpperCase();
    var n = $('apNota'); n.className = 'ap-nota ' + (ok ? 'ok' : 'warn');
    n.textContent = ok ? 'Se lee bien: el texto sobre tu color tiene contraste ' + r + ':1.'
      : 'Ese color es claro para botones con texto (' + r + ':1). Walkan oscurecerá el texto y los enlaces para que se lean.';
  }
  function cambio(){ var a = leer(); AP.vistaPrevia(a); nota(a.acento); sucio = true; $('apMsg').textContent = 'Vista previa: aún no se guarda.'; }

  f.addEventListener('change', function(ev){
    if(ev.target.id === 'apPropio') return;
    // Consola se ve mejor oscura: al elegirla se propone el modo oscuro (se puede cambiar).
    if(ev.target.name === 'estilo' && ev.target.value === 'consola' && leer().modo === 'auto') f.querySelector('input[name="modo"][value="oscuro"]').checked = true;
    cambio();
  });
  $('apPropio').addEventListener('input', function(){
    propio = this.value.toUpperCase();
    f.querySelectorAll('input[name="acento"]').forEach(function(i){ i.checked = false; });
    cambio();
  });
  f.addEventListener('submit', function(ev){
    ev.preventDefault();
    var b = $('apGuardar'); b.disabled = true; $('apMsg').textContent = 'Guardando…';
    AP.guardar(leer()).then(function(a){ sucio = false; pintar(a); $('apMsg').textContent = 'Listo: así se verá tu panel.'; })
      .catch(function(e){ $('apMsg').textContent = e.message || 'No se pudo guardar.'; })
      .then(function(){ b.disabled = false; });
  });
  $('apDescartar').addEventListener('click', function(){ var a = AP.restaurar(); pintar(a); sucio = false; $('apMsg').textContent = 'Cambios descartados.'; });
  $('apDefecto').addEventListener('click', function(){ pintar(AP.DEF); cambio(); });
  // Salir de la sección sin guardar = vuelve la apariencia guardada.
  window.addEventListener('hashchange', function(){ if(sucio && location.hash !== '#apariencia'){ pintar(AP.restaurar()); sucio = false; $('apMsg').textContent = ''; } });

  AP.listo.then(function(a){ pintar(a); });
})();
