// landing.js — la parte con vida de la página pública (/).
// Hace tres cosas: anima las secciones al hacer scroll, maneja el formulario de contacto (solo contacto:
// para contratar se usa /registro, que crea la cuenta y cobra) y el botón flotante.
(function(){
  // scroll reveal: a todo lo que tenga .reveal le pone .in cuando aparece en pantalla (la animación está en landing.css)
  if (!('IntersectionObserver' in window)) { document.querySelectorAll('.reveal').forEach(function(el){ el.classList.add('in'); }); }
  else {
  var obs = new IntersectionObserver(function(es){
    es.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add('in'); obs.unobserve(e.target); } });
  },{threshold:.12});
  document.querySelectorAll('.reveal').forEach(function(el){ obs.observe(el); });
  }

  // Región → comuna del formulario de contacto (lista oficial, ver territorio.js)
  if(window.WalkanTerritorio) WalkanTerritorio.montar(document.getElementById('region'), document.getElementById('comuna'));

  // Pre-selecciona el plan al hacer clic en "Cotizar"
  // Calza por texto: el <h3> de la tarjeta tiene que llamarse igual que la <option> del select.
  document.querySelectorAll('.plan a.btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      var card = btn.closest('.plan'); if(!card) return;
      var nombrePlan = card.querySelector('h3').textContent.trim();
      var sel = document.getElementById('plan');
      for(var i=0;i<sel.options.length;i++){ if(sel.options[i].text===nombrePlan){ sel.selectedIndex=i; break; } }
      actualizarModo();
    });
  });


  function val(id){ var el=document.getElementById(id); return el ? el.value.trim() : ''; }

  // Envío al backend: POST /api/solicitudes guarda el contacto y el equipo lo ve en /admin. No cobra nada.
  var f = document.getElementById('lead');
  // Mensaje de error dentro del formulario (en vez de alert() del navegador).
  function msgForm(texto){
    var m=document.getElementById('leadMsg');
    if(!m){ m=document.createElement('div'); m.id='leadMsg'; m.className='form-msg'; m.setAttribute('role','alert');
      var b=f.querySelector('button[type="submit"]'); if(b && b.parentNode) b.parentNode.insertBefore(m, b); else f.appendChild(m); }
    m.textContent=texto; m.hidden=!texto;
  }
  f.addEventListener('submit', function(ev){
    ev.preventDefault();
    msgForm('');
    if(!f.checkValidity()){ f.reportValidity(); return; }
    var btn = f.querySelector('button[type="submit"]');
    var textoBtn = btn ? btn.textContent : '';
    if(btn){ btn.disabled = true; btn.textContent = 'Enviando…'; }
    var datos = {
      nombre: val('nombre'), negocio: val('negocio'), email: val('email'),
      telefono: val('telefono'), comuna: window.WalkanTerritorio ? WalkanTerritorio.nombreComuna(document.getElementById('comuna')) : '',
      plan: document.getElementById('plan').value, mensaje: val('mensaje'),
      // Consentimiento (Ley 21.719): el servidor rechaza la solicitud si no viene aceptado.
      aceptaPrivacidad: !!(document.getElementById('aceptaPrivacidad') || {}).checked,
      aceptaMarketing: !!(document.getElementById('aceptaMarketing') || {}).checked
    };
    fetch('/api/solicitudes', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(datos) })
      .then(function(r){ return r.json().then(function(d){ return { ok:r.ok, d:d }; }); })
      .then(function(res){
        if(!res.ok){ throw new Error((res.d && res.d.message) || 'Error al enviar la solicitud'); }
        var d = res.d;
        var nombre = datos.nombre;
        document.getElementById('okmsg').textContent = 'Gracias' + (nombre ? ', ' + nombre : '') + '. Recibimos tu mensaje y te respondemos dentro de 1 día hábil.';
        f.style.display = 'none';
        document.getElementById('ok').style.display = 'block';
        document.getElementById('ok').scrollIntoView({ behavior:'smooth', block:'center' });
      })
      .catch(function(e){
        msgForm(e instanceof TypeError ? 'No hay conexión con el servidor. Inténtalo de nuevo en unos segundos.' : 'No se pudo enviar: ' + e.message);
        if(btn){ btn.disabled = false; btn.textContent = textoBtn; }
      });
  });
  // Botón flotante de contacto rápido
  // Abre/cierra el menú (partials/landing/fab.ejs); se cierra solo si haces click en cualquier otro lado.
  var fabBtn=document.getElementById('fabBtn'), fabMenu=document.getElementById('fabMenu'), fabWrap=document.getElementById('fab');
  if(fabBtn){
    fabBtn.addEventListener('click', function(e){
      e.stopPropagation();
      var abierto = !fabMenu.hidden; fabMenu.hidden = abierto; fabBtn.setAttribute('aria-expanded', String(!abierto));
    });
    var fabCotiza=document.getElementById('fabCotiza');
    if(fabCotiza) fabCotiza.addEventListener('click', function(){ fabMenu.hidden=true; fabBtn.setAttribute('aria-expanded','false'); });
    document.addEventListener('click', function(e){ if(fabWrap && !fabWrap.contains(e.target)){ fabMenu.hidden=true; fabBtn.setAttribute('aria-expanded','false'); } });
  }

  // Video de presentación: con JS se cambian los controles del navegador por un botón "Ver el video" sobre la portada.
  // Al apretarlo aparecen los controles y parte con sonido (nunca se reproduce solo). Al terminar vuelve el botón.
  var video = document.getElementById('videoWalkan'), vPlay = document.getElementById('videoPlay');
  if (video && vPlay) {
    video.controls = false; vPlay.hidden = false;
    vPlay.addEventListener('click', function(){
      vPlay.hidden = true; video.controls = true;
      var p = video.play(); if (p && p.catch) p.catch(function(){ /* si el navegador lo bloquea, quedan los controles */ });
      video.focus();
    });
    video.addEventListener('play', function(){ vPlay.hidden = true; video.controls = true; });
    video.addEventListener('ended', function(){ video.controls = false; video.load(); vPlay.hidden = false; vPlay.querySelector('.vp-txt').firstChild.textContent = 'Ver de nuevo'; });
  }
})();
