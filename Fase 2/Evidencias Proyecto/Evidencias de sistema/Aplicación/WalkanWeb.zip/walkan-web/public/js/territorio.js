// territorio.js — selectores Región → Comuna con la lista oficial (public/geo/territorio-cl.json).
// Uso: WalkanTerritorio.montar(selectRegion, selectComuna[, codigoComunaInicial]).
// El valor de la comuna es su código CUT (5 dígitos); nombreComuna(select) da el nombre visible.
(function(){
  var promesa = null;
  function cargar(){
    if(!promesa) promesa = fetch('/geo/territorio-cl.json').then(function(r){ if(!r.ok) throw new Error('sin datos'); return r.json(); });
    return promesa;
  }
  function opcion(valor, texto){ var o = document.createElement('option'); o.value = valor; o.textContent = texto; return o; }
  function montar(selRegion, selComuna, inicial){
    if(!selRegion || !selComuna) return Promise.resolve();
    selRegion.disabled = true; selComuna.disabled = true;
    return cargar().then(function(d){
      function llenarComunas(idRegion, cut){
        var r = d.regiones.filter(function(x){ return x.id === idRegion; })[0];
        selComuna.innerHTML = '';
        selComuna.appendChild(opcion('', r ? 'Elige la comuna…' : 'Primero elige la región'));
        if(r) r.comunas.forEach(function(c){ selComuna.appendChild(opcion(c[0], c[1])); });
        selComuna.disabled = !r;
        if(cut) selComuna.value = cut;
      }
      selRegion.innerHTML = '';
      selRegion.appendChild(opcion('', 'Elige la región…'));
      d.regiones.forEach(function(r){ selRegion.appendChild(opcion(r.id, r.nombre)); });
      selRegion.addEventListener('change', function(){ llenarComunas(selRegion.value); });
      selRegion.disabled = false;
      if(inicial){ selRegion.value = String(inicial).slice(0, 2); llenarComunas(selRegion.value, inicial); }
      else llenarComunas('');
    }).catch(function(){
      // Sin la lista no se bloquea el formulario: la ubicación es opcional.
      selRegion.innerHTML = ''; selRegion.appendChild(opcion('', 'No disponible'));
      selComuna.innerHTML = ''; selComuna.appendChild(opcion('', 'No disponible'));
    });
  }
  // Normaliza nombres para comparar ("Ñuñoa" = "nunoa", "O'Higgins" = "o higgins").
  function norm(t){ return String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/^comuna de /, '').replace(/[^a-z0-9]+/g, ' ').trim(); }

  // Elige región y comuna por código (para rellenar el formulario con lo que se detectó).
  function seleccionar(selRegion, selComuna, cut){
    if(!cut) return;
    selRegion.value = String(cut).slice(0, 2);
    selRegion.dispatchEvent(new Event('change'));
    selComuna.value = cut;
  }

  // Interpreta la respuesta de OpenStreetMap (Nominatim) contra la lista oficial.
  // Devuelve { regionId, cut, comuna, calle, conNumero }; los campos que no calcen quedan vacíos.
  function interpretar(d, a){
    a = a || {};
    var iso = a['ISO3166-2-lvl4'] || '';
    var region = d.regiones.filter(function(r){ return r.iso === iso; })[0]
      || d.regiones.filter(function(r){ return a.state && norm(a.state).indexOf(norm(r.nombre)) > -1; })[0];
    var donde = region ? [region] : d.regiones;
    var claves = ['city', 'town', 'village', 'municipality', 'city_district', 'suburb', 'county', 'hamlet'];
    var hallada = null;
    for(var i = 0; i < claves.length && !hallada; i++){
      var n = norm(a[claves[i]]); if(!n) continue;
      for(var j = 0; j < donde.length && !hallada; j++){
        var c = donde[j].comunas.filter(function(x){ return norm(x[1]) === n; })[0];
        if(c){ hallada = { cut: c[0], comuna: c[1], regionId: donde[j].id }; }
      }
    }
    var calle = [a.road || a.pedestrian || a.residential || '', a.house_number || ''].join(' ').trim();
    return {
      regionId: hallada ? hallada.regionId : (region ? region.id : ''),
      region: hallada ? d.regiones.filter(function(r){ return r.id === hallada.regionId; })[0].nombre : (region ? region.nombre : ''),
      cut: hallada ? hallada.cut : '', comuna: hallada ? hallada.comuna : '',
      calle: calle, conNumero: !!a.house_number
    };
  }

  // Pide la ubicación al navegador y la convierte en dirección. Falla con un código:
  // 'no-soportado' (sin GPS o sin HTTPS), 'sin-permiso', 'sin-senal', 'sin-red', 'fuera-de-chile'.
  function detectar(){
    return new Promise(function(ok, mal){
      if(!window.isSecureContext || !navigator.geolocation) return mal('no-soportado');
      navigator.geolocation.getCurrentPosition(function(pos){ ok(pos.coords); },
        function(e){ mal(e && e.code === 1 ? 'sin-permiso' : 'sin-senal'); },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 });
    }).then(function(c){
      var ctl = window.AbortController ? new AbortController() : null;
      var t = ctl ? setTimeout(function(){ ctl.abort(); }, 8000) : null;
      var url = 'https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language=es&lat='
        + c.latitude.toFixed(6) + '&lon=' + c.longitude.toFixed(6);
      return Promise.all([cargar(), fetch(url, ctl ? { signal: ctl.signal } : {}).then(function(r){ if(!r.ok) throw 0; return r.json(); })])
        .catch(function(e){ throw (typeof e === 'string' ? e : 'sin-red'); })
        .then(function(res){
          if(t) clearTimeout(t);
          var a = res[1] && res[1].address;
          if(!a || a.country_code !== 'cl') throw 'fuera-de-chile';
          return interpretar(res[0], a);
        });
    });
  }

  function nombreComuna(sel){
    if(!sel) return '';
    if(sel.tagName !== 'SELECT') return (sel.value || '').trim(); // formularios viejos con texto libre
    var o = sel.options[sel.selectedIndex]; return o && o.value ? o.textContent : '';
  }
  window.WalkanTerritorio = { montar: montar, nombreComuna: nombreComuna, seleccionar: seleccionar, detectar: detectar, interpretar: interpretar, cargar: cargar };
})();
