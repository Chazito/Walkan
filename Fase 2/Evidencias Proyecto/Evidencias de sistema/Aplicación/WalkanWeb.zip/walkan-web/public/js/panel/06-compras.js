// Parte de panel.js: el servidor junta public/js/panel/*.js en orden (ver views.controller.ts) dentro de un solo
// (function(){ … })(), así que todo comparte el mismo scope. No es un módulo suelto: no cargarlo solo.
  // ================= COMPRAS (1. pedidos -> 2. ingresos de mercadería) =================
  // Pedido = lo que le pides al proveedor; no mueve stock. Estados: Borrador -> Enviado -> Recibido.
  // Ingreso de mercadería = lo que llegó y sumó stock (al recibir un pedido o directo). En la API sigue siendo /api/compras.
  // Los productos que controlan vencimiento piden lote y vencimiento por línea; el backend crea los lotes.
  document.querySelector('.subtabs').addEventListener('click', function(e){
    var b=e.target.closest('.subtab'); if(!b) return;
    this.querySelectorAll('.subtab').forEach(function(x){x.classList.remove('on'); x.setAttribute('aria-selected','false');}); b.classList.add('on'); b.setAttribute('aria-selected','true');
    $('tab-pedidos').hidden = b.dataset.tab!=='pedidos';
    $('tab-recepciones').hidden = b.dataset.tab!=='recepciones';
  });
  function irTab(t){ var b=document.querySelector('.subtab[data-tab="'+t+'"]'); if(b) b.click(); }
  // Avance del pedido en los 3 pasos (Pedir -> Recibir -> Ingresado), como barrita + texto.
  var pasoPed={Borrador:{n:1,t:'Borrador: falta enviarlo'},Enviado:{n:2,t:'Enviado: por recibir'},Recibido:{n:3,t:'Listo: stock sumado'}};
  function avance(estado){
    var s=pasoPed[estado]||pasoPed.Enviado, i='';
    for(var k=1;k<=3;k++) i+='<i class="'+(k<s.n||s.n===3?'done':k===s.n?'on':'')+'"></i>';
    return '<span class="avance" role="img" aria-label="Paso '+s.n+' de 3">'+i+'</span> <span class="small muted">'+s.t+'</span>';
  }
  // No hay folio: el pedido se nombra "P-06/10 · Proveedor" (fecha dd/mm + proveedor), más legible que el id. El id de la BD no cambia.
  // Si hay varios el mismo día al mismo proveedor, desde el segundo lleva "#2", "#3"… (db.pedidos viene del más nuevo al más viejo).
  var numPed=function(o){ var f=String(o.fecha||''), i=db.pedidos.findIndex(function(x){return x.id===o.id;}), n=1;
    if(i>-1) db.pedidos.slice(i+1).forEach(function(x){ if(x.fecha===o.fecha&&x.prov===o.prov) n++; });
    return 'P-'+f.slice(8,10)+'/'+f.slice(5,7)+' · '+(o.provNombre||provNombre(o.prov))+(n>1?' #'+n:''); }; // provNombre viene aunque el proveedor esté archivado
  var totalPed=function(o){ return o.items.reduce(function(s,i){return s+(Number(i.qty)||0)*(Number(i.costo)||0);},0); };
  function renderPedidos(){
    $('pedBody').innerHTML=db.pedidos.map(function(o){
      var id=esc(o.id);
      var acc = o.estado==='Recibido' ? '<button class="mini" data-ver-ingreso="'+id+'">Ver ingreso</button> <button class="mini" data-repetir="'+id+'">Repetir</button>'
        : o.estado==='Borrador' ? '<button class="mini" data-enviar="'+id+'">Enviar al proveedor</button> <button class="mini" data-editar-ped="'+id+'">Editar</button> <button class="mini icon del" data-borrar-ped="'+id+'" aria-label="Eliminar borrador">'+ico('borrar')+'</button>'
        : '<button class="mini" data-recibir="'+id+'">Recibir</button>';
      return '<tr><td class="prin"><b>'+esc(numPed(o))+'</b></td><td data-l="Ítems">'+Number(o.items.length)+'</td><td data-l="Total">'+clp(totalPed(o))+'</td><td>'+avance(o.estado)+'</td><td class="acc" style="white-space:nowrap">'+acc+'</td></tr>';
    }).join('')||'<tr><td colspan="5" class="muted" style="text-align:center;padding:20px">Sin pedidos. Crea uno con "＋ Nuevo pedido" o desde Proveedores.</td></tr>';
    renderResumen();
  }
  $('nuevoPedido').addEventListener('click', function(){
    if(!db.proveedores.length){ abrirModal('Nuevo pedido','<p>Para hacer un pedido primero registra a tu proveedor.</p><button class="btn btn-primary" data-goto="proveedores" data-cerrar>Ir a Proveedores</button>'); return; }
    abrirModal('Nuevo pedido','<div class="f full"><label for="npProv">¿A qué proveedor le vas a pedir?</label><select id="npProv">'+db.proveedores.map(function(p){ return '<option value="'+esc(p.id)+'">'+esc(p.nombre)+'</option>'; }).join('')+'</select></div>'+
      '<div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-primary" id="npSeguir">Seguir</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    $('npSeguir').addEventListener('click', function(){ formPedido($('npProv').value); });
  });

  // Pedidos sugeridos: junta lo que la predicción marca para reponer (agotado o bajo el punto de reorden), agrupado por
  // proveedor, y crea un borrador por proveedor. Se salta lo que ya está en un pedido abierto (borrador o enviado).
  $('pedSugeridos').addEventListener('click', function(){
    var abiertos={}; db.pedidos.forEach(function(o){ if(o.estado!=='Recibido') o.items.forEach(function(i){ if(i.prod) abiertos[i.prod]=1; }); });
    var grupos={}, yaPedidos=0;
    db.prediccion.forEach(function(r){
      if(!(r.sugerida>0)||(r.estado!=='agotado'&&r.estado!=='reponer')) return;
      if(abiertos[r.id]){ yaPedidos++; return; }
      var p=prodPorId(r.id); if(!p) return; var k=p.prov||'';
      (grupos[k]=grupos[k]||[]).push({p:p,qty:r.sugerida});
    });
    var claves=Object.keys(grupos).sort(function(a,b){ return (a?0:1)-(b?0:1)||provNombre(a).localeCompare(provNombre(b)); });
    if(!claves.length){ aviso(yaPedidos?'Lo que hay que reponer ya está en pedidos abiertos.':'Nada que reponer por ahora según tus ventas.'); return; }
    abrirModal('Pedidos sugeridos',
      '<p class="intro" style="margin:0 0 12px">Lo que conviene reponer según las ventas de las últimas 4 semanas y los días de entrega de cada proveedor. Se crea un <b>borrador por proveedor</b>: después lo revisas y lo envías.'+(yaPedidos?' Se omitieron '+yaPedidos+' producto'+(yaPedidos>1?'s':'')+' que ya están en un pedido abierto.':'')+'</p>'+
      claves.map(function(k){ var g=grupos[k], tot=g.reduce(function(s,x){ return s+x.qty*(x.p.costo||0); },0);
        return '<div class="mblock sug" data-prov="'+esc(k)+'"><label class="check" style="font-weight:700"><input type="checkbox" class="sgOn" name="sgOn"'+(k?' checked':'')+'> '+esc(k?provNombre(k):'Sin proveedor')+' <span class="muted small">· '+g.length+' producto'+(g.length>1?'s':'')+' · '+clp(tot)+'</span></label>'+
          (k?'':'<p class="small muted" style="margin:4px 0 0">Asigna un proveedor a estos productos para pedirles por WhatsApp.</p>')+
          '<table style="margin-top:6px"><tbody>'+g.map(function(x){ return '<tr><td>'+esc(x.p.nombre)+'</td><td class="muted small">stock '+fmtCant(x.p, x.p.stock)+'</td><td style="text-align:right"><input class="sgQ" name="sgQ" type="number" min="0" step="'+paso(x.p)+'" style="width:76px" value="'+Number(x.qty)+'" data-prod="'+esc(x.p.id)+'" aria-label="Cantidad a pedir de '+esc(x.p.nombre)+'"></td></tr>'; }).join('')+'</tbody></table></div>'; }).join('')+
      '<div style="display:flex;gap:8px;margin-top:14px"><button class="btn btn-primary" id="sgCrear">Crear borradores</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    $('sgCrear').addEventListener('click', function(){
      var reqs=[];
      document.querySelectorAll('#modalBody .sug').forEach(function(b){
        if(!b.querySelector('.sgOn').checked) return;
        var items=[]; b.querySelectorAll('.sgQ').forEach(function(i){ var q=parseFloat(i.value)||0, p=prodPorId(i.dataset.prod); if(q>0&&p) items.push({prod:p.id,nombre:p.nombre,qty:q,costo:p.costo||0}); });
        if(items.length) reqs.push({prov:b.dataset.prov,items:items,borrador:true});
      });
      if(!reqs.length){ aviso('Marca al menos un proveedor con cantidades mayores a 0.'); return; }
      this.disabled=true;
      // Cada POST con su propio catch: se espera a todos y recién ahí se recarga, así no queda nada a medias en pantalla.
      var fallas=[];
      Promise.all(reqs.map(function(r){ return API.send('POST','/api/pedidos',r).catch(function(e){ fallas.push(provNombre(r.prov)+': '+e.message); return null; }); })).then(function(res){
        var creados=res.filter(Boolean);
        return recargarPC().then(function(){
          irTab('pedidos');
          $('modalBody').innerHTML='<div class="ped-ok">'+ico('ok')+''+creados.length+' borrador'+(creados.length===1?'':'es')+' creado'+(creados.length===1?'':'s')+' en Compras › 1. Pedidos. Revísalos y presiona «Enviar al proveedor».</div>'+
            (fallas.length?'<ul class="small" role="alert">'+fallas.map(function(f){ return '<li>'+esc(f)+'</li>'; }).join('')+'</ul>':'')+'<button class="btn btn-ghost" data-cerrar style="margin-top:14px">Cerrar</button>';
        });
      });
    });
  });

  // ---- Lote y vencimiento por línea + lector GS1 (compartido por recepción e ingreso directo) ----
  // Solo se pinta (o se muestra) en líneas de productos que controlan vencimiento: ahí el vencimiento es obligatorio,
  // salvo que el producto tenga vida útil (`vida`, días): entonces es opcional y el backend lo calcula (hoy + días).
  // `oculto`: el ingreso directo lo crea escondido y lo vuelve a pintar cuando eligen un producto que vence.
  function lv(oculto, nombre, vida){
    var de=nombre?' de '+esc(nombre):'';
    return '<div class="lv"'+(oculto?' hidden':'')+'><label>Lote (opcional)<input class="ll" name="ll" maxlength="40" placeholder="Código del envase" aria-label="Lote'+de+' (opcional)"></label>'+
      '<label><span>Vencimiento '+(vida?'':'<b class="req" aria-hidden="true">* obligatorio</b>')+'</span><input class="lvv" name="lvv" type="date"'+(vida?'':' required aria-required="true"')+' aria-label="Vencimiento'+de+'"></label>'+
      (vida?'<span class="small muted" style="grid-column:1/-1">'+hintVida(vida)+'</span>':'')+'</div>';
  }
  function escanerHTML(){
    return '<div class="f full escaner"><label for="scanGS1">Escanear código del envase '+ayuda('Apunta el lector al código GS1-128 o DataMatrix de la caja: completa solo el lote y el vencimiento de la línea de ese producto. Un código de barras normal (EAN-13) no trae esos datos; en ese caso escríbelos a mano.')+'</label>'+
      '<input id="scanGS1" placeholder="Escanea aquí y presiona Enter" autocomplete="off"><div class="small muted" id="scanMsg" aria-live="polite"></div></div>';
  }
  // filas(): [{prod, el}] con el .linea de cada producto. Busca la línea por GTIN (= SKU sin ceros a la izquierda);
  // si el GTIN no calza con ninguna línea avisa y no llena nada. Solo un código sin GTIN va a la primera con lote/vencimiento visible y vacío. Nunca escribe en una línea sin esos campos (o con ellos ocultos).
  function conectarEscaner(filas){
    var scan=$('scanGS1'); if(!scan) return; // la recepción no lo pinta si ningún producto vence
    scan.addEventListener('keydown', function(e){
      if(e.key!=='Enter') return; e.preventDefault();
      var r=window.parseGS1?window.parseGS1(this.value):{}, msg=$('scanMsg'); this.value='';
      if(!r.lote&&!r.vence){ msg.textContent='Ese código no trae lote ni vencimiento (código de barras normal). Escríbelos a mano.'; return; }
      var fs=filas(), sin0=function(s){ return String(s||'').replace(/^0+/,''); };
      var conLv=function(x){ var b=x.el&&x.el.querySelector('.lv'); return !!(b&&!b.hidden&&b.querySelector('.lvv')); };
      var g=r.gtin&&fs.find(function(x){ var p=prodPorId(x.prod); return p&&p.sku&&sin0(p.sku)===sin0(r.gtin); });
      if(r.gtin&&!g){ msg.textContent='Ese código ('+r.gtin+') no corresponde a ningún producto de esta lista. No se llenó nada: revisa el SKU del producto o escribe el lote a mano.'; return; }
      if(g&&!conLv(g)){ var pg=prodPorId(g.prod); msg.textContent=(pg?pg.nombre:'Ese producto')+' no controla vencimiento: no necesita lote.'; return; }
      var f=g||fs.find(function(x){ return conLv(x)&&!x.el.querySelector('.lvv').value; });
      if(!f){ msg.textContent='No hay una línea libre que pida lote y vencimiento para este código.'; return; }
      if(r.lote) f.el.querySelector('.ll').value=r.lote;
      if(r.vence) f.el.querySelector('.lvv').value=r.vence;
      var p=prodPorId(f.prod); msg.textContent=''+(p?p.nombre:'Línea')+': lote '+(r.lote||'Sin código')+', vence '+(r.vence?fmtFecha(r.vence):'—');
    });
  }

  // Al ingresar mercadería el costo del producto pasa a ser el de la compra. Si subió, se avisa con el margen
  // antes y después para que el dueño revise el precio de venta. `antes` = {id: costo} tomado antes del ingreso.
  function costosDe(ids){ var m={}; ids.forEach(function(id){ var p=prodPorId(id); if(p) m[id]=p.costo; }); return m; }
  function avisoCostos(antes){
    var mg=margen;
    var li=Object.keys(antes).map(function(id){ var p=prodPorId(id); if(!p||!(p.costo>antes[id])) return '';
      return '<li><b>'+esc(p.nombre)+'</b>: costo '+clp(antes[id])+' → '+clp(p.costo)+', margen '+mg(p.precio,antes[id])+'% → <b>'+mg(p.precio,p.costo)+'%</b> (precio '+clp(p.precio)+')</li>'; }).join('');
    return li?'<div class="mblock" role="status" style="margin-top:12px"><h4>'+ico('alerta')+'Subió el costo</h4><ul class="small" style="margin:6px 0 0;padding-left:18px">'+li+'</ul><p class="small muted" style="margin:8px 0 0">Revisa el precio de venta en Inventario (Editar) si quieres mantener tu margen.</p></div>':'';
  }
  // Recibir pedido (paso 2): se edita lo que llegó de verdad, a qué costo y con qué lote/vencimiento, y se manda a
  // /api/pedidos/:id/recibir. El backend suma el stock, crea los lotes y el ingreso; después recargamos con recargarPC().
  function recibirPedido(o){
    var lineas=o.items.map(function(it){ var p=prodPorId(it.prod); return {prod:it.prod||null,nombre:it.nombre||(p?p.nombre:'(producto)'),qty:it.qty,costo:it.costo!=null?it.costo:(p?p.costo:0),lote:'',vence:'',req:!!(p&&p.controlaVence),vida:p&&p.vidaUtil,paso:paso(p)}; });
    var det='<div class="linea rec cab muted small"><span>Producto</span><span>Llegó</span><span>Costo</span></div>'+lineas.map(function(l,i){
      return '<div class="linea rec'+(l.req?' pide-vence':'')+'" data-i="'+i+'"><span>'+esc(l.nombre)+'</span>'+
        '<input class="rq" name="rq" type="number" min="0" step="'+l.paso+'" value="'+Number(l.qty)+'" aria-label="Cantidad que llegó de '+esc(l.nombre)+'"><input class="rc" name="rc" type="number" min="0" value="'+Number(l.costo)+'" aria-label="Costo unitario de '+esc(l.nombre)+'">'+
        (!l.prod?'<div class="lv small muted">Producto fuera del catálogo: suma al total pero no al stock.</div>':l.req?lv(false,l.nombre,l.vida):'')+'</div>';
    }).join('');
    abrirModal('Recibir pedido '+numPed(o),
      '<p class="intro" style="margin:0 0 12px">Paso 2 de 3. Anota lo que <b>realmente llegó</b> (0 si no llegó) y, solo en los productos que vencen, su lote y vencimiento. Al confirmar se suma al stock y queda como ingreso de mercadería.</p>'+
      (lineas.some(function(l){ return l.req; })?escanerHTML():'')+det+
      '<div class="ord-total"><span>Total</span><b id="recTotal"></b></div>'+
      '<button class="btn btn-primary" id="confRecibir" style="width:100%">Confirmar recepción</button>');
    // Pasa lo que hay en los inputs a `lineas` y actualiza el total.
    function leer(){
      document.querySelectorAll('#modalBody .linea.rec[data-i]').forEach(function(d){
        var l=lineas[+d.dataset.i]; l.qty=+d.querySelector('.rq').value||0; l.costo=+d.querySelector('.rc').value||0;
        var ll=d.querySelector('.ll'); if(ll){ l.lote=ll.value.trim(); l.vence=d.querySelector('.lvv').value; }
      });
      $('recTotal').textContent=clp(lineas.reduce(function(s,l){return s+l.qty*l.costo;},0));
    }
    document.querySelectorAll('#modalBody .rq, #modalBody .rc').forEach(function(inp){ inp.addEventListener('input', leer); }); leer();
    conectarEscaner(function(){ return lineas.map(function(l,i){ return {prod:l.prod, el:document.querySelector('#modalBody .linea.rec[data-i="'+i+'"]')}; }).filter(function(x){ return x.prod; }); });
    $('confRecibir').addEventListener('click', function(){
      leer();
      var falta=lineas.findIndex(function(l){ return l.req&&!l.vida&&l.qty>0&&!l.vence; }); // con vida útil lo calcula el backend
      if(falta>-1){ aviso('Falta el vencimiento de "'+lineas[falta].nombre+'". Este producto controla vencimiento.'); document.querySelector('#modalBody .linea.rec[data-i="'+falta+'"] .lvv').focus(); return; }
      var items=lineas.map(function(l){ return {prod:l.prod,nombre:l.nombre,qty:l.qty,costo:l.costo,lote:l.lote||null,vence:l.vence||null}; });
      var antes=costosDe(lineas.filter(function(l){ return l.prod&&l.qty>0; }).map(function(l){ return l.prod; }));
      API.send('POST','/api/pedidos/'+encodeURIComponent(o.id)+'/recibir',{items:items})
        .then(function(){ return recargarPC(); })
        .then(function(){
          // Lo que se pidió y no llegó (o llegó de menos) se puede volver a pedir como borrador al mismo proveedor.
          var faltan=o.items.map(function(it,i){ return {prod:it.prod||null,nombre:it.nombre,qty:Math.round(((Number(it.qty)||0)-(lineas[i]?lineas[i].qty:0))*1000)/1000,costo:it.costo||0}; }).filter(function(x){ return x.qty>0; });
          $('modalBody').innerHTML='<div class="ped-ok">'+ico('ok')+'Mercadería recibida (paso 3 de 3). Stock actualizado e ingreso registrado.</div>'+avisoCostos(antes)+
            (faltan.length?'<div class="mblock" role="status" style="margin-top:12px"><h4>Faltó mercadería</h4><ul class="small" style="margin:6px 0 0;padding-left:18px">'+faltan.map(function(x){ return '<li>'+esc(x.nombre)+': faltaron '+x.qty+'</li>'; }).join('')+'</ul><button class="btn btn-ghost" id="pedirFalta" style="margin-top:10px">Pedir lo que faltó (borrador)</button></div>':'')+
            '<div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-primary" id="verIngOk">Ver ingreso</button><button class="btn btn-ghost" data-cerrar>Cerrar</button></div>';
          $('verIngOk').addEventListener('click', function(){ var n=db.pedidos.find(function(x){return x.id===o.id;}); if(n) verIngreso(n); });
          var pf=$('pedirFalta'); if(pf) pf.addEventListener('click', function(){ pf.disabled=true;
            API.send('POST','/api/pedidos',{prov:o.prov||'',nota:'Lo que faltó del pedido '+numPed(o),items:faltan,borrador:true})
              .then(function(s){ db.pedidos.unshift(s); renderPedidos(); pf.outerHTML='<p class="small" style="margin:10px 0 0">'+ico('ok')+'Borrador creado en Compras › 1. Pedidos.</p>'; })
              .catch(function(e){ pf.disabled=false; aviso('No se pudo crear el borrador: '+e.message); });
          });
        })
        .catch(function(e){ aviso('No se pudo recibir: '+e.message); });
    });
  }
  // "Ver ingreso" de un pedido recibido: lo que llegó (con lote y vencimiento) y su fila en Ingresos de mercadería.
  var resaltar=null; // id del ingreso a destacar en la tabla
  function verIngreso(o){
    var c=db.compras.find(function(x){return x.id===o.compraId;});
    var its=o.items.map(function(i){ var vi=venceInfo(i.vence);
      return '<tr><td>'+esc(i.nombre)+'</td><td>'+Number(i.qty)+'</td><td>'+esc(i.lote||(i.vence?'Sin código':'—'))+'</td><td>'+(i.vence?'<span class="tag '+vi.c+'">'+esc(fmtFecha(i.vence))+'</span>':'—')+'</td><td style="text-align:right">'+clp(i.qty*i.costo)+'</td></tr>'; }).join('');
    var total=totalPed(o);
    abrirModal('Ingreso del pedido '+numPed(o),
      '<div class="mblock"><div class="kv"><span class="muted">Fecha</span><b>'+fmtFecha(c?c.fecha:o.fecha)+'</b><span class="muted">Proveedor</span><b>'+esc(c?c.prov:(o.provNombre||provNombre(o.prov)))+'</b><span class="muted">Total</span><b>'+clp(c?c.total:total)+'</b></div></div>'+
      '<div class="mblock"><h4>Lo que llegó</h4><table><thead><tr><th>Producto</th><th>Cant.</th><th>Lote</th><th>Vence</th><th style="text-align:right">Subtotal</th></tr></thead><tbody>'+its+'</tbody></table></div>'+
      (c?'<button class="btn btn-ghost" id="irIngresos">Ver en Ingresos de mercadería</button>':''));
    var ir=$('irIngresos'); if(ir) ir.addEventListener('click', function(){ resaltar=c.id; renderCompras(); cerrarModal(); irTab('recepciones'); });
  }
  $('pedBody').addEventListener('click', function(e){
    var b=e.target.closest('[data-recibir],[data-enviar],[data-ver-ingreso],[data-editar-ped],[data-borrar-ped],[data-repetir]'); if(!b) return;
    var o=db.pedidos.find(function(x){return x.id===(b.dataset.recibir||b.dataset.enviar||b.dataset.verIngreso||b.dataset.editarPed||b.dataset.borrarPed||b.dataset.repetir);}); if(!o) return;
    // Repetir: borrador con lo que llegó la vez anterior (al costo actual de cada producto) y se abre para ajustarlo.
    if(b.dataset.repetir){
      var its=o.items.filter(function(i){ return (Number(i.qty)||0)>0; }).map(function(i){ var p=i.prod&&prodPorId(i.prod); return {prod:p?p.id:null,nombre:p?p.nombre:i.nombre,qty:Number(i.qty),costo:p?p.costo:(i.costo||0)}; });
      if(!its.length){ aviso('Ese pedido no tiene productos para repetir.'); return; }
      API.send('POST','/api/pedidos',{prov:o.prov||'',nota:'',items:its,borrador:true}).then(function(s){ db.pedidos.unshift(s); renderPedidos(); formPedido(s.prov, s); })
        .catch(function(e){ aviso('No se pudo repetir el pedido: '+e.message); });
      return;
    }
    if(b.dataset.recibir) recibirPedido(o);
    else if(b.dataset.verIngreso) verIngreso(o);
    else if(b.dataset.editarPed) formPedido(o.prov, o);
    else if(b.dataset.borrarPed){
      abrirModal('Eliminar borrador','<p>¿Eliminar el borrador <b>'+esc(numPed(o))+'</b>? No se puede deshacer.</p><div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-danger" id="confDelPed">Sí, eliminar</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
      $('confDelPed').addEventListener('click', function(){ API.send('DELETE','/api/pedidos/'+encodeURIComponent(o.id)).then(function(){ db.pedidos=db.pedidos.filter(function(x){return x.id!==o.id;}); renderPedidos(); cerrarModal(); }).catch(function(e){ aviso('No se pudo eliminar: '+e.message); }); });
    }
    else API.send('POST','/api/pedidos/'+encodeURIComponent(o.id)+'/enviar').then(function(saved){
      var i=db.pedidos.findIndex(function(x){return x.id===o.id;}); if(i>-1) db.pedidos[i]=saved; renderPedidos(); avisoEnviado(saved);
    }).catch(function(e){ aviso('No se pudo enviar el pedido: '+e.message); });
  });

  // Tabla de ingresos + KPI "ingresos del mes" (filtra por YYYY-MM de la fecha).
  // Devolucion = mercadería devuelta al proveedor: total negativo (crédito) y no cuenta como compra en los totales.
  var tipoIng={Pedido:{c:'ok',t:'Desde pedido'},Manual:{c:'mut',t:'Directo'},Externa:{c:'mut',t:'Externo'},Devolucion:{c:'warn',t:'Devolución'}};
  var esCompra=function(c){ return c.tipo!=='Devolucion'; };
  function renderCompras(){
    $('compBody').innerHTML=db.compras.map(function(c){
      var t=tipoIng[c.tipo]||{c:'mut',t:c.tipo};
      return '<tr'+(c.id===resaltar?' class="hl"':'')+'><td>'+fmtFecha(c.fecha)+'</td><td class="prin"><b>'+esc(c.prov)+'</b></td><td><span class="tag '+t.c+'">'+esc(t.t)+'</span></td><td data-l="Ítems">'+Number(c.items)+'</td><td>'+(c.total<0?'<span class="tag warn">−'+clp(-c.total)+'</span>':clp(c.total))+'</td><td class="acc"><button class="mini" data-ver-compra="'+esc(c.id)+'" aria-label="Ver detalle del ingreso de '+esc(c.prov)+' del '+fmtFecha(c.fecha)+'">Ver ›</button></td></tr>';
    }).join('')||'<tr><td colspan="5" class="muted" style="text-align:center;padding:20px">Aún no hay ingresos. Aparecen al recibir un pedido o con "Registrar ingreso sin pedido".</td></tr>';
    var m=hoyISO().slice(0,7);
    var mes=db.compras.filter(function(c){return esCompra(c)&&(c.fecha||'').slice(0,7)===m;}).reduce(function(s,c){return s+c.total;},0);
    $('kpiCompras').textContent=clp(mes);
  }
  // Detalle de un ingreso: qué entró, a qué costo y con qué lote (sale del kardex).
  $('compBody').addEventListener('click', function(e){
    var b=e.target.closest('[data-ver-compra]'); if(!b) return;
    abrirModal('Ingreso de mercadería','<p class="muted small">Cargando…</p>');
    fetch('/api/compras/'+encodeURIComponent(b.dataset.verCompra)).then(function(r){ if(!r.ok) throw new Error(); return r.json(); }).then(function(c){
      if(c.tipo==='Devolucion') $('modalTitulo').textContent='Devolución al proveedor'; // mismo detalle: cantidades en negativo, total = crédito
      $('modalBody').innerHTML='<div class="mblock"><div class="kv"><span class="muted">Fecha</span><b>'+fmtFecha(c.fecha)+'</b><span class="muted">Proveedor</span><b>'+esc(c.prov)+'</b><span class="muted">Total</span><b>'+clp(c.total)+'</b></div></div>'+
        '<table><thead><tr><th>Producto</th><th>Cant.</th><th>Costo</th><th>Lote</th><th>Vence</th></tr></thead><tbody>'+
        (c.lineas.map(function(l){ return '<tr><td>'+esc(l.nombre)+'</td><td>'+fmtCant(null,l.cantidad)+'</td><td>'+clp(l.costo)+'</td><td>'+esc(l.lote||(l.vence?'Sin código':'—'))+'</td><td>'+(l.vence?esc(fmtFecha(l.vence)):'—')+'</td></tr>'; }).join('')||'<tr><td colspan="5" class="muted">Sin líneas con stock.</td></tr>')+'</tbody></table>';
    }).catch(function(){ errorModal('el ingreso'); });
  });
  // Ingreso directo sin pedido previo (o a la feria/mayorista, prov='externa'). POST /api/compras.
  // La fecha la pone el servidor (hoy).
  $('nuevaCompra').addEventListener('click', function(){
    var provOpts='<option value="externa">Compra externa (feria, mayorista al paso, supermercado…)</option>'+db.proveedores.map(function(p){ return '<option value="'+esc(p.id)+'">'+esc(p.nombre)+'</option>'; }).join('');
    abrirModal('Registrar ingreso sin pedido',
      '<p class="intro" style="margin:0 0 12px">Para mercadería que llegó sin un pedido previo, por ejemplo si fuiste al mayorista. Al confirmar suma stock y queda en Ingresos de mercadería.</p>'+
      '<div class="form-grid"><div class="f full"><label for="cProv">Proveedor / origen</label><select id="cProv">'+provOpts+'</select></div></div>'+
      '<div style="margin-top:12px">'+escanerHTML()+'</div>'+
      '<h4 style="margin:4px 0 8px; font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; color:var(--muted)">Productos <span style="text-transform:none; letter-spacing:0; font-weight:600">(producto · cantidad · costo)</span></h4>'+
      '<div id="lineas"></div>'+
      '<button class="mini" id="addLinea" style="margin-top:4px">＋ Agregar línea</button>'+
      '<div class="ord-total"><span>Total ingreso</span><b id="cTotal">$0</b></div>'+
      '<div style="display:flex;gap:8px"><button class="btn btn-primary" id="guardarCompra">Registrar ingreso</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    function addLinea(){
      var div=document.createElement('div'); div.className='linea';
      div.innerHTML=buscadorProd('lp', 'Producto')+'<input class="lq" name="lq" type="number" min="0" placeholder="Cant." value="1" aria-label="Cantidad"><input class="lc" name="lc" type="number" min="0" placeholder="Costo" aria-label="Costo unitario"><button class="rm" title="Quitar" aria-label="Quitar línea">'+ico('x')+'</button>'+lv(true);
      $('lineas').appendChild(div);
      // Buscador en vez de <select> con todos los productos (con miles de productos el formulario se pegaba).
      activarBuscadorProd(div, { lista:function(){ return db.productos; }, extra:function(p){ return 'stock '+fmtCant(p, p.stock); }, alElegir:function(p){
        var req=!!(p&&p.controlaVence);
        div.querySelector('.lc').value=p&&p.costo?p.costo:''; div.classList.toggle('pide-vence', req); div.querySelector('.lq').step=paso(p);
        var de=p?' de '+p.nombre:''; div.querySelector('.lq').setAttribute('aria-label','Cantidad'+de); div.querySelector('.lc').setAttribute('aria-label','Costo unitario'+de);
        div.querySelector('.lv').outerHTML=lv(!req, p&&p.nombre, p&&p.vidaUtil); recalc(); // se repinta: nombre en los aria-label y, con vida útil, sin obligatorio
      } });
      div.querySelector('.lq').addEventListener('input', recalc);
      div.querySelector('.lc').addEventListener('input', recalc);
      div.querySelector('.rm').addEventListener('click', function(){ div.remove(); recalc(); });
    }
    function recalc(){ var tot=0; document.querySelectorAll('#lineas .linea').forEach(function(l){ tot+=(+l.querySelector('.lq').value||0)*(+l.querySelector('.lc').value||0); }); $('cTotal').textContent=clp(tot); }
    $('addLinea').addEventListener('click', addLinea); addLinea();
    conectarEscaner(function(){ return Array.prototype.map.call(document.querySelectorAll('#lineas .linea'), function(el){ return {prod:el.querySelector('.lp').value, el:el}; }).filter(function(x){ return x.prod; }); });
    $('guardarCompra').addEventListener('click', function(){
      var lineas=[], falta=null;
      document.querySelectorAll('#lineas .linea').forEach(function(l){
        var pid=l.querySelector('.lp').value, q=+l.querySelector('.lq').value||0, c=+l.querySelector('.lc').value||0;
        if(!pid||q<=0) return;
        // Lote y vencimiento solo cuentan si el producto los pide (si no, el bloque está oculto y se ignora).
        var p=prodPorId(pid), req=!!(p&&p.controlaVence), v=req?l.querySelector('.lvv').value:'';
        if(req&&!v&&!p.vidaUtil&&!falta) falta={p:p,el:l.querySelector('.lvv')}; // con vida útil el backend pone hoy + días
        lineas.push({prod:pid,qty:q,costo:c,lote:req?(l.querySelector('.ll').value.trim()||null):null,vence:v||null});
      });
      if(falta){ aviso('Falta el vencimiento de "'+falta.p.nombre+'". Este producto controla vencimiento.'); falta.el.focus(); return; }
      if(!lineas.length){ aviso('Agrega al menos un producto con cantidad mayor a 0.'); return; }
      var antes=costosDe(lineas.map(function(l){ return l.prod; }));
      API.send('POST','/api/compras',{prov:$('cProv').value,items:lineas})
        .then(function(){ return recargarPC(); })
        .then(function(){ $('modalBody').innerHTML='<div class="ped-ok">'+ico('ok')+'Ingreso registrado. Stock actualizado.</div>'+avisoCostos(antes)+'<button class="btn btn-ghost" data-cerrar style="margin-top:16px">Cerrar</button>'; irTab('recepciones'); })
        .catch(function(e){ aviso('No se pudo registrar: '+e.message); });
    });
  });

  // Devolución al proveedor (vencido, dañado, error del pedido): saca stock con POST /api/compras/devolucion.
  // No es merma: queda en Ingresos como "Devolución" con total negativo (lo que el proveedor te debe acreditar).
  $('nuevaDevol').addEventListener('click', function(){
    if(!db.proveedores.length){ abrirModal('Devolver al proveedor','<p>Para devolver mercadería primero registra a tu proveedor.</p><button class="btn btn-primary" data-goto="proveedores" data-cerrar>Ir a Proveedores</button>'); return; }
    abrirModal('Devolver al proveedor',
      '<p class="intro" style="margin:0 0 12px">Para mercadería que le devuelves al proveedor (vencida, dañada o que no correspondía). Al confirmar se descuenta del stock y queda en Ingresos de mercadería como devolución, con el monto a costo que te debe acreditar. No cuenta como merma.</p>'+
      '<div class="form-grid"><div class="f"><label for="dvProv">Proveedor</label><select id="dvProv" required><option value="">Elige…</option>'+db.proveedores.map(function(p){ return '<option value="'+esc(p.id)+'">'+esc(p.nombre)+'</option>'; }).join('')+'</select></div>'+
      '<div class="f"><label for="dvMotivo">Motivo</label><input id="dvMotivo" maxlength="200" placeholder="Vencido, dañado, error del pedido…"></div></div>'+
      '<h4 style="margin:12px 0 8px; font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; color:var(--muted)">Productos <span style="text-transform:none; letter-spacing:0; font-weight:600">(producto · cantidad)</span></h4>'+
      '<div id="dvLineas"></div><button class="mini" id="dvAdd" style="margin-top:4px">＋ Agregar línea</button>'+
      '<div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-primary" id="dvGuardar">Registrar devolución</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    function addLinea(){
      var div=document.createElement('div'); div.className='linea'; div.style.gridTemplateColumns='1fr 90px 30px'; // sin columna de costo: sale al costo FIFO
      div.innerHTML=buscadorProd('dp', 'Producto a devolver')+'<input class="dq" name="dq" type="number" min="0" step="1" placeholder="Cant." value="1" aria-label="Cantidad a devolver"><button class="rm" title="Quitar" aria-label="Quitar línea">'+ico('x')+'</button>';
      $('dvLineas').appendChild(div);
      activarBuscadorProd(div, { lista:function(){ return db.productos; }, extra:function(p){ return 'stock '+fmtCant(p, p.stock); }, alElegir:function(p){ div.querySelector('.dq').step=paso(p); div.querySelector('.dq').setAttribute('aria-label','Cantidad a devolver'+(p?' de '+p.nombre:'')); } });
      div.querySelector('.rm').addEventListener('click', function(){ div.remove(); });
    }
    $('dvAdd').addEventListener('click', addLinea); addLinea();
    $('dvGuardar').addEventListener('click', function(){
      var prov=$('dvProv').value; if(!prov){ aviso('Elige a qué proveedor le devuelves.'); $('dvProv').focus(); return; }
      var items=[]; document.querySelectorAll('#dvLineas .linea').forEach(function(l){ var pid=l.querySelector('.dp').value, q=parseFloat(l.querySelector('.dq').value)||0; if(pid&&q>0) items.push({prod:pid,qty:q}); });
      if(!items.length){ aviso('Agrega al menos un producto con cantidad mayor a 0.'); return; }
      var b=this; b.disabled=true;
      API.send('POST','/api/compras/devolucion',{prov:prov,motivo:$('dvMotivo').value.trim(),items:items})
        .then(function(r){ return recargarPC().then(function(){ return r; }); })
        .then(function(r){ irTab('recepciones'); $('modalBody').innerHTML='<div class="ped-ok">'+ico('ok')+'Devolución registrada. Stock descontado. Crédito a cobrar al proveedor: <b>'+clp(r.total)+'</b> (a costo).</div><button class="btn btn-ghost" data-cerrar style="margin-top:16px">Cerrar</button>'; })
        .catch(function(e){ b.disabled=false; aviso('No se pudo registrar la devolución: '+e.message); });
    });
  });

