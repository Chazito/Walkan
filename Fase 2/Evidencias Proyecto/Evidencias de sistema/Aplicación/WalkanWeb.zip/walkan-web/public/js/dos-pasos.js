// dos-pasos.js — /dos-pasos: activar la verificación en dos pasos (QR + código), mostrar los códigos de respaldo
// una sola vez, generar otros nuevos o desactivarla. El equipo Walkan llega aquí obligado (no puede desactivarla).
(function(){
  var $=function(id){ return document.getElementById(id); };
  var msg=$('dpMsg'), panel='/panel';
  function mostrar(tipo, texto){
    msg.className='msg msg-'+tipo; msg.innerHTML='';
    var ico=document.createElement('span'); ico.className='msg-ico'; ico.setAttribute('aria-hidden','true'); ico.textContent=tipo==='error'?'!':'i';
    var c=document.createElement('div'); c.className='msg-txt'; c.textContent=texto;
    msg.appendChild(ico); msg.appendChild(c); msg.hidden=false;
  }
  function limpiar(){ msg.hidden=true; }
  function api(metodo, url, body){
    // Sin cuerpo no se manda Content-Type JSON (el servidor rechaza un JSON vacío).
    return fetch(url, body ? { method:metodo, headers:{'Content-Type':'application/json'}, body:JSON.stringify(body) } : { method:metodo })
      .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){
        if(r.status===401){ location.href='/mi-cuenta'; throw new Error('Tu sesión terminó.'); }
        if(!r.ok){ var m=d&&d.message; var e=new Error((Array.isArray(m)?m[0]:m)||'No se pudo completar.'); e.status=r.status; throw e; }
        return d; }); });
  }
  function errorDe(e){ return e instanceof TypeError ? 'No hay conexión con el servidor. Revisa tu internet.' : e.message; }
  function ocupado(b, on, txt){ b.disabled=on; if(txt) b.textContent=txt; }

  // Pantalla de códigos de respaldo: se muestran una sola vez, con opción de copiarlos o bajarlos.
  var codigos=[];
  function verRespaldo(lista){
    codigos=lista;
    $('dpConfigurar').hidden=true; $('dpActiva').hidden=true; $('dpRespaldo').hidden=false;
    $('dpCodigos').innerHTML=''; lista.forEach(function(c){ var li=document.createElement('li'); li.textContent=c; $('dpCodigos').appendChild(li); });
    $('dpIntro').hidden=true; $('dpSeguir').focus();
  }
  function texto(){ return 'Códigos de respaldo de Walkan (cada uno sirve una sola vez):\n\n'+codigos.join('\n')+'\n'; }
  $('dpCopiar').addEventListener('click', function(){
    var b=this; (navigator.clipboard?navigator.clipboard.writeText(texto()):Promise.reject()).then(function(){ b.textContent='Copiados'; }, function(){ b.textContent='No se pudo copiar'; });
  });
  $('dpDescargar').addEventListener('click', function(){
    var a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([texto()],{type:'text/plain'})); a.download='walkan-codigos-de-respaldo.txt';
    document.body.appendChild(a); a.click(); setTimeout(function(){ URL.revokeObjectURL(a.href); a.remove(); }, 0);
  });

  // Pide al servidor un secreto nuevo y pinta el QR para escanearlo con la app.
  function configurar(){
    $('dpConfigurar').hidden=false;
    api('POST','/api/auth/dos-pasos/iniciar').then(function(d){
      $('dpQr').innerHTML=d.qr; $('dpSecreto').textContent=d.secreto; $('dpCodigo').focus();
    }).catch(function(e){ mostrar('error', errorDe(e)); });
  }
  var cod=$('dpCodigo'); cod.classList.add('codigo-dp'); cod.addEventListener('input', limpiar);
  $('dpActivar').addEventListener('submit', function(ev){
    ev.preventDefault();
    var c=cod.value.replace(/\s/g,''), b=this.querySelector('button');
    if(!/^\d{6}$/.test(c)){ mostrar('error', 'Escribe los 6 dígitos que muestra la app.'); cod.focus(); return; }
    ocupado(b, true, 'Activando…');
    api('POST','/api/auth/dos-pasos/activar',{ codigo:c }).then(function(d){ verRespaldo(d.respaldo); })
      .catch(function(e){ ocupado(b, false, 'Activar'); mostrar('error', errorDe(e)); cod.select(); });
  });
  $('dpNuevos').addEventListener('submit', function(ev){
    ev.preventDefault(); limpiar();
    var b=this.querySelector('button');
    ocupado(b, true);
    api('POST','/api/auth/dos-pasos/respaldo',{ codigo:$('dpCodigoN').value.trim() }).then(function(d){ verRespaldo(d.respaldo); })
      .catch(function(e){ ocupado(b, false); mostrar('error', errorDe(e)); });
  });
  $('dpApagar').addEventListener('submit', function(ev){
    ev.preventDefault(); limpiar();
    var b=this.querySelector('button');
    ocupado(b, true);
    api('POST','/api/auth/dos-pasos/desactivar',{ password:$('dpClave').value, codigo:$('dpCodigoA').value.trim() })
      .then(function(){ location.href=panel+'#cuenta'; })
      .catch(function(e){ ocupado(b, false); mostrar('error', errorDe(e)); });
  });

  // Arranque: según si ya la tiene activa se muestra el estado o se parte la configuración.
  Promise.all([api('GET','/api/auth/me'), api('GET','/api/auth/dos-pasos')]).then(function(r){
    var u=r[0].usuario, e=r[1];
    panel=u.rol==='staff'?'/admin':'/panel';
    $('dpSeguir').href=panel; $('dpVolver').href=panel+'#cuenta';
    if(e.obligatorio && !e.activo) mostrar('aviso', 'Para el equipo Walkan la verificación en dos pasos es obligatoria. Actívala para entrar al panel.');
    if(e.activo){
      $('dpActiva').hidden=false;
      $('dpActivaTxt').textContent='La verificación en dos pasos está activa'+(e.desde?' desde el '+new Date(e.desde).toLocaleDateString('es-CL'):'')+'. Te quedan '+e.respaldosRestantes+' código'+(e.respaldosRestantes===1?'':'s')+' de respaldo.';
      $('dpApagar').hidden=e.obligatorio;
    } else configurar();
  }).catch(function(e){ mostrar('error', errorDe(e)); });
})();
