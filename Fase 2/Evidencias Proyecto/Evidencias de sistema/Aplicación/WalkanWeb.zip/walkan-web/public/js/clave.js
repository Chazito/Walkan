// clave.js — política de contraseñas en el navegador (la misma que valida el servidor en
// src/common/util/politica-clave.ts). Muestra la lista de requisitos y los va marcando al escribir.
(function(){
  var REGLAS = [
    { id:'largo',    texto:'Al menos 8 caracteres',          ok:function(p){ return p.length >= 8; } },
    { id:'mayus',    texto:'Una letra mayúscula',            ok:function(p){ return /[A-ZÁÉÍÓÚÑ]/.test(p); } },
    { id:'minus',    texto:'Una letra minúscula',            ok:function(p){ return /[a-záéíóúñ]/.test(p); } },
    { id:'numero',   texto:'Un número',                      ok:function(p){ return /\d/.test(p); } },
    { id:'especial', texto:'Un carácter especial (! @ # $ % & * ? -)', ok:function(p){ return /[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ\s]/.test(p); } },
    { id:'espacios', texto:'Sin espacios',                   ok:function(p){ return !/\s/.test(p); } }
  ];
  function faltas(p){ p = p || ''; return REGLAS.filter(function(r){ return !r.ok(p); }).map(function(r){ return r.texto.toLowerCase(); }); }
  // Pinta la lista en `ul` y la actualiza con cada tecla del `input`.
  function montar(input, ul){
    if(!input || !ul) return;
    ul.innerHTML = '';
    var items = REGLAS.map(function(r){
      var li = document.createElement('li'); li.textContent = r.texto; ul.appendChild(li); return { r:r, li:li };
    });
    function pintar(){ var p = input.value; items.forEach(function(x){ x.li.className = !p ? '' : (x.r.ok(p) ? 'ok' : 'falta'); /* vacío = neutro: antes 'Sin espacios' salía ✓ sin escribir */ }); }
    input.addEventListener('input', pintar); pintar();
  }
  window.WalkanClave = { faltas: faltas, montar: montar, mensaje: function(p){ var f = faltas(p); return f.length ? 'La contraseña debe tener: ' + f.join(', ') + '.' : ''; } };
})();
