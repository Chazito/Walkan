// admin.js — panel interno del equipo Walkan (/admin), solo para usuarios con rol 'staff'.
// Acá se ven todos los clientes, las solicitudes que llegan desde la landing y la flota
// completa de cajas. Mismo estilo que panel.js: fetch a /api/admin/*, render con strings.
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var clp = function (n) { return '$' + (n || 0).toLocaleString('es-CL'); };
  // Ojo: este esc no escapa la comilla simple (el de panel.js sí). Mientras los atributos usen "" no pasa nada.
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); };

  // get() devuelve null si la respuesta no es ok; por eso en recargar() van los `|| []`.
  var API = {
    get: function (u) { return fetch(u).then(function (r) { if (!r.ok) return null; return r.json(); }); },
    send: function (m, u, b) {
      var opt = { method: m };
      if (b !== undefined) { opt.headers = { 'Content-Type': 'application/json' }; opt.body = JSON.stringify(b); }
      return fetch(u, opt).then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error((d && d.message) || 'Error del servidor'); return d; }); });
    }
  };

  // Aviso dentro de la página en vez de alert() (mismo estilo .toast que el panel). Se cierra a los 6 s o al tocarlo.
  var avisoT;
  function aviso(msg) {
    var t = $('toast');
    if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; t.setAttribute('role', 'alert'); t.addEventListener('click', function () { t.hidden = true; }); document.body.appendChild(t); }
    t.textContent = msg; t.hidden = false; clearTimeout(avisoT); avisoT = setTimeout(function () { t.hidden = true; }, 6000);
  }

  // Resultado del correo con el enlace para crear la contraseña (invitación o acceso restablecido).
  function textoEnvio(envio, email) {
    if (envio === 'enviado') return 'Le enviamos un correo a ' + email + ' con el enlace para crear su contraseña (vale 72 horas y sirve una vez). Llega desde walkan.pos@gmail.com: si no lo ve, que revise spam.';
    if (envio === 'simulado') return 'Este servidor no tiene el correo configurado (SMTP), así que el enlace no se envió.';
    return 'No se pudo enviar el correo a ' + email + '. Inténtalo de nuevo en unos minutos.';
  }
  function avisoEnvio(titulo, envio, email) {
    $('modalTit').textContent = titulo;
    abrirModal(
      '<p' + (envio === 'enviado' ? '' : ' style="color:var(--danger)"') + '>' + esc(textoEnvio(envio, email)) + '</p>' +
      '<div class="btns" style="margin-top:10px"><button class="btn btn-primary" id="envListo">Listo</button></div>'
    );
    $('envListo').addEventListener('click', cerrarModal);
  }

  // "leads" = solicitudes de la landing (en la API se llaman /solicitudes).
  var db = { resumen: {}, clientes: [], leads: [], cajas: [], equipo: [], bitacora: [] };
  var yo = {}; // usuario en sesión (/api/auth/me): superAdmin abre "Equipo Walkan" y "Bitácora".

  // ---------- navegación ----------
  var navs = document.querySelectorAll('.side nav a');
  var titulos = { resumen: 'Resumen', clientes: 'Clientes', solicitudes: 'Solicitudes', flota: 'Flota de cajas', soporte: 'Soporte', equipo: 'Equipo Walkan', bitacora: 'Bitácora', cuenta: 'Mi cuenta' };
  navs.forEach(function (a) {
    a.addEventListener('click', function () {
      var v = a.dataset.view;
      navs.forEach(function (x) { x.classList.toggle('active', x === a); });
      document.querySelectorAll('.view').forEach(function (s) { s.classList.toggle('active', s.dataset.view === v); });
      $('tTitulo').textContent = titulos[v] || 'Admin';
    });
  });
  // El logo lleva al Resumen sin recargar (sin JS, el enlace recarga /admin, que también abre en Resumen).
  var brandAdmin = $('brandAdmin');
  if (brandAdmin) brandAdmin.addEventListener('click', function (e) {
    var r = document.querySelector('.side nav a[data-view="resumen"]');
    if (r) { e.preventDefault(); r.click(); }
  });

  // ---------- render ----------
  // KPIs de arriba (clientes, MRR, cajas) + desglose por plan. Todo viene armado desde /api/admin/resumen.
  function renderResumen() {
    var r = db.resumen || {};
    $('kClientes').textContent = r.clientes || 0;
    $('kActivos').textContent = (r.activos || 0) + ' activos' + (r.enMora ? ' · ' + r.enMora + ' en mora' : '');
    $('kMrr').textContent = clp(r.mrr || 0);
    $('kCajas').textContent = r.cajas || 0;
    $('kCajasOn').textContent = (r.cajasEnLinea || 0) + ' en línea';
    $('kBloq').textContent = r.cajasBloqueadas || 0;
    var pp = r.porPlan || {};
    var keys = Object.keys(pp);
    $('porPlan').innerHTML = keys.length
      ? keys.map(function (k) { return '<span class="muted">' + esc(k) + '</span><b>' + pp[k] + '</b>'; }).join('')
      : '<span class="muted">Sin clientes aún.</span>';
    $('tFlota').textContent = (r.cajasEnLinea || 0) + ' de ' + (r.cajas || 0) + ' cajas en línea';
  }

  // Prueba de consentimiento (Ley 21.719): versión y fecha en que el dueño aceptó la política.
  function privacidadCelda(email) {
    var c = (db.privacidad || {})[String(email || '').toLowerCase()];
    if (!c || !c.aceptado) return '<span class="tag warn">Pendiente</span>';
    return '<span class="tag ok" title="' + esc('Origen: ' + c.origen) + '">Aceptó v' + esc(c.version) + '</span><div class="muted small">' + esc(new Date(c.createdAt).toLocaleDateString('es-CL')) + '</div>';
  }

  // Tabla de clientes. Activo -> botón Suspender; cualquier otro estado (pendiente/suspendido) -> Activar.
  function renderClientes() {
    var b = $('clientesBody');
    if (!db.clientes.length) { b.innerHTML = '<tr><td colspan="7" class="muted" style="text-align:center;padding:22px">Aún no hay clientes. Provisiona el primero.</td></tr>'; return; }
    b.innerHTML = db.clientes.map(function (c) {
      var tag = c.estado === 'activo' ? '<span class="tag ok">Activo</span>' : (c.estado === 'suspendido' ? '<span class="tag bad">Suspendido</span>' : '<span class="tag warn">Pendiente</span>');
      // Situación del plan (solo cuentas activas con pago en línea): la etiqueta cambia si venció, canceló o pidió cerrar,
      // y debajo va la fecha que importa. El texto de la fecha puede partirse en dos líneas (no ensancha la tabla).
      var dia = function (iso) { return iso ? new Date(iso).toLocaleDateString('es-CL') : ''; };
      var SIT = { 'al-dia': ['', '', 'Pagado hasta el '], 'por-vencer': ['', '', 'Vence el '], gracia: ['warn', 'Plan vencido', 'venció el '], vencida: ['bad', 'En pausa', 'venció el '], cancelada: ['warn', 'Canceló', 'acceso hasta el '], cerrada: ['bad', 'Cerrada', 'se elimina el '] };
      var s = c.estado === 'activo' && SIT[c.situacion];
      if (s) tag = (s[1] ? '<span class="tag ' + s[0] + '">' + s[1] + '</span>' : tag) + '<div class="muted small">' + s[2] + esc(dia(c.situacion === 'cerrada' ? c.eliminarEn : c.vigenteHasta)) + '</div>';
      // Una cuenta pendiente (nunca pagó) no se activa con un clic: se registra su pago, que le da el período.
      var accion = c.estado === 'activo'
        ? '<button class="btn btn-ghost" data-susp="' + c.id + '">Suspender</button>'
        : (c.estado === 'pendiente' ? '' : '<button class="btn btn-ghost" data-activar="' + c.id + '">Activar</button>');
      if (c.situacion !== 'cerrada') accion = '<button class="btn btn-ghost" data-pago="' + c.id + '">Registrar pago</button> ' + accion;
      accion = '<button class="btn btn-ghost" data-clave="' + c.id + '">Enviar enlace de acceso</button> ' + accion;
      return '<tr><td><b>' + esc(c.negocio) + '</b></td><td class="muted">' + esc(c.email) + '</td><td>' + esc(c.comuna || '—') + (c.region ? '<div class="muted small">' + esc(c.region) + '</div>' : '') + (c.direccion ? '<div class="muted small">' + esc(c.direccion) + '</div>' : '') + '</td><td>' + esc(c.plan) + (c.planSiguiente ? '<div class="muted small">pasa a ' + esc(c.planSiguiente) + ' al renovar</div>' : '') + '<div><button class="mini" data-plan="' + c.id + '" aria-label="Cambiar plan de ' + esc(c.negocio) + '">Cambiar</button></div></td><td>' + tag + '</td><td>' + privacidadCelda(c.email) + '</td><td style="text-align:right">' + accion + '</td></tr>';
    }).join('');
    b.querySelectorAll('[data-susp]').forEach(function (x) { x.addEventListener('click', function () { cambiarEstado(x.dataset.susp, 'suspendido'); }); });
    b.querySelectorAll('[data-activar]').forEach(function (x) { x.addEventListener('click', function () { cambiarEstado(x.dataset.activar, 'activo'); }); });
    b.querySelectorAll('[data-clave]').forEach(function (x) { x.addEventListener('click', function () { confirmarRestablecer(x.dataset.clave); }); });
    b.querySelectorAll('[data-plan]').forEach(function (x) { x.addEventListener('click', function () { cambiarPlan(x.dataset.plan); }); });
    b.querySelectorAll('[data-pago]').forEach(function (x) { x.addEventListener('click', function () { registrarPago(x.dataset.pago); }); });
  }

  // Pago hecho por fuera (transferencia, efectivo): suma meses pagados al plan del negocio (con las cuotas de cajas
  // adicionales que correspondan). También activa una cuenta que quedó pendiente de pago.
  function registrarPago(id) {
    var c = db.clientes.find(function (x) { return x.id === id; }) || {};
    $('modalTit').textContent = 'Registrar pago';
    abrirModal(
      '<p>Pago de <b>' + esc(c.negocio || '') + '</b> (plan ' + esc(c.plan || '') + ') recibido por fuera de Flow. Se suma al período que tenga pagado.</p>' +
      '<div class="f"><label for="rpMeses">Meses pagados</label><select id="rpMeses">' + [1, 2, 3, 6, 12].map(function (n) { return '<option value="' + n + '">' + n + (n === 1 ? ' mes' : ' meses') + '</option>'; }).join('') + '</select></div>' +
      '<div class="f"><label for="rpNota">Detalle (opcional)</label><input id="rpNota" maxlength="120" placeholder="Ej.: transferencia del 14-nov"></div>' +
      '<div class="btns" style="margin-top:14px;display:flex;gap:10px"><button class="btn btn-primary" id="rpOk">Registrar</button><button class="btn btn-ghost" id="rpCancel">Cancelar</button></div>' +
      '<div id="rpErr" role="alert" style="color:var(--danger);font-size:.85rem;margin-top:8px"></div>'
    );
    $('rpCancel').addEventListener('click', cerrarModal);
    $('rpOk').addEventListener('click', function () {
      $('rpOk').disabled = true;
      API.send('POST', '/api/admin/clientes/' + id + '/pago', { meses: Number($('rpMeses').value), nota: $('rpNota').value })
        .then(function () { cerrarModal(); return recargar(); })
        .catch(function (e) { $('rpOk').disabled = false; $('rpErr').textContent = e.message; });
    });
  }

  // Cambiar el plan de un negocio: rige de inmediato y sin cobro (cuentas que no pagan en línea, o un ajuste acordado).
  // Un dueño que paga en línea cambia su plan él mismo desde Mi cuenta → Mi plan.
  function cambiarPlan(id) {
    var c = db.clientes.find(function (x) { return x.id === id; }) || {};
    $('modalTit').textContent = 'Cambiar plan';
    abrirModal(
      '<p>Plan de <b>' + esc(c.negocio || '') + '</b>. El cambio rige de inmediato y no genera ningún cobro.</p>' +
      '<div class="f"><label for="cpPlan">Plan</label><select id="cpPlan">' +
      ['Esencial', 'Profesional', 'Empresa'].map(function (p) { return '<option' + (p === c.plan ? ' selected' : '') + '>' + p + '</option>'; }).join('') + '</select></div>' +
      (c.planSiguiente ? '<p class="muted" style="font-size:.86rem">El dueño tenía programado pasar a ' + esc(c.planSiguiente) + ' al renovar: ese cambio quedará sin efecto.</p>' : '') +
      '<div class="btns" style="margin-top:14px;display:flex;gap:10px"><button class="btn btn-primary" id="cpOk">Guardar</button><button class="btn btn-ghost" id="cpCancel">Cancelar</button></div>' +
      '<div id="cpErr" role="alert" style="color:var(--danger);font-size:.85rem;margin-top:8px"></div>'
    );
    $('cpCancel').addEventListener('click', cerrarModal);
    $('cpOk').addEventListener('click', function () {
      $('cpOk').disabled = true;
      API.send('POST', '/api/admin/clientes/' + id + '/plan', { plan: $('cpPlan').value })
        .then(function () { cerrarModal(); return recargar(); })
        .catch(function (e) { $('cpOk').disabled = false; $('cpErr').textContent = e.message; });
    });
  }

  // Al dueño que no puede entrar se le manda un enlace para crear una contraseña nueva (nadie ve una clave temporal).
  // Su clave actual sigue sirviendo hasta que use el enlace.
  function confirmarRestablecer(id) {
    var c = db.clientes.find(function (x) { return x.id === id; }) || {};
    $('modalTit').textContent = 'Enviar enlace de acceso';
    abrirModal(
      '<p>Se enviará al dueño de <b>' + esc(c.negocio || '') + '</b>' + (c.email ? ' (' + esc(c.email) + ')' : '') + ' un correo con un enlace para crear una contraseña nueva. Vale 72 horas y sirve una vez.</p>' +
      '<p class="muted" style="font-size:.86rem">Úsalo solo si el dueño lo pidió y verificaste su identidad. Él mismo también puede usar "¿Olvidaste tu contraseña?" al iniciar sesión.</p>' +
      '<div class="btns" style="margin-top:14px;display:flex;gap:10px"><button class="btn btn-primary" id="rOk">Enviar enlace</button><button class="btn btn-ghost" id="rCancel">Cancelar</button></div>' +
      '<div id="rErr" role="alert" style="color:var(--danger);font-size:.85rem;margin-top:8px"></div>'
    );
    $('rCancel').addEventListener('click', cerrarModal);
    $('rOk').addEventListener('click', function () {
      $('rOk').disabled = true;
      API.send('POST', '/api/admin/clientes/' + id + '/restablecer-clave', {}).then(function (res) {
        avisoEnvio('Enlace de acceso', res.envio, res.email);
      }).catch(function (e) { $('rOk').disabled = false; $('rErr').textContent = e.message; });
    });
  }

  // Solicitudes de la landing. El globito del menú (nLeads) cuenta solo las 'Nueva'.
  // "Avanzar" mueve la solicitud al siguiente estado; cuando queda Activa o Descartada ya no hay botón.
  function renderLeads() {
    var b = $('leadsBody');
    var n = $('nLeads');
    var nuevas = db.leads.filter(function (l) { return l.estado === 'Nueva'; }).length;
    if (nuevas > 0) { n.hidden = false; n.textContent = nuevas; } else { n.hidden = true; }
    if (!db.leads.length) { b.innerHTML = '<tr><td colspan="6" class="muted" style="text-align:center;padding:22px">No hay solicitudes todavía.</td></tr>'; return; }
    b.innerHTML = db.leads.map(function (l) {
      var pago = l.pagoEstado === 'Pagado' ? '<span class="tag ok">Pagado</span>' : '<span class="tag warn">' + esc(l.pagoEstado || 'Pendiente') + '</span>';
      var est = l.estado === 'Descartada' ? '<span class="tag bad">Descartada</span>' : (l.estado === 'Activa' ? '<span class="tag ok">Activa</span>' : '<span class="tag mut">' + esc(l.estado) + '</span>');
      var acc = (l.estado === 'Activa' || l.estado === 'Descartada') ? '' : '<button class="btn btn-ghost" data-avanzar="' + l.id + '">Avanzar</button>';
      return '<tr><td><b>' + esc(l.negocio) + '</b></td><td class="muted">' + esc(l.contacto || '') + '<br><span style="font-size:.8rem">' + esc(l.email || '') + '</span></td><td>' + esc(l.plan || '—') + '</td><td>' + pago + '</td><td>' + est + '</td><td style="text-align:right">' + acc + '</td></tr>';
    }).join('');
    b.querySelectorAll('[data-avanzar]').forEach(function (x) { x.addEventListener('click', function () { avanzarLead(x.dataset.avanzar); }); });
  }

  // Copia de la de panel.js ("hace 5 min"). Si cambias una, cambia la otra.
  function fechaRel(iso) { if (!iso) return 'nunca'; var s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000); if (s < 0) s = 0; if (s < 60) return 'hace ' + s + 's'; if (s < 3600) return 'hace ' + Math.floor(s / 60) + ' min'; if (s < 86400) return 'hace ' + Math.floor(s / 3600) + ' h'; return new Date(iso).toLocaleDateString('es-CL'); }

  function nombreCliente(id) { var c = db.clientes.find(function (x) { return x.id === id; }); return c ? c.negocio : '—'; }

  // Todas las cajas de todos los clientes, con su dueño cruzado contra db.clientes.
  function renderFlota() {
    var b = $('flotaBody');
    if (!db.cajas.length) { b.innerHTML = '<tr><td colspan="6" class="muted" style="text-align:center;padding:22px">Ninguna caja registrada aún.</td></tr>'; return; }
    b.innerHTML = db.cajas.map(function (c) {
      var tag = c.estado === 'bloqueada' ? '<span class="tag bad"><span class="punto" aria-hidden="true"></span>Bloqueada</span>' : (c.enLinea ? '<span class="tag ok"><span class="punto" aria-hidden="true"></span>En línea</span>' : '<span class="tag warn"><span class="punto" aria-hidden="true"></span>Sin conexión</span>');
      return '<tr><td><b>' + esc(c.nombre) + '</b><br><span class="muted" style="font-size:.8rem">' + esc(c.id) + '</span></td><td>' + esc(nombreCliente(c.clienteId)) + '</td><td>' + tag + '</td><td>' + fechaRel(c.ultimaSync) + '</td><td style="text-align:right">' + c.ventas + '</td><td style="text-align:right">' + clp(c.monto) + '</td></tr>';
    }).join('');
  }

  // ---------- equipo Walkan (solo super admin) ----------
  function renderEquipo() {
    var b = $('equipoBody');
    if (!b) return;
    if (!db.equipo.length) { b.innerHTML = '<tr><td colspan="6" class="muted" style="text-align:center;padding:22px">Sin cuentas del equipo.</td></tr>'; return; }
    b.innerHTML = db.equipo.map(function (u) {
      var soyYo = u.id === yo.id;
      var nivel = u.superAdmin ? '<span class="tag ok">Super admin</span>' : '<span class="tag mut">Staff</span>';
      var est = !u.activo ? null : (u.invitacionPendiente ? '<span class="tag warn">Invitación enviada</span><div class="muted small">aún no crea su contraseña</div>' : '<span class="tag ok">Activa</span>');
      if (!est) est = '<span class="tag bad">Desactivada</span><div class="muted small">desde el ' + esc(new Date(u.desactivadoEn).toLocaleDateString('es-CL')) + '</div>';
      var dp = u.dosPasos ? '<span class="tag ok">Activa</span>' : '<span class="tag warn">Pendiente</span>';
      var acc = '';
      if (soyYo) acc = '<span class="muted small">Tu cuenta</span>';
      else if (!u.activo) acc = '<button class="btn btn-ghost" data-ereact="' + u.id + '">Reactivar</button>';
      else acc = (u.invitacionPendiente ? '<button class="btn btn-ghost" data-ereenv="' + u.id + '">Reenviar invitación</button> ' : '') + '<button class="btn btn-ghost" data-enivel="' + u.id + '">' + (u.superAdmin ? 'Quitar super admin' : 'Nombrar super admin') + '</button> ' +
        (u.invitacionPendiente ? '' : '<button class="btn btn-ghost" data-erest="' + u.id + '">Restablecer acceso</button> ') +
        '<button class="btn btn-ghost" data-edesac="' + u.id + '">Desactivar</button>';
      return '<tr><td><b>' + esc(u.nombre) + '</b><div class="muted small">' + esc(u.email) + '</div></td><td>' + nivel + '</td><td>' + est + '</td><td>' + dp + '</td><td>' + fechaRel(u.ultimoUso) + '</td><td style="text-align:right">' + acc + '</td></tr>';
    }).join('');
    b.querySelectorAll('[data-ereact]').forEach(function (x) { x.addEventListener('click', function () { accionEquipo(x.dataset.ereact, 'reactivar', 'Reactivar cuenta', 'Podrá volver a entrar con su contraseña actual.', 'Reactivar'); }); });
    b.querySelectorAll('[data-edesac]').forEach(function (x) { x.addEventListener('click', function () { accionEquipo(x.dataset.edesac, 'desactivar', 'Desactivar cuenta', 'Sale de inmediato de todos sus dispositivos y no podrá volver a entrar. Lo que hizo queda en la bitácora.', 'Desactivar'); }); });
    b.querySelectorAll('[data-enivel]').forEach(function (x) {
      var u = porIdEquipo(x.dataset.enivel);
      x.addEventListener('click', function () {
        accionEquipo(u.id, 'nivel', u.superAdmin ? 'Quitar super admin' : 'Nombrar super admin',
          u.superAdmin ? 'Seguirá en el equipo como staff, pero ya no podrá administrar cuentas ni ver la bitácora.' : 'Podrá crear y desactivar cuentas del equipo y ver la bitácora.',
          u.superAdmin ? 'Quitar' : 'Nombrar', { superAdmin: !u.superAdmin });
      });
    });
    b.querySelectorAll('[data-ereenv]').forEach(function (x) {
      x.addEventListener('click', function () {
        x.disabled = true;
        API.send('POST', '/api/admin/equipo/' + x.dataset.ereenv + '/reenviar', {})
          .then(function (res) { avisoEnvio('Invitación', res.envio, res.email); return recargar(); })
          .catch(function (e) { x.disabled = false; aviso('No se pudo reenviar: ' + e.message); });
      });
    });
    b.querySelectorAll('[data-erest]').forEach(function (x) { x.addEventListener('click', function () { restablecerStaff(x.dataset.erest); }); });
  }
  function porIdEquipo(id) { return db.equipo.find(function (u) { return u.id === id; }) || {}; }

  // Confirmación en el modal (no con confirm()) y después POST /api/admin/equipo/:id/<accion>.
  function accionEquipo(id, accion, titulo, texto, boton, cuerpo) {
    var u = porIdEquipo(id);
    $('modalTit').textContent = titulo;
    abrirModal(
      '<p><b>' + esc(u.nombre || '') + '</b> (' + esc(u.email || '') + ')</p><p class="muted" style="font-size:.86rem">' + esc(texto) + '</p>' +
      '<div class="btns" style="margin-top:14px;display:flex;gap:10px"><button class="btn btn-primary" id="eOk">' + esc(boton) + '</button><button class="btn btn-ghost" id="eCancel">Cancelar</button></div>' +
      '<div id="eErr" role="alert" style="color:var(--danger);font-size:.85rem;margin-top:8px"></div>'
    );
    $('eCancel').addEventListener('click', cerrarModal);
    $('eOk').addEventListener('click', function () {
      $('eOk').disabled = true;
      API.send('POST', '/api/admin/equipo/' + id + '/' + accion, cuerpo || {})
        .then(function () { cerrarModal(); return recargar(); })
        .catch(function (e) { $('eOk').disabled = false; $('eErr').textContent = e.message; });
    });
  }

  function restablecerStaff(id) {
    var u = porIdEquipo(id);
    $('modalTit').textContent = 'Restablecer acceso';
    abrirModal(
      '<p>Para <b>' + esc(u.nombre || '') + '</b> (' + esc(u.email || '') + '), si perdió la contraseña o el celular.</p>' +
      '<p class="muted" style="font-size:.86rem">Su contraseña actual deja de servir, se borra su verificación en dos pasos y se cierran sus sesiones. Le llega por correo un enlace para crear una contraseña nueva y, al entrar, vuelve a activar los dos pasos. Hazlo solo si confirmaste que es la persona.</p>' +
      '<div class="btns" style="margin-top:14px;display:flex;gap:10px"><button class="btn btn-primary" id="eOk">Restablecer</button><button class="btn btn-ghost" id="eCancel">Cancelar</button></div>' +
      '<div id="eErr" role="alert" style="color:var(--danger);font-size:.85rem;margin-top:8px"></div>'
    );
    $('eCancel').addEventListener('click', cerrarModal);
    $('eOk').addEventListener('click', function () {
      $('eOk').disabled = true;
      API.send('POST', '/api/admin/equipo/' + id + '/restablecer', {}).then(function (res) {
        avisoEnvio('Acceso restablecido', res.envio, res.email);
        recargar();
      }).catch(function (e) { $('eOk').disabled = false; $('eErr').textContent = e.message; });
    });
  }

  var btnNuevoStaff = $('btnNuevoStaff');
  if (btnNuevoStaff) btnNuevoStaff.addEventListener('click', function () {
    $('modalTit').textContent = 'Agregar persona al equipo';
    abrirModal(
      '<div class="f"><div class="form-grid">' +
      '<div><label for="sNombre">Nombre *</label><input id="sNombre" maxlength="80" autocomplete="off" placeholder="Nombre y apellido"></div>' +
      '<div><label for="sEmail">Correo de la empresa *</label><input id="sEmail" type="email" maxlength="120" autocomplete="off" placeholder="nombre@walkan.cl"></div>' +
      '</div></div>' +
      '<label style="display:flex;gap:8px;align-items:center;margin-top:12px;font-size:.9rem"><input type="checkbox" id="sSuper"> Super admin (administra el equipo y ve la bitácora)</label>' +
      '<div class="btns" style="margin-top:14px;display:flex;gap:10px"><button class="btn btn-primary" id="sOk">Crear cuenta</button><button class="btn btn-ghost" id="sCancel">Cancelar</button></div>' +
      '<div id="sErr" role="alert" style="color:var(--danger);font-size:.85rem;margin-top:8px"></div>'
    );
    $('sCancel').addEventListener('click', cerrarModal);
    $('sOk').addEventListener('click', function () {
      var body = { nombre: $('sNombre').value.trim(), email: $('sEmail').value.trim().toLowerCase(), superAdmin: $('sSuper').checked };
      if (!body.nombre || !body.email) { $('sErr').textContent = 'Nombre y correo son obligatorios.'; return; }
      if (!/@walkan\.cl$/.test(body.email)) { $('sErr').textContent = 'Usa el correo de la empresa (@walkan.cl).'; return; }
      $('sOk').disabled = true;
      API.send('POST', '/api/admin/equipo', body).then(function (res) {
        avisoEnvio('Cuenta creada', res.envio, res.email);
        recargar();
      }).catch(function (e) { $('sOk').disabled = false; $('sErr').textContent = e.message; });
    });
  });

  function renderBitacora() {
    var b = $('bitacoraBody');
    if (!b) return;
    if (!db.bitacora.length) { b.innerHTML = '<tr><td colspan="4" class="muted" style="text-align:center;padding:22px">Aún no hay acciones registradas.</td></tr>'; return; }
    b.innerHTML = db.bitacora.map(function (r) {
      return '<tr><td style="white-space:nowrap">' + esc(new Date(r.fecha).toLocaleString('es-CL')) + '</td><td>' + esc(r.actor) + '</td><td>' + esc(r.accion) + '</td><td class="muted">' + esc(r.detalle) + '</td></tr>';
    }).join('');
  }

  // ---------- soporte (todo el equipo) ----------
  // Pendientes = no resueltas, primero las que esperan respuesta del equipo. La conversación se abre en el modal.
  var sopFiltro = '', sopTickets = [];
  var sopAbierto = null; // { id, firma } del ticket abierto en el modal: se refresca solo (ver refrescarSop)
  var firmaSop = function (t) { return t.mensajes.length + '|' + t.estado + '|' + (t.asignado || ''); };
  var fechaHora = function (iso) { return new Date(iso).toLocaleString('es-CL', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); };
  var SOP_TAG = { abierto: 'warn', en_curso: 'mut', resuelto: 'ok' };
  function cargarSoporte() {
    var q = sopFiltro && sopFiltro !== 'todos' ? '?estado=' + sopFiltro : '';
    return API.get('/api/admin/soporte' + q).then(function (r) {
      r = r || { tickets: [], pendientes: 0 };
      sopTickets = sopFiltro ? r.tickets : r.tickets.filter(function (t) { return t.estado !== 'resuelto'; });
      var n = $('nSoporte'); n.hidden = !r.pendientes; n.textContent = r.pendientes;
      renderSoporte();
    });
  }
  function renderSoporte() {
    var b = $('soporteBody');
    if (!sopTickets.length) { b.innerHTML = '<tr><td colspan="7" class="muted" style="text-align:center;padding:22px">No hay solicitudes ' + (sopFiltro ? 'en este estado.' : 'pendientes.') + '</td></tr>'; return; }
    b.innerHTML = sopTickets.map(function (t) {
      var espera = t.estado !== 'resuelto' && t.esperaRespuesta ? ' <span class="tag bad">Espera respuesta</span>' : '';
      return '<tr><td class="muted">' + esc(t.numero) + '</td><td><b>' + esc(t.asunto) + '</b><div class="muted small">' + esc(t.categoriaNombre) + (t.origen === 'publico' ? ' · sin sesión' : '') + '</div></td>' +
        '<td>' + esc(t.negocio || t.nombre) + '<div class="muted small">' + esc(t.email) + '</div></td>' +
        '<td><span class="tag ' + (SOP_TAG[t.estado] || 'mut') + '">' + esc(t.estadoNombre) + '</span>' + espera + '</td>' +
        '<td class="muted">' + esc(t.asignado || '—') + '</td><td class="muted">' + esc(fechaHora(t.actualizado)) + '</td>' +
        '<td style="text-align:right"><button class="btn btn-ghost" data-sopver="' + esc(t.id) + '">Abrir</button></td></tr>';
    }).join('');
    b.querySelectorAll('[data-sopver]').forEach(function (x) { x.addEventListener('click', function () { verTicketSop(x.dataset.sopver); }); });
  }
  document.querySelectorAll('[data-sop]').forEach(function (x) {
    x.addEventListener('click', function () {
      sopFiltro = x.dataset.sop;
      document.querySelectorAll('[data-sop]').forEach(function (y) { y.setAttribute('aria-pressed', y === x ? 'true' : 'false'); });
      cargarSoporte();
    });
  });
  // Verificación de identidad (lo que escribió quien no puede entrar, contra los datos de la cuenta con ese correo).
  function verifHtml(t) {
    var v = t.verificacion || {};
    var si = function (b) { return b === null || b === undefined ? '<span class="muted">no lo escribió</span>' : (b ? '<span class="tag ok">Coincide</span>' : '<span class="tag bad">No coincide</span>'); };
    if (!v.cuenta) return '<div class="verif"><span class="muted">Cuenta</span><b>No hay una cuenta con ese correo</b></div>';
    if (v.equipo) return '<div class="verif"><span class="muted">Cuenta</span><b>Es una cuenta del equipo Walkan</b></div>';
    return '<div class="verif"><span class="muted">Cuenta</span><b>Dueño de ' + esc(v.negocio || '—') + (v.desactivada ? ' (desactivada)' : '') + '</b>' +
      (t.origen === 'publico' ? '<span class="muted">RUT escrito</span><span>' + esc(t.rut || '—') + ' ' + (v.rutRegistrado ? si(v.rutCoincide) : '<span class="muted">(el negocio no tiene RUT registrado)</span>') + '</span>' +
        '<span class="muted">Orden de pago</span><span>' + esc(t.ordenPago || '—') + ' ' + si(v.ordenCoincide) + '</span>' : '') +
      '<span class="muted">Dos pasos</span><span>' + (v.dosPasos ? 'Activa' : 'No activa') + '</span></div>';
  }
  function hiloSop(t) {
    return '<div class="hilo">' + t.mensajes.map(function (m) {
      var quien = m.autor === 'equipo' ? 'Equipo Walkan' : (m.autor === 'sistema' ? 'Walkan' : m.nombre);
      return '<div class="hilo-msg hilo-' + esc(m.autor) + '"><div class="hilo-cab"><b>' + esc(quien) + '</b> <span class="muted">' + esc(fechaHora(m.fecha)) + '</span></div><div class="hilo-txt">' + esc(m.texto).replace(/\n/g, '<br>') + '</div></div>';
    }).join('') + '</div>';
  }
  function bajarHiloSop() { var h = document.querySelector('#sopHilo .hilo'); if (h) h.scrollTop = h.scrollHeight; }
  // Sin recargar: cada 15 s (con la pestaña a la vista) se trae la bandeja y el globito; si hay un ticket abierto y el
  // cliente escribió o cambió algo, se redibuja el modal conservando lo que estés escribiendo en "Responder".
  function refrescarSop() {
    if (document.hidden) return;
    cargarSoporte();
    if (!sopAbierto || !$('modal').classList.contains('open') || !$('sopHilo')) { sopAbierto = null; return; }
    var id = sopAbierto.id;
    API.get('/api/admin/soporte/' + encodeURIComponent(id)).then(function (t) {
      if (!t || !sopAbierto || sopAbierto.id !== id || !$('sopHilo') || firmaSop(t) === sopAbierto.firma) return;
      var borrador = $('sopResp') ? $('sopResp').value : '';
      verTicketSop(id, borrador);
    });
  }
  setInterval(refrescarSop, 15000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) refrescarSop(); });
  function verTicketSop(id, borrador) {
    API.get('/api/admin/soporte/' + encodeURIComponent(id)).then(function (t) {
      if (!t) { aviso('No se pudo abrir la solicitud.'); return; }
      $('modalTit').textContent = t.numero + ' · ' + t.asunto;
      var hilo = '<div id="sopHilo">' + hiloSop(t) + '</div>';
      var v = t.verificacion || {};
      abrirModal(
        '<p class="muted small" style="margin:0 0 8px">' + esc(t.nombre) + ' · ' + esc(t.email) + ' · ' + esc(t.categoriaNombre) + ' · ' + (t.origen === 'publico' ? 'sin sesión' : 'desde su panel') + ' · <span class="tag ' + (SOP_TAG[t.estado] || 'mut') + '">' + esc(t.estadoNombre) + '</span>' + (t.asignado ? ' · atiende ' + esc(t.asignado) : '') + '</p>' +
        verifHtml(t) + hilo +
        '<div class="f" style="margin-top:12px"><label for="sopResp">Responder (le llega por correo' + (t.origen === 'panel' || v.negocio ? ' y lo ve en su panel' : '') + ')</label><textarea id="sopResp" class="ta" rows="4" maxlength="4000"></textarea></div>' +
        '<div class="btns" style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">' +
        '<button class="btn btn-primary" id="sopEnviar">Responder</button><button class="btn btn-ghost" id="sopResolver">Responder y resolver</button>' +
        (t.estado === 'resuelto' ? '<button class="btn btn-ghost" id="sopReabrir">Reabrir</button>' : '<button class="btn btn-ghost" id="sopCerrar">Resolver sin responder</button>') +
        (t.asignado ? '' : '<button class="btn btn-ghost" id="sopAsignar">Asignármela</button>') +
        (v.dosPasos ? '<button class="btn btn-ghost" id="sopQuitar2fa">Quitar dos pasos…</button>' : '') + '</div>' +
        '<div id="sopErr" role="alert" style="color:var(--danger);font-size:.85rem;margin-top:8px"></div>'
      );
      sopAbierto = { id: id, firma: firmaSop(t) }; bajarHiloSop();
      if (borrador) $('sopResp').value = borrador;
      var err = function (e) { $('sopErr').textContent = e.message; document.querySelectorAll('#modalBody button').forEach(function (b) { b.disabled = false; }); };
      var listo = function () { cargarSoporte(); verTicketSop(id); };
      var responder = function (estado) {
        var txt = $('sopResp').value.trim();
        if (txt.length < 2) { $('sopErr').textContent = 'Escribe la respuesta.'; $('sopResp').focus(); return; }
        this.disabled = true;
        API.send('POST', '/api/admin/soporte/' + id + '/responder', estado ? { texto: txt, estado: estado } : { texto: txt })
          .then(function (r) { if (r.envio && r.envio !== 'enviado') aviso('La respuesta quedó en el ticket, pero el correo no se envió (' + r.envio + ').'); listo(); }).catch(err);
      };
      $('sopEnviar').addEventListener('click', function () { responder.call(this); });
      $('sopResolver').addEventListener('click', function () { responder.call(this, 'resuelto'); });
      var estado = function (e) { return function () { this.disabled = true; API.send('POST', '/api/admin/soporte/' + id + '/estado', { estado: e }).then(listo).catch(err); }; };
      if ($('sopCerrar')) $('sopCerrar').addEventListener('click', estado('resuelto'));
      if ($('sopReabrir')) $('sopReabrir').addEventListener('click', estado('abierto'));
      if ($('sopAsignar')) $('sopAsignar').addEventListener('click', function () { this.disabled = true; API.send('POST', '/api/admin/soporte/' + id + '/asignarme', {}).then(listo).catch(err); });
      if ($('sopQuitar2fa')) $('sopQuitar2fa').addEventListener('click', function () {
        $('sopErr').innerHTML = '';
        var c = document.createElement('div');
        c.className = 'verif'; c.style.marginTop = '10px';
        c.innerHTML = '<span></span><span><b>¿Quitar la verificación en dos pasos de ' + esc(v.negocio || t.email) + '?</b><br>Hazlo solo si verificaste que es el dueño (RUT y orden de pago coinciden, o lo confirmaste por otro medio). Se cierran sus sesiones y le avisamos al correo de la cuenta. Queda en la bitácora.' +
          '<br><button class="btn btn-danger" id="sopQuitarSi" style="margin-top:8px">Sí, quitar dos pasos</button> <button class="btn btn-ghost" id="sopQuitarNo" style="margin-top:8px">Cancelar</button></span>';
        $('sopErr').appendChild(c);
        $('sopQuitarNo').addEventListener('click', function () { $('sopErr').innerHTML = ''; });
        $('sopQuitarSi').addEventListener('click', function () { this.disabled = true; API.send('POST', '/api/admin/soporte/' + id + '/quitar-dos-pasos', {}).then(function () { aviso('Listo: se quitó la verificación en dos pasos y se avisó al dueño.'); listo(); }).catch(err); });
      });
    });
  }

  // ---------- acciones ----------
  // Después de cada acción se recarga todo (son pocos datos, no vale la pena actualizar a mano).
  function cambiarEstado(id, estado) {
    API.send('POST', '/api/admin/clientes/' + id + '/estado', { estado: estado })
      .then(recargar).catch(function (e) { aviso('No se pudo cambiar el estado: ' + e.message); });
  }
  function avanzarLead(id) {
    API.send('POST', '/api/admin/solicitudes/' + id + '/avanzar', {})
      .then(recargar).catch(function (e) { aviso('No se pudo avanzar la solicitud: ' + e.message); });
  }

  // ---------- modal provisionar ----------
  // "Provisionar" = crear un cliente a mano (sin pasar por la landing ni por Flow), con su usuario dueño.
  function abrirModal(html) { $('modalBody').innerHTML = html; $('modal').classList.add('open'); }
  function cerrarModal() { $('modal').classList.remove('open'); }
  $('modalX').addEventListener('click', cerrarModal);
  $('modal').addEventListener('click', function (e) { if (e.target === $('modal')) cerrarModal(); });

  $('btnNuevoCliente').addEventListener('click', function () {
    $('modalTit').textContent = 'Provisionar cliente';
    abrirModal(
      '<div class="f">' +
      '<div class="form-grid">' +
      '<div><label>Negocio *</label><input id="pNegocio" placeholder="Almacén Doña Rosa"></div>' +
      '<div><label>Nombre del dueño</label><input id="pNombre" placeholder="Rosa Pérez"></div>' +
      '<div><label>Correo (login del dueño) *</label><input id="pEmail" type="email" placeholder="rosa@negocio.cl"></div>' +
      '<div><label>Teléfono</label><input id="pTel" placeholder="+56 9 ..."></div>' +
      '<div><label>RUT</label><input id="pRut" placeholder="12.345.678-9"></div>' +
      '<div><label>Plan</label><select id="pPlan"><option>Esencial</option><option selected>Profesional</option><option>Empresa</option></select></div>' +
      '<div><label>Región</label><select id="pRegion"><option value="">Elige la región…</option></select></div>' +
      '<div><label>Comuna</label><select id="pComuna" disabled><option value="">Primero elige la región</option></select></div>' +
      '<div style="grid-column:1/-1"><label>Calle y número</label><input id="pDireccion" maxlength="120" placeholder="Av. Matta 1234, local 2"></div>' +
      '</div>' +
      '<p class="muted" style="font-size:.86rem;margin:12px 0 0">Al dueño le llega un correo con el enlace para crear su contraseña.</p>' +
      '<div class="btns" style="margin-top:14px;display:flex;gap:10px"><button class="btn btn-primary" id="pOk">Crear cliente</button><button class="btn btn-ghost" id="pCancel">Cancelar</button></div>' +
      '<div id="pErr" style="color:var(--danger);font-size:.85rem;margin-top:8px"></div>' +
      '</div>'
    );
    if (window.WalkanTerritorio) WalkanTerritorio.montar($('pRegion'), $('pComuna'));
    $('pCancel').addEventListener('click', cerrarModal);
    $('pOk').addEventListener('click', provisionar);
  });

  // POST /api/admin/clientes. Al dueño le llega por correo el enlace para crear su contraseña (res.owner.envio).
  function provisionar() {
    var body = {
      negocio: $('pNegocio').value.trim(),
      email: $('pEmail').value.trim(),
      nombre: $('pNombre').value.trim(),
      comunaCut: $('pComuna').value || undefined,
      direccion: $('pDireccion').value.trim() || undefined,
      rut: $('pRut').value.trim(),
      telefono: $('pTel').value.trim(),
      plan: $('pPlan').value
    };
    if (!body.negocio || !body.email) { $('pErr').textContent = 'Negocio y correo son obligatorios.'; return; }
    if (body.direccion && !body.comunaCut) { $('pErr').textContent = 'Elige la región y la comuna del local.'; return; }
    API.send('POST', '/api/admin/clientes', body).then(function (res) {
      avisoEnvio('Cliente creado: ' + res.cliente.negocio, res.owner.envio, res.owner.email);
      recargar();
    }).catch(function (e) { $('pErr').textContent = e.message; });
  }

  // ---------- carga ----------
  function recargar() {
    var nada = Promise.resolve(null);
    return Promise.all([
      API.get('/api/admin/resumen'), API.get('/api/admin/clientes'),
      API.get('/api/admin/solicitudes'), API.get('/api/admin/cajas'), API.get('/api/admin/consentimientos/resumen'),
      yo.superAdmin ? API.get('/api/admin/equipo') : nada, yo.superAdmin ? API.get('/api/admin/bitacora') : nada
    ]).then(function (r) {
      db.equipo = r[5] || []; db.bitacora = r[6] || [];
      db.resumen = r[0] || {}; db.clientes = r[1] || []; db.leads = r[2] || []; db.cajas = r[3] || [];
      // Último consentimiento de privacidad de cada cuenta (el servidor ya trae uno por cuenta).
      db.privacidad = {};
      (r[4] || []).forEach(function (c) { db.privacidad[c.email] = c; });
      renderResumen(); renderClientes(); renderLeads(); renderFlota(); renderEquipo(); renderBitacora();
      cargarSoporte();
    });
  }

  $('logout').addEventListener('click', function (e) { e.preventDefault(); fetch('/api/auth/logout', { method: 'POST' }).then(function () { window.location.href = '/mi-cuenta'; }); });

  // arranque: exige sesión staff
  // Sin sesión -> login; con sesión pero sin rol staff -> lo mandamos a su panel normal.
  // Ojo que esto es solo la redirección del front: la protección de verdad está en la API.
  // Solo un 401 manda al login; otro error (429, 5xx) no cierra la sesión: se avisa y se puede recargar.
  fetch('/api/auth/me').then(function (r) {
    if (r.status === 401) { window.location.href = '/mi-cuenta'; return null; }
    if (!r.ok) { var h = document.querySelector('main h1') || document.body; h.insertAdjacentHTML('afterend', '<p role="alert" style="color:var(--danger)">Walkan no respondió bien (error ' + r.status + '). Recarga la página en unos segundos.</p>'); return null; }
    return r.json();
  })
    .then(function (m) {
      if (!m) return;
      if (!m.usuario || m.usuario.rol !== 'staff') { window.location.href = '/panel'; return; }
      $('stNombre').textContent = m.usuario.nombre || 'Equipo Walkan';
      $('stEmail').textContent = m.usuario.email || '';
      yo = m.usuario;
      if (yo.superAdmin) document.querySelectorAll('.side nav a[data-super]').forEach(function (a) { a.hidden = false; });
      return recargar();
    })
    .catch(function (e) { console.error('No se pudo cargar administración', e); });
})();
