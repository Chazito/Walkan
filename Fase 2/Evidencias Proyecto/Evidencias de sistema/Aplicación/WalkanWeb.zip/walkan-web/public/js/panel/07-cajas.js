// Parte de panel.js: el servidor junta public/js/panel/*.js en orden (ver views.controller.ts) dentro de un solo
// (function(){ … })(), así que todo comparte el mismo scope. No es un módulo suelto: no cargarlo solo.
  // ================= CAJAS =================
  // Las cajas (TV Box) se registran solas desde el equipo; acá solo se ven y se bloquean/desbloquean.
  // fechaRel() deja la última sync en formato "hace 5 min".
  function fechaRel(iso){ if(!iso) return 'nunca'; var d=new Date(iso); var s=Math.floor((Date.now()-d.getTime())/1000); if(s<0)s=0; if(s<60) return 'hace '+s+'s'; if(s<3600) return 'hace '+Math.floor(s/60)+' min'; if(s<86400) return 'hace '+Math.floor(s/3600)+' h'; return fmtFecha(iso); }
  function actualizarTopbar(){ var c=db.cajas||[]; var on=c.filter(function(x){return x.enLinea;}).length; var el=$('cajasEstado'); if(el) el.textContent = c.length ? (on+' de '+c.length+' caja'+(c.length>1?'s':'')+' en línea') : 'Sin cajas registradas'; }
  function recargarCajas(){ return API.get('/api/cajas').then(function(c){ db.cajas=c; renderCajas(); actualizarTopbar(); }); }
  // Sin cajas -> instrucciones de alta. Con cajas -> una tarjeta por caja, con el bloqueo por robo
  // escondido detrás de una confirmación (.confirm) para que no se apriete sin querer.
  function renderCajas(){
    var cont=$('cajas'); if(!cont) return;
    var cajas=db.cajas||[];
    if(!cajas.length){
      var correo = cuenta && cuenta.email ? cuenta.email : 'el correo de tu cuenta';
      cont.innerHTML='<div class="panel caja-alta">'+
        '<h3 style="margin:0 0 4px">Aún no tienes cajas registradas</h3>'+
        '<p class="muted small" style="margin:0 0 16px">Tu caja Walkan se da de alta sola. No hay que configurar nada acá: se registra desde el propio equipo.</p>'+
        '<ol class="alta-pasos">'+
          '<li><b>Enciende tu caja Walkan.</b> Al partir por primera vez muestra una pantalla de bienvenida.</li>'+
          '<li><b>Ingresa las credenciales de tu cuenta</b> (<code>'+esc(correo)+'</code> y tu contraseña) en esa pantalla.</li>'+
          '<li><b>Listo.</b> La caja queda vinculada a tu negocio y aparece aquí. Sus ventas empezarán a llegar solas por sincronización.</li>'+
        '</ol>'+
        '<p class="muted small" style="margin:14px 0 0">La caja guarda solo un código de vinculación, nunca tu contraseña. Si pierdes o te roban un equipo, lo bloqueas desde aquí mismo.</p>'+
      '</div>';
      return;
    }
    cont.innerHTML=cajas.map(function(c){
      var bloq=c.estado==='bloqueada';
      var tag = bloq?'<span class="tag bad"><span class="punto" aria-hidden="true"></span>Bloqueada</span>':(c.enLinea?'<span class="tag ok"><span class="punto" aria-hidden="true"></span>En línea</span>':'<span class="tag warn"><span class="punto" aria-hidden="true"></span>Sin conexión</span>');
      var acts = bloq ? '<button class="btn btn-ghost" data-desbloq>Desbloquear</button>'
        : '<button class="btn btn-ghost" data-detalle>Ver detalle</button><button class="btn btn-danger" data-block>Bloquear por robo</button>';
      return '<div class="caja'+(bloq?' locked':'')+'" data-cajaid="'+esc(c.id)+'">'+
        '<div class="head"><div><div class="name">'+esc(c.nombre)+'</div><span style="margin-top:6px;display:inline-block">'+tag+'</span></div></div>'+
        '<div class="rows"><div>Última sincronización: <b>'+fechaRel(c.ultimaSync)+'</b></div><div>Ventas registradas: <b>'+c.ventas+'</b> · <b>'+clp(c.monto)+'</b></div><div>Dispositivo: <b>TV Box · ID '+esc(c.id)+'</b></div></div>'+
        '<div class="acts">'+acts+'</div>'+
        '<div class="confirm" hidden><b>¿Bloquear '+esc(c.nombre)+'?</b><br>La caja quedará inutilizable en cuanto tenga señal y se protegerán sus datos. Úsalo solo si el equipo fue robado o perdido.<div class="btns"><button class="btn btn-danger" data-confirm>Sí, bloquear</button><button class="btn btn-ghost" data-cancel>Cancelar</button></div></div>'+
      '</div>';
    }).join('');
    cont.querySelectorAll('.caja').forEach(function(caja){
      var id=caja.dataset.cajaid; var conf=caja.querySelector('.confirm');
      var bb=caja.querySelector('[data-block]'); if(bb) bb.addEventListener('click', function(){ conf.hidden=false; });
      var cc=caja.querySelector('[data-cancel]'); if(cc) cc.addEventListener('click', function(){ conf.hidden=true; });
      var cf=caja.querySelector('[data-confirm]'); if(cf) cf.addEventListener('click', function(){ API.send('POST','/api/cajas/'+encodeURIComponent(id)+'/bloquear').then(recargarCajas).catch(function(e){ aviso('No se pudo bloquear: '+e.message); }); });
      var dd=caja.querySelector('[data-desbloq]'); if(dd) dd.addEventListener('click', function(){ API.send('POST','/api/cajas/'+encodeURIComponent(id)+'/desbloquear').then(recargarCajas).catch(function(e){ aviso('No se pudo desbloquear: '+e.message); }); });
      var vd=caja.querySelector('[data-detalle]'); if(vd) vd.addEventListener('click', function(){ detalleCaja(id); });
    });
  }
  function detalleCaja(id){
    var c=(db.cajas||[]).find(function(x){return x.id===id;}); if(!c) return;
    abrirModal(c.nombre,
      '<div class="mblock"><h4>Dispositivo</h4><div class="kv"><span class="muted">ID</span><b>'+esc(c.id)+'</b><span class="muted">Estado</span><b>'+esc(c.estado)+'</b><span class="muted">Última sincronización</span><b>'+fechaRel(c.ultimaSync)+'</b></div></div>'+
      '<div class="mblock"><h4>Actividad</h4><div class="kv"><span class="muted">Ventas registradas</span><b>'+c.ventas+'</b><span class="muted">Monto acumulado</span><b>'+clp(c.monto)+'</b></div></div>'+
      (c.ventas===0?'<p class="muted small" style="margin:0">Esta caja aún no ha sincronizado ventas.</p>':''));
  }
  // Gráfico de barras de ventas por hora hecho con divs, sin librería.
  function renderChart(ventas){
    var chart=$('chart'); if(!chart) return; chart.innerHTML='';
    // De 9 a 20 h, ampliado si hubo ventas antes o después (un almacén que abre a las 7 o cierra a las 23).
    var by={}, hMin=9, hMax=20;
    (ventas||[]).forEach(function(v){ var h=parseInt((v.hora||'').slice(0,2),10); if(!isNaN(h)){ by[h]=(by[h]||0)+(v.total||0); hMin=Math.min(hMin,h); hMax=Math.max(hMax,h); } });
    var horas=[]; for(var hh=hMin;hh<=hMax;hh++) horas.push(hh);
    var vals=horas.map(function(h){return by[h]||0;});
    var hay=vals.some(function(x){return x>0;}); var ce=$('chartEmpty');
    if(!hay){ chart.style.display='none'; if(ce) ce.hidden=false; return; }
    chart.style.display='flex'; if(ce) ce.hidden=true;
    var max=Math.max.apply(null,vals);
    vals.forEach(function(v,i){ var b=document.createElement('div'); b.className='bar'; b.style.height=(v/max*100)+'%'; b.innerHTML='<span>'+horas[i]+'</span>'; chart.appendChild(b); });
  }
  // Checklist de onboarding en el Resumen. Desaparece solo cuando están los 3 pasos listos.
  function renderBienvenida(){
    var box=$('bienvenida'); if(!box) return;
    var pasos=[
      {ok:db.productos.length>0, t:'Agrega tu primer producto', d:'Uno a uno, o todos de una vez con «Importar CSV» desde una planilla.', v:'inventario'},
      {ok:db.proveedores.length>0, t:'Registra un proveedor', d:'Para hacer pedidos y registrar compras.', v:'proveedores'},
      {ok:(db.cajas||[]).some(function(c){return c.ultimaSync;}), t:'Sincroniza tu caja', d:'Enciende tu caja Walkan; sus ventas llegarán solas.', v:'cajas'}
    ];
    var hechos=pasos.filter(function(p){return p.ok;}).length;
    if(hechos===pasos.length){ box.innerHTML=''; return; }
    var items=pasos.map(function(p){
      return '<div class="onb-step'+(p.ok?' done':'')+'"'+(p.ok?'':' tabindex="0" role="link" data-goto="'+p.v+'"')+'>'+
        '<span class="onb-check">'+(p.ok?ico('ok'):'')+'</span>'+
        '<div><b>'+p.t+'</b><div class="muted small">'+p.d+'</div></div>'+
        (p.ok?'<span class="tag ok" style="margin-left:auto">Listo</span>':'<span class="link" style="margin-left:auto">Ir →</span>')+
      '</div>';
    }).join('');
    box.innerHTML='<div class="panel welcome"><h3>Bienvenido a Walkan</h3><p class="muted small" style="margin:2px 0 12px">Completa estos pasos para dejar tu tienda lista ('+hechos+'/'+pasos.length+').</p>'+items+'</div>';
  }

  // ================= CAJEROS =================
  // El dueño crea, renombra, cambia el PIN y desactiva cajeros. Las cajas los reciben con el catálogo (cada ~1 min)
  // y validan el PIN sin internet. Desactivar (en vez de borrar) conserva el nombre en las ventas antiguas.
  var cajerosData={cajeros:[], cupo:null};
  function recargarCajeros(){
    return fetch('/api/cajeros').then(function(r){ return r.ok?r.json():null; })
      .then(function(d){ if(d&&Array.isArray(d.cajeros)){ cajerosData=d; renderCajeros(); } }).catch(function(){});
  }
  function renderCajeros(){
    var body=$('cajerosBody'); if(!body) return;
    var lista=cajerosData.cajeros||[], cupo=cajerosData.cupo;
    var info=$('cajerosCupo');
    if(info&&cupo) info.textContent='Plan '+cupo.plan+': '+cupo.activos+' de '+cupo.max+' cajero'+(cupo.max>1?'s':'')+' activo'+(cupo.max>1?'s':'')+'.';
    var lleno=cupo&&cupo.activos>=cupo.max; var nb=$('nuevoCajero'); if(nb) nb.disabled=!!lleno;
    if(!lista.length){
      body.innerHTML='<tr><td colspan="4" class="muted small" style="padding:14px 8px">Aún no creas cajeros aquí. Mientras tanto, cada caja usa los cajeros que se crearon en el propio equipo al instalarla. '+
        'Cuando crees el primero, tus cajas pasan a usar solo los cajeros de esta lista.</td></tr>';
      return;
    }
    body.innerHTML=lista.map(function(c){
      return '<tr data-cid="'+esc(c.id)+'"><td><b>'+esc(c.nombre)+'</b></td>'+
        '<td>'+(c.activo?'<span class="tag ok">Activo</span>':'<span class="tag warn">Desactivado</span>')+'</td>'+
        '<td class="muted small">'+fmtFecha(c.createdAt)+'</td>'+
        '<td style="text-align:right;white-space:nowrap">'+
          (c.activo?'<button class="btn btn-ghost" data-edit>Editar</button> <button class="btn btn-ghost" data-off>Desactivar</button>'
                   :'<button class="btn btn-ghost" data-on'+(lleno?' disabled title="Sin cupo en tu plan"':'')+'>Reactivar</button>')+
        '</td></tr>';
    }).join('');
    body.querySelectorAll('tr[data-cid]').forEach(function(tr){
      var c=lista.find(function(x){ return x.id===tr.dataset.cid; });
      var ed=tr.querySelector('[data-edit]'); if(ed) ed.addEventListener('click', function(){ formCajero(c); });
      var off=tr.querySelector('[data-off]'); if(off) off.addEventListener('click', function(){ cambiarCajero(c, {activo:false}, c.nombre+' ya no podrá abrir caja.'); });
      var on=tr.querySelector('[data-on]'); if(on) on.addEventListener('click', function(){ cambiarCajero(c, {activo:true}, c.nombre+' puede volver a abrir caja.'); });
    });
  }
  function cambiarCajero(c, datos, ok){
    API.send('PATCH','/api/cajeros/'+encodeURIComponent(c.id),datos)
      .then(function(){ aviso(ok+' Llega a tus cajas en menos de un minuto.'); return recargarCajeros(); })
      .catch(function(e){ aviso('No se pudo actualizar: '+e.message); });
  }
  // Alta y edición. En edición el PIN es opcional: vacío = se mantiene el actual.
  function formCajero(c){
    var nuevo=!c; c=c||{};
    abrirModal(nuevo?'Nuevo cajero':'Editar '+c.nombre,
      '<div class="form-grid">'+
      '<div class="f full"><label>Nombre</label><input id="cjNombre" maxlength="60" autocomplete="off" value="'+esc(c.nombre)+'" placeholder="Ej: María"></div>'+
      '<div class="f"><label>'+(nuevo?'PIN':'Nuevo PIN')+' '+ayuda('De 4 a 8 números. El cajero lo usa para abrir la caja. Se guarda cifrado: nadie puede verlo después, solo cambiarlo.')+'</label>'+
        '<input id="cjPin" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password" placeholder="'+(nuevo?'4 a 8 dígitos':'Vacío = se mantiene')+'"></div>'+
      '<div class="f"><label>Repite el PIN</label><input id="cjPin2" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></div>'+
      '</div><p class="small muted" id="cjMsg" style="min-height:1.2em;margin:10px 0 0" role="status"></p>'+
      '<div style="display:flex;gap:8px;margin-top:12px"><button class="btn btn-primary" id="guardarCajero">'+(nuevo?'Crear cajero':'Guardar cambios')+'</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    var msg=function(t){ $('cjMsg').textContent=t; $('cjMsg').style.color='var(--bad, #b00020)'; };
    $('guardarCajero').addEventListener('click', function(){
      var nombre=$('cjNombre').value.trim(), pin=$('cjPin').value, pin2=$('cjPin2').value;
      if(!nombre){ msg('Escribe el nombre del cajero.'); $('cjNombre').focus(); return; }
      if(nuevo||pin){
        if(!/^[0-9]{4,8}$/.test(pin)){ msg('El PIN debe tener entre 4 y 8 números.'); $('cjPin').focus(); return; }
        if(pin!==pin2){ msg('Los PIN no coinciden.'); $('cjPin2').focus(); return; }
      }
      var datos={nombre:nombre}; if(pin) datos.pin=pin;
      var req = nuevo ? API.send('POST','/api/cajeros',datos) : API.send('PATCH','/api/cajeros/'+encodeURIComponent(c.id),datos);
      req.then(function(){ cerrarModal(); aviso((nuevo?'Cajero creado.':'Cambios guardados.')+' Llega a tus cajas en menos de un minuto.'); return recargarCajeros(); })
        .catch(function(e){ msg(e.message); });
    });
    setTimeout(function(){ $('cjNombre').focus(); }, 50);
  }
  var nbCaj=$('nuevoCajero'); if(nbCaj) nbCaj.addEventListener('click', function(){ formCajero(null); });

  // ================= COBRO POR TRANSFERENCIA =================
  var TF={banco:'tfBanco',tipoCuenta:'tfTipo',numero:'tfNumero',rut:'tfRut',titular:'tfTitular',email:'tfEmail'};
  function cargarTransferencia(){
    return fetch('/api/negocio/transferencia').then(function(r){ return r.ok?r.json():null; }).then(function(d){
      if(!d) return; Object.keys(TF).forEach(function(k){ var el=$(TF[k]); if(el) el.value=d[k]||''; });
    }).catch(function(){});
  }
  var tfG=$('tfGuardar');
  if(tfG) tfG.addEventListener('click', function(){
    var datos={}; Object.keys(TF).forEach(function(k){ datos[k]=$(TF[k]).value.trim(); });
    var msg=$('tfMsg'); msg.textContent='Guardando…'; msg.style.color='';
    API.send('PUT','/api/negocio/transferencia',datos)
      .then(function(){ msg.textContent='Guardado. Llega a tus cajas en menos de un minuto.'; })
      .catch(function(e){ msg.textContent=e.message; msg.style.color='var(--bad, #b00020)'; });
  });

  // ================= PAGO CON QR (FLOW, OPCIONAL) =================
  function pintarFlow(d){
    var e=$('flEstado'); if(!e||!d) return;
    e.innerHTML = d.conectado
      ? '<span class="tag ok"><span class="punto" aria-hidden="true"></span>Conectado</span> <span class="muted">'+esc(d.entorno==='produccion'?'Producción':'Sandbox')+' · '+esc(d.apiKey)+'</span>'
      : '<span class="tag warn"><span class="punto" aria-hidden="true"></span>No conectado</span> <span class="muted">La caja usa tus datos de transferencia.</span>';
    $('flDesconectar').hidden=!d.conectado; $('flEntorno').value=d.entorno||'sandbox';
  }
  function cargarFlow(){ return fetch('/api/negocio/flow').then(function(r){ return r.ok?r.json():null; }).then(pintarFlow).catch(function(){}); }
  var flC=$('flConectar');
  if(flC) flC.addEventListener('click', function(){
    var msg=$('flMsg'); msg.style.color=''; msg.textContent='Probando las llaves con Flow…'; flC.disabled=true;
    API.send('PUT','/api/negocio/flow',{apiKey:$('flApiKey').value.trim(), secretKey:$('flSecret').value.trim(), entorno:$('flEntorno').value})
      .then(function(d){ pintarFlow(d); $('flSecret').value=''; $('flApiKey').value=''; msg.textContent='Flow conectado. Tus cajas mostrarán el QR de pago en menos de un minuto.'; })
      .catch(function(e){ msg.textContent=e.message; msg.style.color='var(--bad, #b00020)'; })
      .then(function(){ flC.disabled=false; });
  });
  var flD=$('flDesconectar');
  if(flD) flD.addEventListener('click', function(){
    API.send('DELETE','/api/negocio/flow').then(function(d){ pintarFlow(d); $('flMsg').textContent='Flow desconectado: la caja vuelve a mostrar los datos de transferencia.'; })
      .catch(function(e){ aviso('No se pudo desconectar: '+e.message); });
  });
