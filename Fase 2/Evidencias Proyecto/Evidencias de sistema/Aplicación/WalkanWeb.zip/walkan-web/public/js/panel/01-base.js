// panel.js — todo el panel del cliente (/panel). Repartido en public/js/panel/*.js por sección; el servidor
// los junta en orden en /js/panel.js (ver views.controller.ts), así que comparten un solo scope.
// Básicamente: al cargar pide todo a la API, lo guarda en `db` (en memoria) y
// cada sección tiene su render que arma el HTML a punta de strings.
// Ojo: no hay framework, así que si cambias un id en las vistas EJS
// (views/partials/panel/*) hay que cambiarlo acá también, o revienta al tiro.
(function(){
  // Atajos chicos que se usan en todo el archivo.
  // esc() es el que evita meter HTML del usuario tal cual: úsalo SIEMPRE que pintes texto que viene de la API.
  var $=function(id){ return document.getElementById(id); };
  // Number(): si llega un texto (dato corrupto), sale $0 y nunca el texto tal cual (clp se usa dentro de HTML).
  var clp=function(n){ return '$'+(Number(n)||0).toLocaleString('es-CL'); };
  var esc=function(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); };
  // "Hoy" en Chile (igual que el servidor), aunque el computador esté en otra zona horaria. YYYY-MM-DD.
  var hoyISO=function(){ return new Date().toLocaleDateString('en-CA',{timeZone:'America/Santiago'}); };
  // Para buscar sin importar tildes ni mayúsculas: "azucar" encuentra "Azúcar".
  var sinTildes=function(s){ return String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,''); };
  var fechaCLde=function(iso){ return new Date(iso).toLocaleDateString('en-CA',{timeZone:'America/Santiago'}); }; // ISO con hora -> día de Chile
  // EL formato de fecha de todo el panel: "06-oct-2026". Acepta AAAA-MM-DD (fecha local) o un ISO con hora.
  var MESES=['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
  var aFecha=function(f){ var s=String(f||''); return new Date(s.length===10?s+'T00:00:00':s); };
  var fmtFecha=function(f){ var d=aFecha(f); return !f||isNaN(d)?'':('0'+d.getDate()).slice(-2)+'-'+MESES[d.getMonth()]+'-'+d.getFullYear(); };
  var uid=function(p){ return p+Math.random().toString(36).slice(2,7); };
  // Botón "?" accesible: el lector de pantalla lee el aria-label y el texto se ve al pasar el mouse, tocar o enfocar.
  var ayuda=function(t){ return '<button type="button" class="ayuda" aria-label="Ayuda: '+esc(t)+'" data-tip="'+esc(t)+'">?</button>'; };
  // El texto va en un globo fijo en <body> (#tip): debajo del "?" o arriba si no cabe, siempre dentro de la pantalla.
  // aria-hidden: el lector ya lee el aria-label del botón.
  var tip=document.createElement('div'); tip.id='tip'; tip.hidden=true; tip.setAttribute('aria-hidden','true'); document.body.appendChild(tip);
  function verTip(b){ tip.textContent=b.dataset.tip; tip.hidden=false;
    var r=b.getBoundingClientRect(), w=tip.offsetWidth, h=tip.offsetHeight, y=r.bottom+8;
    if(y+h>innerHeight-8) y=Math.max(8, r.top-8-h);
    tip.style.left=Math.max(8, Math.min(innerWidth-w-8, r.left+r.width/2-w/2))+'px'; tip.style.top=y+'px'; }
  ['mouseover','focusin'].forEach(function(ev){ document.addEventListener(ev, function(e){ var b=e.target.closest&&e.target.closest('.ayuda[data-tip]'); if(b) verTip(b); }); });
  ['mouseout','focusout'].forEach(function(ev){ document.addEventListener(ev, function(e){ if(e.target.closest&&e.target.closest('.ayuda')) tip.hidden=true; }); });
  document.addEventListener('scroll', function(){ tip.hidden=true; }, true); // con scroll el globo quedaría flotando lejos del "?"
  // Aviso dentro de la página en vez de alert(): no bloquea la pestaña y el lector de pantalla lo lee (role="alert").
  // Se cierra solo a los 6 s o al tocarlo.
  var avisoT;
  function aviso(msg){
    var t=$('toast'); if(!t){ t=document.createElement('div'); t.id='toast'; t.className='toast'; t.setAttribute('role','alert'); t.addEventListener('click', function(){ t.hidden=true; }); document.body.appendChild(t); }
    t.textContent=msg; t.hidden=false; clearTimeout(avisoT); avisoT=setTimeout(function(){ t.hidden=true; }, 6000);
  }
  // Wrapper de fetch. get() nunca falla: si algo sale mal devuelve [] para que la vista no se caiga.
  // send() sí tira error con el mensaje del backend (d.message), por eso todos los .catch hacen aviso().
  var API={
    get:function(u){ return fetch(u).then(function(r){ if(!r.ok) return []; return r.json().then(function(d){ return Array.isArray(d)?d:[]; }); }).catch(function(){ return []; }); },
    // lista(): como get() pero SÍ falla, para los modales que deben avisar en vez de quedarse en "Cargando…".
    lista:function(u){ return fetch(u).then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); }).then(function(d){ if(!Array.isArray(d)) throw new Error('Respuesta inválida'); return d; }); },
    send:function(m,u,b){ var opt={method:m}; if(b!==undefined){ opt.headers={'Content-Type':'application/json'}; opt.body=JSON.stringify(b); } return fetch(u,opt).then(function(r){ return r.json().then(function(d){ if(!r.ok) throw new Error((d&&d.message)||'Error del servidor'); return d; }); }); }
  };

  // ---------------- STORE (en memoria) ----------------
  // Copia local de lo que devuelve la API. No se persiste nada acá: si recargas, se vuelve a pedir todo.
  var db={
    proveedores:[],
    productos:[],
    pedidos:[],
    compras:[],
    ventas:[],
    ventasHoy:[],
    prediccion:[],
    cajas:[],
    porVencer:[] // lotes vencidos o por vencer (30 días), para "Vender primero"
  };
  var cuenta={}; // el usuario logueado (sale de /api/auth/me)
  var negocio=function(){ return cuenta.negocio||cuenta.nombre||'mi negocio'; };
  var DIAS_SEM=[['1','Lu'],['2','Ma'],['3','Mi'],['4','Ju'],['5','Vi'],['6','Sá'],['0','Do']]; // valor = getDay() (0 = domingo)
  var diasVisita=function(v){ var s=','+v+','; return DIAS_SEM.filter(function(d){ return s.indexOf(','+d[0]+',')>-1; }).map(function(d){ return d[1]; }).join(', '); };
  var provNombre=function(id){ var p=db.proveedores.find(function(x){return x.id===id;}); return p?p.nombre:'—'; };
  // Buscar un producto por id. Antes recorría toda la lista en cada llamada: dentro de otro recorrido (analíticas, conteo,
  // pedidos) con 10.000 productos eran 100 millones de comparaciones y el panel se congelaba. Ahora usa un índice id → posición
  // que se rehace si cambia la lista (otra lista, otro largo, o el producto ya no está en esa posición).
  var ixArr=null, ixLen=-1, ix=null;
  function rehacerIndice(a){ ixArr=a; ixLen=a.length; ix=new Map(); for(var k=0;k<a.length;k++) ix.set(a[k].id,k); }
  var prodPorId=function(id){
    var a=db.productos||[];
    if(a!==ixArr||a.length!==ixLen) rehacerIndice(a);
    var i=ix.get(id);
    if(i!=null&&a[i]&&a[i].id===id) return a[i];
    if(i!=null){ rehacerIndice(a); i=ix.get(id); return i!=null?a[i]:undefined; } // se movió dentro de la misma lista
    return undefined;
  };
  // Los items de venta vienen como arreglos [nombre, cantidad, precio], no como objetos.
  var totalVenta=function(v){ return v.items.reduce(function(s,i){return s+i[1]*i[2];},0); };
  // Cantidades: los productos a granel (unidad 'kg') van con hasta 3 decimales (gramos) y " kg"; el resto, enteros como siempre.
  var esKg=function(p){ return !!(p&&p.unidad==='kg'); };
  // Siempre con coma decimal (en Chile el punto separa miles: "1.005" se leería mil cinco). p null = sin unidad conocida.
  function fmtCant(p, n){ n=Number(n)||0; var t=n.toLocaleString('es-CL',{maximumFractionDigits:3,useGrouping:false}); return esKg(p)?t+' kg':t; }
  var paso=function(p){ return esKg(p)?'0.001':'1'; }; // step de los inputs de cantidad
  // Vida útil: si el producto la tiene, el backend pone vence = hoy + días cuando llega sin fecha.
  var hintVida=function(d){ return 'Si lo dejas vacío vence en '+Number(d)+' día'+(d==1?'':'s')+'.'; };
  // Margen % SOBRE EL PRECIO SIN IVA. El precio de venta siempre trae IVA; el costo depende de "Mis costos incluyen IVA".
  var costoNeto=function(c){ return db.config&&db.config.costoConIva?c/1.19:c; };
  function margen(precio, costo){ var pn=(precio||0)/1.19, cn=costoNeto(costo||0); return pn?Math.round((pn-cn)/pn*100):0; }

  // ---------------- helpers de estado ----------------
  // Devuelven {c, t}: c es la clase del tag (ok/warn/bad/mut) y t el texto que se muestra.
  // Si el producto no tiene stockMin se usa 10 por defecto.
  function estadoStock(p){ var min=p.stockMin!=null?p.stockMin:(db.config&&db.config.umbralBajo!=null?db.config.umbralBajo:10); if(p.stock<0) return {c:'bad',t:'Revisar'}; if(p.stock<=0) return {c:'bad',t:'Agotado'}; if(p.stock<=min) return {c:'warn',t:'Bajo'}; return {c:'ok',t:'OK'}; }
  // Vencimiento: vencido = rojo, 30 días o menos = amarillo. `flag` lo usa el chip "Por vencer" del inventario.
  function venceInfo(v){
    if(!v) return {c:'mut',t:'—',flag:'',dias:null};
    var dias=Math.round((aFecha(v)-aFecha(hoyISO()))/86400000);
    var txt=fmtFecha(v);
    if(dias<0) return {c:'bad',t:'Vencido',flag:'vence',dias:dias};
    if(dias<=30) return {c:'warn',t:txt+' ('+dias+'d)',flag:'vence',dias:dias};
    return {c:'ok',t:txt,flag:'',dias:dias};
  }
  // "Vencido hace 3 d" / "Vence hoy" / "12 d" para las tablas de lotes.
  function diasTxt(d){ return d==null?'Sin fecha':d<0?'Vencido hace '+(-d)+' d':d===0?'Vence hoy':d+' d'; }

  // ---------------- Navegación ----------------
  // Es una sola página: cada sección es un <section class="view" data-view="..."> y acá
  // solo se prende la que toca. Si agregas una vista nueva, súmala a `titulos`.
  // Mi cuenta, Mi plan y Apariencia son una sola página con pestañas (#tabsCuenta); se abre desde el perfil del sidebar.
  var titulos={resumen:'Resumen',ventas:'Ventas',inventario:'Inventario',proveedores:'Proveedores',compras:'Compras',cajas:'Mis cajas',analiticas:'Analíticas',cuenta:'Mi cuenta',plan:'Mi cuenta',apariencia:'Mi cuenta',soporte:'Ayuda y soporte'};
  var DE_CUENTA={cuenta:1,plan:1,apariencia:1};
  // ---------------- Buscador de productos ----------------
  // Para elegir un producto en pedidos, ingresos y devoluciones. Antes era un <select> con TODOS los productos en cada
  // línea: con 10.000 productos el formulario se pegaba. Ahora se escribe y aparecen hasta 12 coincidencias (nombre o
  // código); el id elegido queda en un <input type="hidden" class="CLS">, así el resto del código lee .value igual que antes.
  var bpSeq=0;
  function buscadorProd(cls, etiqueta){
    var id='bp'+(++bpSeq);
    return '<div class="bprod"><input type="text" class="bprod-q" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="'+id+'" autocomplete="off" spellcheck="false" placeholder="Busca por nombre o código…" aria-label="'+esc(etiqueta||'Producto')+'">'+
      '<input type="hidden" class="'+cls+'"><ul class="bprod-l" id="'+id+'" role="listbox" hidden></ul></div>';
  }
  // root: el elemento que contiene el buscador. opciones: { lista: fn() → productos candidatos, extra: fn(p) → texto
  // gris opcional (stock, costo), alElegir: fn(p|null) }. Devuelve { elegir(p) } para precargar un producto (al editar).
  function activarBuscadorProd(root, op){
    var q=root.querySelector('.bprod-q'), h=root.querySelector('input[type=hidden]'), ul=root.querySelector('.bprod-l'), res=[], act=-1;
    function etiqueta(p){ return p.nombre+(p.sku?' · '+p.sku:''); }
    function cerrar(){ ul.hidden=true; q.setAttribute('aria-expanded','false'); q.removeAttribute('aria-activedescendant'); act=-1; }
    function elegir(p, silencio){
      h.value=p?p.id:''; q.value=p?etiqueta(p):q.value; q.setCustomValidity(''); cerrar();
      if(!silencio && op.alElegir) op.alElegir(p);
    }
    function marcar(i){ act=i; [].forEach.call(ul.children, function(li,k){ li.setAttribute('aria-selected', k===i?'true':'false'); }); if(i>-1){ q.setAttribute('aria-activedescendant', ul.id+'-'+i); ul.children[i].scrollIntoView({block:'nearest'}); } }
    function buscar(){
      var t=sinTildes(q.value.trim()); if(!t){ res=[]; cerrar(); return; }
      var pal=t.split(/\s+/), a=[], b=[], c=[];
      var l=op.lista();
      for(var i=0;i<l.length && a.length<12;i++){
        var p=l[i], sku=p._bs!=null?p._bs:(p._bs=sinTildes(p.sku)), nom=p._bn!=null?p._bn:(p._bn=sinTildes(p.nombre)); // normalizado una vez por producto
        if(sku && sku===t) a.push(p);
        else if(nom.indexOf(t)===0) b.length<12 && b.push(p);
        else if(pal.every(function(w){ return (nom+' '+sku).indexOf(w)>-1; })) c.length<12 && c.push(p);
      }
      res=a.concat(b,c).slice(0,12);
      ul.innerHTML=res.length?res.map(function(p,k){ var x=op.extra?op.extra(p):''; return '<li role="option" id="'+ul.id+'-'+k+'" aria-selected="false" data-i="'+k+'"><span>'+esc(p.nombre)+'</span><small>'+esc((p.sku||'sin código')+(x?' · '+x:''))+'</small></li>'; }).join('')
        :'<li class="bprod-nada" role="option" aria-disabled="true">Sin coincidencias. Revisa el nombre o el código.</li>';
      ul.hidden=false; q.setAttribute('aria-expanded','true'); marcar(res.length?0:-1);
    }
    q.addEventListener('input', function(){ if(h.value){ h.value=''; if(op.alElegir) op.alElegir(null); } buscar(); });
    q.addEventListener('keydown', function(e){
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){ if(ul.hidden) buscar(); if(!res.length) return; e.preventDefault(); marcar((act+(e.key==='ArrowDown'?1:-1)+res.length)%res.length); }
      else if(e.key==='Enter'){ if(!ul.hidden && act>-1){ e.preventDefault(); elegir(res[act]); } }
      else if(e.key==='Escape'){ if(!ul.hidden){ e.preventDefault(); e.stopPropagation(); cerrar(); } }
    });
    ul.addEventListener('mousedown', function(e){ e.preventDefault(); var li=e.target.closest('li[data-i]'); if(li) elegir(res[+li.dataset.i]); });
    q.addEventListener('blur', function(){ setTimeout(cerrar, 0); if(q.value.trim() && !h.value) q.setCustomValidity('Elige un producto de la lista.'); });
    return { elegir: function(p){ elegir(p, true); }, input: q };
  }

  // Ícono del sprite (views/partials/iconos.ejs). 'ic-t' deja un espacio a la derecha cuando va antes de un texto.
  function ico(n){ return '<svg class="ic ic-t" aria-hidden="true" focusable="false"><use href="#i-'+n+'"/></svg>'; }
  var nav=$('nav'), tabsCuenta=$('tabsCuenta'), uLink=$('uLink'), brandPanel=$('brandPanel');
  // Cuenta en pausa (plan vencido o cuenta cerrada): solo se puede estar en Mi cuenta. La fija aplicarVigencia().
  var vistaPausa='';
  function mostrar(v){
    if(vistaPausa && !DE_CUENTA[v] && v!=='soporte') v=vistaPausa; // con la cuenta en pausa igual se puede pedir ayuda
    document.querySelectorAll('.view').forEach(function(s){ s.classList.toggle('active', s.dataset.view===v); });
    nav.querySelectorAll('a').forEach(function(a){ var on=a.dataset.view===v; a.classList.toggle('active', on); if(on) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current'); });
    if(tabsCuenta){ tabsCuenta.hidden=!DE_CUENTA[v]; tabsCuenta.querySelectorAll('a').forEach(function(a){ var on=a.dataset.view===v; a.classList.toggle('active', on); if(on) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current'); }); }
    if(uLink){ uLink.classList.toggle('active', !!DE_CUENTA[v]); if(DE_CUENTA[v]) uLink.setAttribute('aria-current','page'); else uLink.removeAttribute('aria-current'); }
    $('titulo').textContent=titulos[v]||''; window.scrollTo(0,0);
    if(history.replaceState) history.replaceState(null,'','#'+v); // al recargar vuelve a la misma sección
    if(v==='analiticas') compararPeriodos(); // trae las ventas y mermas nuevas desde la última vez
  }
  // Los links tienen href="#vista" para que se puedan usar con teclado (Tab + Enter); no dejamos que salte el hash.
  // ir(): cambia el hash (queda en el historial, así Atrás/Adelante funcionan) y el hashchange muestra la vista. Una sola pasada por mostrar().
  function ir(v){ if(location.hash.slice(1)!==v) location.hash=v; else mostrar(v); }
  // El logo del panel lleva al Resumen (antes iba a la página principal y parecía que se cerraba la sesión).
  [nav, tabsCuenta, uLink, brandPanel].forEach(function(el){ if(el) el.addEventListener('click', function(e){ var a=e.target.closest('a[data-view]'); if(a){ e.preventDefault(); ir(a.dataset.view); } }); });
  // Escribir #proveedores en la barra, o Atrás/Adelante del navegador, también cambia de sección.
  window.addEventListener('hashchange', function(){ var v=location.hash.slice(1); if(titulos[v]) mostrar(v); });
  if(titulos[location.hash.slice(1)]) mostrar(location.hash.slice(1));

  // ---------------- Modal ----------------
  // Un único modal para todo: cada formulario le inyecta su HTML con abrirModal().
  // Cualquier botón con data-cerrar (la X, Cancelar) lo cierra, igual que Escape. Un click afuera NO lo cierra, y si el
  // usuario ya escribió algo se pide confirmación antes de perderlo. Guardar llama cerrarModal() directo, sin preguntar.
  var modal=$('modal'), modalSucio=false;
  function abrirModal(titulo, html){ $('modalTitulo').textContent=titulo; $('modalBody').innerHTML=html; modal.classList.add('open'); modalSucio=false; var md=$('modalDescartar'); if(md) md.hidden=true;
    // Une cada <label> de los formularios con su campo (el id del input siguiente) para lectores de pantalla.
    $('modalBody').querySelectorAll('.f > label:not([for])').forEach(function(l){ var i=l.parentElement.querySelector('input[id],select[id],textarea[id]'); if(i&&!l.contains(i)) l.htmlFor=i.id; });
  }
  var camStop=null; // si hay una cámara abierta (escáner), se apaga al cerrar el modal
  function cerrarModal(){ if(camStop) camStop(); modal.classList.remove('open'); var b=$('modalDescartar'); if(b) b.hidden=true; }
  // Si hay datos sin guardar se pregunta dentro del mismo modal (antes era confirm() del navegador). Una pantalla de
  // éxito ("Borrador guardado", "Devolución registrada") ya no tiene campos: ahí se cierra directo, aunque antes se escribiera.
  var pendienteCerrar=null;
  function hayDatos(){ return modalSucio && !!$('modalBody').querySelector('input:not([type=hidden]):not([type=file]),select:not([hidden]),textarea'); }
  function pedirCerrarModal(origen){
    if(!hayDatos()){ cerrarModal(); return true; }
    pendienteCerrar=origen||null;
    var b=$('modalDescartar');
    if(!b){
      b=document.createElement('div'); b.id='modalDescartar'; b.className='modal-descartar'; b.setAttribute('role','alertdialog'); b.setAttribute('aria-labelledby','mdTxt');
      b.innerHTML='<p id="mdTxt">'+ico('alerta')+'Tienes datos sin guardar. ¿Cerrar y descartarlos?</p><div><button type="button" class="btn btn-danger" id="mdSi">Descartar y cerrar</button><button type="button" class="btn btn-ghost" id="mdNo">Seguir editando</button></div>';
      $('modalBody').parentNode.insertBefore(b, $('modalBody'));
      $('mdNo').addEventListener('click', function(){ b.hidden=true; pendienteCerrar=null; });
      $('mdSi').addEventListener('click', function(){ var o=pendienteCerrar; b.hidden=true; modalSucio=false; pendienteCerrar=null; if(o && o.isConnected) o.click(); else cerrarModal(); });
    }
    b.hidden=false; $('mdNo').focus();
    return false;
  }
  ['input','change'].forEach(function(ev){ $('modalBody').addEventListener(ev, function(){ modalSucio=true; }); });
  // Captura: si el usuario se arrepiente, el click no llega a otros manejadores de data-cerrar (p. ej. "Ir a Proveedores").
  modal.addEventListener('click', function(e){ var c=e.target.closest('[data-cerrar]'); if(c && !pedirCerrarModal(c)) e.stopImmediatePropagation(); }, true);
  document.addEventListener('keydown', function(e){ if(e.key!=='Escape' || !modal.classList.contains('open')) return; var b=$('modalDescartar'); if(b && !b.hidden){ b.hidden=true; pendienteCerrar=null; return; } pedirCerrarModal(); });
  // Enter en un campo del modal: en las listas de cantidades (conteo, pedidos, recepción) salta al siguiente campo de la
  // misma columna; en los formularios simples presiona el botón principal (Guardar, Crear, Registrar…).
  // El escáner GS1 maneja su propio Enter (preventDefault), por eso se respeta defaultPrevented.
  modal.addEventListener('keydown', function(e){
    var t=e.target; if(e.key!=='Enter'||e.defaultPrevented||t.tagName!=='INPUT'||/^(checkbox|file|radio)$/.test(t.type)) return;
    var col=['cnQ','sgQ','etN','qty','rq','rc','xq','xc','lq','lc','dq'].filter(function(c){ return t.classList.contains(c); })[0];
    if(col){ e.preventDefault(); var l=[].slice.call(modal.querySelectorAll('input.'+col)), sig=l[l.indexOf(t)+1]; if(sig){ sig.focus(); sig.select(); } return; }
    // Solo formularios simples: Enter nunca envía un pedido ni confirma una recepción por accidente.
    var b=$('modalBody').querySelector('#guardarProd,#guardarAj,#guardarProv,#elGuardar,#npSeguir,#pmGuardar,#guardarCajero'); if(b&&!b.disabled){ e.preventDefault(); b.click(); }
  });

  // Valor del inventario: stock × costo y stock × precio actuales, agrupado por sucursal.
  // Hoy no hay sucursales y todo cae en "Local principal"; cuando llegue multibodega, basta con que
  // cada fila traiga `sucursal` (una fila por producto y sucursal) para que el desglose aparezca solo.
  // Stock negativo cuenta como 0: es un error de conteo (ya tiene su alerta), no valor que reste.
  function valorInventario(productos){
    var porSuc={}, orden=[];
    var total={nombre:'Total', costo:0, venta:0, sinCosto:0};
    productos.forEach(function(p){
      var n=p.sucursal||'Local principal', q=Math.max(Number(p.stock)||0, 0);
      var s=porSuc[n]; if(!s){ s=porSuc[n]={nombre:n, costo:0, venta:0, sinCosto:0}; orden.push(s); }
      // valorCosto viene del backend por FIFO (cada unidad a lo que costó); si falta, stock × costo actual.
      [s,total].forEach(function(x){ x.costo+=p.valorCosto!=null?p.valorCosto:q*(p.costo||0); x.venta+=q*(p.precio||0); if(q&&!p.costo) x.sinCosto++; });
    });
    return {total:total, sucursales:orden};
  }

  function renderValor(){
    if(!$('valorCosto')) return;
    var v=valorInventario(db.productos), t=v.total;
    $('valorCosto').textContent=clp(t.costo);
    $('valorVenta').textContent=clp(t.venta);
    // Ganancia potencial = venta neta (sin IVA) − costo neto, igual que margen().
    var vn=t.venta/1.19, g=Math.round(vn-costoNeto(t.costo));
    $('valorGanancia').textContent=clp(g);
    $('valorMargen').textContent=t.venta?'margen '+Math.round(g/vn*100)+'% sobre la venta sin IVA':'';
    $('valorNota').hidden=!t.sinCosto;
    $('valorNota').innerHTML=t.sinCosto?t.sinCosto+' producto'+(t.sinCosto>1?'s':'')+' con stock sin costo: no suma'+(t.sinCosto>1?'n':'')+' al valor a costo. <a class="link" href="#inventario" data-goto="inventario">Cargar costos →</a>':'';
    var tabla=$('valorSucursales');
    tabla.hidden=v.sucursales.length<2;
    tabla.tBodies[0].innerHTML=v.sucursales.length<2?'':v.sucursales.map(function(s){
      return '<tr><td class="prin"><b>'+esc(s.nombre)+'</b></td><td data-l="A costo">'+clp(s.costo)+'</td><td data-l="A precio de venta">'+clp(s.venta)+'</td></tr>';
    }).join('');
  }


// Menús desplegables ("Más acciones", "⋯" de cada fila): un botón [data-menu] abre la .menu-lista hermana.
// Se cierran al elegir una opción, al hacer clic fuera o con Esc. Un solo listener para todo el panel.
(function(){
  function cerrarMenus(excepto){
    document.querySelectorAll('[data-menu][aria-expanded="true"]').forEach(function(b){
      if(b===excepto) return; b.setAttribute('aria-expanded','false');
      var l=b.parentNode.querySelector('.menu-lista'); if(l) l.hidden=true;
    });
  }
  document.addEventListener('click', function(e){
    var b=e.target.closest('[data-menu]');
    if(b){ var l=b.parentNode.querySelector('.menu-lista'); var abrir=b.getAttribute('aria-expanded')!=='true';
      cerrarMenus(b); b.setAttribute('aria-expanded',abrir?'true':'false'); if(l){ l.hidden=!abrir; if(abrir){ var p=l.querySelector('button'); if(p) p.focus(); } } return; }
    if(e.target.closest('.menu-lista button')){ setTimeout(function(){ cerrarMenus(null); }, 0); return; }
    if(!e.target.closest('.menu-lista')) cerrarMenus(null);
  });
  document.addEventListener('keydown', function(e){
    if(e.key!=='Escape') return; var ab=document.querySelector('[data-menu][aria-expanded="true"]');
    if(ab){ cerrarMenus(null); ab.focus(); }
  });
})();

// Consentimiento de datos (Ley 21.719): si el dueño no aceptó la política vigente (cuenta creada por
// el staff, o la política cambió de versión), se le pide antes de usar el panel.
fetch('/api/privacidad/estado').then(function(r){ return r.ok ? r.json() : null; }).then(function(e){
  if(e && e.requiere) location.replace('/privacidad?aceptar=1');
}).catch(function(){});
