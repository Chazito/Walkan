// privacidad.js — /privacidad?aceptar=1: el dueño acepta la política vigente antes de entrar al panel.
// El servidor guarda la aceptación (versión, hash del texto, fecha, IP y navegador) en `consentimientos`.
(function(){
  var f = document.getElementById('aceptarPolitica');
  if(!f || !/[?&]aceptar=1/.test(location.search)) return;
  f.hidden = false;
  var err = document.getElementById('apError');
  f.addEventListener('submit', function(ev){
    ev.preventDefault(); err.hidden = true;
    if(!document.getElementById('apPrivacidad').checked){ err.textContent = 'Para usar Walkan debes aceptar los Términos y la Política de Privacidad.'; err.hidden = false; return; }
    var btn = f.querySelector('button'); btn.disabled = true; btn.textContent = 'Guardando…';
    fetch('/api/privacidad/aceptar', { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ marketing: document.getElementById('apMarketing').checked }) })
      .then(function(r){
        if(r.status === 401){ location.href = '/mi-cuenta'; return; }
        if(!r.ok) throw new Error();
        location.href = '/panel';
      })
      .catch(function(){ err.textContent = 'No pudimos guardar tu aceptación. Intenta de nuevo.'; err.hidden = false; btn.disabled = false; btn.textContent = 'Aceptar y continuar'; });
  });
})();
