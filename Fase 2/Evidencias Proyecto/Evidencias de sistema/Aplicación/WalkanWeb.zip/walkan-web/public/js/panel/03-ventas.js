// Parte de panel.js: el servidor junta public/js/panel/*.js en orden (ver views.controller.ts) dentro de un solo
// (function(){ … })(), así que todo comparte el mismo scope. No es un módulo suelto: no cargarlo solo.
  // ================= VENTAS =================
  // Solo lectura: las ventas las manda la caja por sync, acá no se crean.
  // estadoVenta() acepta tanto `estado` como `sii`; cualquier cosa que no sea emitida/aceptada sale en amarillo.
  function estadoVenta(v){ var e=(v.estado||v.sii||'Emitida'); var ok=/emit|acept/i.test(e); return { ok:ok, t:ok?'ok':'warn', lbl:ok?'Emitida':e }; }
  // Bandeja "Vendido sin catálogo" (B1): líneas que la caja vendió con un código que tu inventario no tiene. Las guarda el
  // servidor (/api/ventas/pendientes); al crear el producto con ese código, o al vincularlo a uno que ya tienes, se descuenta
  // ese stock UNA vez y con la fecha de la venta. También muestra las ventas que la nube no pudo aplicar (rechazos).
  db.pendientes={grupos:[],rechazos:[]};
  var pendSku=''; // productos con el SKU que había la última vez: si cambia (producto nuevo o SKU corregido), se recarga la bandeja
  function recargarPendientes(){
    return fetch('/api/ventas/pendientes').then(function(r){ return r.ok?r.json():null; })
      .then(function(d){ if(d&&Array.isArray(d.grupos)){ db.pendientes=d; pintarPendientes(); } }).catch(function(){});
  }
  // La llama renderInventario: el servidor descuenta solo al crear o corregir un producto, acá solo se refresca la lista.
  function renderNoReconocidos(){
    var k=db.productos.map(function(p){ return p.sku; }).join('|');
    if(k!==pendSku){ pendSku=k; recargarPendientes(); } else pintarPendientes();
  }
  function pintarPendientes(){
    var g=db.pendientes.grupos||[], rz=db.pendientes.rechazos||[];
    $('noRecBox').hidden=!g.length&&!rz.length;
    $('noRecList').innerHTML=g.map(function(x){
      return '<li><span><code>'+esc(x.sku||'sin código')+'</code> '+esc(x.nombre)+' · '+fmtCant(null,x.unidades)+' un. en '+Number(x.ventas)+' venta'+(x.ventas==1?'':'s')+'</span> '
        +(x.sku?'<button type="button" class="mini" data-pend-crear="'+esc(x.id)+'">Crear producto</button> ':'')
        +'<button type="button" class="mini" data-pend-vincular="'+esc(x.id)+'">Vincular…</button> '
        +'<button type="button" class="mini" data-pend-ignorar="'+esc(x.id)+'">Ignorar</button></li>';
    }).join('')+rz.map(function(x){
      return '<li><span>'+ico('alerta')+'La nube no pudo aplicar '+(x.tipo==='venta'?'la venta'+(x.folio?' folio '+esc(x.folio):''):'un evento ('+esc(x.tipo)+')')
        +(x.total!=null?' por '+clp(x.total):'')+' de la caja '+esc(x.caja)+': '+esc(x.motivo)+'</span> '
        +'<button type="button" class="mini" data-rechazo-ok="'+esc(x.id)+'">Revisado</button></li>';
    }).join('');
  }
  var grupoPend=function(id){ return (db.pendientes.grupos||[]).find(function(x){ return x.id===id; }); };
  function resolverPend(url, body, ok){
    return API.send('POST', url, body).then(function(r){
      aviso(ok(r)); recargarPendientes();
      API.get('/api/productos').then(function(p){ if(p.length){ db.productos=p; pendSku=p.map(function(x){ return x.sku; }).join('|'); renderInventario(); } });
    }).catch(function(e){ aviso(e.message); recargarPendientes(); });
  }
  $('noRecList').addEventListener('click', function(e){
    var b=e.target.closest('button'); if(!b) return;
    if(b.dataset.pendCrear){ var x=grupoPend(b.dataset.pendCrear); if(x) formProducto({sku:x.sku, nombre:x.nombre, precio:x.precio}); return; }
    if(b.dataset.pendIgnorar){ resolverPend('/api/ventas/pendientes/'+encodeURIComponent(b.dataset.pendIgnorar)+'/ignorar', undefined, function(r){ return r.ignoradas+' línea(s) ignorada(s): no mueven stock.'; }); return; }
    if(b.dataset.rechazoOk){ resolverPend('/api/ventas/pendientes/rechazos/'+encodeURIComponent(b.dataset.rechazoOk)+'/revisado', undefined, function(){ return 'Marcado como revisado.'; }); return; }
    if(b.dataset.pendVincular) vincularPend(grupoPend(b.dataset.pendVincular));
  });
  // Vincular: el código leído en la caja es de un producto que ya tienes (por ejemplo, otro código de barras del mismo).
  function vincularPend(x){
    if(!x) return;
    var ops=db.productos.slice().sort(function(a,b){ return a.nombre.localeCompare(b.nombre); });
    var et=function(p){ return p.nombre+' · '+p.sku; };
    abrirModal('Vincular a un producto',
      '<p class="intro" style="margin:0 0 12px">La caja vendió <b>'+fmtCant(null,x.unidades)+' un.</b> de <code>'+esc(x.sku||'sin código')+'</code> ('+esc(x.nombre)+'). Elige el producto de tu inventario: se descontará de su stock con la fecha de cada venta.</p>'
      +'<div class="f"><label>Producto</label><input id="pvBuscar" list="pvLista" autocomplete="off" placeholder="Nombre o SKU"><datalist id="pvLista">'
      +ops.map(function(p){ return '<option value="'+esc(et(p))+'"></option>'; }).join('')+'</datalist></div>'
      +'<div style="display:flex;gap:8px;margin-top:16px"><button type="button" class="btn btn-primary" id="pvOk">Vincular</button><button type="button" class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    $('pvBuscar').focus();
    $('pvOk').addEventListener('click', function(){
      var v=$('pvBuscar').value, p=ops.find(function(o){ return et(o)===v; });
      if(!p){ aviso('Elige un producto de la lista.'); return; }
      cerrarModal();
      resolverPend('/api/ventas/pendientes/'+encodeURIComponent(x.id)+'/vincular', {productoId:p.id}, function(r){ return r.aplicadas+' venta(s) descontada(s) de '+p.nombre+'.'; });
    });
  }
  // Buscador de ventas: por folio, producto, caja, cajero o medio de pago (palabras sin tildes), sobre lo cargado.
  var ventasQ='';
  function ventasVisibles(){ return db.ventas.filter(function(v){ var hay=sinTildes(v.folio+' '+v.caja+' '+(v.cajero||'')+' '+(v.pago||'')+' '+v.items.map(function(i){ return i[0]; }).join(' ')); return ventasQ.split(' ').every(function(w){ return hay.indexOf(w)>-1; }); }); }
  function renderVentas(){
    renderNoReconocidos();
    var vis=ventasVisibles();
    var rows=vis.map(function(v){ var i=db.ventas.indexOf(v);
      var s=estadoVenta(v);
      return '<tr data-venta="'+i+'" style="cursor:pointer"><td class="prin"><b>'+esc(v.folio)+'</b></td><td>'+fmtFecha(v.fecha)+' '+esc(v.hora)+'</td><td data-l="Caja">'+esc(v.caja)+'</td><td data-l="Ítems">'+Number(v.items.length)+'</td><td>'+clp(totalVenta(v))+'</td><td><span class="tag '+s.t+'">'+esc(s.lbl)+'</span></td><td class="acc"><button type="button" class="mini icon" aria-label="Ver comprobante '+esc(v.folio)+'">Ver ›</button></td></tr>';
    }).join('');
    var filtro=$('vDesde').value||$('vHasta').value;
    $('ventasBody').innerHTML=rows||'<tr><td colspan="7" class="muted" style="text-align:center;padding:24px">'+(ventasQ?'Ninguna venta coincide con la búsqueda.':filtro?'No hay ventas en esas fechas.':'Aún no hay ventas sincronizadas. Cuando tu caja registre ventas, aparecerán aquí.')+'</td></tr>';
    var tot=vis.reduce(function(s,v){return s+totalVenta(v);},0);
    $('vResumen').textContent=vis.length?(vis.length+' venta'+(vis.length>1?'s':'')+' · '+clp(tot)+(filtro||ventasQ?'':' (últimas 100)')):'';
  }
  // Filtro por fechas (días de Chile, inclusive). Sin fechas = las últimas 100. La recarga de cada 30 s respeta el filtro.
  function urlVentas(){ var d=$('vDesde').value, h=$('vHasta').value; return d||h?'/api/ventas?desde='+encodeURIComponent(d)+'&hasta='+encodeURIComponent(h):'/api/ventas'; }
  // `ventasSeq`: si llegan respuestas fuera de orden (clics rápidos o la recarga de 30 s), solo vale la última pedida.
  var ventasSeq=0;
  function filtrarVentas(){ var n=++ventasSeq; return API.get(urlVentas()).then(function(v){ if(n!==ventasSeq) return; db.ventas=v; renderVentas(); }); }
  var diaAtras=function(n){ return new Date(Date.parse(hoyISO()+'T12:00:00Z')-n*86400000).toISOString().slice(0,10); };
  $('vDesde').addEventListener('change', filtrarVentas); $('vHasta').addEventListener('change', filtrarVentas);
  $('vHoy').addEventListener('click', function(){ $('vDesde').value=$('vHasta').value=hoyISO(); filtrarVentas(); });
  $('v7').addEventListener('click', function(){ $('vDesde').value=diaAtras(6); $('vHasta').value=hoyISO(); filtrarVentas(); });
  // Exporta las ventas que se ven (con el filtro aplicado), una fila por comprobante.
  $('vCSV').addEventListener('click', function(){
    if(!ventasVisibles().length){ aviso('No hay ventas para exportar con este filtro.'); return; }
    var d=$('vDesde').value, h=$('vHasta').value;
    descargarCSV('ventas-'+(d||h?(d||'inicio')+'_a_'+(h||hoyISO()):'ultimas-100')+'.csv', ['Folio','Fecha','Hora','Caja','Cajero','Medio de pago','Estado','Ítems','Neto','IVA','Total'],
      ventasVisibles().map(function(v){ var t=totalVenta(v), n=Math.round(t/1.19); return [v.folio, v.fecha, v.hora, v.caja, v.cajero, v.pago, v.estado, v.items.length, n, t-n, t]; }));
  });
  $('vLimpiar').addEventListener('click', function(){ $('vDesde').value=$('vHasta').value=''; filtrarVentas(); });
  $('buscarVenta').addEventListener('input', function(){ ventasQ=sinTildes(this.value.trim()); renderVentas(); });
  // Click en una fila -> modal con el comprobante. El neto/IVA se saca dividiendo por 1,19 (precios con IVA incluido).
  // "Imprimir copia" abre un ticket de 80 mm marcado como COPIA (el comprobante válido es el que emitió la caja).
  $('ventasBody').addEventListener('click', function(e){
    var tr=e.target.closest('tr[data-venta]'); if(!tr) return;
    var v=db.ventas[+tr.dataset.venta]; var tot=totalVenta(v); var neto=Math.round(tot/1.19); var iva=tot-neto;
    var its=v.items.map(function(i){ return '<div class="tline"><span style="flex:1">'+esc(i[0])+' <span class="muted">× '+Number(i[1])+'</span></span><b>'+clp(i[1]*i[2])+'</b></div>'; }).join('');
    var s=estadoVenta(v);
    abrirModal('Comprobante '+v.folio, // el título va por textContent: no necesita esc()
      '<div class="mblock"><div class="kv"><span class="muted">Hora</span><b>'+esc(v.hora)+'</b><span class="muted">Caja</span><b>'+esc(v.caja)+'</b><span class="muted">Cajero</span><b>'+esc(v.cajero)+'</b><span class="muted">Pago</span><b>'+esc(v.pago)+'</b><span class="muted">Estado</span><b><span class="tag '+s.t+'">'+esc(s.lbl)+'</span></b></div></div>'+
      '<div class="mblock"><h4>Detalle</h4>'+its+'</div>'+
      (pagoTexto(v)?'<p class="small" style="margin:0 0 10px"><span class="muted">Pago:</span> '+esc(pagoTexto(v))+'</p>':'')+
      ((v.correos||[]).length?'<p class="small" style="margin:0 0 10px"><span class="muted">Enviado por correo:</span> '+v.correos.map(function(c){ return esc(c.email)+' <span class="tag '+(c.estado==='enviado'?'ok':c.estado==='error'?'bad':'warn')+'">'+esc({enviado:'enviado',simulado:'simulado',error:'error',pendiente:'pendiente'}[c.estado]||c.estado)+'</span>'; }).join(' · ')+'</p>':'')+
      '<div class="kv" style="font-size:.92rem"><span class="muted">Neto</span><b>'+clp(neto)+'</b><span class="muted">IVA (19%)</span><b>'+clp(iva)+'</b><span class="muted">Total</span><b style="font-size:1.05rem">'+clp(tot)+'</b></div>'+
      '<div style="margin-top:16px"><button class="btn btn-ghost" id="imprimirCopia">Imprimir copia</button></div>');
    $('imprimirCopia').addEventListener('click', function(){
      var w=window.open('','_blank'); if(!w){ aviso('El navegador bloqueó la ventana: permite ventanas emergentes para imprimir.'); return; }
      var fila=function(a,b){ return '<tr><td>'+a+'</td><td style="text-align:right">'+b+'</td></tr>'; };
      w.document.write('<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Copia '+esc(v.folio)+'</title><style>@page{size:80mm auto;margin:4mm}body{font:10pt/1.35 monospace;width:72mm;margin:0;color:#000}h1{font-size:11pt;text-align:center;margin:0}p{text-align:center;margin:2px 0}table{width:100%;border-collapse:collapse}td{vertical-align:top;padding:1px 0}hr{border:0;border-top:1px dashed #000}</style></head><body>'+
        '<h1>'+esc(negocio())+'</h1><p><b>COPIA · NO VÁLIDA COMO COMPROBANTE</b></p><p>Comprobante '+esc(v.folio)+' · '+fmtFecha(v.fecha)+' '+esc(v.hora)+'</p><p>'+esc(v.caja)+(v.cajero?' · '+esc(v.cajero):'')+'</p><hr><table>'+
        v.items.map(function(i){ return fila(esc(i[0])+'<br>'+Number(i[1])+' × '+clp(i[2]), clp(i[1]*i[2])); }).join('')+'</table><hr><table>'+fila('Neto',clp(neto))+fila('IVA 19%',clp(iva))+fila('<b>Total</b>','<b>'+clp(tot)+'</b>')+'</table>'+
        (v.pago?'<p>Pago: '+esc(v.pago)+'</p>':'')+'</body></html>');
      w.document.close(); w.focus(); setTimeout(function(){ w.print(); }, 300);
    });
  });

  // Detalle del pago que informó la caja: autorización de la máquina, o lo recibido y el vuelto en efectivo.
  function pagoTexto(v){
    var d=v.pagoDetalle; if(!d) return '';
    var flow=/^Flow/.test(d.terminal||'');
    var p=[]; if(flow) p.push(d.terminal.replace('Flow QR','QR Flow'));
    if(d.autorizacion) p.push((flow?'orden ':'autorización ')+d.autorizacion+(d.tarjeta?' ('+d.tarjeta+')':''));
    if(d.recibido!=null) p.push('recibido '+clp(d.recibido)+' · vuelto '+clp(d.vuelto||0));
    if(d.simulado) p.push('simulado');
    return p.join(' · ');
  }
