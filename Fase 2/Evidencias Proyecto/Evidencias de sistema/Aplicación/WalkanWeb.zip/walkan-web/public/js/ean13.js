// ean13.js — dibuja un código EAN-13 como SVG para las etiquetas de góndola (sin librerías).
// Solo acepta 13 dígitos con dígito verificador correcto (o 12 y lo calcula); si no, devuelve ''
// y la etiqueta muestra el SKU en texto. Es pura: scripts/check-lotes.js la prueba con require().
(function(raiz){
  var L=['0001101','0011001','0010011','0111101','0100011','0110001','0101111','0111011','0110111','0001011'];
  var R=L.map(function(s){ return s.replace(/./g,function(b){ return b==='0'?'1':'0'; }); });
  var G=R.map(function(s){ return s.split('').reverse().join(''); });
  var PARIDAD=['LLLLLL','LLGLGG','LLGGLG','LLGGGL','LGLLGG','LGGLLG','LGGGLL','LGLGLG','LGLGGL','LGGLGL'];
  function verificador(d12){ var s=0; for(var i=0;i<12;i++) s+=(+d12[i])*(i%2?3:1); return (10-s%10)%10; }
  // 13 dígitos -> se valida. 12 dígitos = UPC-A (ya trae su verificador): es el EAN-13 con un 0 adelante,
  // así la etiqueta escanea el mismo código que tiene la caja. Otro formato -> ''.
  function normalizar(cod){
    cod=String(cod||'').trim();
    if(/^\d{12}$/.test(cod)) cod='0'+cod;
    return /^\d{13}$/.test(cod)&&verificador(cod)===+cod[12]?cod:'';
  }
  // Los 95 módulos (1 = barra) o '' si el código no es un EAN-13 válido.
  function ean13Bits(cod){
    cod=normalizar(cod); if(!cod) return '';
    var par=PARIDAD[+cod[0]], b='101';
    for(var i=1;i<=6;i++) b+=(par[i-1]==='L'?L:G)[+cod[i]];
    b+='01010';
    for(i=7;i<=12;i++) b+=R[+cod[i]];
    return b+'101';
  }
  // SVG con 9 módulos de margen a cada lado (zona de silencio) y los dígitos abajo.
  function ean13SVG(cod){
    var b=ean13Bits(cod); if(!b) return '';
    var r='';
    for(var i=0;i<b.length;i++) if(b[i]==='1'){ var j=i; while(b[j+1]==='1') j++; r+='<rect x="'+(i+9)+'" y="0" width="'+(j-i+1)+'" height="50"/>'; i=j; }
    var c=normalizar(cod);
    return '<svg class="ean" viewBox="0 0 113 60" role="img" aria-label="Código '+c+'">'+r+'<text x="56.5" y="59" font-size="9" text-anchor="middle" font-family="monospace">'+c+'</text></svg>';
  }
  var api={ean13Bits:ean13Bits, ean13SVG:ean13SVG};
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
  else { raiz.ean13Bits=ean13Bits; raiz.ean13SVG=ean13SVG; }
})(this);
