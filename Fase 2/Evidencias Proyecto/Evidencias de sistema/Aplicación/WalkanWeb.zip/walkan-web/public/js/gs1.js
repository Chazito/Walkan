// gs1.js — lee el código GS1-128 / DataMatrix de un envase y saca GTIN, lote y vencimiento.
// IA 01 = GTIN (14), IA 17 = vencimiento AAMMDD, IA 10 = lote (largo variable, hasta 20).
// Acepta la forma con paréntesis "(01)…(17)261115(10)L123" y la cruda que manda el lector,
// donde los campos de largo variable terminan con el separador GS (\x1d, FNC1).
// Un EAN-13 normal no trae lote ni vencimiento: devuelve {} y se ingresan a mano.
// Es pura a propósito: la prueba scripts/check-lotes.js la carga con require().
(function(raiz){
  var FIJOS={'00':18,'01':14,'02':14,'11':6,'12':6,'13':6,'15':6,'16':6,'17':6};
  // AAMMDD -> AAAA-MM-DD. Día 00 = último día del mes (regla GS1). Siglo 20xx.
  function fecha(s){
    if(!/^\d{6}$/.test(s)) return '';
    var a=2000+(+s.slice(0,2)), m=+s.slice(2,4), d=+s.slice(4,6);
    if(m<1||m>12) return '';
    if(d===0) d=new Date(Date.UTC(a,m,0)).getUTCDate();
    return a+'-'+('0'+m).slice(-2)+'-'+('0'+d).slice(-2);
  }
  function parseGS1(txt){
    var s=String(txt||'').trim().replace(/^\][A-Za-z]\d/,''), ia={}, m;
    if(s.indexOf('(')>-1){
      var re=/\((\d{2,4})\)([^(]*)/g;
      while((m=re.exec(s))) ia[m[1]]=m[2].replace(/\x1d/g,'').trim();
    } else {
      s=s.replace(/^\x1d/,'');
      var i=0;
      while(i<s.length){
        var c=s.substr(i,2);
        if(FIJOS[c]){ if(s.length<i+2+FIJOS[c]) break; ia[c]=s.substr(i+2,FIJOS[c]); i+=2+FIJOS[c]; if(s[i]==='\x1d') i++; }
        else if(c==='10'||c==='21'){ var fin=s.indexOf('\x1d',i+2); if(fin<0) fin=s.length; ia[c]=s.slice(i+2,fin); i=fin+1; }
        else break; // IA desconocida: se deja de leer
      }
      // Si no empezó con una IA conocida (ej. un EAN-13 suelto) no se inventa nada.
      if(!ia['01']&&!ia['17']&&!ia['10']) return {};
    }
    var r={};
    if(ia['01']) r.gtin=ia['01'];
    if(ia['10']) r.lote=ia['10'].slice(0,20);
    if(ia['17']&&fecha(ia['17'])) r.vence=fecha(ia['17']);
    return r;
  }
  if(typeof module!=='undefined'&&module.exports) module.exports={parseGS1:parseGS1};
  else raiz.parseGS1=parseGS1;
})(this);
