// Parte de panel.js: el servidor junta public/js/panel/*.js en orden (ver views.controller.ts) dentro de un solo
// (function(){ … })(), así que todo comparte el mismo scope. No es un módulo suelto: no cargarlo solo.
  // ---------------- goto delegado (alertas / links) ----------------
  // Con data-f (alertas del resumen) además deja Inventario filtrado: agotados, bajo stock o por vencer.
  // Con data-alzas (alerta "Subió el costo…") abre además la lista de alzas.
  document.addEventListener('click', function(e){ var g=e.target.closest('[data-goto]'); if(!g) return; e.preventDefault(); ir(g.dataset.goto);
    var ch=g.dataset.f&&document.querySelector('#chipsInv .chip[data-f="'+g.dataset.f+'"]'); if(ch) ch.click();
    if(g.dataset.alzas) verAlzas(); });
  // Productos cuyo costo subió en 30 días (db.alzas, de /api/inventario/alzas): antes → ahora y un atajo para revisar el precio.
  function verAlzas(){
    var al=db.alzas||[];
    abrirModal('Subió el costo',
      '<p class="intro" style="margin:0 0 12px">Estos productos te están costando más que hace un mes. Revisa su precio de venta si quieres mantener tu margen.</p>'+
      '<table><thead><tr><th>Producto</th><th>Proveedor</th><th>Costo</th><th>Alza</th><th></th></tr></thead><tbody>'+
      (al.map(function(a){ return '<tr><td>'+esc(a.nombre)+'</td><td class="muted">'+esc(a.proveedor||'—')+'</td><td>'+clp(a.antes)+' → <b>'+clp(a.ahora)+'</b></td><td><span class="tag warn">+'+Number(a.pct)+'%</span></td><td><button class="mini" data-alza-edit="'+esc(a.id)+'" aria-label="Revisar precio de '+esc(a.nombre)+'">Revisar precio</button></td></tr>'; }).join('')||'<tr><td colspan="5" class="muted">Ningún costo subió este mes.</td></tr>')+'</tbody></table>');
    $('modalBody').querySelector('tbody').addEventListener('click', function(e){ var b=e.target.closest('[data-alza-edit]'), p=b&&prodPorId(b.dataset.alzaEdit); if(p) formProducto(p); });
  }
  // Los atajos (alertas, "Ver inventario →") no son <a>: Enter los activa igual que un click.
  document.addEventListener('keydown', function(e){ if(e.key==='Enter'&&e.target.matches('[data-goto][tabindex]')) e.target.click(); });

  // ---------------- init ----------------
  // Pone el nombre del negocio y las iniciales del avatar en el sidebar.
  function aplicarUsuario(u){
    if(!u) return;
    cuenta=u;
    var neg = u.negocio || u.nombre || 'Mi negocio';
    var nEl=$('uNegocio'); if(nEl) nEl.textContent=neg;
    var av=$('uAvatar'); if(av) av.textContent=(neg.split(/\s+/).map(function(w){return w[0]||'';}).join('').slice(0,2)||'W').toUpperCase();
  }
  // Situación del plan (viene en /api/auth/me): franja de aviso arriba y, si la cuenta está en pausa, el panel se
  // queda solo en Mi cuenta. Devuelve true si está en pausa (no hay datos que cargar: la API responde 403).
  function aplicarVigencia(v){
    var el=$('avisoPlan'); if(!v||!el) return false;
    var f=fmtFecha(v.vigenteHasta), html='', mal=false;
    if(v.situacion==='por-vencer') html='Tu plan vence el <b>'+esc(f)+'</b>. <a href="#plan" data-goto="plan">Renovar ahora →</a>';
    else if(v.situacion==='gracia') html='Tu plan venció el <b>'+esc(f)+'</b>. Paga antes del <b>'+esc(fmtFecha(v.pausaEl))+'</b> para que tu panel no quede en pausa. <a href="#plan" data-goto="plan">Pagar renovación →</a>';
    else if(v.situacion==='cancelada') html='Cancelaste tu plan: tienes acceso hasta el <b>'+esc(f)+'</b>. <a href="#plan" data-goto="plan">Ver Mi plan →</a>';
    else if(v.situacion==='vencida'){ mal=true; html='<b>Tu panel está en pausa.</b> '+(v.cancelado?'Tu plan terminó el ':'Tu plan venció el ')+esc(f)+'. Tu caja sigue vendiendo en el local y sus ventas se sincronizan cuando pagues la renovación. <a href="#plan" data-goto="plan">Ir a Mi plan →</a>'; }
    else if(v.situacion==='cerrada'){ mal=true; html='<b>Cerraste tu cuenta.</b> Tus datos se eliminarán el '+esc(fmtFecha(v.eliminarEn))+'. Hasta ese día puedes descargarlos o recuperar la cuenta. <a href="#cuenta" data-goto="cuenta">Ir a Mi cuenta →</a>'; }
    el.innerHTML=html; el.classList.toggle('bad', mal); el.hidden=!html;
    if(v.operativa) return false;
    vistaPausa=v.situacion==='cerrada'?'cuenta':'plan';
    document.body.classList.add('en-pausa');
    mostrar(DE_CUENTA[location.hash.slice(1)]?location.hash.slice(1):vistaPausa);
    return true;
  }
  function errorDeCarga(status, mensaje){
    var el=$('avisoPlan'); if(!el) return;
    var txt = status===429 ? 'Hiciste muchas peticiones seguidas. Espera un minuto y recarga la página.'
      : status===403 ? (mensaje||'Tu cuenta no está habilitada.')
      : status===0 ? 'No hay conexión con Walkan. Revisa tu internet y recarga la página.'
      : 'Walkan no respondió bien (error '+status+'). Recarga la página en unos segundos.';
    el.textContent=txt; el.classList.add('bad'); el.hidden=false;
  }
  var elLogout=$('logout');
  if(elLogout) elLogout.addEventListener('click', function(e){ e.preventDefault(); fetch('/api/auth/logout',{method:'POST'}).then(function(){ window.location.href='/mi-cuenta'; }); });

  // Recarga lo que cambia al comprar/recibir (PC = productos + compras, más pedidos y predicción).
  var URL_POR_VENCER='/api/lotes/por-vencer?dias=30';
  // Solo la lista "Vender primero" (tras un ajuste o un producto nuevo).
  function recargarLotes(){ return API.get(URL_POR_VENCER).then(function(l){ db.porVencer=l; renderResumen(); }); }
  function recargarPC(){
    return Promise.all([API.get('/api/productos'), API.get('/api/pedidos'), API.get('/api/compras'), API.get('/api/inventario/prediccion'), API.get(URL_POR_VENCER)]).then(function(r){
      db.productos=r[0]; db.pedidos=r[1]; db.compras=r[2]; db.prediccion=r[3]; db.porVencer=r[4];
      renderInventario(); renderPedidos(); renderCompras(); renderAnaliticas(); renderResumen();
    });
  }
  // Costo FIFO de lo vendido hoy (objeto {costo}, no arreglo): para la ganancia estimada del Resumen. Falla = null.
  function pedirCostoHoy(){ var h=hoyISO(); return fetch('/api/inventario/costo-ventas?desde='+h+'&hasta='+h).then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); }).then(function(c){ return c.costo; }).catch(function(){ return null; }); }
  // Ventas nuevas de la caja: se refresca cada 30 s (sin interrumpir un modal abierto).
  // Cada request que falla devuelve null y ese dato se queda como estaba: un corte de red no vacía el panel.
  function recargarVentas(){
    var h=hoyISO(), n=++ventasSeq, o=function(u){ return API.lista(u).catch(function(){ return null; }); };
    return Promise.all([o(urlVentas()), o('/api/ventas?desde='+h+'&hasta='+h), o('/api/productos'), o('/api/inventario/prediccion'), o('/api/cajas'), o(URL_POR_VENCER), o('/api/proveedores'), pedirCostoHoy()]).then(function(r){
      if(n===ventasSeq&&r[0]) db.ventas=r[0]; // si el filtro cambió mientras tanto, gana el filtro
      ['ventasHoy','productos','prediccion','cajas','porVencer','proveedores','costoHoy'].forEach(function(k,i){ if(r[i+1]!=null) db[k]=r[i+1]; }); // proveedores: por si otra pestaña borró uno
      renderVentas(); renderInventario(); renderAnaliticas(); renderCajas(); renderProveedores(); actualizarTopbar();
      recargarPendientes(); // ventas nuevas de la caja con códigos que el inventario no tiene
    });
  }
  // Si en otra pestaña se entró con otra cuenta, esta seguiría con los proveedores y productos de la anterior
  // y el servidor los rechazaría ("ese proveedor ya no existe"): al volver a la pestaña se revisa y se recarga.
  document.addEventListener('visibilitychange', function(){
    if(document.hidden||!cuenta.id||modal.classList.contains('open')||vistaPausa) return; // no se pierde un formulario a medio llenar
    fetch('/api/auth/me').then(function(r){ if(r.status===401){ window.location.href='/mi-cuenta'; return null; } return r.ok?r.json():null; })
      .then(function(m){ if(m&&m.usuario&&m.usuario.id!==cuenta.id) window.location.reload(); }).catch(function(){});
  });
  // Tampoco recarga si la pestaña está en segundo plano, para no gastar requests.
  setInterval(function(){ if(!modal.classList.contains('open') && !document.hidden && !vistaPausa) recargarVentas(); }, 30000);

  // Chequeo de sesión: sin sesión -> al login. Con sesión -> hidrata todo.
  // Solo un 401 (sin sesión o vencida) manda al login. Otro error (cuenta suspendida 403, demasiadas peticiones 429,
  // servidor caído 5xx) no cierra la sesión: se muestra arriba y se puede reintentar recargando.
  fetch('/api/auth/me').then(function(r){
      if(r.status===401){ window.location.href='/mi-cuenta'; return null; }
      if(!r.ok) return r.json().catch(function(){ return {}; }).then(function(d){ errorDeCarga(r.status, d&&d.message); return null; });
      return r.json();
    }, function(){ errorDeCarga(0); return null; })
    .then(function(m){
      if(!m) return;
      aplicarUsuario(m.usuario);
      if(aplicarVigencia(m.vigencia)){ renderPlan(); return; } // en pausa: solo Mi cuenta
      return Promise.all([API.get('/api/proveedores'), API.get('/api/productos'), API.get('/api/ventas'), API.get('/api/pedidos'), API.get('/api/compras'), API.get('/api/cajas'), API.get('/api/ventas?desde='+hoyISO()+'&hasta='+hoyISO()), API.get('/api/inventario/prediccion'), API.get(URL_POR_VENCER)]).then(function(res){
        db.proveedores=res[0]; db.productos=res[1]; db.ventas=res[2]; db.pedidos=res[3]; db.compras=res[4]; db.cajas=res[5]; db.ventasHoy=res[6]; db.prediccion=res[7]; db.porVencer=res[8];
        renderProveedores(); renderInventario(); renderVentas(); renderPedidos(); renderCompras(); renderCajas(); renderAnaliticas(); renderPlan(); renderResumen(); actualizarTopbar();
        recargarMermas(); recargarDias(); compararPeriodos(); recargarCajeros(); cargarTransferencia(); cargarFlow();
        API.get('/api/ventas?desde='+diaAtras(7)+'&hasta='+diaAtras(7)).then(function(v){ db.semanaPasada=v; renderResumen(); });
        // SKUs de archivados: sus ventas antiguas no deben salir como "códigos no reconocidos".
        API.get('/api/productos/archivados').then(function(a){ db.archivados=a; renderNoReconocidos(); });
        // Parámetros del negocio (umbral de stock bajo): objeto, no arreglo, por eso va con fetch directo.
        // También trae costoConIva, que cambia todos los márgenes: por eso se repintan Inventario y Analíticas.
        fetch('/api/inventario/config').then(function(r){ return r.ok?r.json():null; }).then(function(c){ if(c){ db.config=c; renderInventario(); renderAnaliticas(); } }).catch(function(){});
        pedirCostoHoy().then(function(c){ db.costoHoy=c; renderResumen(); });
        API.get('/api/inventario/alzas?dias=30').then(function(a){ db.alzas=a; renderResumen(); });
      });
    })
    .catch(function(e){ console.error('No se pudo cargar el panel', e); });
})();
