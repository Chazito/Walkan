// ayuda.js — centro de ayuda (/ayuda: buscador y temas) y formulario de contacto sin sesión (/ayuda/contacto).
(function(){
  var $=function(id){ return document.getElementById(id); };
  var norm=function(s){ return String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,''); };

  // ---- Buscador y temas ----
  var q=$('ayBuscar');
  if(q){
    var preguntas=[].slice.call(document.querySelectorAll('.ay-q')), grupos=[].slice.call(document.querySelectorAll('.ay-grupo'));
    var temas=[].slice.call(document.querySelectorAll('.ay-tema')), cat='';
    preguntas.forEach(function(p){ p._txt=norm(p.textContent); });
    function filtrar(){
      var palabras=norm(q.value).split(/\s+/).filter(function(w){ return w.length>1; }), visibles=0;
      preguntas.forEach(function(p){
        var ok=(!cat || p.dataset.cat===cat) && palabras.every(function(w){ return p._txt.indexOf(w)>=0; });
        p.hidden=!ok; if(ok) visibles++;
        if(palabras.length && ok && visibles<=3) p.open=true; // con búsqueda, abre las primeras coincidencias
      });
      grupos.forEach(function(g){ g.hidden=!g.querySelector('.ay-q:not([hidden])'); });
      $('ayVacio').hidden=visibles>0;
    }
    q.addEventListener('input', filtrar);
    temas.forEach(function(b){ b.addEventListener('click', function(){
      cat=b.dataset.cat; temas.forEach(function(x){ x.setAttribute('aria-pressed', x===b ? 'true' : 'false'); }); filtrar();
    }); });
    // Enlace directo a una pregunta (/ayuda#olvide-contrasena): se abre.
    var h=location.hash.slice(1), d=h && document.getElementById(h);
    if(d && d.tagName==='DETAILS') d.open=true;
    if(q.value) filtrar(); // el navegador puede dejar escrito lo de la visita anterior
  }

  // ---- Formulario de contacto sin sesión ----
  var f=$('ayForm');
  if(f){
    var msg=$('tMsgRes'), b=f.querySelector('button[type="submit"]');
    function mostrar(tipo, texto){
      msg.className='msg msg-'+tipo; msg.innerHTML='<span class="msg-ico" aria-hidden="true">'+(tipo==='error'?'!':'i')+'</span><div class="msg-txt"></div>';
      msg.querySelector('.msg-txt').textContent=texto; msg.hidden=false;
    }
    function rutOk(v){
      var m=String(v).replace(/\./g,'').trim().toUpperCase().match(/^(\d{1,8})-?([\dK])$/); if(!m) return false;
      var s=0, mul=2; for(var i=m[1].length-1;i>=0;i--){ s+=Number(m[1][i])*mul; mul=mul===7?2:mul+1; }
      var dv=11-(s%11); return m[2]===(dv===11?'0':dv===10?'K':String(dv));
    }
    $('tCat').addEventListener('change', function(){ $('tVerif').hidden=this.value!=='acceso'; });
    f.addEventListener('input', function(){ msg.hidden=true; });
    f.addEventListener('submit', function(ev){
      ev.preventDefault();
      var d={ nombre:$('tNombre').value.trim(), email:$('tEmail').value.trim(), categoria:$('tCat').value, asunto:$('tAsunto').value.trim(), mensaje:$('tMsg').value.trim() };
      var rut=$('tRut').value.trim(), orden=$('tOrden').value.trim(), web=$('tWeb').value;
      if(d.nombre.length<2){ mostrar('error','Escribe tu nombre.'); $('tNombre').focus(); return; }
      if(!$('tEmail').checkValidity() || !d.email){ mostrar('error','Escribe un correo válido.'); $('tEmail').focus(); return; }
      if(!d.categoria){ mostrar('error','Elige un tema.'); $('tCat').focus(); return; }
      if(d.categoria==='acceso' && rut && !rutOk(rut)){ mostrar('error','Ese RUT no es válido: revisa el dígito verificador.'); $('tRut').focus(); return; }
      if(d.asunto.length<4){ mostrar('error','Escribe un asunto.'); $('tAsunto').focus(); return; }
      if(d.mensaje.length<10){ mostrar('error','Cuéntanos un poco más (al menos 10 letras).'); $('tMsg').focus(); return; }
      if(d.categoria==='acceso'){ if(rut) d.rut=rut; if(orden) d.ordenPago=orden; }
      if(web) d.web=web;
      b.disabled=true; b.textContent='Enviando…';
      fetch('/api/soporte/publico', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(d) })
        .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(x){ return { ok:r.ok, status:r.status, d:x }; }); })
        .then(function(res){
          if(!res.ok){ var m=res.d && res.d.message; throw new Error(res.status===429 && !m ? 'Demasiados intentos. Espera un momento e inténtalo de nuevo.' : (Array.isArray(m)?m[0]:m) || 'No se pudo enviar.'); }
          f.reset(); $('tVerif').hidden=true;
          mostrar('aviso', (res.d.numero ? 'Solicitud '+res.d.numero+'. ' : '')+res.d.mensaje);
          b.textContent='Solicitud enviada';
        })
        .catch(function(e){ b.disabled=false; b.textContent='Enviar solicitud'; mostrar('error', e instanceof TypeError ? 'No hay conexión con el servidor. Inténtalo de nuevo.' : e.message); });
    });
  }
})();
