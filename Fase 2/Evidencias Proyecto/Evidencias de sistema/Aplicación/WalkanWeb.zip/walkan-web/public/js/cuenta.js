// cuenta.js — sección "Mi cuenta" (views/partials/cuenta.ejs), la misma en /panel y en /admin.
// Muestra los datos del usuario en sesión y permite cambiar la contraseña con POST /api/auth/password, que además
// pide un código: el de la app de dos pasos o uno que llega al correo (POST /api/auth/password/codigo).
// Los mensajes van dentro de la página (no alert()).
(function(){
  var f=document.getElementById('formClave');
  if(!f) return;
  var $=function(id){ return document.getElementById(id); };
  var msg=$('claveMsg'), btn=$('claveBtn');
  var ROLES={ staff:'Equipo Walkan', admin:'Dueño del negocio', cajero:'Cajero' };

  function mostrar(tipo, texto){ msg.className='cuenta-msg '+tipo; msg.textContent=texto; msg.hidden=false; }
  function limpiar(){ msg.hidden=true; }
  ['claveActual','claveNueva','claveRepite','claveCodigo'].forEach(function(id){ $(id).addEventListener('input', limpiar); });
  if(window.WalkanClave) WalkanClave.montar($('claveNueva'), $('claveReglasCuenta'));

  // Datos de la cuenta (solo lectura).
  fetch('/api/auth/me').then(function(r){ return r.ok ? r.json() : null; }).then(function(m){
    var u=m && m.usuario; if(!u) return;
    $('cuentaUser').value=u.email || '';
    var filas=[['Nombre', u.nombre], ['Correo', u.email], ['Negocio', u.negocio], ['Perfil', ROLES[u.rol] || u.rol]];
    var kv=$('cuentaDatos'); kv.innerHTML='';
    filas.forEach(function(f){ if(!f[1]) return;
      var a=document.createElement('span'); a.className='muted'; a.textContent=f[0];
      var b=document.createElement('b'); b.textContent=f[1]; kv.appendChild(a); kv.appendChild(b); });
    prepararBaja(u, m.vigencia);
  }).catch(function(){});

  // Segundo factor para cambiar la contraseña: código de la app de dos pasos o, si no la usa, uno que llega al correo.
  var conApp=false;
  $('claveCodigoBtn').addEventListener('click', function(){
    var b=this; b.disabled=true; limpiar();
    fetch('/api/auth/password/codigo', { method:'POST' })
      .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){ return { ok:r.ok, d:d }; }); })
      .then(function(res){
        if(!res.ok) throw new Error((res.d && res.d.message) || 'No se pudo enviar el código.');
        if(res.d.metodo==='app'){ mostrar('ok','Usa el código de tu app de verificación.'); return; }
        if(res.d.estado==='error') throw new Error('No pudimos enviar el correo. Inténtalo de nuevo en unos minutos.');
        mostrar('ok','Te enviamos un código a '+(res.d.destino||'tu correo')+'. Vale 10 minutos. Si no lo ves, revisa la carpeta de spam.');
        $('claveCodigo').focus();
      })
      .catch(function(e){ mostrar('error', e instanceof TypeError ? 'No hay conexión con el servidor. Inténtalo de nuevo.' : e.message); })
      .then(function(){ setTimeout(function(){ b.disabled=false; }, 60000); });
  });

  // Dispositivos recordados (solo dueños): cuántos hay y olvidarlos todos, por si pierde un equipo.
  function pintarDisp(n){
    if(!$('dispBloque')) return;
    $('dispBloque').hidden = !n;
    $('dispTexto').textContent = n===1 ? 'Hay 1 dispositivo recordado: ahí no se pide el código al entrar (la contraseña sí).' : 'Hay '+n+' dispositivos recordados: ahí no se pide el código al entrar (la contraseña sí).';
  }
  fetch('/api/auth/dispositivos').then(function(r){ return r.ok ? r.json() : null; }).then(function(d){ if(d) pintarDisp(d.recordados); }).catch(function(){});
  if($('dispOlvidar')) $('dispOlvidar').addEventListener('click', function(){
    var b=this; b.disabled=true;
    fetch('/api/auth/dispositivos/olvidar', { method:'POST' })
      .then(function(r){ if(!r.ok) throw new Error(); $('dispTexto').textContent='Listo: en todos los equipos se volverá a pedir el código al entrar.'; b.hidden=true; })
      .catch(function(){ $('dispTexto').textContent='No se pudo completar. Inténtalo de nuevo.'; })
      .then(function(){ b.disabled=false; });
  });

  // Verificación en dos pasos: estado y enlace a /dos-pasos (ahí se activa, se generan códigos o se desactiva).
  fetch('/api/auth/dos-pasos').then(function(r){ return r.ok ? r.json() : null; }).then(function(e){
    if(!e || !$('dpEstado')) return;
    if(e.activo){
      // Con dos pasos, el código para cambiar la contraseña sale de la app (no se manda correo).
      conApp=true; $('claveCodigoLbl').textContent='Código de tu app de verificación'; $('claveCodigoBtn').hidden=true;
      $('claveCodigoAyuda').textContent='Abre tu app de verificación y escribe el código de 6 dígitos (o uno de respaldo).';
      $('dpEstado').textContent='Activa'+(e.desde?' desde el '+new Date(e.desde).toLocaleDateString('es-CL'):'')+'. Te quedan '+e.respaldosRestantes+' código'+(e.respaldosRestantes===1?'':'s')+' de respaldo.';
      $('dpIr').textContent='Administrar';
    } else if(e.obligatorio){ $('dpEstado').textContent='Obligatoria para el equipo Walkan.'; }
  }).catch(function(){});

  // Tus datos y tu cuenta (solo el dueño de un negocio): descargar los datos, eliminar la cuenta o recuperarla.
  // Eliminar cierra la cuenta de inmediato y el servidor borra los datos a los 30 días; pide la contraseña.
  function prepararBaja(u, vig){
    var bloque=$('bajaBloque'); if(!bloque || u.rol!=='admin' || !u.clienteId) return;
    var bm=$('bajaMsg'), form=$('bajaForm');
    function bmsg(tipo, texto){ bm.className='cuenta-msg '+tipo; bm.textContent=texto; bm.hidden=!texto; }
    function post(ruta, cuerpo){
      return fetch(ruta, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(cuerpo||{}) })
        .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){
          if(!r.ok){ var mm=d && d.message; throw new Error(Array.isArray(mm) ? mm[0] : (mm || 'No se pudo completar. Intenta de nuevo.')); }
          return d; }); });
    }
    var cerrada=!!(vig && vig.situacion==='cerrada');
    $('bajaAbierta').hidden=cerrada; $('bajaCerrada').hidden=!cerrada;
    if(cerrada){
      var dia=new Date(vig.eliminarEn).toLocaleDateString('es-CL',{ day:'numeric', month:'long', year:'numeric' });
      $('bajaCerradaTxt').textContent='Tu cuenta está cerrada y tus datos se eliminarán el '+dia+'. Si cambiaste de idea, recupérala antes de ese día.';
    }
    bloque.hidden=false;
    $('bajaEliminar').addEventListener('click', function(){ this.hidden=true; form.hidden=false; bmsg('',''); $('bajaClave').focus(); });
    $('bajaVolver').addEventListener('click', function(){ form.hidden=true; form.reset(); $('bajaEliminar').hidden=false; bmsg('',''); });
    form.addEventListener('submit', function(ev){
      ev.preventDefault(); var clave=$('bajaClave').value, b=$('bajaConfirmar');
      if(!clave){ bmsg('error','Escribe tu contraseña para confirmar.'); return; }
      b.disabled=true;
      post('/api/cuenta/eliminar', { password: clave }).then(function(){ window.location.reload(); })
        .catch(function(e){ b.disabled=false; bmsg('error', e instanceof TypeError ? 'No hay conexión con el servidor. Inténtalo de nuevo.' : e.message); });
    });
    $('bajaRecuperar').addEventListener('click', function(){
      var b=this; b.disabled=true;
      post('/api/cuenta/recuperar').then(function(){ window.location.reload(); })
        .catch(function(e){ b.disabled=false; bmsg('error', e.message); });
    });
  }

  // Privacidad (Ley 21.719): versión aceptada y consentimiento de marketing, que se puede retirar acá.
  // Cada cambio agrega una fila al historial de consentimientos (no se sobrescribe).
  function pintarPriv(e){
    if(!e || !e.privacidad) return;
    var fecha=new Date(e.privacidad.fecha).toLocaleDateString('es-CL',{ day:'numeric', month:'long', year:'numeric' });
    $('privAceptada').textContent='Aceptaste los Términos y la Política de Privacidad (versión '+e.privacidad.version+') el '+fecha+'.';
    $('privMarketing').checked=!!(e.marketing && e.marketing.aceptado);
    $('privBloque').hidden=false;
  }
  if($('privBloque')){
    fetch('/api/privacidad/estado').then(function(r){ return r.ok ? r.json() : null; }).then(pintarPriv).catch(function(){});
    $('privMarketing').addEventListener('change', function(){
      var chk=this, valor=chk.checked, pm=$('privMsg'); chk.disabled=true;
      fetch('/api/privacidad/marketing',{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ aceptado:valor }) })
        .then(function(r){ if(!r.ok) throw new Error(); return r.json(); })
        .then(function(e){ pintarPriv(e); pm.className='cuenta-msg ok'; pm.textContent=valor?'Listo: te enviaremos novedades.':'Listo: ya no te enviaremos novedades.'; pm.hidden=false; })
        .catch(function(){ chk.checked=!valor; pm.className='cuenta-msg error'; pm.textContent='No se pudo guardar. Intenta de nuevo.'; pm.hidden=false; })
        .then(function(){ chk.disabled=false; });
    });
  }

  f.addEventListener('submit', function(ev){
    ev.preventDefault(); limpiar();
    var actual=$('claveActual').value, nueva=$('claveNueva').value, rep=$('claveRepite').value;
    if(!actual || !nueva || !rep){ mostrar('error','Completa los tres campos.'); return; }
    var mc = window.WalkanClave ? WalkanClave.mensaje(nueva) : (nueva.length<8 ? 'La nueva contraseña debe tener al menos 8 caracteres.' : '');
    if(mc){ mostrar('error', mc); $('claveNueva').focus(); return; }
    if(nueva!==rep){ mostrar('error','La nueva contraseña y su repetición no coinciden.'); $('claveRepite').focus(); return; }
    if(nueva===actual){ mostrar('error','La nueva contraseña debe ser distinta de la actual.'); return; }
    var codigo=$('claveCodigo').value.trim();
    if(!codigo){ mostrar('error', conApp ? 'Escribe el código de tu app de verificación.' : 'Pide el código con "Enviarme el código" y escríbelo.'); $('claveCodigo').focus(); return; }
    btn.disabled=true; btn.textContent='Guardando…';
    fetch('/api/auth/password', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ actual:actual, nueva:nueva, codigo:codigo }) })
      .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){ return { ok:r.ok, d:d }; }); })
      .then(function(res){
        if(!res.ok){ var m=res.d && res.d.message; throw new Error(Array.isArray(m) ? m[0] : (m || 'No se pudo cambiar la contraseña.')); }
        f.reset(); $('claveNueva').dispatchEvent(new Event('input'));
        mostrar('ok','Listo: tu contraseña quedó actualizada. Por seguridad, se cerraron las sesiones abiertas en otros equipos.');
      })
      .catch(function(e){ mostrar('error', e instanceof TypeError ? 'No hay conexión con el servidor. Inténtalo de nuevo.' : e.message); })
      .then(function(){ btn.disabled=false; btn.textContent='Guardar contraseña'; });
  });
})();
