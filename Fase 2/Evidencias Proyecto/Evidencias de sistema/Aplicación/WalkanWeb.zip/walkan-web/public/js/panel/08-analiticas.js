// Parte de panel.js: el servidor junta public/js/panel/*.js en orden (ver views.controller.ts) dentro de un solo
// (function(){ … })(), así que todo comparte el mismo scope. No es un módulo suelto: no cargarlo solo.
  // ================= ANALÍTICAS =================
  // Todo sale de /api/inventario/prediccion: top 6 por ingreso (con su clase ABC) y la tabla de
  // reposición ordenada por urgencia. El "28" es porque la venta diaria se calcula sobre 4 semanas.
  var estadoPred={agotado:{c:'bad',t:'Agotado'},reponer:{c:'warn',t:'Reponer'},ok:{c:'ok',t:'OK'},insuficiente:{c:'mut',t:'Pocos datos'}};
  var predMax=100;
  function renderAnaliticas(){
    var tp=$('topProd'); if(!tp) return;
    var pred=db.prediccion||[];
    var top=pred.filter(function(r){return r.ingreso>0;}).sort(function(a,b){return b.ingreso-a.ingreso;}).slice(0,6);
    tp.innerHTML=top.length?top.map(function(r){return '<tr><td>'+esc(r.nombre)+'</td><td><span class="tag '+(r.abc==='A'?'ok':r.abc==='B'?'warn':'mut')+'">'+esc(r.abc)+'</span></td><td>'+Math.round(r.ventaDiaria*28)+'</td><td>'+clp(r.ingreso)+'</td></tr>';}).join(''):'<tr><td colspan="4" class="muted" style="text-align:center;padding:20px">Aún no hay datos de ventas.</td></tr>';
    // Ganancia por categoría (28 días): ingreso de la predicción (unidades × precio) menos unidades × costo actual.
    // Solo cuenta la ganancia de productos con costo cargado; ganancia y margen sin IVA, igual que margen().
    if($('catBody')){
      var cats={};
      pred.forEach(function(r){ if(!r.ingreso) return; var p=prodPorId(r.id); if(!p) return; var c=cats[p.cat]=cats[p.cat]||{n:p.cat,v:0,vc:0,g:0};
        c.v+=r.ingreso; if(p.costo&&p.precio){ var u=r.ingreso/p.precio, neta=r.ingreso/1.19; c.vc+=neta; c.g+=neta-u*costoNeto(p.costo); } });
      $('catBody').innerHTML=Object.keys(cats).map(function(k){ return cats[k]; }).sort(function(a,b){ return b.g-a.g||b.v-a.v; }).map(function(c){ var m=c.vc?Math.round(c.g/c.vc*100):null;
        return '<tr><td class="prin"><b>'+esc(c.n)+'</b></td><td data-l="Ventas">'+clp(c.v)+'</td><td data-l="Ganancia">'+(c.vc?clp(Math.round(c.g)):'—')+'</td><td data-l="Margen">'+(m==null?'—':'<span class="tag '+(m<10?'bad':m<20?'warn':'ok')+'">'+m+'%</span>')+'</td></tr>'; }).join('')||'<tr><td colspan="4" class="muted" style="text-align:center;padding:16px">Aún no hay ventas en las últimas 4 semanas.</td></tr>';
    }
    // Inventario detenido: con stock, con al menos 7 días de historia (si no, "Pocos datos") y sin ventas en 28 días.
    var valor=valorInventario(db.productos).total.costo;
    if($('valorInv')) $('valorInv').textContent=clp(valor);
    var det=pred.filter(function(r){ return r.stock>0&&r.ventaDiaria===0&&r.estado!=='insuficiente'; }).map(function(r){ var p=prodPorId(r.id)||{}; return {r:r, c:r.stock*(p.costo||0)}; }).sort(function(a,b){ return b.c-a.c; });
    if($('detenidoBody')){
      var tot=det.reduce(function(s,x){ return s+x.c; },0);
      $('detenidoIntro').textContent=det.length?det.length+' producto'+(det.length>1?'s':'')+' con stock y sin ventas en 4 semanas: '+clp(tot)+' a costo.':'Con stock y sin ventas en las últimas 4 semanas.';
      $('detenidoBody').innerHTML=det.slice(0,10).map(function(x){ return '<tr><td class="prin"><b>'+esc(x.r.nombre)+'</b></td><td data-l="Stock">'+fmtCant(prodPorId(x.r.id),x.r.stock)+'</td><td data-l="A costo">'+clp(x.c)+'</td></tr>'; }).join('')||'<tr><td colspan="3" class="muted" style="text-align:center;padding:16px">Todo lo que tienes se está vendiendo.</td></tr>';
    }
    var pb=$('predBody'); if(!pb) return;
    var orden={agotado:0,reponer:1,insuficiente:2,ok:3};
    // Con miles de productos la tabla era inmensa y Analíticas no terminaba de cargar: se muestran los más urgentes
    // (predMax, de a 100) y un botón para ver más. El orden pone primero lo agotado y lo que hay que reponer.
    var ordenada=pred.slice().sort(function(a,b){return orden[a.estado]-orden[b.estado]||b.sugerida-a.sugerida;});
    var masBtn=$('predMas');
    if(!masBtn){ masBtn=document.createElement('div'); masBtn.id='predMas'; masBtn.className='pager'; pb.closest('table').insertAdjacentElement('afterend', masBtn);
      masBtn.addEventListener('click', function(e){ if(e.target.closest('button')){ predMax+=100; renderAnaliticas(); } }); }
    var f=function(n){ return n.toLocaleString('es-CL'); };
    masBtn.hidden=ordenada.length<=predMax;
    masBtn.innerHTML='<span class="muted small" aria-live="polite">Mostrando '+f(Math.min(predMax,ordenada.length))+' de '+f(ordenada.length)+' productos (primero lo más urgente)</span><button type="button" class="mini">Ver 100 más</button>';
    pb.innerHTML=ordenada.slice(0,predMax).map(function(r){
      var e=estadoPred[r.estado]||estadoPred.ok;
      return '<tr><td><b>'+esc(r.nombre)+'</b></td><td>'+fmtCant(prodPorId(r.id),r.stock)+'</td><td>'+fmtCant(null,r.ventaDiaria)+'</td><td>'+(r.diasStock==null?'—':Number(r.diasStock)+' d')+'</td><td>'+Number(r.puntoReorden)+'</td><td><b>'+(Number(r.sugerida)||'—')+'</b></td><td><span class="tag '+e.c+'">'+e.t+'</span></td></tr>';
    }).join('')||'<tr><td colspan="7" class="muted" style="text-align:center;padding:20px">Agrega productos para ver la predicción.</td></tr>';
  }
  // Ventas por día de los últimos 14 días (días de Chile). Barras con divs, como el gráfico por hora del resumen.
  // El aria-label del gráfico resume el total y el mejor día para lectores de pantalla.
  function recargarDias(){
    var desde=diaAtras(13), hasta=hoyISO();
    return API.get('/api/ventas?desde='+desde+'&hasta='+hasta).then(function(vs){
      var por={}; vs.forEach(function(v){ por[v.fecha]=(por[v.fecha]||0)+(v.total||0); });
      var dias=[]; for(var i=13;i>=0;i--) dias.push(diaAtras(i));
      var vals=dias.map(function(d){ return por[d]||0; }), max=Math.max.apply(null,vals), tot=vals.reduce(function(s,x){return s+x;},0);
      var ch=$('chartDias'); if(!ch) return;
      $('chartDiasEmpty').hidden=tot>0; ch.style.display=tot>0?'flex':'none';
      $('dias14Total').textContent=tot?'Total '+clp(tot):'';
      var mejor=vals.indexOf(max);
      ch.setAttribute('aria-label','Ventas por día de los últimos 14 días: total '+clp(tot)+(tot?', mejor día '+fmtFecha(dias[mejor])+' con '+clp(max):''));
      ch.innerHTML=vals.map(function(v,i){ var d=dias[i]; return '<div class="bar" style="height:'+(max?Math.max(2,v/max*100):0)+'%" title="'+fmtFecha(d)+': '+clp(v)+'"><span>'+d.slice(8,10)+'</span></div>'; }).join('');
    });
  }

  // Informe del mes para imprimir o guardar como PDF: ventas, ganancia estimada, compras, mermas, inventario y top productos.
  // La ventana se abre al tiro (en el click) para que el navegador no la bloquee, y se llena cuando llegan los datos.
  $('informeMes').addEventListener('click', function(){
    var w=window.open('','_blank'); if(!w){ aviso('El navegador bloqueó la ventana: permite ventanas emergentes para ver el informe.'); return; }
    w.document.write('<p style="font-family:system-ui;padding:24px">Preparando informe…</p>');
    var hoy=hoyISO(), desde=hoy.slice(0,8)+'01', mes=hoy.slice(0,7);
    Promise.all([API.get('/api/ventas?desde='+desde+'&hasta='+hoy), fetch('/api/inventario/mermas').then(function(r){ return r.ok?r.json():{costo:0,porMotivo:[]}; }),
      fetch('/api/inventario/costo-ventas?desde='+desde+'&hasta='+hoy).then(function(r){ return r.ok?r.json():{costo:0}; })]).then(function(r){
      var vs=r[0], mm=r[1], costo=r[2].costo||0;
      var total=0, top={};
      vs.forEach(function(v){ total+=v.total||0; v.items.forEach(function(i){ var m=i[1]*i[2]; var t=top[i[0]]=top[i[0]]||{n:i[0],u:0,m:0}; t.u+=i[1]; t.m+=m; }); });
      // Ganancia = ventas del mes − costo FIFO de lo vendido (mismo criterio de IVA que el Resumen).
      var conCosto=costo>0?(db.config&&db.config.costoConIva?total:total/1.19):0;
      var tops=Object.keys(top).map(function(k){ return top[k]; }).sort(function(a,b){ return b.m-a.m; }).slice(0,10);
      var compras=db.compras.filter(function(c){ return esCompra(c)&&(c.fecha||'').slice(0,7)===mes; }).reduce(function(s,c){ return s+c.total; },0);
      var valor=valorInventario(db.productos).total.costo;
      var det=(db.prediccion||[]).filter(function(x){ return x.stock>0&&x.ventaDiaria===0&&x.estado!=='insuficiente'; });
      var kpi=function(t,v,d){ return '<div class="k"><div class="t">'+t+'</div><div class="v">'+v+'</div>'+(d?'<div class="d">'+d+'</div>':'')+'</div>'; };
      var tabla=function(cab,filas){ return '<table><thead><tr>'+cab.map(function(c){ return '<th>'+c+'</th>'; }).join('')+'</tr></thead><tbody>'+(filas.join('')||'<tr><td colspan="'+cab.length+'">Sin datos.</td></tr>')+'</tbody></table>'; };
      w.document.open();
      w.document.write('<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Informe '+esc(mes)+' · '+esc(negocio())+'</title><style>'+
        'body{font-family:system-ui,sans-serif;color:#14201a;margin:28px;font-size:11pt}h1{margin:0;font-size:20pt;color:#086640}h2{font-size:13pt;margin:22px 0 6px;color:#086640}'+
        '.sub{color:#556358;margin:4px 0 16px}.g{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.k{border:1px solid #d6e2da;border-radius:10px;padding:10px}.t{font-size:9pt;color:#556358}.v{font-size:15pt;font-weight:800}.d{font-size:8.5pt;color:#556358}'+
        'table{width:100%;border-collapse:collapse;font-size:10pt}th,td{border-bottom:1px solid #e0e8e2;padding:5px 6px;text-align:left}th{background:#eef5f0}td:not(:first-child),th:not(:first-child){text-align:right}'+
        '@media print{body{margin:12mm}}</style></head><body>'+
        '<h1>Informe del mes · '+esc(negocio())+'</h1><p class="sub">Del '+fmtFecha(desde)+' al '+fmtFecha(hoy)+'. Generado por Walkan.</p>'+
        '<div class="g">'+kpi('Ventas',clp(total),vs.length+' comprobantes · ticket '+clp(vs.length?Math.round(total/vs.length):0))+
          kpi('Ganancia estimada',conCosto?clp(Math.round(conCosto-costo)):'—',conCosto?Math.round((conCosto-costo)/conCosto*100)+'% sobre lo vendido'+(db.config&&db.config.costoConIva?'':' (sin IVA)'):'carga los costos de tus productos')+
          kpi('Compras ingresadas',clp(compras),'')+kpi('Mermas a costo',clp(mm.costo||0),'')+'</div>'+
        '<h2>Productos más vendidos</h2>'+tabla(['Producto','Unidades','Monto'],tops.map(function(t){ return '<tr><td>'+esc(t.n)+'</td><td>'+t.u+'</td><td>'+clp(t.m)+'</td></tr>'; }))+
        '<h2>Mermas por motivo</h2>'+tabla(['Motivo','Unidades','A costo'],(mm.porMotivo||[]).map(function(x){ return '<tr><td>'+esc(x.nombre)+'</td><td>'+x.unidades+'</td><td>'+clp(x.costo)+'</td></tr>'; }))+
        '<h2>Inventario</h2><div class="g">'+kpi('Valor a costo',clp(valor),db.productos.length+' productos')+kpi('Agotados',db.productos.filter(function(p){ return p.stock<=0; }).length,'')+kpi('Sin ventas en 4 semanas',det.length,'')+kpi('Lotes por vencer (30 d)',(db.porVencer||[]).length,'')+'</div>'+
        '</body></html>');
      w.document.close(); w.focus(); setTimeout(function(){ w.print(); }, 400);
    }).catch(function(){ w.document.body.textContent='No se pudo preparar el informe. Revisa tu conexión.'; });
  });

  // Parámetros del negocio para alertas y reposición (PUT /api/inventario/config).
  $('paramInv').addEventListener('click', function(){
    var c=db.config||{umbralBajo:10,diasSeguridad:2,diasCobertura:7};
    abrirModal('Parámetros de inventario',
      '<p class="intro" style="margin:0 0 12px">Ajusta cómo Walkan decide qué está bajo y cuánto sugiere pedir. Valen para todo tu negocio.</p>'+
      '<div class="form-grid"><div class="f full"><label for="pmUmbral">Stock bajo desde '+ayuda('Un producto sin stock mínimo propio sale como «Bajo» con esta cantidad o menos.')+'</label><input id="pmUmbral" type="number" min="0" max="100000" value="'+Number(c.umbralBajo)+'"></div>'+
      '<div class="f"><label for="pmSeg">Días de colchón '+ayuda('Días extra sobre la entrega del proveedor, por si se atrasa o vendes más de lo normal.')+'</label><input id="pmSeg" type="number" min="0" max="30" value="'+Number(c.diasSeguridad)+'"></div>'+
      '<div class="f"><label for="pmCob">Días que cubre un pedido '+ayuda('Cuántos días de venta quieres cubrir con cada pedido, además de los días de entrega.')+'</label><input id="pmCob" type="number" min="1" max="60" value="'+Number(c.diasCobertura)+'"></div>'+
      '<div class="f full"><label class="check"><input type="checkbox" id="pmIva"'+(c.costoConIva?' checked':'')+'> Mis costos incluyen IVA</label>'+ayuda('Márcalo si anotas los costos con IVA (compras con boleta). Déjalo sin marcar si son netos, como en una factura. Los márgenes siempre se calculan sin IVA.')+'</div></div>'+
      '<div style="display:flex;gap:8px;margin-top:18px"><button class="btn btn-primary" id="pmGuardar">Guardar</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    $('pmGuardar').addEventListener('click', function(){
      var d={umbralBajo:parseInt($('pmUmbral').value,10), diasSeguridad:parseInt($('pmSeg').value,10), diasCobertura:parseInt($('pmCob').value,10), costoConIva:$('pmIva').checked};
      if([d.umbralBajo,d.diasSeguridad,d.diasCobertura].some(isNaN)){ aviso('Completa los tres valores con números enteros.'); return; }
      API.send('PUT','/api/inventario/config',d).then(function(s){ db.config=s; return API.get('/api/inventario/prediccion'); })
        .then(function(p){ db.prediccion=p; renderInventario(); renderAnaliticas(); cerrarModal(); aviso('Parámetros guardados. La reposición sugerida ya usa los nuevos valores.'); })
        .catch(function(e){ aviso('No se pudo guardar: '+e.message); });
    });
  });

  // Mermas del mes (ajustes negativos a costo): total, por motivo y los productos que más pierden.
  function renderMermas(m){
    if(!$('mermaTotal')) return;
    m=m||{costo:0,porMotivo:[],porProducto:[]};
    $('mermaTotal').textContent=clp(m.costo);
    var fila=function(x){ return '<tr><td>'+esc(x.nombre)+'</td><td>'+Number(x.unidades)+'</td><td>'+clp(x.costo)+'</td></tr>'; };
    var vacio='<tr><td colspan="3" class="muted" style="text-align:center;padding:16px">Sin mermas este mes.</td></tr>';
    $('mermaMotivo').innerHTML=(m.porMotivo||[]).map(fila).join('')||vacio;
    $('mermaProd').innerHTML=(m.porProducto||[]).map(fila).join('')||vacio;
  }
  // get() devuelve [] si no es un arreglo: las mermas son un objeto, así que van con fetch directo.
  function recargarMermas(){ return fetch('/api/inventario/mermas').then(function(r){ return r.ok?r.json():null; }).then(renderMermas).catch(function(){}); }
  // Mi plan: datos reales de la suscripción desde /api/mi-plan (plan, monto, cupo de cajas, situación del pago e
  // historial de cobros). El plan se paga mes a mes: desde 7 días antes de vencer aparece "Pagar renovación", que
  // lleva a Flow. Las reglas (días de gracia, pausa) las calcula el servidor: common/util/vigencia.ts.
  var ESTADOS={ activo:'Cuenta activa', pendiente:'Pago pendiente', suspendido:'Cuenta suspendida' };
  var SITUACION={ 'por-vencer':['Vence pronto','warn'], gracia:['Plan vencido','warn'], vencida:['En pausa por falta de pago','bad'], cancelada:['Plan cancelado','warn'], cerrada:['Cuenta cerrada','bad'] };
  var planActual=null;
  // Funciones del plan (configuracion.ts → funciones). La API ya las niega con 403; acá se explica en vez de mostrar
  // tablas vacías, y se esconden los botones que no sirven en ese plan.
  db.sinPedidos=false;
  function aplicarFuncionesPlan(p){
    var f=(p.limites&&p.limites.funciones)||{}, sinAn=f.analiticas===false;
    db.sinPedidos=f.pedidosProveedor===false;
    var nota=function(id, sel, si, html){
      var el=$(id), cont=document.querySelector(sel); if(!cont) return;
      if(!el){ el=document.createElement('p'); el.id=id; el.className='cuenta-msg warn'; cont.insertBefore(el, cont.firstChild); }
      el.hidden=!si; el.innerHTML=html;
    };
    nota('planSinAnaliticas','section[data-view="analiticas"]', sinAn, ico('candado')+'<b>Qué reponer, rotación ABC e inventario detenido</b> son parte de los planes Profesional y Empresa (tu plan: '+esc(p.plan)+'). Puedes cambiarlo en <a href="#plan" data-view="plan">Mi cuenta → Mi plan</a>.');
    nota('planSinPedidos','#tab-pedidos', db.sinPedidos, ico('candado')+'<b>Los pedidos a proveedores</b> son parte de los planes Profesional y Empresa. En tu plan anotas lo que llega con «Registrar ingreso sin pedido» (pestaña 2). <a href="#plan" data-view="plan">Cambiar de plan</a>.');
    ['pedSugeridos','nuevoPedido'].forEach(function(id){ var b=$(id); if(b) b.hidden=db.sinPedidos; });
  }
  function planMsg(tipo, texto){ var m=$('planMsg'); if(!m) return; m.className='cuenta-msg '+tipo; m.textContent=texto; m.hidden=!texto; }
  function renderPlan(){
    fetch('/api/mi-plan').then(function(r){ return r.ok?r.json():null; }).then(function(p){
      if(!p) return;
      planActual=p; aplicarFuncionesPlan(p);
      var t=function(id,v){ var el=$(id); if(el) el.textContent=v; };
      var ver=function(id,si){ var el=$(id); if(el) el.hidden=!si; };
      t('planNombre','Plan '+p.plan); t('planMonto', clp(p.monto)+' / mes');
      var sit=SITUACION[p.situacion], est=$('planEstado');
      if(est){ est.textContent=sit?sit[0]:(ESTADOS[p.estado]||p.estado); est.className=sit?'tag '+sit[1]:(p.estado==='activo'?'pay-ok':''); }
      var lim=p.limites||{}, nf=function(n){ return Number(n).toLocaleString('es-CL'); };
      t('planCajas', (p.cajasIncluidas===1 ? '1 caja incluida' : p.cajasIncluidas+' cajas incluidas')+(lim.cajasMax>1?' · hasta '+lim.cajasMax+' en total':''));
      t('planCupos', lim.cajeros ? 'Hasta '+lim.cajeros+' cajeros · '+(lim.productos?'hasta '+nf(lim.productos)+' productos':'productos sin límite')+' · historial '+(lim.historialMeses?'de '+lim.historialMeses+' meses':'completo') : 'Cajeros con PIN');
      // Cajas adicionales: cuota de arriendo que se suma a cada renovación hasta completar el total.
      var ca=p.cajaAdicional||{}, arr=$('planArriendo'), conCuota=(ca.cajas||[]).filter(function(c){ return c.cuotasPagadas<ca.cuotas; });
      if(arr){ arr.hidden=!(ca.cajas&&ca.cajas.length);
        arr.innerHTML=(ca.cajas||[]).length ? '<b>Cajas adicionales</b> ('+clp(ca.cuota)+' al mes cada una, '+ca.cuotas+' cuotas):<br>'+ca.cajas.map(function(c){
          return esc(c.nombre)+': '+(c.cuotasPagadas>=ca.cuotas?'pagada, es tuya':c.cuotasPagadas+' de '+ca.cuotas+' cuotas pagadas');
        }).join('<br>')+(conCuota.length?'<br>Tu próxima renovación incluye '+conCuota.length+' cuota'+(conCuota.length>1?'s':'')+' ('+clp(ca.cuota*conCuota.length)+').':'') : ''; }
      t('uPlan','Plan '+p.plan);
      var tp=$('topPlan'); if(tp){ tp.textContent='Plan '+p.plan; tp.hidden=false; } db.limites=p.limites||null; if($('invBody')) renderInventario(); // cupo del plan para el total del inventario y la importación var up=$('upsellPlan'); if(up) up.hidden=(p.plan==='Empresa'); // el aviso de mejorar plan no tiene sentido en el plan más alto
      var vig=p.vigenteHasta ? fmtFecha(p.vigenteHasta) : '';
      var sigTxt=p.planSiguiente?' Desde esa fecha pasas al plan '+p.planSiguiente+' ('+clp(p.montoRenovacion)+' al mes).':'';
      t('planVigencia',
        p.situacion==='cerrada' ? 'Tus datos se eliminarán el '+fmtFecha(p.eliminarEn)+'. Puedes recuperar la cuenta en "Datos y seguridad".' :
        p.situacion==='cancelada' ? 'Tienes acceso hasta el '+vig+'. No se te cobrará nada más.' :
        p.situacion==='gracia' ? 'Venció el '+vig+'. Si no pagas antes del '+fmtFecha(p.pausaEl)+', el panel queda en pausa (tu caja sigue vendiendo en el local).' :
        p.situacion==='vencida' ? (p.cancelado?'Tu plan terminó el ':'Venció el ')+vig+'. Paga la renovación para reactivar el panel y la sincronización de tus cajas.' :
        vig ? 'Vigente hasta el '+vig+'.'+sigTxt : '');
      // Acciones según la situación. Cuenta sin pagos en línea (creada por el equipo Walkan) o cerrada: ninguna.
      var conPlan=p.situacion!=='sin-plan'&&p.situacion!=='cerrada';
      // La renovación se paga por el plan que regirá el mes siguiente (el programado, si pidió cambiarlo).
      var pagar=$('planPagar'); if(pagar){ pagar.hidden=!(conPlan&&p.puedeRenovar); pagar.textContent='Pagar renovación · '+clp(p.montoRenovacion)+(p.planSiguiente?' (plan '+p.planSiguiente+')':''); }
      ver('planReactivar', p.situacion==='cancelada');
      ver('planCancelar', conPlan&&!p.cancelado&&p.situacion!=='vencida');
      ver('planAcciones', conPlan);
      var nota=$('planNota'); if(nota){ nota.hidden=p.situacion!=='al-dia'; nota.textContent='Podrás pagar la renovación desde '+p.diasRenovarAntes+' días antes del vencimiento. Te avisaremos por correo desde walkan.pos@gmail.com (si no lo ves, revisa la carpeta de spam).'; }
      renderCambioPlan(p);
      renderTarjeta(p, conPlan);
      var c=$('cobros');
      if(c) c.innerHTML=(p.cobros||[]).map(function(x){
        // Dos columnas (cabe en el teléfono): el pago con su plan y, debajo, el período que cubre.
        var det=x.tipo==='cambio' ? 'Diferencia por subir de plan, hasta el '+esc(fmtFecha(x.hasta)) : 'Cubre del '+esc(fmtFecha(x.desde))+' al '+esc(fmtFecha(x.hasta));
        det+=x.medio==='tarjeta'?' · cobro automático':x.medio==='manual'?' · registrado por Walkan':'';
        return '<tr><td><b>'+esc(fmtFecha(x.fecha))+'</b> · '+esc((x.tipo==='cambio'?'Cambio a plan ':'Plan ')+x.plan)+'<div class="muted small">'+det+'</div></td><td style="text-align:right; white-space:nowrap">'+clp(x.monto)+'</td></tr>';
      }).join('')||'<tr><td colspan="2" class="muted" style="text-align:center;padding:16px">Aún no hay cobros registrados.</td></tr>';
    }).catch(function(){});
  }
  // Cambiar de plan sin salir del panel. El servidor dice qué pasa al elegir cada plan (p.planes[].cambio):
  //  'pago' = sube y paga hoy la diferencia · 'gratis' = sube sin costo · 'programado' = rige al renovar · 'no' = no se puede.
  function renderCambioPlan(p){
    var caja=$('planCambio'), lista=$('planOpciones'), nota=$('planCambioNota'); if(!caja||!lista) return;
    caja.hidden=p.situacion==='cerrada'||!(p.planes&&p.planes.length);
    var hasta=p.vigenteHasta?fmtFecha(p.vigenteHasta):'';
    lista.innerHTML=(p.planes||[]).map(function(x){
      var c=x.cambio, acc='';
      if(x.actual) acc='<span class="tag ok">Tu plan</span>'+(p.planSiguiente?'<button class="mini" type="button" data-plan-ir="'+esc(x.nombre)+'">Mantener este plan</button>':'');
      else if(p.planSiguiente===x.nombre) acc='<span class="tag warn">'+(hasta&&p.situacion!=='gracia'&&p.situacion!=='vencida'?'Desde el '+esc(hasta):'Al renovar')+'</span>';
      else if(c&&c.modo!=='no') acc='<button class="mini" type="button" data-plan-ir="'+esc(x.nombre)+'" aria-label="'+(c.sube?'Subir':'Bajar')+' al plan '+esc(x.nombre)+'">'+(c.sube?'Subir':'Bajar')+'</button>';
      return '<div class="plan-op'+(x.actual?' actual':'')+'"><div><b>'+esc(x.nombre)+'</b> <span class="muted">'+clp(x.monto)+' / mes</span>'+
        '<div class="muted small">Hasta '+x.cajeros+' cajeros · '+(x.productos?Number(x.productos).toLocaleString('es-CL')+' productos':'productos sin límite')+' · hasta '+x.cajas+' cajas</div></div><div class="po-acc">'+acc+'</div></div>';
    }).join('');
    // Si ningún plan se puede elegir, todos comparten el motivo (cuenta administrada por Walkan, plan cancelado…).
    var otros=(p.planes||[]).filter(function(x){ return !x.actual; });
    var bloqueo=otros.length&&otros.every(function(x){ return x.cambio&&x.cambio.modo==='no'; })?otros[0].cambio.motivo:'';
    nota.textContent=bloqueo||'Subir de plan rige al instante: pagas solo la diferencia por los días que quedan de tu mes. Bajar rige desde tu próxima renovación.';
    // El correo de contacto del motivo queda como enlace para escribir de una.
    if(bloqueo&&p.contacto&&bloqueo.indexOf(p.contacto)>-1) nota.innerHTML=esc(bloqueo).replace(esc(p.contacto), '<a class="link" href="mailto:'+esc(p.contacto)+'">'+esc(p.contacto)+'</a>');
  }
  function enviarCambioPlan(nombre, boton){
    if(boton) boton.disabled=true;
    API.send('POST','/api/cuenta/plan',{plan:nombre}).then(function(r){
      if(r.resultado==='pago'){ location.href=r.pagoUrl; return; }
      location.reload();
    }).catch(function(e){ cerrarModal(); planMsg('error', e.message); });
  }
  // Antes de cambiar se muestra qué se paga hoy, desde cuándo rige y cuánto costará la renovación.
  function confirmarCambioPlan(nombre){
    var p=planActual, x=p&&(p.planes||[]).find(function(y){ return y.nombre===nombre; }); if(!x) return;
    if(x.actual){ enviarCambioPlan(nombre); return; } // "Mantener este plan": deshace el cambio programado
    var c=x.cambio||{}, hasta=p.vigenteHasta?fmtFecha(p.vigenteHasta):'', vencido=p.situacion==='gracia'||p.situacion==='vencida';
    if(c.modo==='no'){ planMsg('error', c.motivo||'No se puede cambiar a ese plan.'); return; }
    var li=[], boton='Cambiar de plan';
    if(c.modo==='pago'){ boton='Pagar '+clp(c.pagarHoy)+' y cambiar';
      li=['Pagas hoy <b>'+clp(c.pagarHoy)+'</b>: la diferencia por los '+Number(c.dias)+' días que quedan de tu mes.','Tu plan cambia apenas se confirme el pago; el vencimiento sigue siendo el <b>'+esc(hasta)+'</b>.']; }
    else if(c.modo==='gratis'){ boton='Cambiar ahora';
      li=['Quedan pocos días de tu mes: el cambio no tiene costo hoy.','Tu plan cambia al instante; el vencimiento sigue siendo el <b>'+esc(hasta)+'</b>.']; }
    else if(vencido){ boton='Elegir este plan';
      li=['Tu mes ya venció: el plan '+esc(nombre)+' parte cuando pagues la renovación.']; }
    else { boton='Programar el cambio';
      li=['Sigues con el plan '+esc(p.plan)+' hasta el <b>'+esc(hasta)+'</b>: ya está pagado y no hay devoluciones.','Si te arrepientes, puedes mantener tu plan actual antes de esa fecha.']; }
    li.push((vencido?'La renovación costará ':'Desde la renovación pagas ')+'<b>'+clp(x.monto)+'</b> al mes.');
    abrirModal((c.sube?'Subir':'Bajar')+' al plan '+nombre,
      '<p style="margin:0 0 10px">Plan <b>'+esc(nombre)+'</b>: hasta '+x.cajeros+' cajeros, '+(x.productos?Number(x.productos).toLocaleString('es-CL')+' productos':'productos sin límite')+', historial '+(x.historialMeses?'de '+x.historialMeses+' meses':'completo')+(x.funciones&&x.funciones.analiticas?'':', sin analíticas ni pedidos a proveedores')+'.</p>'+
      '<ul class="muted small" style="margin:0 0 16px; padding-left:18px; line-height:1.6">'+li.map(function(l){ return '<li>'+l+'</li>'; }).join('')+'</ul>'+
      '<div style="display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end"><button class="btn btn-ghost" type="button" data-cerrar>Volver</button><button class="btn btn-primary" type="button" id="siCambiarPlan">'+esc(boton)+'</button></div>');
    $('siCambiarPlan').addEventListener('click', function(){ enviarCambioPlan(nombre, this); });
  }
  // Cobro automático: tarjeta inscrita (marca y 4 últimos dígitos) o el botón para inscribirla en Flow.
  function renderTarjeta(p, conPlan){
    var si=$('tarjetaSi'), no=$('tarjetaNo'), ins=$('tarjetaInscribir'); if(!si||!no) return;
    var tj=p.tarjeta;
    si.hidden=!tj; no.hidden=!!tj; if(ins) ins.hidden=!conPlan;
    if(tj){
      $('tarjetaTxt').textContent='Pago automático con '+(tj.marca||'tarjeta')+' terminada en '+tj.ultimos4;
      var err=p.cobroAuto&&p.cobroAuto.error;
      $('tarjetaNota').textContent = err ? 'El último cobro no se pudo hacer ('+err+'). Lo reintentamos cada día; también puedes pagar la renovación ahora.'
        : (p.cancelado ? 'Tu plan está cancelado: no se cobrará nada más.' : p.vigenteHasta ? 'Renovaremos tu plan solos el día antes del '+fmtFecha(p.vigenteHasta)+' ('+clp(p.montoRenovacion)+').' : '');
    }
  }
  function tarjetaMsg(tipo, texto){ var m=$('tarjetaMsg'); if(!m) return; m.className='cuenta-msg '+tipo; m.textContent=texto; m.hidden=!texto; }
  function inscribirTarjeta(){
    var b=this; b.disabled=true; tarjetaMsg('','');
    API.send('POST','/api/cuenta/tarjeta',{}).then(function(r){ location.href=r.url; })
      .catch(function(e){ b.disabled=false; tarjetaMsg('error', e.message); });
  }
  function confirmarQuitarTarjeta(){
    abrirModal('Quitar tarjeta',
      '<p style="margin:0 0 16px">Dejaremos de cobrar automáticamente. Tu plan sigue igual y la renovación la pagas desde aquí cuando se acerque el vencimiento.</p>'+
      '<div style="display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end"><button class="btn btn-ghost" type="button" data-cerrar>Volver</button><button class="btn btn-danger" type="button" id="siQuitarTarjeta">Quitar tarjeta</button></div>');
    $('siQuitarTarjeta').addEventListener('click', function(){ this.disabled=true;
      API.send('POST','/api/cuenta/tarjeta/quitar',{}).then(function(){ location.reload(); }).catch(function(e){ cerrarModal(); tarjetaMsg('error', e.message); }); });
  }
  // Vuelta desde Flow tras inscribir la tarjeta (?tarjeta=ok|error): se avisa y se limpia la dirección.
  (function(){
    var q=/[?&]tarjeta=(ok|error)/.exec(location.search); if(!q) return;
    tarjetaMsg(q[1]==='ok'?'ok':'error', q[1]==='ok'?'Listo: tu tarjeta quedó inscrita para el pago automático.':'No se pudo inscribir la tarjeta. Inténtalo de nuevo.');
    try{ history.replaceState(null,'',location.pathname+location.hash); }catch(e){}
  })();

  // Pagar la renovación: el servidor crea el cobro y devuelve la página de pago de Flow.
  function pagarRenovacion(){
    var b=$('planPagar'); if(b) b.disabled=true; planMsg('','');
    API.send('POST','/api/cuenta/renovar',{}).then(function(r){
      if(r.activa){ location.reload(); return; } // el pago anterior ya estaba hecho: no se cobra de nuevo
      location.href=r.pagoUrl;
    }).catch(function(e){ if(b) b.disabled=false; planMsg('error', e.message); });
  }
  function cambiarPlan(ruta){ return API.send('POST',ruta,{}).then(function(){ location.reload(); }).catch(function(e){ cerrarModal(); planMsg('error', e.message); }); }
  // Cancelar pide confirmación en el modal del panel (no con confirm() del navegador) y dice qué pasa después.
  function confirmarCancelarPlan(){
    // En días de gracia el período pagado ya terminó: cancelar deja el panel en pausa al tiro.
    var vencido=!!(planActual&&planActual.situacion==='gracia');
    var hasta=planActual&&planActual.vigenteHasta&&!vencido?fmtFecha(planActual.vigenteHasta):'';
    abrirModal('Cancelar plan',
      '<p style="margin:0 0 10px">¿Seguro que quieres cancelar tu plan?</p>'+
      '<ul class="muted small" style="margin:0 0 16px; padding-left:18px; line-height:1.6">'+
      '<li>No se te cobrará nada más.</li>'+
      (hasta?'<li>Mantienes el panel y tus cajas hasta el <b>'+esc(hasta)+'</b>.</li>':'')+
      '<li>'+(vencido?'Como tu plan ya venció, el panel queda en pausa de inmediato.':'Después el panel queda en pausa.')+' Tus datos se guardan: puedes volver pagando la renovación, descargarlos o eliminar la cuenta.</li>'+
      '</ul>'+
      '<div style="display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end"><button class="btn btn-ghost" type="button" data-cerrar>No, mantener mi plan</button><button class="btn btn-danger" type="button" id="siCancelar">Sí, cancelar mi plan</button></div>');
    $('siCancelar').addEventListener('click', function(){ this.disabled=true; cambiarPlan('/api/cuenta/cancelar'); });
  }
  (function(){
    var on=function(id,fn){ var el=$(id); if(el) el.addEventListener('click', fn); };
    on('planPagar', pagarRenovacion);
    on('planCancelar', confirmarCancelarPlan);
    on('planReactivar', function(){ this.disabled=true; cambiarPlan('/api/cuenta/reactivar'); });
    on('tarjetaInscribir', inscribirTarjeta);
    on('tarjetaCambiar', inscribirTarjeta);
    on('tarjetaQuitar', confirmarQuitarTarjeta);
    on('planOpciones', function(e){ var b=e.target.closest('[data-plan-ir]'); if(b) confirmarCambioPlan(b.dataset.planIr); });
  })();


  // ================= COMPARAR PERÍODOS =================
  // Ventas, ganancia estimada, compras y mermas de dos rangos de días (A contra B). Todo sale de endpoints que ya
  // aceptan desde/hasta; las compras se filtran de db.compras. Se recalcula al entrar a Analíticas y al cambiar fechas.
  function statsPeriodo(d, h){
    var j=function(u,def){ return fetch(u).then(function(r){ return r.ok?r.json():def; }).catch(function(){ return def; }); }, q='?desde='+d+'&hasta='+h;
    return Promise.all([API.get('/api/ventas'+q), j('/api/inventario/mermas'+q,{costo:0,unidades:0,productos:0,porProducto:[]}), j('/api/inventario/costo-ventas'+q,{costo:0})]).then(function(r){
      var vs=r[0], mm=r[1], costo=r[2].costo||0, total=vs.reduce(function(s,v){ return s+(v.total||0); },0);
      var conCosto=costo>0?(db.config&&db.config.costoConIva?total:total/1.19):0; // mismo criterio de IVA que el informe del mes
      return {ventas:total, boletas:vs.length, ticket:vs.length?Math.round(total/vs.length):0, ganancia:conCosto?Math.round(conCosto-costo):null,
        compras:db.compras.filter(function(c){ var f=(c.fecha||'').slice(0,10); return esCompra(c)&&f>=d&&f<=h; }).reduce(function(s,c){ return s+(c.total||0); },0),
        mermas:Math.round(mm.costo||0), mermaUn:mm.unidades||0, mermaProd:mm.productos||0, peores:mm.porProducto||[]};
    });
  }
  // Fechas en AAAA-MM-DD con aritmética UTC (sin horario de verano de por medio).
  var isoUTC=function(y,m,d){ return new Date(Date.UTC(y,m,d)).toISOString().slice(0,10); };
  function presetPeriodos(k){
    var h=hoyISO(), y=+h.slice(0,4), m=+h.slice(5,7)-1, d=+h.slice(8,10);
    if(k==='mes') return [isoUTC(y,m,1), h, isoUTC(y,m-1,1), isoUTC(y,m-1,Math.min(d, new Date(Date.UTC(y,m,0)).getUTCDate()))];
    if(k==='mesAnt') return [isoUTC(y,m-1,1), isoUTC(y,m,0), isoUTC(y,m-2,1), isoUTC(y,m-1,0)];
    var n=+k; return [diaAtras(n-1), h, diaAtras(2*n-1), diaAtras(n)];
  }
  var cmpIds=['cmpAd','cmpAh','cmpBd','cmpBh'], cmpSeq=0;
  function compararPeriodos(){
    if(!$('cmpBody')||!cmpIds) return; // cmpIds aún no existe si mostrar() corre al cargar, antes de este archivo
    if($('cmpPreset').value!=='otro') presetPeriodos($('cmpPreset').value).forEach(function(v,i){ $(cmpIds[i]).value=v; });
    var f=cmpIds.map(function(id){ return $(id).value; });
    if(f.some(function(v){ return !v; })||f[0]>f[1]||f[2]>f[3]){ $('cmpBody').innerHTML='<tr><td colspan="4" class="muted" style="text-align:center;padding:16px">Completa las fechas: cada "desde" debe ser anterior o igual a su "hasta".</td></tr>'; return; }
    if(Date.parse(f[1])-Date.parse(f[0])>366*86400000||Date.parse(f[3])-Date.parse(f[2])>366*86400000){ $('cmpBody').innerHTML='<tr><td colspan="4" class="muted" style="text-align:center;padding:16px">Cada período puede ser de hasta un año.</td></tr>'; return; }
    var n=++cmpSeq, rango=function(a,b){ return a===b?fmtFecha(a):fmtFecha(a)+' – '+fmtFecha(b); };
    $('cmpTA').textContent='A · '+rango(f[0],f[1]); $('cmpTB').textContent='B · '+rango(f[2],f[3]);
    Promise.all([statsPeriodo(f[0],f[1]), statsPeriodo(f[2],f[3])]).then(function(r){
      if(n!==cmpSeq) return; // el usuario cambió las fechas mientras tanto
      var a=r[0], b=r[1];
      // [etiqueta, clave, formato, subir es bueno (true), malo (false) o neutro (null)]
      var filas=[['Ventas','ventas',clp,true],['Comprobantes','boletas',String,true],['Ticket promedio','ticket',clp,true],['Ganancia estimada','ganancia',clp,true],
        ['Compras','compras',clp,null],['Mermas (a costo)','mermas',clp,false],['Unidades perdidas','mermaUn',function(x){ return fmtCant(null,x); },false],['Productos con mermas','mermaProd',String,false]];
      $('cmpBody').innerHTML=filas.map(function(x){
        var va=a[x[1]], vb=b[x[1]], cambio='—';
        if(va!=null&&vb!=null&&va!==vb){
          var pct=vb?Math.round((va-vb)/Math.abs(vb)*100):null, sube=va>vb, c=x[3]==null?'mut':(sube===x[3]?'ok':'bad');
          cambio='<span class="tag '+c+'">'+ico(sube?'sube':'baja')+(pct==null?'nuevo':Math.abs(pct)+'%')+'</span>';
        }
        return '<tr><td class="prin"><b>'+x[0]+'</b></td><td data-l="A">'+(va==null?'—':x[2](va))+'</td><td data-l="B">'+(vb==null?'—':x[2](vb))+'</td><td data-l="Cambio">'+cambio+'</td></tr>';
      }).join('');
      $('cmpPeores').innerHTML=a.peores.map(function(p){ return '<tr><td class="prin"><b>'+esc(p.nombre)+'</b></td><td data-l="Unidades">'+fmtCant(null,p.unidades)+'</td><td data-l="A costo">'+clp(Math.round(p.costo))+'</td></tr>'; }).join('')||
        '<tr><td colspan="3" class="muted" style="text-align:center;padding:16px">Sin pérdidas de inventario en el período A</td></tr>';
    });
  }
  $('cmpPreset').addEventListener('change', compararPeriodos);
  cmpIds.forEach(function(id){ $(id).addEventListener('change', function(){ $('cmpPreset').value='otro'; compararPeriodos(); }); });
  // Resumen de los últimos 6 meses (el actual va "en curso"): se pide solo la primera vez que se abre el desplegable.
  var cmpMeses=$('cmpMeses'); cmpMeses.addEventListener('toggle', function cargar(){ if(!cmpMeses.open) return; cmpMeses.removeEventListener('toggle', cargar);
    var h=hoyISO(), y=+h.slice(0,4), m=+h.slice(5,7)-1, meses=[];
    for(var i=0;i<6;i++) meses.push({d:isoUTC(y,m-i,1), h:i?isoUTC(y,m-i+1,0):h, curso:!i});
    Promise.all(meses.map(function(x){ return statsPeriodo(x.d,x.h); })).then(function(r){
      cmpMeses.querySelector('div').outerHTML='<table class="compacta" style="margin-top:8px"><thead><tr><th>Mes</th><th>Ventas</th><th>Comprobantes</th><th>Ganancia est.</th><th>Compras</th><th>Mermas</th><th>Productos con mermas</th></tr></thead><tbody>'+
        r.map(function(s,i){ var nom=new Date(meses[i].d+'T12:00:00Z').toLocaleDateString('es-CL',{month:'long',year:'numeric',timeZone:'UTC'});
          return '<tr><td class="prin"><b>'+esc(nom.charAt(0).toUpperCase()+nom.slice(1))+'</b>'+(meses[i].curso?' <span class="tag mut">en curso</span>':'')+'</td><td data-l="Ventas">'+clp(s.ventas)+'</td><td data-l="Comprobantes">'+s.boletas+'</td><td data-l="Ganancia">'+(s.ganancia==null?'—':clp(s.ganancia))+'</td><td data-l="Compras">'+clp(s.compras)+'</td><td data-l="Mermas">'+clp(s.mermas)+'</td><td data-l="Productos con mermas">'+s.mermaProd+'</td></tr>'; }).join('')+'</tbody></table>';
    });
  });
