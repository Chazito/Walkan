// registro.js — formulario de /registro: valida, detecta la dirección del local, crea la cuenta y manda al pago en Flow.
// También maneja el "reintentar pago" para quien se quedó a medio camino.
(function(){
  function $(id){ return document.getElementById(id); }
  // POST JSON; si el servidor responde error, lanza con el primer mensaje que venga.
  function post(url, body){
    return fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) })
      .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){
        if(!r.ok){ var m = d && d.message; throw new Error(Array.isArray(m) ? m[0] : (m || 'Error del servidor')); }
        return d;
      }); });
  }
  // Mensaje de error del formulario, justo antes del botón de envío. Antes usaba el primer <button> del formulario
  // (el de "Agregar dirección", que no es hijo directo) y insertBefore fallaba: no se veía ningún error.
  function error(form, msg){
    var el = form.querySelector('.msg-error');
    if(!el){
      el = document.createElement('div'); el.className='msg-error'; el.setAttribute('role','alert');
      var b = form.querySelector('button[type="submit"]');
      if(b && b.parentNode) b.parentNode.insertBefore(el, b); else form.appendChild(el);
    }
    el.hidden = false;
    el.textContent = msg;
  }
  // Error de un campo: lo marca, muestra el texto bajo el campo y lo enfoca.
  function errorCampo(input, msg){
    var id = input.id + 'Err', el = document.getElementById(id);
    if(!el){ el = document.createElement('p'); el.id = id; el.className = 'campo-error'; input.insertAdjacentElement('afterend', el); }
    el.textContent = msg; el.hidden = false;
    input.setAttribute('aria-invalid', 'true'); input.setAttribute('aria-describedby', ((input.getAttribute('aria-describedby') || '').replace(id, '') + ' ' + id).trim());
    input.focus();
  }
  function limpiarCampo(input){
    var el = document.getElementById(input.id + 'Err'); if(el) el.hidden = true;
    input.removeAttribute('aria-invalid');
  }
  function ocupado(btn, on, txt){ btn.disabled = on; btn.textContent = txt; }

  var f = $('registro');
  // El aviso aparece al enviar (no al salir del campo: movía el formulario justo cuando se hacía clic en lo siguiente)
  // y se quita apenas las dos contraseñas coinciden.
  $('pass2').addEventListener('input', function(){ if($('pass2').value === $('pass').value) limpiarCampo($('pass2')); });
  $('pass').addEventListener('input', function(){ if($('pass2').value && $('pass2').value === $('pass').value) limpiarCampo($('pass2')); });
  if(window.WalkanClave) WalkanClave.montar($('pass'), $('claveReglas'));
  // ---- Dirección del local (opcional): plegada; al abrirla se intenta detectar sola ----
  // Estados: cerrado → detectando → propuesta (tarjeta para confirmar) → confirmada, o form (formulario completo).
  var T = window.WalkanTerritorio;
  var montaje = T ? T.montar($('region'), $('comuna')) : Promise.resolve();
  var dir = { modo: 'cerrado', intento: 0 };
  var MSG = {
    'no-soportado': 'Este navegador no permite detectar la ubicación aquí. Escribe la dirección.',
    'sin-permiso': 'No diste permiso para usar tu ubicación. Escribe la dirección.',
    'sin-senal': 'No pudimos obtener tu ubicación. Escribe la dirección.',
    'sin-red': 'No pudimos buscar la dirección en este momento. Escríbela aquí.',
    'fuera-de-chile': 'Tu ubicación no parece estar en Chile. Escribe la dirección del local.'
  };
  function estadoDir(texto, cargando){
    var el = $('dirEstado'); el.textContent = '';
    if(!texto) return;
    if(cargando){ var g = document.createElement('span'); g.className = 'giro'; g.setAttribute('aria-hidden', 'true'); el.appendChild(g); }
    el.appendChild(document.createTextNode(texto));
    if(cargando){ var b = document.createElement('button'); b.type = 'button'; b.className = 'link-btn'; b.textContent = 'Escribirla yo'; b.addEventListener('click', function(){ dir.intento++; abrirForm(''); }); el.appendChild(b); }
  }
  function abrirForm(msg){
    dir.modo = 'form'; $('dirCard').hidden = true; $('dirForm').hidden = false; estadoDir(msg);
    ($('comuna').value ? $('direccion') : ($('region').value ? $('comuna') : $('region'))).focus();
  }
  function cerrarDir(){
    dir.intento++; dir.modo = 'cerrado';
    $('region').value = ''; $('region').dispatchEvent(new Event('change')); $('direccion').value = '';
    $('dirPanel').hidden = true; $('dirCard').hidden = true; $('dirForm').hidden = true; estadoDir('');
    $('agregarDir').hidden = false; $('agregarDir').setAttribute('aria-expanded', 'false'); $('agregarDir').focus();
  }
  $('agregarDir').addEventListener('click', function(){
    this.setAttribute('aria-expanded', 'true'); this.hidden = true; $('dirPanel').hidden = false;
    if(!T || !T.detectar){ abrirForm(''); return; }
    var intento = ++dir.intento; dir.modo = 'detectando';
    estadoDir('Buscando la dirección donde estás (si estás en tu local)… ', true);
    Promise.all([T.detectar(), montaje]).then(function(res){
      if(intento !== dir.intento) return;
      var r = res[0];
      if(r.cut) T.seleccionar($('region'), $('comuna'), r.cut);
      else if(r.regionId){ $('region').value = r.regionId; $('region').dispatchEvent(new Event('change')); }
      $('direccion').value = r.calle;
      if(r.cut && r.calle && r.conNumero){
        dir.modo = 'propuesta'; estadoDir('');
        $('dirTexto').textContent = r.calle; $('dirZona').textContent = r.comuna + ', ' + r.region;
        $('dirCard').classList.remove('ok'); $('dirUsar').hidden = false; $('dirCorregir').textContent = 'Corregir';
        $('dirCard').hidden = false; $('dirUsar').focus();
      } else {
        abrirForm(r.cut ? 'Encontramos la comuna; completa la calle y el número.' : 'No encontramos la dirección completa; termínala aquí.');
      }
    }).catch(function(code){ if(intento === dir.intento) abrirForm(MSG[code] || MSG['sin-red']); });
  });
  $('dirUsar').addEventListener('click', function(){
    dir.modo = 'confirmada'; $('dirCard').classList.add('ok'); this.hidden = true;
    $('dirCorregir').textContent = 'Cambiar'; $('dirCard').querySelector('.dir-card-txt .muted').textContent = 'Usaremos esta dirección';
    $('dirCorregir').focus();
  });
  $('dirCorregir').addEventListener('click', function(){ abrirForm(''); });
  $('dirQuitar').addEventListener('click', cerrarDir);
  // Envío del alta: validaciones en el navegador y recién ahí se crea la cuenta y se redirige al pago.
  f.addEventListener('submit', function(ev){
    ev.preventDefault();
    if(!f.checkValidity()){ f.reportValidity(); return; }
    var mc = window.WalkanClave ? WalkanClave.mensaje($('pass').value) : '';
    if(mc){ error(f, mc); $('pass').focus(); return; }
    if($('pass').value !== $('pass2').value){ errorCampo($('pass2'), 'Las contraseñas no coinciden.'); return; }
    if(!$('aceptaPrivacidad').checked){ error(f, 'Para crear tu cuenta debes aceptar la Política de Privacidad.'); $('aceptaPrivacidad').focus(); return; }
    if(dir.modo === 'propuesta'){ error(f, 'Confirma o corrige la dirección del local.'); $('dirUsar').focus(); return; }
    var conDir = dir.modo === 'confirmada' || dir.modo === 'form';
    var direccion = conDir ? $('direccion').value.replace(/\s+/g, ' ').trim() : '';
    var comunaCut = conDir ? $('comuna').value : '';
    if(direccion && !comunaCut){ error(f, 'Elige la región y la comuna del local.'); abrirForm(''); return; }
    var plan = (f.querySelector('input[name="plan"]:checked') || {}).value;
    var btn = f.querySelector('button[type="submit"]');
    ocupado(btn, true, 'Creando tu cuenta…');
    post('/api/registro', {
      negocio: $('negocio').value.trim(), nombre: $('nombre').value.trim(), email: $('email').value.trim(),
      password: $('pass').value, plan: plan,
      comunaCut: comunaCut || undefined, direccion: direccion || undefined,
      telefono: $('telefono').value.trim() || undefined,
      aceptaPrivacidad: true, aceptaMarketing: $('aceptaMarketing').checked
    }).then(function(d){
      btn.textContent = 'Redirigiendo al pago…';
      window.location.href = d.pagoUrl;
    }).catch(function(e){ error(f, e.message); ocupado(btn, false, 'Crear cuenta y pagar'); });
  });

  // Reintento de pago: para quien ya creó la cuenta pero no alcanzó a pagar.
  var r = $('reintento');
  r.addEventListener('submit', function(ev){
    ev.preventDefault();
    if(!r.checkValidity()){ r.reportValidity(); return; }
    var btn = r.querySelector('button');
    ocupado(btn, true, 'Generando pago…');
    post('/api/registro/reintentar', { email: $('r-email').value.trim(), password: $('r-pass').value })
      .then(function(d){
        // El pago anterior ya estaba hecho (Flow no alcanzó a avisar): la cuenta quedó activa, no se cobra de nuevo.
        if(d.activa){ error(r, 'Tu pago ya estaba registrado y tu cuenta quedó activa. Te llevamos a iniciar sesión…'); setTimeout(function(){ window.location.href='/mi-cuenta'; }, 1800); return; }
        window.location.href = d.pagoUrl;
      })
      .catch(function(e){ error(r, e.message); ocupado(btn, false, 'Reintentar pago'); });
  });

  if(location.hash === '#reintentar'){ $('reintentar').open = true; }
})();
