// apariencia.js — aplica la apariencia del negocio (Mi cuenta › Apariencia) en el panel y en admin.
// Va en el <head>, después de los CSS: primero aplica la última apariencia guardada en este navegador
// (sin parpadeo) y luego la confirma con GET /api/apariencia. Expone window.WalkanApariencia.
(function(){
  var DEF = { estilo:'nitido', modo:'auto', acento:'#0B7C4E' };
  var FUENTES = {
    nitido: 'family=Archivo:wght@400;500;600;700;800',
    suave: 'family=Onest:wght@400;500;600;700;800',
    consola: 'family=JetBrains+Mono:wght@400;600;700&family=IBM+Plex+Sans:wght@400;500;600;700'
  };
  var html = document.documentElement, LS = 'walkan-apariencia';

  function rgb(h){ h = String(h || '').replace('#',''); if(h.length === 3) h = h.replace(/./g, '$&$&'); var n = parseInt(h, 16); return isNaN(n) ? null : [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function hex(c){ return '#' + c.map(function(v){ return ('0' + Math.round(v).toString(16)).slice(-2); }).join('').toUpperCase(); }
  function lum(c){ var a = c.map(function(v){ v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126*a[0] + 0.7152*a[1] + 0.0722*a[2]; }
  function ratio(a, b){ var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function mix(a, b, t){ return a.map(function(v, i){ return v + (b[i] - v) * t; }); }
  // El color más parecido al acento que se lea sobre `fondo` (4,5:1): se acerca a `tinta` de a poco.
  // `fondos` = todos los fondos donde se usa ese color (tarjeta, menú, fondos teñidos con el acento): debe pasar en todos.
  function legible(c, fondos, tinta){ for(var t = 0; t <= 1.0001; t += 0.05){ var m = mix(c, tinta, t); if(fondos.every(function(f){ return ratio(m, f) >= 4.6; })) return m; } return tinta; }
  function variable(n){ return getComputedStyle(html).getPropertyValue(n).trim(); }

  function fuente(estilo){
    var id = 'ap-fuente-' + estilo; if(document.getElementById(id)) return;
    var l = document.createElement('link'); l.id = id; l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?' + FUENTES[estilo] + '&display=swap';
    document.head.appendChild(l);
  }

  /** Datos del contraste para la pantalla de Ajustes. */
  function contraste(acento){
    var A = rgb(acento) || rgb(DEF.acento);
    var blanco = ratio(A, [255,255,255]), negro = ratio(A, [17,20,24]);
    return { ratio: Math.max(blanco, negro), onAcento: blanco >= negro ? '#FFFFFF' : '#111418' };
  }

  function aplicar(a){
    a = { estilo: FUENTES[a && a.estilo] ? a.estilo : DEF.estilo, modo: a && /^(auto|claro|oscuro)$/.test(a.modo) ? a.modo : DEF.modo, acento: rgb(a && a.acento) ? a.acento : DEF.acento };
    html.setAttribute('data-estilo', a.estilo);
    if(a.modo === 'claro') html.setAttribute('data-theme', 'light');
    else if(a.modo === 'oscuro') html.setAttribute('data-theme', 'dark');
    else html.removeAttribute('data-theme');
    fuente(a.estilo);
    // Colores derivados del acento, medidos contra el fondo REAL del estilo y modo ya aplicados.
    html.style.removeProperty('--accent-strong');
    var A = rgb(a.acento), sup = rgb(variable('--surface')) || [255,255,255], sup2 = rgb(variable('--surface-2')) || sup, tinta = rgb(variable('--ink')) || [17,20,24];
    var c = contraste(a.acento), oscuro = lum(sup) < 0.2;
    // El texto con el color de la marca aparece sobre la tarjeta, sobre el menú y sobre fondos teñidos con el mismo color (hasta 22%).
    var fondos = [sup, sup2, mix(sup, A, 0.22), mix(sup2, A, 0.22)];
    html.style.setProperty('--accent', hex(A));
    html.style.setProperty('--brand', hex(A));
    html.style.setProperty('--on-accent', c.onAcento);
    // Número de los avisos del menú (Nítido): rojo oscuro sobre pastilla blanca, rojo claro sobre pastilla oscura.
    html.style.setProperty('--bell-tx', c.onAcento === '#FFFFFF' ? '#B91C1C' : '#FCA5A5');
    html.style.setProperty('--accent-strong', hex(legible(A, fondos, tinta)));
    // Fondos de hover/activo del menú en Nítido: se alejan del color del texto (más oscuros si el texto es blanco,
    // más claros si es oscuro), así el contraste sube en vez de bajar.
    var lejos = c.onAcento === '#FFFFFF' ? [0,0,0] : [255,255,255];
    html.style.setProperty('--side-hover', hex(mix(A, lejos, 0.12)));
    html.style.setProperty('--side-activo', hex(mix(A, lejos, 0.26)));
    html.style.setProperty('--accent-hover', hex(mix(A, oscuro ? [255,255,255] : [0,0,0], 0.12)));
    return a;
  }

  function recordar(a){ try { localStorage.setItem(LS, JSON.stringify(a)); } catch(e){} }
  function guardada(){ try { return JSON.parse(localStorage.getItem(LS) || 'null'); } catch(e){ return null; } }

  var actual = aplicar(guardada() || DEF);
  // Si el usuario cambia el tema del equipo y está en automático, se recalculan los colores del acento.
  if(window.matchMedia) try { window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(){ if(actual.modo === 'auto') aplicar(actual); }); } catch(e){}

  var listo = fetch('/api/apariencia').then(function(r){ return r.ok ? r.json() : null; }).then(function(s){
    if(s){ actual = aplicar(s); recordar(actual); }
    return actual;
  }).catch(function(){ return actual; });

  window.WalkanApariencia = {
    DEF: DEF, contraste: contraste, listo: listo,
    actual: function(){ return actual; },
    vistaPrevia: function(a){ return aplicar(a); },          // aplica sin guardar
    restaurar: function(){ return aplicar(actual); },         // vuelve a la guardada
    guardar: function(a){
      return fetch('/api/apariencia', { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(a) })
        .then(function(r){ return r.json().then(function(d){ if(!r.ok) throw new Error((d && d.message && [].concat(d.message)[0]) || 'No se pudo guardar.'); return d; }); })
        .then(function(s){ actual = aplicar(s); recordar(actual); return actual; });
    }
  };
})();
