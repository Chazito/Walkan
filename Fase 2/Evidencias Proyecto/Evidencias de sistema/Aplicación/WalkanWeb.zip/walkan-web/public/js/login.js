// login.js — el form de /mi-cuenta. Manda las credenciales a /api/auth/login
// (la sesión queda en una cookie) y según el rol te tira a /admin (staff) o a /panel (el resto).
// Los errores se muestran dentro de la tarjeta (#loginMsg), no con alert()/confirm() del navegador.
(function(){
  var f=document.getElementById('login');
  var msg=document.getElementById('loginMsg');
  var email=document.getElementById('email'), pass=document.getElementById('pass');
  var btn=f.querySelector('button[type="submit"]');
  var TEXTO_BTN = btn ? btn.textContent : 'Entrar';

  // tipo: 'error' (rojo) o 'aviso' (ámbar). accion: { texto, href } opcional, para un botón dentro del mensaje.
  function mostrar(tipo, texto, accion){
    msg.className='msg msg-'+tipo;
    msg.innerHTML='';
    var ico=document.createElement('span'); ico.className='msg-ico'; ico.setAttribute('aria-hidden','true'); ico.textContent = tipo==='error' ? '!' : 'i';
    var cuerpo=document.createElement('div'); cuerpo.className='msg-txt';
    var p=document.createElement('div'); p.textContent=texto; cuerpo.appendChild(p);
    if(accion){ var a=document.createElement('a'); a.className='msg-accion'; a.href=accion.href; a.textContent=accion.texto; cuerpo.appendChild(a); }
    msg.appendChild(ico); msg.appendChild(cuerpo); msg.hidden=false;
  }
  // Con la sesión abierta, el servidor ya redirige /mi-cuenta al panel (views.controller.ts).
  function irAlPanel(u){ window.location.href = (u && u.rol === 'staff') ? '/admin' : '/panel'; }

  // ---- Segundo paso: código de la app (o de respaldo) ----
  var fc=document.getElementById('loginCodigo'), cod=document.getElementById('codigo'), cmsg=document.getElementById('codigoMsg');
  var desafio='', respaldo=false;
  // puede: la cuenta es de un dueño (el equipo Walkan siempre escribe el código; ver auth.controller.ts).
  function pedirCodigo(d, puede){
    var fila=document.getElementById('recordarDispFila'); if(fila){ fila.hidden=!puede; document.getElementById('recordarDisp').checked=false; }
    desafio=d; f.hidden=true; fc.hidden=false; msg.hidden=true;
    document.querySelector('h1').textContent='Verificación en dos pasos';
    document.querySelectorAll('.card > .sub, .card > .foot').forEach(function(el){ el.hidden=true; });
    cod.value=''; cod.focus();
  }
  function errCodigo(t){ cmsg.className='msg msg-error'; cmsg.innerHTML='<span class="msg-ico" aria-hidden="true">!</span><div class="msg-txt"></div>'; cmsg.querySelector('.msg-txt').textContent=t; cmsg.hidden=false; }
  cod.addEventListener('input', function(){ cmsg.hidden=true; });
  document.getElementById('usarRespaldo').addEventListener('click', function(e){
    e.preventDefault(); respaldo=!respaldo;
    document.getElementById('codigoLbl').textContent=respaldo?'Código de respaldo':'Código de la app de verificación';
    document.getElementById('codigoAyuda').textContent=respaldo?'Uno de los 8 códigos que guardaste al activar la verificación (por ejemplo abcde-23456). Cada uno sirve una vez.':'Abre Google Authenticator (u otra app de códigos) y escribe los 6 dígitos de Walkan.';
    this.textContent=respaldo?'Usar el código de la app':'Usar un código de respaldo';
    cod.inputMode=respaldo?'text':'numeric'; cod.placeholder=respaldo?'abcde-23456':'123 456'; cod.classList.toggle('codigo-dp', !respaldo); cod.value=''; cod.focus();
  });
  fc.addEventListener('submit', function(ev){
    ev.preventDefault();
    var c=cod.value.trim(), b=fc.querySelector('button[type="submit"]');
    if(!respaldo && !/^\d{6}$/.test(c.replace(/\s/g,''))){ errCodigo('Escribe los 6 dígitos que muestra la app.'); cod.focus(); return; }
    if(respaldo && c.replace(/[^a-z0-9]/gi,'').length<10){ errCodigo('El código de respaldo tiene 10 letras y números.'); cod.focus(); return; }
    b.disabled=true; b.textContent='Verificando…';
    fetch('/api/auth/login/codigo', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ desafio:desafio, codigo:respaldo?c:c.replace(/\s/g,''), recordarDispositivo: !!(document.getElementById('recordarDisp')||{}).checked }) })
      .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){ return { ok:r.ok, status:r.status, d:d }; }); })
      .then(function(res){
        if(res.ok){ irAlPanel(res.d.usuario); return; }
        b.disabled=false; b.textContent='Verificar y entrar';
        var m=res.d && res.d.message; m=Array.isArray(m)?m[0]:m;
        // Pasó el tiempo o demasiados intentos: vuelve a pedir la contraseña.
        if(res.status===429 || /Pasó mucho tiempo/.test(m||'')){ fc.hidden=true; f.hidden=false; document.querySelector('h1').textContent='Ingresa a tu cuenta'; document.querySelectorAll('.card > .sub, .card > .foot').forEach(function(el){ el.hidden=false; }); pass.value=''; pass.focus(); mostrar('error', m || 'Vuelve a intentarlo.'); return; }
        errCodigo(m || 'El código no es correcto.'); cod.select();
      })
      .catch(function(){ b.disabled=false; b.textContent='Verificar y entrar'; errCodigo('No hay conexión con el servidor. Revisa tu internet e inténtalo de nuevo.'); });
  });

  function limpiar(){ msg.hidden=true; email.classList.remove('invalido'); pass.classList.remove('invalido'); }
  email.addEventListener('input', limpiar); pass.addEventListener('input', limpiar);

  f.addEventListener('submit', function(ev){
    ev.preventDefault();
    limpiar();
    if(!email.value.trim() || !pass.value){
      mostrar('error', 'Ingresa tu correo y tu contraseña.');
      (email.value.trim() ? pass : email).focus(); return;
    }
    if(!email.checkValidity()){ email.classList.add('invalido'); mostrar('error', 'El correo no tiene un formato válido.'); email.focus(); return; }
    if(btn){ btn.disabled=true; btn.textContent='Entrando…'; }
    var cred = { email: email.value.trim(), password: pass.value };
    var recordar = document.getElementById('recordar');
    function post(url, body){
      return fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) })
        .then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){ return { ok:r.ok, status:r.status, d:d }; }); });
    }
    function entrar(){ return post('/api/auth/login', { email:cred.email, password:cred.password, recordar: recordar ? recordar.checked : true }); }
    entrar()
    .then(function(res){
      // Cuenta pendiente de pago: antes de mandarlo a pagar otra vez, se le pregunta a Flow si ya pagó
      // (pasa cuando Flow no alcanzó a avisarnos). Si estaba pagado, la cuenta se activa y entra al tiro.
      if(res.status === 403 && /pendiente de pago/i.test((res.d && res.d.message) || '')){
        if(btn) btn.textContent='Verificando tu pago…';
        return post('/api/registro/verificar', cred).then(function(v){ return (v.ok && v.d && v.d.activa) ? entrar() : res; });
      }
      return res;
    })
    .then(function(res){
      if(!res.ok){ var m=res.d && res.d.message; var e=new Error((Array.isArray(m)?m[0]:m) || 'No se pudo iniciar sesión.'); e.status=res.status; throw e; }
      // Verificación en dos pasos: la contraseña está bien, falta el código de la app.
      if(res.d && res.d.dosPasos){ pedirCodigo(res.d.desafio, res.d.puedeRecordar); return; }
      irAlPanel(res.d && res.d.usuario);
    })
    // Si falla se devuelve el botón a la normalidad.
    .catch(function(e){
      if(btn){ btn.disabled=false; btn.textContent=TEXTO_BTN; }
      if(/pendiente de pago/i.test(e.message)){
        mostrar('aviso', e.message, { texto:'Completar el pago', href:'/registro#reintentar' });
      } else if(e.status===429){
        mostrar('error', e.message);
      } else if(e.status===401){
        email.classList.add('invalido'); pass.classList.add('invalido');
        mostrar('error', 'Correo o contraseña incorrectos. Revisa los datos e inténtalo de nuevo.');
        pass.value=''; pass.focus();
      } else if(e instanceof TypeError){
        mostrar('error', 'No hay conexión con el servidor. Revisa tu internet e inténtalo de nuevo.');
      } else {
        mostrar('error', e.message);
      }
    });
  });
})();
