// Parte de panel.js: el servidor junta public/js/panel/*.js en orden (ver views.controller.ts) dentro de un solo
// (function(){ … })(), así que todo comparte el mismo scope. No es un módulo suelto: no cargarlo solo.
  // ================= INVENTARIO (CRUD) =================
  // Tabla de productos con buscador + chips de filtro (todos / ok / warn / bad / vence).
  // API: /api/productos (GET, POST, PUT, DELETE), /ajuste y /movimientos.
  var invFiltro='todos', invQ='';
  function thumb(p){ return '<div class="thumb">'+(p.img?'<img src="'+esc(p.img)+'" alt="">':ico('inventario'))+'</div>'; }
  // Miniatura de la tabla: la imagen si existe; si no, las iniciales (sin emojis: el campo emoji de los productos ya no se muestra).
  function thumbFila(p){ if(p.img) return thumb(p); var ini=String(p.nombre||'?').trim().split(/\s+/).slice(0,2).map(function(w){ return w.charAt(0); }).join('').toUpperCase(); return '<div class="thumb ini" aria-hidden="true">'+esc(ini)+'</div>'; }
  // Los productos que se ven con el buscador y el chip actuales (también los usan las etiquetas).
  // Orden de la tabla: click en el encabezado ordena ascendente, otro click descendente. Sin orden = como llegan (por creación).
  var invOrd=null, invDir=1;
  function productosVisibles(){
    var l=db.productos.filter(function(p){
      var hay=sinTildes(p.nombre+' '+p.sku+' '+p.cat), okQ=invQ.split(' ').every(function(w){ return hay.indexOf(w)>-1; }); // cada palabra, en cualquier orden; también por categoría
      var e=estadoStock(p), vi=venceInfo(p.vence);
      var okF = invFiltro==='todos' || (invFiltro==='vence'?vi.flag==='vence':e.c===invFiltro);
      return okQ && okF;
    });
    // Sin orden elegido: los más recientes primero. Con páginas, un producto recién creado quedaba al final (página 200).
    if(!invOrd) l.reverse();
    if(invOrd) l.sort(function(a,b){ var x=a[invOrd], y=b[invOrd];
      if(invOrd==='vence'&&(!x||!y)) return !x&&!y?0:!x?1:-1; // sin vencimiento siempre al final
      return (typeof x==='string'?x.localeCompare(y,'es'):x-y)*invDir; });
    return l;
  }
  // En el celular no se ven los encabezados (filas apiladas): el mismo orden con un selector.
  $('ordMovil').addEventListener('change', function(){ var v=this.value.split(':'); invOrd=v[0]||null; invDir=+v[1]||1; renderInventario(); });
  $('invHead').addEventListener('click', function(e){
    var b=e.target.closest('.ord'); if(!b) return;
    if(invOrd===b.dataset.ord) invDir=-invDir; else { invOrd=b.dataset.ord; invDir=1; }
    this.querySelectorAll('th[aria-sort]').forEach(function(th){ th.setAttribute('aria-sort', th.contains(b)?(invDir>0?'ascending':'descending'):'none'); });
    renderInventario();
  });
  // Paginación: con miles de productos pintar todas las filas a la vez pegaba el panel. Se filtran y ordenan todos
  // (en memoria es rápido) y se pintan de a POR_PAG. Al cambiar el buscador, el filtro o el orden se vuelve a la página 1.
  var POR_PAG=50, invPag=0, invClave='';
  function pagerInventario(total){
    var pg=$('invPager');
    if(!pg){ pg=document.createElement('nav'); pg.id='invPager'; pg.className='pager'; pg.setAttribute('aria-label','Páginas de productos'); $('invBody').closest('table').insertAdjacentElement('afterend', pg);
      pg.addEventListener('click', function(e){ var b=e.target.closest('button[data-pag]'); if(!b||b.disabled) return; invPag=+b.dataset.pag; renderInventario(); $('invBody').closest('table').scrollIntoView({block:'start'}); }); }
    var paginas=Math.max(1, Math.ceil(total/POR_PAG)), f=function(n){ return n.toLocaleString('es-CL'); };
    // Total de productos registrados siempre a la vista (y el cupo del plan); con buscador o filtro, también cuántos calzan.
    var reg=db.productos.length, lim=db.limites&&db.limites.productos;
    if(!reg){ pg.hidden=true; return; }
    pg.hidden=false;
    var plural=function(n){ return f(n)+' producto'+(n===1?'':'s'); };
    var regTxt=(total!==reg?f(total)+' de '+f(reg)+' registrados':plural(reg)+' registrado'+(reg===1?'':'s'))+(lim!=null?' · tu plan permite '+f(lim):'');
    if(total<=POR_PAG){ pg.innerHTML='<span class="muted small" aria-live="polite">'+regTxt+'</span>'; return; }
    var desde=invPag*POR_PAG+1, hasta=Math.min(total,(invPag+1)*POR_PAG);
    pg.innerHTML='<span class="muted small" aria-live="polite">Mostrando '+f(desde)+'–'+f(hasta)+' · '+regTxt+'</span><span class="pager-btns">'+
      '<button type="button" class="mini" data-pag="0"'+(invPag===0?' disabled':'')+' aria-label="Primera página">«</button>'+
      '<button type="button" class="mini" data-pag="'+(invPag-1)+'"'+(invPag===0?' disabled':'')+'>Anterior</button>'+
      '<span class="small">Página '+(invPag+1)+' de '+paginas+'</span>'+
      '<button type="button" class="mini" data-pag="'+(invPag+1)+'"'+(invPag>=paginas-1?' disabled':'')+'>Siguiente</button>'+
      '<button type="button" class="mini" data-pag="'+(paginas-1)+'"'+(invPag>=paginas-1?' disabled':'')+' aria-label="Última página">»</button></span>';
  }
  function renderInventario(){
    var clave=invQ+'|'+invFiltro+'|'+invOrd+'|'+invDir; if(clave!==invClave){ invClave=clave; invPag=0; }
    var todos=productosVisibles(), paginas=Math.max(1, Math.ceil(todos.length/POR_PAG)); if(invPag>paginas-1) invPag=paginas-1;
    var rows=todos.slice(invPag*POR_PAG, (invPag+1)*POR_PAG).map(function(p){
      var e=estadoStock(p), vi=venceInfo(p.vence);
      return '<tr><td class="thumbcel">'+thumbFila(p)+'</td><td class="prin"><b>'+esc(p.nombre)+'</b><div class="muted small">'+esc(p.cat)+'</div></td><td class="muted" data-l="SKU">'+(p.sku?esc(p.sku):'<span class="tag warn" title="Sin código la caja no puede descontar sus ventas">Sin código</span>')+'</td><td data-l="Stock">'+fmtCant(p, p.stock)+'</td><td data-l="Precio">'+clp(p.precio)+(esKg(p)?'<span class="muted small"> /kg</span>':'')+(p.precio&&p.costo?(function(m){ return '<div class="small '+(m<10?'neg':'muted')+'" title="Margen sobre el precio sin IVA">'+m+'% margen</div>'; })(margen(p.precio,p.costo)):'')+'</td><td><span class="tag '+vi.c+'">'+vi.t+'</span></td><td><span class="tag '+e.c+'">'+e.t+'</span></td>'+
        '<td class="acc"><div class="acc-fila"><button class="mini" data-ajuste="'+esc(p.id)+'" aria-label="Ajustar stock de '+esc(p.nombre)+'">± Stock</button>'+
          '<div class="menu-acc"><button type="button" class="mini icon" data-menu aria-expanded="false" aria-label="Más acciones para '+esc(p.nombre)+'" title="Más acciones">⋯</button><div class="menu-lista" hidden>'+
          (p.controlaVence?'<button type="button" data-lotes="'+esc(p.id)+'" aria-label="Lotes de '+esc(p.nombre)+'">Lotes y vencimientos</button>':'')+
          '<button type="button" data-hist="'+esc(p.id)+'" aria-label="Movimientos de '+esc(p.nombre)+'">Movimientos</button><button type="button" data-edit="'+esc(p.id)+'" aria-label="Editar '+esc(p.nombre)+'">Editar</button><button type="button" class="del" data-del="'+esc(p.id)+'" aria-label="Eliminar '+esc(p.nombre)+'">Eliminar</button></div></div></div></td></tr>';
    }).join('');
    $('invBody').innerHTML=rows||'<tr><td colspan="8" class="muted" style="text-align:center;padding:24px">Sin resultados.</td></tr>';
    pagerInventario(todos.length);
    // Cantidad en cada chip de filtro (sin contar el buscador). El número va en <span> aparte para que el nombre del botón siga siendo "Agotado 3".
    var cuenta={bad:0,warn:0,vence:0}; db.productos.forEach(function(p){ var c=estadoStock(p).c; if(cuenta[c]!=null) cuenta[c]++; if(venceInfo(p.vence).flag==='vence') cuenta.vence++; });
    document.querySelectorAll('#chipsInv .chip[data-f]').forEach(function(ch){ var n=cuenta[ch.dataset.f]; if(n==null) return; var sp=ch.querySelector('.cnt'); if(!sp){ sp=document.createElement('span'); sp.className='cnt'; ch.appendChild(sp); } sp.textContent=n?' '+n:''; });
    var om=$('ordMovil'), ov=invOrd?invOrd+':'+invDir:''; om.value=ov; if(om.value!==ov) om.value=''; // mismo orden que los encabezados
    renderResumen(); renderNoReconocidos(); // un producto nuevo puede sacar un código de la bandeja de Ventas
  }
  $('buscarProd').addEventListener('input', function(){ invQ=sinTildes(this.value); renderInventario(); });
  // Atajo "/": va al buscador de la sección abierta (si no estás escribiendo en otro campo).
  document.addEventListener('keydown', function(e){
    if(e.key!=='/'||e.ctrlKey||e.metaKey||e.altKey||/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)||modal.classList.contains('open')) return;
    var b=document.querySelector('.view.active .search'); if(b){ e.preventDefault(); b.focus(); }
  });

  // Escanear con la cámara del celular (sin lector). Solo aparece si el navegador trae BarcodeDetector (Chrome en Android).
  // Si el código no está en el inventario, ofrece crear el producto con ese SKU.
  // ponytail: sin zxing de respaldo; agregarlo si piden iPhone (Safari no trae BarcodeDetector).
  if('BarcodeDetector' in window && navigator.mediaDevices){ $('camScan').hidden=false; }
  $('camScan').addEventListener('click', function(){
    abrirModal('Escanear código','<video id="camVid" playsinline muted style="width:100%;border-radius:12px;background:#000"></video><p class="small muted" id="camMsg" aria-live="polite">Apunta al código de barras.</p><button class="btn btn-ghost" data-cerrar>Cancelar</button>');
    var vivo=true, stream=null, det=new window.BarcodeDetector();
    camStop=function(){ vivo=false; camStop=null; if(stream) stream.getTracks().forEach(function(t){ t.stop(); }); };
    navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'}}).then(function(s){
      stream=s; if(!vivo){ camStop&&camStop(); s.getTracks().forEach(function(t){ t.stop(); }); return; }
      var v=$('camVid'); v.srcObject=s; return v.play().then(function buscar(){
        if(!vivo) return;
        return det.detect(v).then(function(cods){
          if(!cods.length){ setTimeout(buscar, 250); return; }
          var cod=cods[0].rawValue; cerrarModal();
          var p=db.productos.find(function(x){ return x.sku===cod; });
          if(p){ $('buscarProd').value=cod; invQ=sinTildes(cod); renderInventario(); return; }
          abrirModal('Código '+cod,'<p>No hay ningún producto con el código <b>'+esc(cod)+'</b>.</p><div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-primary" id="camCrear">Crear producto con este código</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
          $('camCrear').addEventListener('click', function(){ formProducto({sku:cod}); });
        });
      });
    }).catch(function(){ if($('camMsg')) $('camMsg').textContent='No se pudo usar la cámara. Revisa el permiso del navegador.'; });
  });
  $('chipsInv').addEventListener('click', function(e){ var c=e.target.closest('.chip'); if(!c) return; this.querySelectorAll('.chip').forEach(function(x){x.classList.remove('on'); x.setAttribute('aria-pressed','false');}); c.classList.add('on'); c.setAttribute('aria-pressed','true'); invFiltro=c.dataset.f; renderInventario(); });

  // Categorías en uso (sin repetir, ordenadas). En el formulario se sugieren en un <datalist> junto a CATS_BASE,
  // y al guardar se reusa la ya escrita aunque cambien mayúsculas o tildes ("lacteos" → "Lácteos").
  var CATS_BASE=['Abarrotes','Bebidas','Lácteos','Panadería','Frutas y verduras','Carnes y cecinas','Congelados','Snacks y dulces','Licores','Limpieza','Aseo personal','General'];
  function categorias(){ var cats=[]; db.productos.forEach(function(p){ if(p.cat&&cats.indexOf(p.cat)<0) cats.push(p.cat); }); return cats.sort(); }
  function categoriaCanon(v){ var k=sinTildes(v); return categorias().concat(CATS_BASE).filter(function(c){ return sinTildes(c)===k; })[0]||v; }

  // Modal para crear o editar producto (si viene p.id es edición).
  // El stock inicial solo se pide al crear; después se mueve con ajustes, ventas o recepciones.
  // El vencimiento ya no se edita acá: sale de los lotes. Solo se pide para el lote del stock inicial.
  function formProducto(p){
    var opts='<option value="">— Sin proveedor —</option>'+db.proveedores.map(function(pr){ return '<option value="'+esc(pr.id)+'"'+(p&&p.prov===pr.id?' selected':'')+'>'+esc(pr.nombre)+'</option>'; }).join('');
    p=p||{};
    var cats=categorias(), ks=cats.map(sinTildes); cats=cats.concat(CATS_BASE.filter(function(c){ return ks.indexOf(sinTildes(c))<0; }));
    abrirModal(p.id?'Editar producto':'Nuevo producto',
      '<div class="imgpick" style="margin-bottom:16px"><div class="imgprev" id="imgPrev">'+(p.img?'<img src="'+esc(p.img)+'" alt="Imagen del producto">':ico('inventario'))+'</div><div><label class="mini" style="display:inline-block">Subir imagen<input type="file" id="imgFile" accept="image/jpeg,image/png,image/webp" hidden></label><div class="muted small" style="margin-top:5px">Imagen de referencia (opcional)</div></div></div>'+
      '<div class="form-grid">'+
      '<div class="f full"><label>Nombre</label><input id="fNombre" value="'+esc(p.nombre)+'"></div>'+
      '<div class="f"><label>SKU / Código de barras '+ayuda('El código que lee la caja. Debe ser igual al de la caja para que las ventas descuenten stock. Si el producto no trae código (pan, fruta, verdura), déjalo vacío: Walkan le asigna un código interno que puedes imprimir en Etiquetas.')+'</label><input id="fSku" value="'+esc(p.sku)+'" placeholder="Vacío = código interno"></div>'+
      '<div class="f"><label>Categoría '+ayuda('Escribe para buscar entre tus categorías o elige una de la lista. Si no existe, escríbela y se crea al guardar.')+'</label><input id="fCat" list="fCats" autocomplete="off" placeholder="Buscar o crear…" value="'+esc(p.cat)+'">'+
        '<datalist id="fCats">'+cats.map(function(c){ return '<option value="'+esc(c)+'">'; }).join('')+'</datalist></div>'+
      '<div class="f"><label>Precio venta</label><input id="fPrecio" type="number" min="0" value="'+(Number(p.precio)||'')+'"></div>'+
      '<div class="f"><label>Costo</label><input id="fCosto" type="number" min="0" value="'+(Number(p.costo)||'')+'"></div>'+
      '<p class="small f full" id="fMargen" aria-live="polite" style="margin:-4px 0 0"></p>'+
      '<div class="f full" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:-6px"><label for="fMObj" class="small muted" style="margin:0">Precio para un margen de</label><input id="fMObj" class="qty" type="number" min="1" max="90" value="30" style="width:64px"><span class="small muted">%</span><button type="button" class="mini" id="fCalcPrecio">Calcular precio</button>'+ayuda('El margen se calcula sobre el precio sin IVA: precio ÷ 1,19 menos el costo neto. Si tus costos traen IVA, márcalo en Analíticas › Parámetros.')+'</div>'+
      '<div class="f"><label for="fUnidad">Se vende</label><select id="fUnidad"><option value="un">Por unidad</option><option value="kg"'+(esKg(p)?' selected':'')+'>Por kilo (granel)</option></select></div>'+
      '<div class="f" id="fPluBox"'+(esKg(p)?'':' hidden')+'><label for="fPlu">Código de balanza (PLU) '+ayuda('Programa este número en tu balanza como PLU o código de artículo. La etiqueta que imprime la balanza lo lleva, y al pasarla por la caja descuenta los kilos de este producto. Déjalo vacío y Walkan asigna uno.')+'</label><input id="fPlu" type="number" min="1" max="99999" step="1" placeholder="Automático" value="'+(p.plu?Number(p.plu):'')+'"></div>'+
      (p.id?'':'<div class="f"><label>Stock inicial</label><input id="fStock" type="number" min="0" step="'+paso(p)+'" value=""></div>')+
      '<div class="f"><label>Stock mínimo '+ayuda('Bajo este número el producto sale como "Bajo" y se sugiere reponer. Déjalo vacío para que Walkan lo calcule.')+'</label><input id="fMin" type="number" min="0" step="'+paso(p)+'" placeholder="Automático" value="'+(p.stockMin!=null?Number(p.stockMin):'')+'"></div>'+
      '<div class="f full"><label class="check"><input type="checkbox" id="fControla"'+(p.controlaVence?' checked':'')+'> Controla vencimiento</label>'+ayuda('Actívalo en productos que vencen (lácteos, cecinas, pan). Cada vez que entre stock se pedirá la fecha de vencimiento y se guardará como un lote. Las ventas descuentan primero el lote que vence antes.')+'</div>'+
      '<div class="f" data-lote'+(p.controlaVence?'':' hidden')+'><label for="fVida">Vida útil (días) '+ayuda('Para pan, fruta o verdura que no traen fecha: el vencimiento del lote se calcula solo (hoy + estos días).')+'</label><input id="fVida" type="number" min="1" max="3650" step="1" placeholder="Opcional" value="'+(p.vidaUtil?Number(p.vidaUtil):'')+'"></div>'+
      (p.id?'':'<div class="f" data-lote'+(p.controlaVence?'':' hidden')+'><label for="fVence">Vencimiento del stock inicial</label><input id="fVence" type="date"></div>'+
        '<div class="f" data-lote'+(p.controlaVence?'':' hidden')+'><label for="fLote">Lote (opcional) '+ayuda('El código de lote que viene impreso en el envase. Sirve para ubicarlo si hay un retiro del producto.')+'</label><input id="fLote" maxlength="40" placeholder="Código del envase"></div>')+
      '<div class="f full"><label>Proveedor</label><select id="fProv">'+opts+'</select></div>'+
      '</div>'+
      (p.id?'<details id="fHist" style="margin-top:14px"><summary class="small" style="cursor:pointer;font-weight:600">Historial de precio y costo</summary><div class="small muted" style="margin-top:8px">Cargando…</div></details>'+
        '<details id="fCostProv" style="margin-top:8px"><summary class="small" style="cursor:pointer;font-weight:600">Costo por proveedor</summary><div class="small muted" style="margin-top:8px">Cargando…</div></details>':'')+
      '<div style="display:flex; gap:8px; margin-top:18px"><button class="btn btn-primary" id="guardarProd">'+(p.id?'Guardar cambios':'Crear producto')+'</button>'+(p.id?'<button class="btn btn-ghost" id="duplicarProd" type="button">Duplicar</button>':'')+'<button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    var imgData=p.img||'';
    // Duplicar: un producto nuevo con los mismos datos (para variantes: otro sabor o tamaño), sin SKU, stock ni imagen.
    var dup=$('duplicarProd'); if(dup) dup.addEventListener('click', function(){
      formProducto({nombre:p.nombre+' (copia)', cat:p.cat, precio:p.precio, costo:p.costo, stockMin:p.stockMin, controlaVence:p.controlaVence, vidaUtil:p.vidaUtil, unidad:p.unidad, prov:p.prov, emoji:p.emoji}); // sin PLU: es único
      $('fSku').focus();
    });
    // Historial: se pide al abrir el desplegable (no en cada edición).
    var hist=$('fHist'); if(hist) hist.addEventListener('toggle', function cargar(){ hist.removeEventListener('toggle', cargar);
      API.lista('/api/productos/'+encodeURIComponent(p.id)+'/precios').then(function(hs){
        hist.querySelector('div').outerHTML='<table style="margin-top:8px"><thead><tr><th>Fecha</th><th>Precio</th><th>Costo</th><th>Margen</th></tr></thead><tbody>'+
          (hs.map(function(h){ var m=h.precio?margen(h.precio,h.costo):null; return '<tr><td>'+fmtFecha(h.fecha)+'</td><td>'+clp(h.precio)+'</td><td>'+clp(h.costo)+'</td><td>'+(m==null||!h.costo?'—':'<span class="tag '+(m<10?'bad':m<20?'warn':'ok')+'">'+m+'%</span>')+'</td></tr>'; }).join('')||'<tr><td colspan="4" class="muted">Sin cambios registrados.</td></tr>')+'</tbody></table>';
      }).catch(function(){ hist.querySelector('div').textContent='No se pudo cargar el historial.'; });
    });
    // Costo por proveedor: lo último que se le pagó a cada uno (el más barato primero, lo marca la API con el orden). Mismo patrón perezoso.
    var cpv=$('fCostProv'); if(cpv) cpv.addEventListener('toggle', function cargar(){ cpv.removeEventListener('toggle', cargar);
      API.lista('/api/productos/'+encodeURIComponent(p.id)+'/costos-proveedor').then(function(cs){
        cpv.querySelector('div').outerHTML='<table style="margin-top:8px"><thead><tr><th>Proveedor</th><th>Último costo</th><th>Fecha</th></tr></thead><tbody>'+
          (cs.map(function(c,i){ return '<tr><td>'+esc(c.proveedor)+(i===0&&cs.length>1?' <span class="tag ok">Más barato</span>':'')+'</td><td>'+clp(c.costo)+'</td><td>'+fmtFecha(c.fecha)+'</td></tr>'; }).join('')||'<tr><td colspan="3" class="muted">Sin compras registradas a proveedores.</td></tr>')+'</tbody></table>';
      }).catch(function(){ cpv.querySelector('div').textContent='No se pudo cargar el costo por proveedor.'; });
    });
    // Margen sobre el precio sin IVA, en vivo (ver margen()). Avisa si el precio no cubre el costo.
    function verMargen(){ var pv=+$('fPrecio').value||0, c=+$('fCosto').value||0, m=$('fMargen');
      if(!pv||!c){ m.textContent=''; return; }
      var g=Math.round(pv/1.19-costoNeto(c)), u=esKg({unidad:$('fUnidad').value})?'kilo':'unidad';
      m.className='small f full '+(g<=0?'tag bad':'muted');
      m.textContent=g<=0?'El precio no cubre el costo: pierdes '+clp(-g)+' por '+u+' (sin IVA).':'Ganas '+clp(g)+' por '+u+' sin IVA (margen '+margen(pv,c)+'%).'; }
    $('fPrecio').addEventListener('input', verMargen); $('fCosto').addEventListener('input', verMargen); verMargen();
    // Precio = costo neto / (1 − margen) + IVA, redondeado hacia arriba a la decena (en Chile no hay monedas de $1 ni $5).
    $('fCalcPrecio').addEventListener('click', function(){
      var c=+$('fCosto').value||0, m=(+$('fMObj').value||0)/100;
      if(!c){ aviso('Primero escribe el costo.'); $('fCosto').focus(); return; }
      if(m<=0||m>=0.9){ aviso('El margen debe estar entre 1 y 89 %.'); $('fMObj').focus(); return; }
      $('fPrecio').value=Math.ceil(costoNeto(c)/(1-m)*1.19/10)*10; verMargen();
    });
    $('fControla').addEventListener('change', function(){ var on=this.checked; document.querySelectorAll('#modalBody [data-lote]').forEach(function(x){ x.hidden=!on; }); });
    // Por kilo: muestra el PLU y deja cantidades con gramos (3 decimales).
    $('fUnidad').addEventListener('change', function(){ var kg=this.value==='kg'; $('fPluBox').hidden=!kg; ['fStock','fMin'].forEach(function(id){ if($(id)) $(id).step=kg?'0.001':'1'; }); verMargen(); });
    $('imgFile').addEventListener('change', function(){
      var f=this.files[0], inp=this; if(!f) return;
      // Se revisa antes de leer: un archivo enorme (QA probó uno de 2 GB) o que no es foto colgaba la pestaña sin aviso.
      // La API igual rechaza todo lo que pase de ~200 KB (bodyLimit 1 MB y MaxLength en el DTO).
      if(!/^image\/(jpeg|png|webp)$/.test(f.type)){ inp.value=''; aviso('Elige una foto JPG, PNG o WebP.'); return; }
      if(f.size>15e6){ inp.value=''; aviso('La foto es muy pesada (máx. 15 MB). Prueba con otra o sácala de nuevo con menos resolución.'); return; }
      // Se reduce a 400px en el navegador: la API limita la imagen a ~200KB. createObjectURL no copia el archivo a memoria.
      var url=URL.createObjectURL(f), im=new Image();
      im.onload=function(){ var k=Math.min(1,400/Math.max(im.width,im.height)); var cv=document.createElement('canvas'); cv.width=Math.round(im.width*k); cv.height=Math.round(im.height*k); cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height); imgData=cv.toDataURL('image/jpeg',0.8); URL.revokeObjectURL(url); $('imgPrev').innerHTML='<img src="'+imgData+'" alt="Imagen del producto">'; };
      im.onerror=function(){ URL.revokeObjectURL(url); inp.value=''; aviso('No pudimos abrir esa foto. Prueba con otra.'); };
      im.src=url;
    });
    $('guardarProd').addEventListener('click', function(){
      var nombre=$('fNombre').value.trim(); if(!nombre){ aviso('Escribe el nombre del producto.'); $('fNombre').focus(); return; }
      var datos={nombre:nombre, sku:$('fSku').value.trim(), cat:categoriaCanon($('fCat').value.trim())||'General', precio:+$('fPrecio').value||0, costo:+$('fCosto').value||0, stockMin:$('fMin').value===''?null:+$('fMin').value, controlaVence:$('fControla').checked, prov:$('fProv').value, img:imgData,
        unidad:$('fUnidad').value, plu:$('fUnidad').value==='kg'&&$('fPlu').value!==''?+$('fPlu').value:null, vidaUtil:$('fControla').checked&&$('fVida').value!==''?+$('fVida').value:null};
      if(!p.id){
        datos.stock=+$('fStock').value||0; // después, el stock solo cambia por movimientos
        if(datos.controlaVence){ datos.vence=$('fVence').value; datos.lote=$('fLote').value.trim(); }
        // Con vida útil no hace falta: el backend pone hoy + días.
        if(datos.controlaVence && datos.stock>0 && !datos.vence && !datos.vidaUtil){ aviso('Indica el vencimiento del stock inicial.'); $('fVence').focus(); return; }
      }
      var btn=this; btn.disabled=true; // un doble clic o doble Enter no crea dos productos
      var req = p.id ? API.send('PUT','/api/productos/'+p.id,datos) : API.send('POST','/api/productos',datos);
      req.then(function(saved){
        if(p.id){ var i=db.productos.findIndex(function(x){return x.id===p.id;}); if(i>-1) db.productos[i]=saved; }
        else { db.productos.push(saved); }
        renderInventario(); recargarLotes(); cerrarModal();
      }).catch(function(e){ btn.disabled=false; aviso('No se pudo guardar: '+e.message); });
    });
  }
  $('nuevoProd').addEventListener('click', function(){ formProducto(null); });
  // Exporta el inventario a CSV para Excel: separador ";" (Excel en español) y BOM para que lea bien los tildes.
  // Una celda que parte con = + - @ se antepone con ' para que Excel no la ejecute como fórmula (inyección CSV).
  function celdaCSV(v){ var t=String(v==null?'':v); if(typeof v!=='number'&&/^[=+\-@\t\r]/.test(t)) t="'"+t; return /[";\n\r]/.test(t)?'"'+t.replace(/"/g,'""')+'"':t; }
  // CSV para Excel: separador ";", BOM para las tildes y celdas protegidas con celdaCSV (inventario y kardex).
  function descargarCSV(archivo, cab, filas){
    var csv=String.fromCharCode(0xfeff)+[cab].concat(filas).map(function(f){ return f.map(celdaCSV).join(';'); }).join(String.fromCharCode(13,10));
    var a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
    a.download=archivo; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function(){ URL.revokeObjectURL(a.href); }, 1000);
  }
  $('exportarProd').addEventListener('click', function(){
    descargarCSV('inventario-'+hoyISO()+'.csv', ['Nombre','SKU','Categoría','Stock','Unidad','Stock mínimo','Precio','Costo','Proveedor','Vence','Estado'],
      db.productos.map(function(p){ return [p.nombre,p.sku,p.cat,Math.round((Number(p.stock)||0)*1000)/1000,esKg(p)?'kg':'un',p.stockMin,p.precio,p.costo,p.prov?provNombre(p.prov):'',p.vence||'',estadoStock(p).t]; }));
  });

  // Archivados: productos eliminados que tenían historial. Se pueden restaurar (vuelven con su stock y, si nadie lo tomó, su SKU).
  $('verArchivados').addEventListener('click', function(){
    abrirModal('Productos archivados','<p class="muted small">Cargando…</p>');
    API.lista('/api/productos/archivados').then(function(ls){
      $('modalBody').innerHTML='<p class="intro" style="margin:0 0 12px">Productos que eliminaste y tenían movimientos: se guardan para no perder su historial. Restaurar los devuelve al inventario.</p>'+
        '<table><thead><tr><th>Producto</th><th>SKU</th><th>Stock</th><th></th></tr></thead><tbody>'+
        (ls.map(function(p){ return '<tr><td>'+esc(p.nombre)+'</td><td class="muted">'+esc(p.sku)+'</td><td>'+fmtCant(p, p.stock)+'</td><td><button class="mini" data-restaurar="'+esc(p.id)+'" aria-label="Restaurar '+esc(p.nombre)+'">Restaurar</button></td></tr>'; }).join('')||'<tr><td colspan="4" class="muted">No hay productos archivados.</td></tr>')+'</tbody></table>';
      $('modalBody').querySelector('tbody').addEventListener('click', function(e){
        var b=e.target.closest('[data-restaurar]'); if(!b) return; b.disabled=true;
        API.send('POST','/api/productos/'+encodeURIComponent(b.dataset.restaurar)+'/restaurar').then(function(r){
          db.productos.push(r.producto); db.archivados=(db.archivados||[]).filter(function(x){ return x.id!==r.producto.id; }); renderInventario(); recargarLotes();
          b.closest('tr').innerHTML='<td colspan="4" class="small">'+ico('ok')+''+esc(r.producto.nombre)+' volvió al inventario'+(r.skuRecuperado?'':r.skuTomado?'. Su SKU lo usa otro producto: asígnale uno nuevo':'. No tenía SKU guardado: asígnale uno para que la caja lo descuente')+'.</td>';
        }).catch(function(e){ b.disabled=false; aviso('No se pudo restaurar: '+e.message); });
      });
    }).catch(function(){ errorModal('los archivados'); });
  });

  // Ajuste masivo de precios (+/− %) por categoría o proveedor, con redondeo chileno y vista previa.
  // Va todo en un solo PUT /api/productos/precios (todo o nada); cada cambio queda igual en el historial de precios.
  $('preciosProd').addEventListener('click', function(){
    if(!db.productos.length){ aviso('Aún no tienes productos.'); return; }
    var cats=categorias();
    abrirModal('Cambiar precios en bloque',
      '<p class="intro" style="margin:0 0 12px">Sube o baja el precio de venta de un grupo de productos de una vez (por ejemplo, cuando el proveedor sube su lista). Revisa la vista previa antes de aplicar.</p>'+
      '<div class="form-grid"><div class="f"><label for="bpGrupo">Productos</label><select id="bpGrupo"><option value="">Todos</option><optgroup label="Categoría">'+cats.map(function(c){ return '<option value="c:'+esc(c)+'">'+esc(c)+'</option>'; }).join('')+'</optgroup>'+
        (db.proveedores.length?'<optgroup label="Proveedor">'+db.proveedores.map(function(p){ return '<option value="p:'+esc(p.id)+'">'+esc(p.nombre)+'</option>'; }).join('')+'</optgroup>':'')+'</select></div>'+
      '<div class="f"><label for="bpPct">Cambio (%)</label><input id="bpPct" type="number" step="0.5" value="5"></div>'+
      '<div class="f full"><label for="bpRed">Redondeo</label><select id="bpRed"><option value="10">A la decena ($1.234 → $1.230)</option><option value="90">Terminado en 90 ($1.234 → $1.290)</option><option value="100">A la centena ($1.234 → $1.200)</option></select></div></div>'+
      '<div style="max-height:min(40vh,calc(90vh - 420px));min-height:120px;overflow:auto;margin-top:12px"><table><thead><tr><th>Producto</th><th>Ahora</th><th>Nuevo</th><th>Margen</th></tr></thead><tbody id="bpBody"></tbody></table></div>'+
      '<div style="display:flex;gap:8px;margin-top:12px"><button class="btn btn-primary" id="bpAplicar">Aplicar</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    var red=function(x,m){ return m==='90'?Math.max(90,Math.ceil((x+10)/100)*100-10):Math.max(0,Math.round(x/+m)*+m); };
    var cambios=[];
    function previa(){
      var g=$('bpGrupo').value, pct=parseFloat($('bpPct').value)||0, m=$('bpRed').value;
      cambios=db.productos.filter(function(p){ return !g||(g[0]==='c'?p.cat===g.slice(2):p.prov===g.slice(2)); })
        .map(function(p){ return {p:p, nuevo:red(p.precio*(1+pct/100),m)}; }).filter(function(x){ return x.p.precio>0&&x.nuevo>0&&x.nuevo!==x.p.precio; }); // nunca deja un precio en 0
      $('bpBody').innerHTML=cambios.map(function(x){ var mg=x.p.costo?margen(x.nuevo,x.p.costo):null;
        return '<tr><td>'+esc(x.p.nombre)+'</td><td>'+clp(x.p.precio)+'</td><td><b>'+clp(x.nuevo)+'</b></td><td>'+(mg==null?'—':'<span class="tag '+(mg<10?'bad':mg<20?'warn':'ok')+'">'+mg+'%</span>')+'</td></tr>'; }).join('')||'<tr><td colspan="4" class="muted">Ningún precio cambia con estos valores.</td></tr>';
      $('bpAplicar').textContent=cambios.length?'Aplicar a '+cambios.length+' producto'+(cambios.length>1?'s':''):'Aplicar';
    }
    ['bpGrupo','bpPct','bpRed'].forEach(function(id){ $(id).addEventListener('input', previa); $(id).addEventListener('change', previa); }); previa();
    $('bpAplicar').addEventListener('click', function(){
      if(!cambios.length){ aviso('Ningún precio cambia con estos valores.'); return; }
      var b=this; b.disabled=true;
      API.send('PUT','/api/productos/precios',{cambios:cambios.map(function(x){ return {id:x.p.id, precio:x.nuevo}; })}).then(function(r){
        cambios.forEach(function(x){ x.p.precio=x.nuevo; }); // x.p es el mismo objeto de db.productos
        renderInventario(); var ok=r.cambiados;
        $('modalBody').innerHTML='<div class="ped-ok">'+ico('ok')+''+ok+' precio'+(ok===1?'':'s')+' actualizado'+(ok===1?'':'s')+'. Recuerda que la caja usa sus propios precios: actualízalos también allá.</div><button class="btn btn-ghost" data-cerrar style="margin-top:14px">Cerrar</button>';
      }).catch(function(e){ b.disabled=false; aviso('No se cambió ningún precio: '+e.message); });
    });
  });

  // Conteo físico por categoría: anotas lo que hay en la góndola y Walkan registra la diferencia como ajuste
  // "Conteo físico" (un POST /ajuste por producto con diferencia). Vacío = no se contó y no se toca.
  // Si un producto que vence aparece con más unidades de las registradas, pide el vencimiento de lo que sobra.
  $('conteoProd').addEventListener('click', function(){
    if(!db.productos.length){ aviso('Aún no tienes productos para contar.'); return; }
    var cats=categorias();
    abrirModal('Conteo físico',
      '<p class="intro" style="margin:0 0 12px">Cuenta lo que hay de verdad y anótalo. Al confirmar se registra la diferencia de cada producto como ajuste «Conteo físico». Deja vacío lo que no contaste.</p>'+
      '<div class="form-grid"><div class="f"><label for="cnCat">Categoría</label><select id="cnCat"><option value="">Todas</option>'+cats.map(function(c){ return '<option>'+esc(c)+'</option>'; }).join('')+'</select></div>'+
      '<div class="f"><label for="cnBuscar">Buscar</label><input id="cnBuscar" type="search" placeholder="Nombre o código" autocomplete="off"></div></div>'+
      '<p class="small muted" id="cnCuantos" aria-live="polite" style="margin:6px 0 0"></p>'+
      '<div style="max-height:min(50vh,calc(90vh - 330px));min-height:140px;overflow:auto;margin-top:12px"><table><thead><tr><th>Producto</th><th>Sistema</th><th>Contado</th><th>Dif.</th></tr></thead><tbody id="cnBody"></tbody></table></div>'+
      '<p class="small muted" id="cnRes" aria-live="polite"></p><div style="display:flex;gap:8px"><button class="btn btn-primary" id="cnAplicar">Registrar ajustes</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    var contado={}, vence={}; // se conservan al cambiar de categoría
    // Con miles de productos se pintan hasta CN_MAX filas: se cuenta por categoría o buscando. Lo anotado se conserva
    // al cambiar de categoría o de búsqueda. Antes se pintaban los 10.000 y cada fila recontaba todo (≈10 s).
    var CN_MAX=200;
    function pintar(){
      var cat=$('cnCat').value, q=sinTildes($('cnBuscar').value.trim());
      var lista=db.productos.filter(function(p){ return (!cat||p.cat===cat) && (!q||sinTildes(p.nombre+' '+(p.sku||'')).indexOf(q)>-1); });
      var f=function(n){ return n.toLocaleString('es-CL'); };
      $('cnCuantos').textContent=lista.length>CN_MAX?'Se muestran '+f(CN_MAX)+' de '+f(lista.length)+' productos: elige una categoría o busca para ver el resto.':f(lista.length)+' producto'+(lista.length===1?'':'s')+'.';
      $('cnBody').innerHTML=lista.slice(0,CN_MAX).map(function(p){
        var v=contado[p.id]!=null?contado[p.id]:'';
        return '<tr data-id="'+esc(p.id)+'"><td>'+esc(p.nombre)+(p.controlaVence?'<div class="cnV" hidden><input type="date" class="cnF" name="cnF" aria-label="Vencimiento de lo que sobra de '+esc(p.nombre)+'" value="'+esc(vence[p.id]||'')+'"></div>':'')+'</td><td>'+fmtCant(p, p.stock)+'</td><td><input class="cnQ" name="cnQ" type="number" min="0" step="'+paso(p)+'" inputmode="'+(esKg(p)?'decimal':'numeric')+'" style="width:76px" value="'+esc(v)+'" aria-label="Contado de '+esc(p.nombre)+'"></td><td class="cnD"></td></tr>';
      }).join('');
      $('cnBody').querySelectorAll('tr').forEach(function(tr){ dif(tr, true); });
      resumenConteo();
    }
    function resumenConteo(){
      var n=Object.keys(contado).filter(function(id){ var x=prodPorId(id); return contado[id]!=null&&x&&contado[id]!==x.stock; }).length;
      $('cnRes').textContent=n?n+' producto'+(n>1?'s':'')+' con diferencia.':'';
    }
    function dif(tr, sinResumen){
      var p=prodPorId(tr.dataset.id), q=tr.querySelector('.cnQ').value, d=q===''?null:Math.round((parseFloat(q)-p.stock)*1000)/1000; // kg: hasta gramos
      contado[p.id]=q===''?null:parseFloat(q);
      tr.querySelector('.cnD').innerHTML=d==null?'':d===0?'<span class="tag ok">OK</span>':'<b class="tag '+(d<0?'bad':'warn')+'">'+(d>0?'+':'')+fmtCant(p, d)+'</b>';
      var bv=tr.querySelector('.cnV'); if(bv) bv.hidden=!(d>0);
      if(!sinResumen) resumenConteo();
    }
    $('cnCat').addEventListener('change', pintar);
    var cnT=null; $('cnBuscar').addEventListener('input', function(){ clearTimeout(cnT); cnT=setTimeout(pintar, 150); });
    $('cnBody').addEventListener('input', function(e){ var tr=e.target.closest('tr'); if(!tr) return; if(e.target.classList.contains('cnF')) vence[tr.dataset.id]=e.target.value; else dif(tr); });
    pintar();
    $('cnAplicar').addEventListener('click', function(){
      var cambios=[];
      for(var id in contado){ var p=prodPorId(id), c=contado[id]; if(c==null||!p||c===p.stock) continue;
        if(c<0||isNaN(c)){ aviso('El contado de "'+p.nombre+'" debe ser 0 o más.'); return; }
        var d=Math.round((c-p.stock)*1000)/1000, b={cantidad:d, motivo:'Conteo físico'};
        if(d>0&&p.controlaVence){ if(!vence[id]&&!p.vidaUtil){ aviso('Indica el vencimiento de lo que sobra de "'+p.nombre+'".'); return; } b.vence=vence[id]; }
        cambios.push({p:p,b:b}); }
      if(!cambios.length){ aviso('No hay diferencias que registrar.'); return; }
      this.disabled=true; var ok=0, fallas=[];
      cambios.reduce(function(pr,x){ return pr.then(function(){
        return API.send('POST','/api/productos/'+encodeURIComponent(x.p.id)+'/ajuste',x.b).then(function(s){ var i=db.productos.findIndex(function(y){return y.id===s.id;}); if(i>-1) db.productos[i]=s; ok++; })
          .catch(function(e){ fallas.push(x.p.nombre+': '+e.message); });
      }); }, Promise.resolve()).then(function(){
        renderInventario(); recargarLotes(); recargarMermas();
        $('modalBody').innerHTML='<div class="ped-ok">'+ico('ok')+''+ok+' ajuste'+(ok===1?'':'s')+' registrado'+(ok===1?'':'s')+' como «Conteo físico».</div>'+
          (fallas.length?'<ul class="small" role="alert">'+fallas.map(function(f){ return '<li>'+esc(f)+'</li>'; }).join('')+'</ul>':'')+'<button class="btn btn-ghost" data-cerrar style="margin-top:14px">Cerrar</button>';
      });
    });
  });

  // Etiquetas de góndola para imprimir (A4, 3 × 8 de 63,5 × 36 mm): nombre, precio y código EAN-13 si el SKU lo es.
  // Parte con los productos que se ven en la tabla (buscador + chip), todos marcados.
  $('etiquetasProd').addEventListener('click', function(){
    var ps=productosVisibles();
    if(!ps.length){ aviso('No hay productos en la tabla para imprimir.'); return; }
    abrirModal('Etiquetas de precio',
      '<p class="intro" style="margin:0 0 12px">Elige qué productos imprimir y cuántas copias de cada uno. Se abre una hoja A4 lista para imprimir (sirve para papel adhesivo de 24 etiquetas).</p>'+
      '<div style="max-height:45vh;overflow:auto"><table><thead><tr><th><input type="checkbox" id="etTodos" checked aria-label="Marcar todos"></th><th>Producto</th><th>Precio</th><th>Copias</th></tr></thead><tbody>'+
      ps.map(function(p){ return '<tr><td><input type="checkbox" class="etSel" name="etSel" data-id="'+esc(p.id)+'" checked aria-label="Imprimir '+esc(p.nombre)+'"></td><td>'+esc(p.nombre)+'</td><td>'+clp(p.precio)+(esKg(p)?' /kg':'')+'</td><td><input class="etN" name="etN" type="number" min="1" max="99" value="1" style="width:64px" aria-label="Copias de '+esc(p.nombre)+'"></td></tr>'; }).join('')+
      '</tbody></table></div><div style="display:flex;gap:8px;margin-top:14px"><button class="btn btn-primary" id="etImprimir">Abrir hoja para imprimir</button><button class="btn btn-ghost" id="etLista">Lista de precios</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    // Lista de precios A4 de los productos marcados, agrupada por categoría (para pegar en el local o mandar como PDF).
    $('etLista').addEventListener('click', function(){
      var sel=[].slice.call(document.querySelectorAll('#modalBody .etSel:checked')).map(function(c){ return prodPorId(c.dataset.id); }).filter(Boolean);
      if(!sel.length){ aviso('Marca al menos un producto.'); return; }
      var w=window.open('','_blank'); if(!w){ aviso('El navegador bloqueó la ventana: permite ventanas emergentes para imprimir.'); return; }
      var cats={}; sel.forEach(function(p){ (cats[p.cat]=cats[p.cat]||[]).push(p); });
      var html=Object.keys(cats).sort(function(a,b){ return a.localeCompare(b,'es'); }).map(function(c){
        return '<h2>'+esc(c)+'</h2><table>'+cats[c].sort(function(a,b){ return a.nombre.localeCompare(b.nombre,'es'); }).map(function(p){ return '<tr><td>'+esc(p.nombre)+'</td><td class="pr">'+clp(p.precio)+(esKg(p)?' /kg':'')+'</td></tr>'; }).join('')+'</table>'; }).join('');
      w.document.write('<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Lista de precios · '+esc(negocio())+'</title><style>@page{size:A4;margin:14mm}body{font-family:system-ui,sans-serif;color:#000;columns:2;column-gap:12mm;font-size:11pt}h1{column-span:all;font-size:18pt;margin:0 0 2px}p{column-span:all;margin:0 0 10px;color:#444}h2{font-size:12pt;margin:12px 0 4px;border-bottom:2px solid #000;break-after:avoid}table{width:100%;border-collapse:collapse;break-inside:auto}td{padding:3px 0;border-bottom:1px dotted #999}tr{break-inside:avoid}.pr{text-align:right;font-weight:700;white-space:nowrap}</style></head><body>'+
        '<h1>'+esc(negocio())+'</h1><p>Lista de precios al '+fmtFecha(hoyISO())+'. Precios con IVA incluido.</p>'+html+'</body></html>');
      w.document.close(); w.focus(); setTimeout(function(){ w.print(); }, 300); cerrarModal();
    });
    $('etTodos').addEventListener('change', function(){ var on=this.checked; document.querySelectorAll('#modalBody .etSel').forEach(function(c){ c.checked=on; }); });
    $('etImprimir').addEventListener('click', function(){
      var et='';
      document.querySelectorAll('#modalBody tbody tr').forEach(function(tr){
        var c=tr.querySelector('.etSel'); if(!c.checked) return;
        var p=prodPorId(c.dataset.id), n=Math.min(99,Math.max(1,parseInt(tr.querySelector('.etN').value,10)||1)); if(!p) return;
        // A granel no lleva código de barras: se pesa y la balanza imprime su propia etiqueta con el PLU.
        var kg=esKg(p), cod=kg?'<div class="s">Balanza: PLU '+('0000'+(Number(p.plu)||0)).slice(-5)+'</div>':(window.ean13SVG&&window.ean13SVG(p.sku))||(p.sku?'<div class="s">'+esc(p.sku)+'</div>':'');
        for(var i=0;i<n;i++) et+='<div class="e"><div class="n">'+esc(p.nombre)+'</div><div class="p">'+clp(p.precio)+(kg?'<small> por kg</small>':'')+'</div>'+cod+'</div>';
      });
      if(!et){ aviso('Marca al menos un producto.'); return; }
      var w=window.open('','_blank'); if(!w){ aviso('El navegador bloqueó la ventana: permite ventanas emergentes para imprimir.'); return; }
      w.document.write('<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Etiquetas · '+esc(negocio())+'</title><style>'+
        '@page{size:A4;margin:10mm 7mm}body{margin:0;font-family:system-ui,sans-serif;color:#000}.g{display:grid;grid-template-columns:repeat(3,63.5mm);grid-auto-rows:36mm;justify-content:center}'+
        '.e{border:1px dashed #bbb;padding:2.5mm 3mm;box-sizing:border-box;display:flex;flex-direction:column;justify-content:space-between;overflow:hidden;break-inside:avoid}'+
        '.n{font-size:10.5pt;font-weight:600;line-height:1.15;max-height:2.35em;overflow:hidden}.p{font-size:22pt;font-weight:800;line-height:1}.p small{font-size:10pt;font-weight:600}.ean{height:11mm;width:auto;align-self:flex-start}.s{font:9pt monospace}'+
        '@media print{.e{border-color:#eee}}</style></head><body><div class="g">'+et+'</div></body></html>');
      // Se imprime desde acá (sin <script> dentro de la hoja): sigue funcionando si después se agrega una CSP estricta.
      w.document.close(); w.focus(); setTimeout(function(){ w.print(); }, 300); cerrarModal();
    });
  });

  // Importar productos desde CSV (el mismo formato que exporta, o uno armado en Excel).
  // Separador ; o , (se detecta), columnas por nombre de encabezado. Vista previa antes de crear nada;
  // un SKU que ya existe (o repetido en el archivo) se omite para no duplicar. Todo va en un POST /api/productos/importar,
  // que devuelve el resultado de cada fila en el mismo orden.
  function leerCSV(txt){
    txt=txt.replace(/^﻿/,''); var sep=(txt.split('\n')[0].split(';').length>=txt.split('\n')[0].split(',').length)?';':',';
    var filas=[], f=[], c='', q=false;
    for(var i=0;i<txt.length;i++){ var ch=txt[i];
      if(q){ if(ch==='"'){ if(txt[i+1]==='"'){ c+='"'; i++; } else q=false; } else c+=ch; }
      else if(ch==='"') q=true; else if(ch===sep){ f.push(c); c=''; } else if(ch==='\n'){ f.push(c.replace(/\r$/,'')); filas.push(f); f=[]; c=''; } else c+=ch; }
    if(c||f.length){ f.push(c.replace(/\r$/,'')); filas.push(f); }
    return filas.filter(function(r){ return r.some(function(x){ return x.trim(); }); });
  }
  var normCab=function(s){ return String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z]/g,''); };
  var CAMPOS={nombre:'nombre',producto:'nombre',sku:'sku',codigo:'sku',codigodebarras:'sku',categoria:'cat',stock:'stock',stockinicial:'stock',stockminimo:'stockMin',precio:'precio',precioventa:'precio',costo:'costo',proveedor:'prov',vence:'vence',vencimiento:'vence',unidad:'unidad'};
  // Enteros chilenos: "$1.990" -> 1990. Con decimales ("1.990,50" o "1200,5") devuelve NaN y la fila se marca con error.
  // Cantidad a granel: coma o punto decimal, hasta 3 decimales ("2,5" = 2.5 kg).
  var decimal=function(s){ s=String(s||'').trim().replace(',','.'); if(s==='') return null; return /^-?\d+(\.\d{1,3})?$/.test(s)?parseFloat(s):NaN; };
  var entero=function(s){ s=String(s||'').trim(); if(/,\d/.test(s)) return NaN; var t=s.replace(/[^\d-]/g,''); return t===''||t==='-'?null:parseInt(t,10); };
  // Fecha AAAA-MM-DD, o DD-MM-AAAA / DD/MM/AAAA (como la deja Excel en español).
  function fechaCSV(s){ s=String(s||'').trim(); if(!s) return ''; var m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/)||s.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/);
    if(!m) return null; var y=m[1].length===4?m[1]:m[3], mo=('0'+m[2]).slice(-2), d=('0'+(m[1].length===4?m[3]:m[1])).slice(-2), iso=y+'-'+mo+'-'+d;
    var dt=new Date(iso+'T00:00:00'); return !isNaN(dt)&&dt.getDate()===+d?iso:null; }
  $('importarProdBtn').addEventListener('click', function(){ $('importarProd').click(); });
  $('importarProd').addEventListener('change', function(){
    var file=this.files[0]; this.value=''; if(!file) return;
    if(file.size>5e6){ aviso('El archivo es muy grande (máx. 5 MB).'); return; }
    // Excel en Windows suele guardar el CSV en Windows-1252 (no UTF-8): si no es UTF-8 válido, se lee así para no perder tildes ni ñ.
    file.arrayBuffer().then(function(buf){ try { return new TextDecoder('utf-8',{fatal:true}).decode(buf); } catch(e){ return new TextDecoder('windows-1252').decode(buf); } }).then(function(txt){
      var filas=leerCSV(txt); if(filas.length>10001){ aviso('Máximo 10.000 productos por archivo: divídelo en partes.'); return; } if(filas.length<2){ aviso('El archivo no tiene productos (falta el encabezado o las filas).'); return; }
      var cols=filas[0].map(function(h){ return CAMPOS[normCab(h)]||null; });
      if(cols.indexOf('nombre')<0){ aviso('Falta la columna "Nombre" en el encabezado.'); return; }
      var skus={}; db.productos.forEach(function(p){ if(p.sku) skus[p.sku.toLowerCase()]=1; });
      var provPorNombre={}; db.proveedores.forEach(function(p){ provPorNombre[p.nombre.trim().toLowerCase()]=p.id; });
      var items=filas.slice(1).map(function(r, i){
        var o={}; cols.forEach(function(k,j){ if(k) o[k]=String(r[j]==null?'':r[j]).trim().replace(/^'(?=[=+\-@])/,''); });
        var kg=/^(kg|kilo|kilos|granel)$/i.test(String(o.unidad||'').trim()), cant=kg?decimal:entero;
        var num=[entero(o.precio),entero(o.costo),cant(o.stock),cant(o.stockMin)];
        var d={nombre:o.nombre||'', sku:o.sku||'', cat:o.cat||'General', precio:num[0]||0, costo:num[1]||0, stock:num[2]||0, stockMin:num[3], unidad:kg?'kg':'un'};
        var err='', nota='';
        if(!d.nombre) err='Sin nombre';
        else if(d.nombre.length>120) err='Nombre muy largo';
        else if(num.some(function(x){ return x!==x; })) err=kg?'Cantidad inválida (hasta 3 decimales)':'Número con decimales: usa enteros (o columna Unidad = kg)'; // x!==x = NaN
        else if(d.precio<0||d.costo<0) err='Precio o costo negativo';
        else if(d.stock<0) err='Stock negativo';
        else if(d.sku&&skus[d.sku.toLowerCase()]) err='SKU ya existe: se omite';
        var v=fechaCSV(o.vence); if(v===null&&!err) err='Vencimiento inválido';
        if(v){ d.controlaVence=true; d.vence=v; }
        if(o.prov){ var pid=provPorNombre[o.prov.toLowerCase()]; if(pid) d.prov=pid; else nota='Proveedor «'+o.prov+'» no existe: queda sin proveedor'; }
        if(d.stockMin==null) delete d.stockMin;
        if(!err&&d.sku) skus[d.sku.toLowerCase()]=1; // repetido más abajo en el mismo archivo = se omite
        return {fila:i+2, d:d, err:err, nota:nota};
      });
      // Cupo del plan: lo que no cabe se marca antes de enviar (la API igual lo rechaza fila por fila: dividir el archivo no sirve).
      var lim=db.limites&&db.limites.productos, libres=lim==null?Infinity:Math.max(0, lim-db.productos.length), usados=0;
      items.forEach(function(x){ if(x.err) return; if(usados>=libres) x.err='Supera el cupo de tu plan'; else usados++; });
      var sinCupo=items.filter(function(x){ return x.err==='Supera el cupo de tu plan'; }).length;
      var ok=items.filter(function(x){ return !x.err; });
      abrirModal('Importar productos',
        '<p class="intro" style="margin:0 0 12px"><b>'+ok.length.toLocaleString('es-CL')+'</b> de '+items.length.toLocaleString('es-CL')+' fila'+(items.length>1?'s':'')+' se van a crear. Revisa antes de confirmar: el stock entra como stock inicial.</p>'+
        (sinCupo?'<p class="aviso-cupo" role="alert">'+ico('alerta')+'Tu plan permite '+lim.toLocaleString('es-CL')+' productos y ya tienes '+db.productos.length.toLocaleString('es-CL')+': '+sinCupo.toLocaleString('es-CL')+' fila'+(sinCupo>1?'s':'')+' no se crearán. Para cargarlas, archiva productos o sube de plan en Mi plan.</p>':'')+
        '<div style="max-height:45vh;overflow:auto"><table><thead><tr><th>Fila</th><th>Producto</th><th>SKU</th><th>Stock</th><th>Precio</th><th>Estado</th></tr></thead><tbody>'+
        items.slice().sort(function(a,b){ return (b.err?1:0)-(a.err?1:0); }).slice(0,300).map(function(x){ return '<tr><td>'+x.fila+'</td><td>'+esc(x.d.nombre)+(x.nota?'<div class="small muted">'+esc(x.nota)+'</div>':'')+'</td><td class="muted">'+esc(x.d.sku)+'</td><td>'+fmtCant(x.d,x.d.stock)+'</td><td>'+clp(x.d.precio)+'</td><td>'+(x.err?'<span class="tag bad">'+esc(x.err)+'</span>':'<span class="tag ok">Crear</span>')+'</td></tr>'; }).join('')+
        '</tbody></table></div>'+(items.length>300?'<p class="small muted">Vista previa: primero las filas con problemas, hasta 300 de '+items.length.toLocaleString('es-CL')+'.</p>':'')+'<p class="small muted" id="impMsg" aria-live="polite"></p>'+
        '<div style="display:flex;gap:8px;margin-top:12px"><button class="btn btn-primary" id="confImport"'+(ok.length?'':' disabled')+'>Crear '+ok.length+' producto'+(ok.length===1?'':'s')+'</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
      $('confImport').addEventListener('click', function(){
        var b=this; b.disabled=true; var hechos=0, fallas=[]; $('impMsg').textContent='Creando '+ok.length+' producto'+(ok.length===1?'':'s')+'…';
        // Tandas de 500 (el tope de la API), una tras otra; r[i] es el resultado de ok[i]. Después se recargan los productos (la API solo devuelve los id).
        var r=[], tanda=function(i){ if(i>=ok.length) return Promise.resolve(r);
          return API.send('POST','/api/productos/importar',{productos:ok.slice(i,i+500).map(function(x){ return x.d; })}).then(function(x){ r=r.concat(x); return tanda(i+500); }); };
        tanda(0).then(function(r){
          ok.forEach(function(x,i){ var y=r[i]||{}; if(y.ok) hechos++; else fallas.push('Fila '+x.fila+': '+(y.error||'Error')); });
          $('modalBody').innerHTML='<div class="ped-ok">'+ico('ok')+''+hechos+' producto'+(hechos===1?'':'s')+' creado'+(hechos===1?'':'s')+'.</div>'+
            (fallas.length?'<p class="small" role="alert" style="margin-top:12px">No se pudieron crear '+fallas.length+':</p><ul class="small">'+fallas.map(function(f){ return '<li>'+esc(f)+'</li>'; }).join('')+'</ul>':'')+
            '<button class="btn btn-ghost" data-cerrar style="margin-top:14px">Cerrar</button>';
          // Si la recarga falla se queda la lista anterior (la de 30 s la trae después), nunca una vacía.
          API.lista('/api/productos').then(function(ps){ db.productos=ps; renderInventario(); recargarLotes(); }).catch(function(){});
        }).catch(function(e){ b.disabled=false; $('impMsg').textContent=''; aviso('No se pudo importar: '+e.message); });
      });
    }).catch(function(){ aviso('No se pudo leer el archivo.'); });
  });
  // Un solo listener para todos los botones de la tabla (ajuste, historial, editar, borrar).
  $('invBody').addEventListener('click', function(e){
    var ed=e.target.closest('[data-edit]'), dl=e.target.closest('[data-del]'), aj=e.target.closest('[data-ajuste]'), hi=e.target.closest('[data-hist]'), lo=e.target.closest('[data-lotes]');
    if(aj) formAjuste(db.productos.find(function(x){return x.id===aj.dataset.ajuste;}));
    else if(lo) verLotes(prodPorId(lo.dataset.lotes));
    else if(hi) verMovimientos(db.productos.find(function(x){return x.id===hi.dataset.hist;}));
    else if(ed){ formProducto(db.productos.find(function(x){return x.id===ed.dataset.edit;})); }
    else if(dl){
      var p=db.productos.find(function(x){return x.id===dl.dataset.del;});
      abrirModal('Eliminar producto','<p>¿Eliminar <b>'+esc(p.nombre)+'</b> del inventario? Si ya tiene movimientos se archiva para conservar el historial.</p><div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-danger" id="confDel">Sí, eliminar</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
      $('confDel').addEventListener('click', function(){ API.send('DELETE','/api/productos/'+encodeURIComponent(p.id)).then(function(r){ if(r&&r.archivado) db.archivados=(db.archivados||[]).concat([p]); db.productos=db.productos.filter(function(x){return x.id!==p.id;}); renderInventario(); recargarLotes(); cerrarModal(); }).catch(function(e){ aviso('No se pudo eliminar: '+e.message); }); });
    }
  });

  // Ajuste manual de stock (mermas, conteo físico...). El backend exige motivo, por eso el mínimo de 3 letras.
  // Si el producto controla vencimiento, un ajuste positivo crea un lote (pide vencimiento) y uno negativo descuenta por FEFO.
  // Para sacar un lote entero está retirarLote (botón Retirar en los lotes y en "Vender primero").
  function formAjuste(p){
    abrirModal('Ajustar stock',
      '<p class="intro" style="margin:0 0 12px"><b>'+esc(p.nombre)+'</b> · stock actual <b>'+fmtCant(p, p.stock)+'</b>. Usa negativo para mermas o pérdidas.</p>'+
      '<div class="form-grid"><div class="f"><label>Cantidad (+/−) '+ayuda('Positivo si encontraste más unidades (entra stock); negativo si se perdieron, vencieron o se consumieron.')+'</label><input id="ajCant" type="number" step="'+paso(p)+'" placeholder="'+(esKg(p)?'Ej: -0.250':'Ej: -3')+'"></div>'+
      '<div class="f"><label>Motivo</label><input id="ajMotivo" list="ajMotivos" placeholder="Ej: merma, conteo físico"><datalist id="ajMotivos"><option value="Merma"><option value="Producto vencido"><option value="Producto dañado"><option value="Robo"><option value="Conteo físico"><option value="Consumo interno"><option value="Devolución de cliente"></datalist></div>'+
      (p.controlaVence?'<div class="f aj-entra"><label for="ajVence">Vencimiento (si entra stock)</label><input id="ajVence" type="date">'+(p.vidaUtil?'<span class="small muted">'+hintVida(p.vidaUtil)+'</span>':'')+'</div><div class="f aj-entra"><label for="ajLote">Lote (opcional)</label><input id="ajLote" maxlength="40"></div>'+
        '<p class="small muted f full" style="margin:0">Si la cantidad es negativa se descuenta del lote que vence primero.</p>':'')+
      '</div>'+
      '<div style="display:flex;gap:8px;margin-top:18px"><button class="btn btn-primary" id="guardarAj">Registrar ajuste</button><button class="btn btn-ghost" data-cerrar>Cancelar</button></div>');
    // Vencimiento y lote solo aplican cuando entra stock: se ocultan con cantidad negativa.
    function verEntra(){ var neg=parseFloat($('ajCant').value)<0; document.querySelectorAll('#modalBody .aj-entra').forEach(function(el){ el.hidden=neg; }); }
    $('ajCant').addEventListener('input', verEntra); verEntra();
    $('guardarAj').addEventListener('click', function(){
      var q=parseFloat($('ajCant').value), m=$('ajMotivo').value.trim();
      if(!q){ aviso('Indica la cantidad: positiva si entra stock, negativa si sale.'); $('ajCant').focus(); return; } if(m.length<3){ aviso('Escribe el motivo del ajuste (ej: merma, conteo físico).'); $('ajMotivo').focus(); return; }
      var body={cantidad:q,motivo:m};
      if(p.controlaVence && q>0){
        body.vence=$('ajVence').value; body.lote=$('ajLote').value.trim();
        if(!body.vence&&!p.vidaUtil){ aviso('Este producto controla vencimiento: indica la fecha de vencimiento de lo que entra.'); $('ajVence').focus(); return; }
      }
      API.send('POST','/api/productos/'+encodeURIComponent(p.id)+'/ajuste',body).then(function(saved){
        var i=db.productos.findIndex(function(x){return x.id===p.id;}); if(i>-1) db.productos[i]=saved;
        renderInventario(); recargarLotes(); recargarMermas(); cerrarModal();
        // La predicción (Analíticas) usa el stock: se pide de nuevo para no mostrar el de antes del ajuste.
        API.lista('/api/inventario/prediccion').then(function(r){ db.prediccion=r; renderAnaliticas(); }).catch(function(){});
      }).catch(function(e){ aviso('No se pudo ajustar: '+e.message); });
    });
  }
  // Retirar un lote entero (vencido, dañado, retirado por el proveedor): da de baja todo su saldo de una vez, de ese
  // lote puntual (no por FEFO). Queda como merma en los movimientos. `volver` (opcional): qué mostrar al terminar.
  function retirarLote(p, l, volver){
    var vencido=(venceInfo(l.vence).dias||0)<0;
    abrirModal('Retirar lote · '+p.nombre,
      '<p class="intro" style="margin:0 0 12px">Lote <b>'+esc(l.codigo||'Sin código')+'</b>'+(l.vence?' · vence '+esc(fmtFecha(l.vence)):'')+'. Se dan de baja sus <b>'+fmtCant(p, l.cantidad)+'</b> del inventario; queda como merma en los movimientos del producto.</p>'+
      '<div class="form-grid"><div class="f"><label for="rlMotivo">Motivo</label><input id="rlMotivo" list="rlMotivos" value="'+(vencido?'Retiro por vencimiento':'')+'" placeholder="Ej: producto dañado"><datalist id="rlMotivos"><option value="Retiro por vencimiento"><option value="Producto dañado"><option value="Retiro del proveedor"></datalist></div></div>'+
      '<div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-danger" id="rlOk">Retirar lote</button><button class="btn btn-ghost" id="rlVolver">'+(volver?'Volver':'Cancelar')+'</button></div>');
    $('rlVolver').addEventListener('click', function(){ if(volver) volver(); else cerrarModal(); });
    $('rlOk').addEventListener('click', function(){
      var b=this, m=$('rlMotivo').value.trim();
      if(m.length<3){ aviso('Escribe el motivo (ej: producto dañado).'); $('rlMotivo').focus(); return; }
      b.disabled=true;
      API.send('POST','/api/lotes/'+encodeURIComponent(l.id)+'/retirar',{motivo:m}).then(function(){
        // Ya quedó retirado: si la recarga falla, la de 30 s la trae después (no se reactiva el botón para no retirar dos veces).
        Promise.all([API.get('/api/productos'), recargarLotes()]).then(function(r){ db.productos=r[0]; renderInventario(); if(volver) volver(); }).catch(function(){});
        if(!volver) cerrarModal();
        recargarMermas();
        API.lista('/api/inventario/prediccion').then(function(r){ db.prediccion=r; renderAnaliticas(); }).catch(function(){});
      }, function(e){ b.disabled=false; aviso('No se pudo retirar: '+e.message); });
    });
  }
  // Historial de movimientos del producto. tipoMov traduce el `tipo` que guarda la BD a algo legible.
  // Una venta que tocó dos lotes aparece en dos filas (una por lote).
  var tipoMov={inicial:'Stock inicial',venta:'Venta',recepcion:'Ingreso desde pedido',compra:'Ingreso de mercadería',ajuste:'Ajuste',devolucion:'Devolución a proveedor'};
  function verMovimientos(p){
    abrirModal('Movimientos · '+p.nombre,'<p class="muted small">Cargando…</p>');
    API.lista('/api/productos/'+encodeURIComponent(p.id)+'/movimientos').then(function(ms){
      // Usuario vacío = lo hizo la caja (venta sincronizada) o un movimiento antiguo.
      // Saldo después de cada movimiento: vienen del más nuevo al más viejo, así que se parte del stock actual hacia atrás.
      var saldo=[], acc=Number(p.stock); ms.forEach(function(m){ saldo.push(acc); acc-=Number(m.cantidad)||0; });
      var filas=ms.map(function(m,i){ var d=new Date(m.fecha);
        var lote=(m.lote||m.loteVence)?'<div class="muted small">Lote '+esc(m.lote||'Sin código')+(m.loteVence?' · vence '+esc(fmtFecha(m.loteVence)):'')+'</div>':'';
        return '<tr><td>'+fmtFecha(m.fecha)+' '+d.toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit',hourCycle:'h23'})+'</td><td>'+(tipoMov[m.tipo]||esc(m.tipo))+(m.motivo?'<div class="muted small">'+esc(m.motivo)+'</div>':'')+lote+'</td><td>'+esc(m.usuario||'Caja')+'</td><td style="text-align:right"><b>'+(m.cantidad>0?'+':'')+fmtCant(p, m.cantidad)+'</b></td><td style="text-align:right" class="muted">'+fmtCant(p, saldo[i])+'</td></tr>'; }).join('');
      $('modalBody').innerHTML='<p class="small muted" style="margin:0 0 12px">Stock actual <b>'+fmtCant(p, p.stock)+'</b>. Últimos 200 movimientos. '+(ms.length?'<button class="mini" id="kardexCSV">'+ico('descargar')+'Exportar CSV</button>':'')+'</p><table><thead><tr><th>Fecha</th><th>Tipo</th><th>Usuario</th><th style="text-align:right">Cantidad</th><th style="text-align:right">Saldo</th></tr></thead><tbody>'+(filas||'<tr><td colspan="5" class="muted">Sin movimientos.</td></tr>')+'</tbody></table>';
      var bx=$('kardexCSV'); if(bx) bx.addEventListener('click', function(){
        descargarCSV('kardex-'+(p.sku||p.nombre).replace(/[^\w-]+/g,'_').slice(0,40)+'-'+hoyISO()+'.csv', ['Fecha','Hora','Tipo','Motivo','Lote','Vence lote','Usuario','Cantidad','Saldo','Costo unitario'],
          ms.map(function(m,i){ return [fechaCLde(m.fecha), new Date(m.fecha).toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit',hourCycle:'h23',timeZone:'America/Santiago'}), tipoMov[m.tipo]||m.tipo, m.motivo||'', m.lote||'', m.loteVence||'', m.usuario||'Caja', m.cantidad, Math.round(saldo[i]*1000)/1000, m.costoUnit==null?'':m.costoUnit]; }));
      });
    }).catch(function(){ errorModal('los movimientos'); });
  }
  // Si falla la carga de un modal de consulta, se avisa en vez de dejarlo en "Cargando…".
  function errorModal(que){ $('modalBody').innerHTML='<p class="small" role="alert">No se pudieron cargar '+que+'. Revisa tu conexión y vuelve a intentarlo.</p><button class="btn btn-ghost" data-cerrar style="margin-top:12px">Cerrar</button>'; }
  // Lotes con saldo del producto, en orden FEFO (la API ya los manda así).
  function verLotes(p){
    if(!p) return;
    abrirModal('Lotes · '+p.nombre,'<p class="muted small">Cargando…</p>');
    API.lista('/api/productos/'+encodeURIComponent(p.id)+'/lotes').then(function(ls){
      var suma=ls.reduce(function(s,l){return s+l.cantidad;},0), resto=Math.round((p.stock-suma)*1000)/1000; // redondeo: con kg la suma de decimales deja restos como 1e-12
      var primero=ls.findIndex(function(l){ var d=venceInfo(l.vence).dias; return d==null||d>=0; }); // los vencidos no se venden: se retiran
      var filas=ls.map(function(l,i){ var vi=venceInfo(l.vence);
        return '<tr><td><b>'+esc(l.codigo||'Sin código')+'</b>'+(vi.dias!=null&&vi.dias<0?' <span class="tag bad">Retirar</span>':i===primero?' <span class="tag ok">Vender primero</span>':'')+'</td><td>'+(l.vence?esc(fmtFecha(l.vence)):'Sin fecha')+'</td><td>'+fmtCant(p, l.cantidad)+'</td><td><span class="tag '+vi.c+'">'+diasTxt(vi.dias)+'</span></td><td style="white-space:nowrap"><button class="mini" data-retirar-lote="'+i+'" aria-label="Retirar lote '+esc(l.codigo||'sin código')+'">Retirar</button> <button class="mini icon" data-edit-lote="'+i+'" aria-label="Corregir lote '+esc(l.codigo||'sin código')+'">'+ico('editar')+'</button></td></tr>'; }).join('');
      $('modalBody').innerHTML='<p class="intro" style="margin:0 0 12px">Ordenados por vencimiento: cada venta descuenta primero el lote de arriba (lo que vence primero, sale primero).</p>'+
        '<table><thead><tr><th>Lote</th><th>Vence</th><th>Cantidad</th><th>Días</th><th></th></tr></thead><tbody id="lotesBody">'+(filas||'<tr><td colspan="5" class="muted">Sin lotes con saldo.</td></tr>')+'</tbody></table>'+
        (resto?'<p class="small muted" style="margin:12px 0 0">'+(resto>0?fmtCant(p, resto)+(esKg(p)?'':' unidad'+(resto>1?'es':''))+' sin lote (stock cargado antes de controlar vencimiento).':'Se vendieron '+fmtCant(p, -resto)+(esKg(p)?'':' unidad'+(resto<-1?'es':''))+' más de las que había; se descontarán del próximo lote que ingrese.')+'</p>':'');
      // El lápiz corrige código o vencimiento (error de tipeo). No cambia cantidades; queda en el kardex.
      $('lotesBody').addEventListener('click', function(e){
        var r=e.target.closest('[data-retirar-lote]');
        if(r) return retirarLote(p, ls[+r.dataset.retirarLote], function(){ verLotes(prodPorId(p.id)||p); });
        var b=e.target.closest('[data-edit-lote]'); if(!b) return; var l=ls[+b.dataset.editLote];
        abrirModal('Corregir lote · '+p.nombre,
          '<p class="intro" style="margin:0 0 12px">Para corregir un error al ingresarlo. No cambia la cantidad; el cambio queda en los movimientos del producto.</p>'+
          '<div class="form-grid"><div class="f"><label for="elCod">Código del lote</label><input id="elCod" maxlength="40" value="'+esc(l.codigo||'')+'"></div>'+
          '<div class="f"><label for="elVence">Vencimiento</label><input id="elVence" type="date" value="'+esc(l.vence||'')+'"></div></div>'+
          '<div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-primary" id="elGuardar">Guardar</button><button class="btn btn-ghost" id="elVolver">Volver</button></div>');
        $('elVolver').addEventListener('click', function(){ verLotes(p); });
        $('elGuardar').addEventListener('click', function(){
          if(!$('elVence').value){ aviso('Indica el vencimiento.'); $('elVence').focus(); return; }
          API.send('PUT','/api/lotes/'+encodeURIComponent(l.id),{codigo:$('elCod').value.trim(),vence:$('elVence').value})
            .then(function(){ return Promise.all([API.get('/api/productos'), recargarLotes()]); })
            .then(function(r){ db.productos=r[0]; renderInventario(); verLotes(prodPorId(p.id)||p); })
            .catch(function(e){ aviso('No se pudo corregir: '+e.message); });
        });
      });
    }).catch(function(){ errorModal('los lotes'); });
  }

