-- Cobro automático con tarjeta (Flow "Cargo Automático") y pagos registrados por el staff.
--   clientes.flow_customer_id   cliente creado en Flow (customer/create); se conserva aunque quite la tarjeta
--   clientes.tarjeta_marca / tarjeta_ultimos4 / tarjeta_desde   tarjeta inscrita (Walkan no guarda el número)
--   clientes.cobro_auto_intento / cobro_auto_error              último intento de cobro automático y su error
--   suscripciones.medio   'flow' (pago en línea), 'tarjeta' (cobro automático) o 'manual' (registrado por el staff)
--   suscripciones.nota    detalle del pago manual (p. ej. "transferencia 14-nov") y quién lo registró
ALTER TABLE clientes ADD COLUMN flow_customer_id TEXT;
ALTER TABLE clientes ADD COLUMN tarjeta_marca TEXT;
ALTER TABLE clientes ADD COLUMN tarjeta_ultimos4 TEXT;
ALTER TABLE clientes ADD COLUMN tarjeta_desde TEXT;
ALTER TABLE clientes ADD COLUMN cobro_auto_intento TEXT;
ALTER TABLE clientes ADD COLUMN cobro_auto_error TEXT;
ALTER TABLE suscripciones ADD COLUMN medio TEXT NOT NULL DEFAULT 'flow';
ALTER TABLE suscripciones ADD COLUMN nota TEXT;
CREATE INDEX IF NOT EXISTS idx_clientes_flow_customer ON clientes(flow_customer_id);
