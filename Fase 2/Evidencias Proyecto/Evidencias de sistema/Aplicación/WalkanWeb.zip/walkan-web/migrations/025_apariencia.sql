-- Apariencia del panel por negocio (Ajustes › Apariencia). Solo cambia cómo se ve, no qué hace.
-- estilo: nitido | suave | consola · modo: auto (según el equipo) | claro | oscuro · acento: color de la marca (#RRGGBB).
ALTER TABLE clientes ADD COLUMN apariencia_estilo TEXT NOT NULL DEFAULT 'nitido';
ALTER TABLE clientes ADD COLUMN apariencia_modo TEXT NOT NULL DEFAULT 'auto';
ALTER TABLE clientes ADD COLUMN apariencia_acento TEXT NOT NULL DEFAULT '#1E3A8A';
