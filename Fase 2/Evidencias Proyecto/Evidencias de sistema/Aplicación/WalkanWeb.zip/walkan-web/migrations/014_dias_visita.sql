-- Días en que pasa el preventista o vendedor del proveedor ("1,4" = lunes y jueves; 0 = domingo, como getDay()).
-- Ese día el panel recuerda revisar el pedido sugerido.
ALTER TABLE proveedores ADD COLUMN dias_visita TEXT;
