-- B1 (P5/P6, I1, I2, I4, C3, C4): ventas de la caja que no se pudieron aplicar del todo, guardadas para resolverlas en el panel.
-- (La 029 la reservó la Ronda 2 de docs/plan/coordinacion-franco-alvaro.md.)

-- Líneas de venta con un código que el catálogo no conoce. Antes solo se contaban y quedaban en el log: el stock nunca se
-- descontaba, ni siquiera después de crear el producto. Ahora quedan acá hasta que el dueño crea o vincula el producto
-- (se descuenta una sola vez, con la fecha de la venta) o las ignora.
CREATE TABLE ventas_pendientes (
  id           TEXT    PRIMARY KEY,
  cliente_id   TEXT    NOT NULL REFERENCES clientes(id),
  venta_id     TEXT    NOT NULL REFERENCES ventas(id),
  caja_id      TEXT,
  sku          TEXT,                -- código leído en la caja (puede faltar)
  nombre       TEXT    NOT NULL,
  cantidad     REAL    NOT NULL,
  precio       REAL    NOT NULL DEFAULT 0,
  fecha        TEXT    NOT NULL,    -- fecha de la venta (el descuento de stock usa esta)
  estado       TEXT    NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','aplicada','ignorada')),
  producto_id  TEXT,                -- con qué producto se resolvió
  resuelta_en  TEXT,
  resuelta_por TEXT,                -- usuario del panel (NULL = automático al crear el producto)
  created_at   TEXT    NOT NULL
);
CREATE INDEX idx_vp_cliente_estado ON ventas_pendientes(cliente_id, estado);
CREATE INDEX idx_vp_cliente_sku    ON ventas_pendientes(cliente_id, sku, estado);

-- Eventos de la caja que la nube rechazó (I4). Antes ultimo_seq avanzaba y se perdían sin rastro. Solo se guarda lo
-- necesario para revisarlos (tipo, motivo, folio y total): nada del pago ni correos (minimización, Ley 21.719).
CREATE TABLE sync_rechazos (
  id          TEXT    PRIMARY KEY,
  cliente_id  TEXT    REFERENCES clientes(id),
  caja_id     TEXT    NOT NULL,
  seq         INTEGER NOT NULL,
  tipo        TEXT    NOT NULL,
  motivo      TEXT    NOT NULL,
  folio       TEXT,
  total       INTEGER,
  revisado    INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL
);
CREATE INDEX idx_sync_rechazos_cliente ON sync_rechazos(cliente_id, revisado);

-- C3: id propio de cada evento de la caja (el id de la venta en la caja). Con él la nube distingue un reenvío (ya lo tiene)
-- de una caja que reinició su numeración (seq ya usado, pero evento nuevo): antes esas ventas se descartaban en silencio.
ALTER TABLE ventas ADD COLUMN uid TEXT;
CREATE UNIQUE INDEX idx_ventas_caja_uid ON ventas(caja_id, uid) WHERE uid IS NOT NULL;
