-- Ubicación normalizada del local (opcional). `comuna` (texto) se mantiene por compatibilidad y ahora
-- guarda el nombre oficial; `comuna_cut` es el Código Único Territorial (5 dígitos) y permite agrupar
-- o filtrar por comuna/región más adelante (instalaciones, soporte en terreno, reportes por zona).
-- Lista oficial en public/geo/territorio-cl.json. Número 023 porque la rama Franco ya usa el 022.
ALTER TABLE clientes ADD COLUMN comuna_cut TEXT;
ALTER TABLE clientes ADD COLUMN region TEXT;
ALTER TABLE clientes ADD COLUMN direccion TEXT;
