-- Parámetros de inventario por negocio (plan de ítems §I). Sin fila = valores por defecto (10, 2 y 7).
CREATE TABLE config_inventario (
  cliente_id     TEXT PRIMARY KEY,
  umbral_bajo    INTEGER NOT NULL DEFAULT 10, -- stock bajo cuando el producto no tiene mínimo propio
  dias_seguridad INTEGER NOT NULL DEFAULT 2,  -- colchón sobre los días de entrega del proveedor
  dias_cobertura INTEGER NOT NULL DEFAULT 7,  -- días de venta que debe cubrir un pedido además de la entrega
  updated_at     TEXT NOT NULL
);
