-- Lotes con vencimiento (FEFO) y flujo de compras Pedido -> Ingreso.
-- Ver docs/plan/plan-lotes-compras.md.

-- Indicador por producto: si está activo, cada entrada de stock pide vencimiento y crea un lote.
ALTER TABLE productos ADD COLUMN controla_vence INTEGER NOT NULL DEFAULT 0;

-- Lote = unidades que entraron juntas con el mismo vencimiento. `cantidad` es lo que queda.
CREATE TABLE lotes (
  id               TEXT PRIMARY KEY,
  cliente_id       TEXT NOT NULL,
  producto_id      TEXT NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
  codigo           TEXT,
  vence            TEXT,
  cantidad_inicial INTEGER NOT NULL,
  cantidad         INTEGER NOT NULL,
  created_at       TEXT NOT NULL
);
CREATE INDEX idx_lotes_cliente_prod ON lotes(cliente_id, producto_id, vence);
CREATE INDEX idx_lotes_cliente_vence ON lotes(cliente_id, vence);

-- Cada porción del kardex que tocó un lote lo anota (una venta puede partirse en varios lotes).
ALTER TABLE movimientos_stock ADD COLUMN lote_id TEXT;

-- Pedidos: estado 'Borrador' y enlace al ingreso (fila de compras) que generó al recibirse.
-- SQLite no altera un CHECK: se recrea la tabla (nada la referencia, igual que en 007).
CREATE TABLE pedidos_new (
  id           TEXT    PRIMARY KEY,
  proveedor_id TEXT    REFERENCES proveedores(id) ON DELETE SET NULL,
  fecha        TEXT    NOT NULL,
  estado       TEXT    NOT NULL DEFAULT 'Enviado' CHECK (estado IN ('Borrador','Enviado','Recibido')),
  nota         TEXT,
  items_json   TEXT    NOT NULL,
  cliente_id   TEXT,
  compra_id    TEXT,
  created_at   TEXT    NOT NULL,
  updated_at   TEXT    NOT NULL
);
INSERT INTO pedidos_new (id,proveedor_id,fecha,estado,nota,items_json,cliente_id,created_at,updated_at)
  SELECT id,proveedor_id,fecha,estado,nota,items_json,cliente_id,created_at,updated_at FROM pedidos;
DROP TABLE pedidos;
ALTER TABLE pedidos_new RENAME TO pedidos;
CREATE INDEX idx_pedidos_cliente ON pedidos(cliente_id);

-- Datos existentes: quien tenía vencimiento pasa a controlarlo, con un lote inicial por su stock.
UPDATE productos SET controla_vence = 1 WHERE TRIM(COALESCE(vence, '')) <> '';
INSERT INTO lotes (id, cliente_id, producto_id, codigo, vence, cantidad_inicial, cantidad, created_at)
  SELECT lower(hex(randomblob(16))), cliente_id, id, NULL, vence, stock, stock, updated_at
  FROM productos WHERE controla_vence = 1 AND stock > 0 AND cliente_id IS NOT NULL;
