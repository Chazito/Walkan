-- Sesiones por dispositivo: cada inicio de sesión crea una fila con un identificador aleatorio
-- (es lo que va en la cookie firmada). Cerrar sesión borra solo esa fila; cambiar la clave borra
-- las demás; restablecerla borra todas. Las sesiones con "Recordarme" duran 30 días y se renuevan
-- solas mientras se usen; sin "Recordarme", 12 horas.
CREATE TABLE sesiones (
  id          TEXT    PRIMARY KEY,
  usuario_id  TEXT    NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  recordar    INTEGER NOT NULL DEFAULT 1,
  creada      TEXT    NOT NULL,
  expira      TEXT    NOT NULL,
  ultimo_uso  TEXT    NOT NULL
);
CREATE INDEX idx_sesiones_usuario ON sesiones(usuario_id);
