-- Usuarios del panel (dueños / cajeros). Contraseña con scrypt (salt:hash hex).
CREATE TABLE usuarios (
  id            TEXT    PRIMARY KEY,
  email         TEXT    NOT NULL UNIQUE,
  nombre        TEXT    NOT NULL,
  negocio       TEXT,
  password_hash TEXT    NOT NULL,
  rol           TEXT    NOT NULL DEFAULT 'admin' CHECK (rol IN ('staff','admin','cajero')),
  created_at    TEXT    NOT NULL,
  updated_at    TEXT    NOT NULL
);
CREATE INDEX idx_usuarios_email ON usuarios(email);
