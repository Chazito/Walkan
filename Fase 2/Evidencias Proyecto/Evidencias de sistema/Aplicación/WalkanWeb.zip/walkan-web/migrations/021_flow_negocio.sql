-- Pago automático con QR vía Flow (opcional, por negocio). Cada negocio conecta SU cuenta Flow:
-- la plata llega a su cuenta, nunca a la de Walkan. La secretKey se guarda cifrada (AES-256-GCM).
ALTER TABLE clientes ADD COLUMN flow_api_key TEXT;
ALTER TABLE clientes ADD COLUMN flow_secret_cifrada TEXT;
ALTER TABLE clientes ADD COLUMN flow_entorno TEXT; -- 'sandbox' | 'produccion'

-- Cobros con QR creados por las cajas. La caja muestra el QR (url de pago de Flow) y consulta el estado.
CREATE TABLE cobros_qr (
  id             TEXT PRIMARY KEY,
  cliente_id     TEXT NOT NULL,
  caja_id        TEXT NOT NULL,
  commerce_order TEXT NOT NULL UNIQUE,
  token          TEXT,
  url            TEXT,
  monto          INTEGER NOT NULL,
  estado         TEXT NOT NULL CHECK (estado IN ('pendiente','pagado','rechazado','anulado')),
  flow_order     TEXT,
  medio          TEXT,
  created_at     TEXT NOT NULL,
  updated_at     TEXT NOT NULL
);
CREATE INDEX idx_cobros_qr_token ON cobros_qr(token);
