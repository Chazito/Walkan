-- Cambio de plan desde el panel (Mi cuenta → Mi plan).
--   clientes.plan_siguiente  plan al que el dueño pidió pasar en la próxima renovación: bajar de plan, o cualquier
--                            cambio pedido con el período ya vencido. Se aplica cuando paga esa renovación.
--   suscripciones.tipo       'periodo' = pago de un mes (primer pago o renovación);
--                            'cambio'  = diferencia prorrateada por subir de plan a mitad de mes. No mueve el
--                            vencimiento: su periodo_fin es el del período que ya estaba pagado.
ALTER TABLE clientes ADD COLUMN plan_siguiente TEXT;
ALTER TABLE suscripciones ADD COLUMN tipo TEXT NOT NULL DEFAULT 'periodo';
