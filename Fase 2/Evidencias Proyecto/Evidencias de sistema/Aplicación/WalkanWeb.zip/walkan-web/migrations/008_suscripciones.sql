-- Registro autoservicio + suscripción (pago del plan).
-- Un cliente nuevo nace 'pendiente'; al confirmarse el pago de su suscripción pasa a 'activo'.
CREATE TABLE suscripciones (
  id             TEXT    PRIMARY KEY,
  cliente_id     TEXT    NOT NULL REFERENCES clientes(id),
  plan           TEXT    NOT NULL,
  monto          INTEGER NOT NULL,
  estado         TEXT    NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','pagada','rechazada')),
  flow_token     TEXT,
  flow_order     TEXT,
  periodo_inicio TEXT,
  periodo_fin    TEXT,
  created_at     TEXT    NOT NULL,
  updated_at     TEXT    NOT NULL
);
CREATE INDEX idx_suscripciones_cliente ON suscripciones(cliente_id);
CREATE INDEX idx_suscripciones_token   ON suscripciones(flow_token);
