-- Pedidos a proveedores y compras (recepciones / compras externas).
CREATE TABLE pedidos (
  id           TEXT    PRIMARY KEY,
  proveedor_id TEXT    REFERENCES proveedores(id) ON DELETE SET NULL,
  fecha        TEXT    NOT NULL,
  estado       TEXT    NOT NULL DEFAULT 'Enviado' CHECK (estado IN ('Enviado','Recibido')),
  nota         TEXT,
  items_json   TEXT    NOT NULL,
  created_at   TEXT    NOT NULL,
  updated_at   TEXT    NOT NULL
);

CREATE TABLE compras (
  id         TEXT    PRIMARY KEY,
  proveedor  TEXT    NOT NULL,
  tipo       TEXT    NOT NULL CHECK (tipo IN ('Pedido','Externa','Manual')),
  fecha      TEXT    NOT NULL,
  items      INTEGER NOT NULL DEFAULT 0,
  total      INTEGER NOT NULL DEFAULT 0,
  created_at TEXT    NOT NULL
);
