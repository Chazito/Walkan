-- Arregla el CHECK de rol en bases creadas con el 003 antiguo (rol IN ('admin','cajero')),
-- que rechazaba el rol 'staff'. No se puede alterar un CHECK en SQLite, así que se
-- recrea la tabla. Se evita RENAME de usuarios (reescribiría la FK cajas.usuario_id):
-- se crea usuarios_new, se copian los datos, se DROPEA usuarios y se renombra
-- usuarios_new -> usuarios (nada referencia a usuarios_new, no hay reescritura de FK).
CREATE TABLE usuarios_new (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  nombre        TEXT NOT NULL,
  negocio       TEXT,
  cliente_id    TEXT,
  password_hash TEXT NOT NULL,
  rol           TEXT NOT NULL DEFAULT 'admin' CHECK (rol IN ('staff','admin','cajero')),
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
INSERT INTO usuarios_new (id,email,nombre,negocio,cliente_id,password_hash,rol,created_at,updated_at)
  SELECT id,email,nombre,negocio,cliente_id,password_hash,rol,created_at,updated_at FROM usuarios;
DROP TABLE usuarios;
ALTER TABLE usuarios_new RENAME TO usuarios;
CREATE INDEX idx_usuarios_email   ON usuarios(email);
CREATE INDEX idx_usuarios_cliente ON usuarios(cliente_id);
