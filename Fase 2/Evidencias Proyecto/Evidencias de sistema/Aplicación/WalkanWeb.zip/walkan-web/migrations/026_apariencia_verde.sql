-- 026: el color por defecto de la apariencia pasa a ser el verde de Walkan (#0B7C4E) en vez del azul marino.
-- Los negocios que seguían con el azul por defecto (la función salió el 10-nov-2026) pasan al verde.
UPDATE clientes SET apariencia_acento = '#0B7C4E' WHERE apariencia_acento = '#1E3A8A';

-- SQLite no deja cambiar el DEFAULT de una columna: los negocios nuevos se crean con el azul de la 025
-- y este trigger los deja en verde apenas se insertan.
CREATE TRIGGER IF NOT EXISTS clientes_apariencia_verde AFTER INSERT ON clientes
WHEN NEW.apariencia_acento = '#1E3A8A'
BEGIN
  UPDATE clientes SET apariencia_acento = '#0B7C4E' WHERE id = NEW.id;
END;
