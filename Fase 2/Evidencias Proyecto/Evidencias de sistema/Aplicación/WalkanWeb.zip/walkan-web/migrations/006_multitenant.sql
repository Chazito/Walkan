-- Multi-tenant: clientes (tenants) + cliente_id en todas las tablas del negocio.
-- El staff de Walkan (rol 'staff') administra clientes; cada cliente es un tenant
-- con su dueño (rol 'admin') y sus datos aislados por cliente_id.

CREATE TABLE clientes (
  id         TEXT PRIMARY KEY,
  negocio    TEXT NOT NULL,
  rut        TEXT,
  comuna     TEXT,
  email      TEXT,
  telefono   TEXT,
  plan       TEXT NOT NULL DEFAULT 'Kiosko',
  estado     TEXT NOT NULL DEFAULT 'activo' CHECK (estado IN ('activo','suspendido','pendiente')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Agregar cliente_id a usuarios (el rol 'staff' ya está permitido desde 003_usuarios.sql).
ALTER TABLE usuarios ADD COLUMN cliente_id TEXT;
CREATE INDEX idx_usuarios_cliente ON usuarios(cliente_id);

-- cliente_id en las tablas del negocio (aislamiento por tenant).
ALTER TABLE proveedores ADD COLUMN cliente_id TEXT;
ALTER TABLE productos   ADD COLUMN cliente_id TEXT;
ALTER TABLE cajas       ADD COLUMN cliente_id TEXT;
ALTER TABLE ventas      ADD COLUMN cliente_id TEXT;
ALTER TABLE pedidos     ADD COLUMN cliente_id TEXT;
ALTER TABLE compras     ADD COLUMN cliente_id TEXT;

CREATE INDEX idx_productos_cliente   ON productos(cliente_id);
CREATE INDEX idx_proveedores_cliente ON proveedores(cliente_id);
CREATE INDEX idx_cajas_cliente       ON cajas(cliente_id);
CREATE INDEX idx_ventas_cliente      ON ventas(cliente_id);
CREATE INDEX idx_pedidos_cliente     ON pedidos(cliente_id);
CREATE INDEX idx_compras_cliente     ON compras(cliente_id);
