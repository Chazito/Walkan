-- Productos a granel, vida útil, proveedores archivados, IVA del costo y devoluciones a proveedor.

-- Unidad de venta: 'un' (unidades enteras) o 'kg' (se vende pesado, stock con hasta 3 decimales).
-- plu = número corto (1..99999) que se programa en la balanza; va dentro del código que imprime la balanza.
ALTER TABLE productos ADD COLUMN unidad TEXT NOT NULL DEFAULT 'un' CHECK (unidad IN ('un','kg'));
ALTER TABLE productos ADD COLUMN plu INTEGER;
CREATE UNIQUE INDEX ux_productos_cliente_plu ON productos(cliente_id, plu) WHERE plu IS NOT NULL;
-- Días que dura el producto desde que entra (pan = 1). Si está, el vencimiento del lote se calcula solo.
ALTER TABLE productos ADD COLUMN vida_util_dias INTEGER;

-- Un proveedor con historial se archiva en vez de borrarse: así los pedidos viejos conservan su nombre.
ALTER TABLE proveedores ADD COLUMN activo INTEGER NOT NULL DEFAULT 1;

-- 1 = los costos se ingresan con IVA (boleta del mayorista); 0 = netos (factura). Los precios de venta siempre con IVA.
ALTER TABLE config_inventario ADD COLUMN costo_con_iva INTEGER NOT NULL DEFAULT 0;

-- Kardex: nuevo tipo 'devolucion' (mercadería que vuelve al proveedor; no es merma). SQLite no altera un CHECK:
-- se recrea la tabla (nada la referencia). cantidad pasa a REAL para el granel.
CREATE TABLE movimientos_stock_new (
  id          TEXT PRIMARY KEY,
  cliente_id  TEXT NOT NULL,
  producto_id TEXT NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
  tipo        TEXT NOT NULL CHECK (tipo IN ('inicial','venta','recepcion','compra','ajuste','devolucion')),
  cantidad    REAL NOT NULL,
  costo_unit  INTEGER,
  ref_id      TEXT,
  motivo      TEXT,
  fecha       TEXT NOT NULL,
  created_at  TEXT NOT NULL,
  lote_id     TEXT,
  usuario_id  TEXT
);
INSERT INTO movimientos_stock_new (id,cliente_id,producto_id,tipo,cantidad,costo_unit,ref_id,motivo,fecha,created_at,lote_id,usuario_id)
  SELECT id,cliente_id,producto_id,tipo,cantidad,costo_unit,ref_id,motivo,fecha,created_at,lote_id,usuario_id FROM movimientos_stock;
DROP TABLE movimientos_stock;
ALTER TABLE movimientos_stock_new RENAME TO movimientos_stock;
CREATE INDEX idx_mov_cliente_prod_fecha ON movimientos_stock(cliente_id, producto_id, fecha);
CREATE INDEX idx_mov_cliente_tipo_fecha ON movimientos_stock(cliente_id, tipo, fecha);

-- La devolución queda también en el historial de ingresos (tipo 'Devolucion', total negativo = crédito del proveedor).
CREATE TABLE compras_new (
  id         TEXT    PRIMARY KEY,
  proveedor  TEXT    NOT NULL,
  tipo       TEXT    NOT NULL CHECK (tipo IN ('Pedido','Externa','Manual','Devolucion')),
  fecha      TEXT    NOT NULL,
  items      INTEGER NOT NULL DEFAULT 0,
  total      INTEGER NOT NULL DEFAULT 0,
  created_at TEXT    NOT NULL,
  cliente_id TEXT
);
INSERT INTO compras_new (id,proveedor,tipo,fecha,items,total,created_at,cliente_id)
  SELECT id,proveedor,tipo,fecha,items,total,created_at,cliente_id FROM compras;
DROP TABLE compras;
ALTER TABLE compras_new RENAME TO compras;
CREATE INDEX idx_compras_cliente ON compras(cliente_id);
