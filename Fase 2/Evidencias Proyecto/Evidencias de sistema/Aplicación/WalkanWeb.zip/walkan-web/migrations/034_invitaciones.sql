-- Invitaciones por correo (17-nov-2026): las cuentas creadas desde /admin ya no reciben una clave temporal.
-- Llega un enlace para crear la contraseña; mientras no la cree, clave_pendiente = 1 (la clave guardada es
-- aleatoria y nadie la conoce).
ALTER TABLE usuarios ADD COLUMN clave_pendiente INTEGER NOT NULL DEFAULT 0;
