-- Historial de precio y costo por producto. Lo llenan triggers: así queda registrado venga el cambio
-- de una edición en el panel, de una compra o de una recepción (que actualizan el costo), sin tocar cada ruta.
CREATE TABLE precios_historial (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  cliente_id  TEXT NOT NULL,
  producto_id TEXT NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
  precio      INTEGER,
  costo       INTEGER,
  fecha       TEXT NOT NULL
);
CREATE INDEX idx_precios_cliente_prod ON precios_historial(cliente_id, producto_id, id);

CREATE TRIGGER trg_precios_ins AFTER INSERT ON productos WHEN NEW.cliente_id IS NOT NULL
BEGIN
  INSERT INTO precios_historial (cliente_id, producto_id, precio, costo, fecha)
  VALUES (NEW.cliente_id, NEW.id, NEW.precio, NEW.costo, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'));
END;

CREATE TRIGGER trg_precios_upd AFTER UPDATE OF precio, costo ON productos
  WHEN NEW.cliente_id IS NOT NULL AND (NEW.precio IS NOT OLD.precio OR NEW.costo IS NOT OLD.costo)
BEGIN
  INSERT INTO precios_historial (cliente_id, producto_id, precio, costo, fecha)
  VALUES (NEW.cliente_id, NEW.id, NEW.precio, NEW.costo, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'));
END;

-- Punto de partida: el precio y costo actuales de lo que ya existe.
INSERT INTO precios_historial (cliente_id, producto_id, precio, costo, fecha)
  SELECT cliente_id, id, precio, costo, updated_at FROM productos WHERE cliente_id IS NOT NULL;
