-- Equipo Walkan: super admin, cuentas de staff desactivables y bitácora de acciones (17-nov-2026).

-- super_admin = 1: además de lo del staff, crea/desactiva cuentas del equipo y ve la bitácora.
-- desactivado_en: la cuenta no puede entrar (no se borra, para que la bitácora conserve quién hizo qué).
ALTER TABLE usuarios ADD COLUMN super_admin INTEGER NOT NULL DEFAULT 0;
ALTER TABLE usuarios ADD COLUMN desactivado_en TEXT;

-- El staff más antiguo (staff@walkan.cl, creado al partir) queda como primer super admin.
UPDATE usuarios SET super_admin = 1
 WHERE id = (SELECT id FROM usuarios WHERE rol = 'staff' ORDER BY created_at, id LIMIT 1);

-- Quién hizo qué en el panel de administración. Se guarda el correo además del id por si la cuenta cambia.
CREATE TABLE IF NOT EXISTS bitacora_staff (
  id           TEXT PRIMARY KEY,
  fecha        TEXT NOT NULL,
  actor_id     TEXT,
  actor_email  TEXT NOT NULL,
  accion       TEXT NOT NULL,
  detalle      TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_bitacora_staff_fecha ON bitacora_staff(fecha);
