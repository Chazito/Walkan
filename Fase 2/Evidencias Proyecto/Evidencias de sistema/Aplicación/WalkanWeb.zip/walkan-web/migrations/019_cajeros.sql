-- Cajeros administrados desde el panel. Cada caja del negocio los recibe junto con el catálogo (GET /api/catalogo)
-- y valida el PIN localmente, así que el PIN se guarda SOLO como hash scrypt (mismo formato que la caja:
-- scrypt$<salt>$<hash>). Nunca se guarda ni se envía el PIN en claro.
CREATE TABLE cajeros (
  id         TEXT PRIMARY KEY,
  cliente_id TEXT NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  nombre     TEXT NOT NULL,
  pin_hash   TEXT NOT NULL,
  activo     INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_cajeros_cliente ON cajeros(cliente_id);
