-- Planes nuevos (14-nov-2026): Kiosko → Esencial, Minimarket → Profesional, Minisúper → Empresa.
-- Precios, cupos y funciones viven en src/config/configuracion.ts (PLANES_DEF); acá solo se renombra lo guardado.
-- (La 029 queda reservada para las ventas pendientes de Franco.)
UPDATE clientes SET plan = CASE plan WHEN 'Kiosko' THEN 'Esencial' WHEN 'Minimarket' THEN 'Profesional'
  WHEN 'Minisúper' THEN 'Empresa' WHEN 'Minisuper' THEN 'Empresa' ELSE plan END;
UPDATE clientes SET plan_siguiente = CASE plan_siguiente WHEN 'Kiosko' THEN 'Esencial' WHEN 'Minimarket' THEN 'Profesional'
  WHEN 'Minisúper' THEN 'Empresa' WHEN 'Minisuper' THEN 'Empresa' ELSE plan_siguiente END
 WHERE plan_siguiente IS NOT NULL;
UPDATE suscripciones SET plan = CASE plan WHEN 'Kiosko' THEN 'Esencial' WHEN 'Minimarket' THEN 'Profesional'
  WHEN 'Minisúper' THEN 'Empresa' WHEN 'Minisuper' THEN 'Empresa' ELSE plan END;
UPDATE solicitudes SET plan = CASE plan WHEN 'Kiosko' THEN 'Esencial' WHEN 'Minimarket' THEN 'Profesional'
  WHEN 'Minisúper' THEN 'Empresa' WHEN 'Minisuper' THEN 'Empresa' ELSE plan END
 WHERE plan IS NOT NULL;

-- Caja adicional en arriendo: la primera caja de cada negocio va incluida; desde la segunda se paga una cuota
-- mensual junto con la renovación hasta completar las cuotas (configuracion.ts → cajaAdicional).
--   cajas.adicional       1 = caja en arriendo (no es la incluida)
--   cajas.cuotas_pagadas  cuotas ya cobradas en renovaciones pagadas
--   suscripciones.cajas_json  ids de las cajas cuya cuota va en ese cobro (al pagarse, a cada una se le suma 1)
ALTER TABLE cajas ADD COLUMN adicional INTEGER NOT NULL DEFAULT 0;
ALTER TABLE cajas ADD COLUMN cuotas_pagadas INTEGER NOT NULL DEFAULT 0;
ALTER TABLE suscripciones ADD COLUMN cajas_json TEXT;
-- Cajas que ya existían: en cada negocio, todas menos la primera registrada pasan a ser adicionales (su primera
-- cuota se cobra en la próxima renovación).
UPDATE cajas SET adicional = 1
 WHERE cliente_id IS NOT NULL
   AND id <> (SELECT c2.id FROM cajas c2 WHERE c2.cliente_id = cajas.cliente_id ORDER BY c2.created_at, c2.id LIMIT 1);
