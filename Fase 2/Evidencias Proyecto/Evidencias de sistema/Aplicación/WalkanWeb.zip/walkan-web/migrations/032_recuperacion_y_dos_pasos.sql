-- Recuperar la contraseña por correo y verificación en dos pasos con app de códigos (16-nov-2026).

-- Enlace "¿Olvidaste tu contraseña?": un token de un solo uso por pedido. Se guarda solo su hash (sha256):
-- quien vea la base no puede usar los enlaces que estén vigentes.
CREATE TABLE IF NOT EXISTS recuperaciones (
  id          TEXT PRIMARY KEY,
  usuario_id  TEXT NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  expira      TEXT NOT NULL,
  usado_en    TEXT,
  creado_en   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_recuperaciones_usuario ON recuperaciones(usuario_id);

-- Verificación en dos pasos (TOTP). El secreto va cifrado con una clave derivada de SESSION_SECRET.
ALTER TABLE usuarios ADD COLUMN totp_secreto TEXT;          -- activo (NULL = sin verificación en dos pasos)
ALTER TABLE usuarios ADD COLUMN totp_pendiente TEXT;        -- mientras se configura la app, aún sin confirmar
ALTER TABLE usuarios ADD COLUMN totp_desde TEXT;            -- cuándo se activó
ALTER TABLE usuarios ADD COLUMN totp_ultimo_paso INTEGER;   -- último código aceptado: no se acepta dos veces
ALTER TABLE usuarios ADD COLUMN totp_respaldo TEXT;         -- JSON con los hashes de los códigos de respaldo sin usar
