-- Solicitudes de alta (leads) del embudo comercial.
CREATE TABLE solicitudes (
  id            TEXT    PRIMARY KEY,
  negocio       TEXT    NOT NULL,
  contacto      TEXT    NOT NULL,
  email         TEXT    NOT NULL,
  telefono      TEXT,
  comuna        TEXT,
  plan          TEXT    NOT NULL,
  mensaje       TEXT,
  -- Etapa del embudo: va de 'Nueva' hasta 'Activa' (o 'Descartada' si se cae el trato).
  estado        TEXT    NOT NULL DEFAULT 'Nueva'
                  CHECK (estado IN ('Nueva','Contactada','En evaluación','Contrato firmado',
                                    'Certificado cargado','CAF cargado','Activa','Descartada')),
  pago_estado   TEXT    NOT NULL DEFAULT 'Pendiente'
                  CHECK (pago_estado IN ('Pendiente','Pagado','Rechazado')),
  -- Datos del cobro en Flow: orden y token con que se vuelve a consultar el pago.
  flow_order    TEXT,
  flow_token    TEXT,
  monto         INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT    NOT NULL,
  updated_at    TEXT    NOT NULL
);
-- Índices para filtrar por etapa y para ubicar la solicitud cuando Flow avisa con su token.
CREATE INDEX idx_solicitudes_estado ON solicitudes(estado);
CREATE INDEX idx_solicitudes_token  ON solicitudes(flow_token);
