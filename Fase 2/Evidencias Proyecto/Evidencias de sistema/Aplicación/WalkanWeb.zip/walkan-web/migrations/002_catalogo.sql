-- Catálogo: proveedores y productos (persistencia del panel del cliente).
CREATE TABLE proveedores (
  id          TEXT    PRIMARY KEY,
  nombre      TEXT    NOT NULL,
  tel         TEXT,
  email       TEXT,
  rubro       TEXT,
  created_at  TEXT    NOT NULL,
  updated_at  TEXT    NOT NULL
);

CREATE TABLE productos (
  id            TEXT    PRIMARY KEY,
  nombre        TEXT    NOT NULL,
  sku           TEXT,
  categoria     TEXT    NOT NULL DEFAULT 'General',
  -- Precio y costo en pesos enteros (CLP no usa decimales).
  precio        INTEGER NOT NULL DEFAULT 0,
  costo         INTEGER NOT NULL DEFAULT 0,
  stock         INTEGER NOT NULL DEFAULT 0,
  vence         TEXT,
  -- Si se borra el proveedor, el producto queda sin proveedor en vez de borrarse.
  proveedor_id  TEXT    REFERENCES proveedores(id) ON DELETE SET NULL,
  emoji         TEXT,
  img           TEXT,
  created_at    TEXT    NOT NULL,
  updated_at    TEXT    NOT NULL
);
CREATE INDEX idx_productos_prov ON productos(proveedor_id);
