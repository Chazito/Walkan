-- Quién hizo cada movimiento de stock (auditoría, ISO 27002 8.15). NULL = la caja (sync) o un script.
ALTER TABLE movimientos_stock ADD COLUMN usuario_id TEXT;
