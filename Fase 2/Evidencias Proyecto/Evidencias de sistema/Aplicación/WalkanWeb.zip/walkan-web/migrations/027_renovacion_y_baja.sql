-- Renovación mensual del plan y baja voluntaria de la cuenta.
--   cancelado_en      el dueño canceló el plan: no se le avisa ni se le cobra más y mantiene el acceso hasta el
--                     fin del período ya pagado.
--   eliminar_en       el dueño pidió eliminar su cuenta: queda cerrada de inmediato y sus datos se borran en esta
--                     fecha (30 días para arrepentirse).
--   eliminado_en      los datos ya se borraron. La fila queda vacía solo porque el registro de pagos
--                     (suscripciones) la referencia.
--   aviso_renovacion  último aviso de vencimiento enviado por correo: "<periodo_fin>|previo" o "<periodo_fin>|vencido".
ALTER TABLE clientes ADD COLUMN cancelado_en TEXT;
ALTER TABLE clientes ADD COLUMN eliminar_en TEXT;
ALTER TABLE clientes ADD COLUMN eliminado_en TEXT;
ALTER TABLE clientes ADD COLUMN aviso_renovacion TEXT;

-- Hasta ahora nadie revisaba el vencimiento. Para que ninguna cuenta existente quede en pausa de un día para
-- otro, las que ya tenían el período vencido parten con 30 días desde esta migración (se les avisa antes de vencer).
UPDATE suscripciones
   SET periodo_fin = strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '+30 days')
 WHERE estado = 'pagada'
   AND periodo_fin < strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
   AND periodo_fin = (SELECT MAX(s2.periodo_fin) FROM suscripciones s2 WHERE s2.cliente_id = suscripciones.cliente_id AND s2.estado = 'pagada');
