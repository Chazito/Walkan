-- Receptor de sincronización: dispositivos (cajas) y ventas subidas desde la caja.
CREATE TABLE cajas (
  id          TEXT    PRIMARY KEY,
  nombre      TEXT    NOT NULL,
  token       TEXT    NOT NULL UNIQUE,
  usuario_id  TEXT    REFERENCES usuarios(id),
  estado      TEXT    NOT NULL DEFAULT 'activa' CHECK (estado IN ('activa','bloqueada')),
  ultimo_seq  INTEGER NOT NULL DEFAULT 0,
  ultima_sync TEXT,
  created_at  TEXT    NOT NULL,
  updated_at  TEXT    NOT NULL
);

CREATE TABLE ventas (
  id          TEXT    PRIMARY KEY,
  caja_id     TEXT    NOT NULL REFERENCES cajas(id),
  seq         INTEGER NOT NULL,
  folio       TEXT    NOT NULL,
  fecha       TEXT    NOT NULL,
  cajero      TEXT,
  medio_pago  TEXT,
  neto        INTEGER NOT NULL DEFAULT 0,
  iva         INTEGER NOT NULL DEFAULT 0,
  total       INTEGER NOT NULL DEFAULT 0,
  sii_estado  TEXT    NOT NULL DEFAULT 'Aceptada',
  items_json  TEXT    NOT NULL,
  created_at  TEXT    NOT NULL,
  UNIQUE (caja_id, seq)
);
CREATE INDEX idx_ventas_caja  ON ventas(caja_id);
CREATE INDEX idx_ventas_fecha ON ventas(fecha);

-- Sin cajas sembradas: cada caja se da de alta sola desde su pantalla de bienvenida
-- (POST /api/cajas/registrar con las credenciales de la cuenta -> devuelve token).
