-- Registro de consentimientos (Ley 21.719): prueba de que la persona aceptó, qué texto exacto
-- (versión + hash), cuándo, desde dónde y con qué navegador/IP. Es un historial de SOLO INSERCIÓN:
-- retirar un consentimiento agrega una fila nueva con aceptado=0; nunca se edita ni se borra una fila.
CREATE TABLE consentimientos (
  id          TEXT PRIMARY KEY,
  email       TEXT NOT NULL,             -- titular (en minúsculas)
  usuario_id  TEXT,                      -- si tiene cuenta
  cliente_id  TEXT,                      -- negocio al que pertenece (si aplica)
  tipo        TEXT NOT NULL CHECK (tipo IN ('privacidad', 'marketing')),
  aceptado    INTEGER NOT NULL CHECK (aceptado IN (0, 1)),
  version     TEXT NOT NULL,             -- versión de la política vigente al aceptar
  texto_hash  TEXT NOT NULL,             -- sha256 del texto aceptado (política + casilla)
  origen      TEXT NOT NULL,             -- registro | contacto | ingreso | mi-cuenta
  ip          TEXT,
  user_agent  TEXT,
  created_at  TEXT NOT NULL
);
CREATE INDEX idx_consentimientos_email ON consentimientos (email, tipo, created_at);
CREATE INDEX idx_consentimientos_usuario ON consentimientos (usuario_id, tipo, created_at);

CREATE TRIGGER consentimientos_sin_update BEFORE UPDATE ON consentimientos
BEGIN SELECT RAISE(ABORT, 'consentimientos es un historial de solo inserción'); END;
CREATE TRIGGER consentimientos_sin_delete BEFORE DELETE ON consentimientos
BEGIN SELECT RAISE(ABORT, 'consentimientos es un historial de solo inserción'); END;
