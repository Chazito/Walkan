-- Pan, fruta, verdura y otros productos sin código de barras: la caja vende por código, así que sin SKU no se
-- podían vender ni descontar. Ahora ProductosService les asigna un código interno al crearlos; esto hace lo mismo
-- con los que ya existen. EAN-13 con prefijo GS1 20 (circulación restringida: ningún producto del comercio lo usa)
-- + correlativo por negocio (sigue después del mayor "20…" que ya tenga) + dígito verificador.
WITH base AS (
  SELECT cliente_id, MAX(CAST(substr(c, 3, 10) AS INTEGER)) AS n FROM (
    SELECT cliente_id, sku AS c FROM productos UNION ALL SELECT cliente_id, sku_archivado FROM productos)
  WHERE c GLOB '20[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' GROUP BY cliente_id
), n AS (
  SELECT p.id, '20' || printf('%010d', COALESCE(b.n, 0) + ROW_NUMBER() OVER (PARTITION BY p.cliente_id ORDER BY p.created_at, p.id)) AS d
  FROM productos p LEFT JOIN base b ON b.cliente_id = p.cliente_id
  WHERE p.activo = 1 AND p.sku IS NULL AND p.cliente_id IS NOT NULL
)
UPDATE productos SET sku = (SELECT d || ((10 - (
    (substr(d,1,1) + substr(d,3,1) + substr(d,5,1) + substr(d,7,1) + substr(d,9,1) + substr(d,11,1))
    + 3 * (substr(d,2,1) + substr(d,4,1) + substr(d,6,1) + substr(d,8,1) + substr(d,10,1) + substr(d,12,1))) % 10) % 10)
  FROM n WHERE n.id = productos.id)
WHERE id IN (SELECT id FROM n);
