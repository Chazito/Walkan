-- Las ventas del panel se piden por negocio y ordenadas por fecha (las últimas 100 cada 30 s por pestaña, y por
-- rango en analíticas). Con índices separados SQLite filtraba por negocio y después ordenaba en una tabla temporal.
-- El índice compuesto sirve para las dos cosas y reemplaza al de solo cliente_id (es su prefijo).
CREATE INDEX IF NOT EXISTS idx_ventas_cliente_fecha ON ventas(cliente_id, fecha);
DROP INDEX IF EXISTS idx_ventas_cliente;
