-- Al archivar un producto su SKU se libera (para reutilizarlo); acá se guarda para poder devolverlo si se restaura.
ALTER TABLE productos ADD COLUMN sku_archivado TEXT;
