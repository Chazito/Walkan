-- Dispositivos recordados y soporte (17-nov-2026).

-- "Recordar este dispositivo por 30 días" (solo dueños, nunca el equipo Walkan): con la cookie de ese navegador no se
-- pide el código de la app al entrar (la contraseña sí). Se guarda solo el hash del token.
CREATE TABLE IF NOT EXISTS dispositivos_confiables (
  id          TEXT PRIMARY KEY,
  usuario_id  TEXT NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  expira      TEXT NOT NULL,
  creado_en   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_dispositivos_usuario ON dispositivos_confiables(usuario_id);

-- Tickets de soporte: desde el panel (con sesión) o desde /ayuda/contacto (sin sesión, p. ej. perdió el 2FA).
CREATE TABLE IF NOT EXISTS tickets (
  id              TEXT PRIMARY KEY,
  numero          INTEGER NOT NULL UNIQUE,
  origen          TEXT NOT NULL CHECK (origen IN ('panel','publico')),
  cliente_id      TEXT,                 -- negocio (si se sabe)
  usuario_id      TEXT,                 -- quien lo abrió con sesión
  nombre          TEXT NOT NULL,
  email           TEXT NOT NULL,
  rut             TEXT,                 -- lo escribe quien no tiene sesión (verificación)
  orden_pago      TEXT,                 -- n.º de orden de un pago de Flow (verificación)
  categoria       TEXT NOT NULL,
  asunto          TEXT NOT NULL,
  estado          TEXT NOT NULL DEFAULT 'abierto' CHECK (estado IN ('abierto','en_curso','resuelto')),
  asignado_a      TEXT,                 -- usuario del equipo Walkan
  creado_en       TEXT NOT NULL,
  actualizado_en  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tickets_estado ON tickets(estado, actualizado_en);
CREATE INDEX IF NOT EXISTS idx_tickets_cliente ON tickets(cliente_id);

CREATE TABLE IF NOT EXISTS ticket_mensajes (
  id           TEXT PRIMARY KEY,
  ticket_id    TEXT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  cliente_id   TEXT,                    -- copia del negocio del ticket: así "Descargar mis datos" y el borrado de la cuenta lo cubren
  autor        TEXT NOT NULL CHECK (autor IN ('cliente','equipo','sistema')),
  autor_nombre TEXT NOT NULL,
  texto        TEXT NOT NULL,
  creado_en    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ticket_mensajes_ticket ON ticket_mensajes(ticket_id, creado_en);
