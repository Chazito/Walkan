-- Versión de sesión por usuario: al cambiar o restablecer la contraseña (o cerrar sesión)
-- se incrementa y todas las cookies anteriores de ese usuario dejan de servir.
ALTER TABLE usuarios ADD COLUMN sesion_version INTEGER NOT NULL DEFAULT 0;
