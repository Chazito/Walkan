-- Cobro por transferencia: datos bancarios del negocio (JSON: banco, tipoCuenta, numero, titular, rut, email).
-- La caja los recibe con el catálogo y los muestra, con un QR, cuando el cliente paga por transferencia.
ALTER TABLE clientes ADD COLUMN transferencia_json TEXT;

-- Detalle del pago que informa la caja: autorización de la máquina de tarjetas, monto recibido y vuelto, etc.
ALTER TABLE ventas ADD COLUMN pago_json TEXT;

-- Comprobantes enviados por correo. La caja (offline-first) encola el pedido; la nube envía el correo al sincronizar.
CREATE TABLE comprobantes_correo (
  id         TEXT PRIMARY KEY,
  venta_id   TEXT REFERENCES ventas(id) ON DELETE CASCADE,
  cliente_id TEXT NOT NULL,
  email      TEXT NOT NULL,
  estado     TEXT NOT NULL CHECK (estado IN ('pendiente','enviado','simulado','error')),
  detalle    TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_correo_venta ON comprobantes_correo(venta_id);
CREATE INDEX idx_correo_cliente ON comprobantes_correo(cliente_id);
