-- Módulo de ítems: kardex de stock, archivo de productos, SKU único por cliente
-- y lead time de proveedores (base para la predicción de inventario).

-- Kardex: todo cambio de stock queda registrado aquí (cantidad con signo).
CREATE TABLE movimientos_stock (
  id TEXT PRIMARY KEY,
  cliente_id TEXT NOT NULL,
  producto_id TEXT NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
  tipo TEXT NOT NULL CHECK (tipo IN ('inicial','venta','recepcion','compra','ajuste')),
  cantidad INTEGER NOT NULL,
  costo_unit INTEGER,
  ref_id TEXT,
  motivo TEXT,
  fecha TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_mov_cliente_prod_fecha ON movimientos_stock(cliente_id, producto_id, fecha);
CREATE INDEX idx_mov_cliente_tipo_fecha ON movimientos_stock(cliente_id, tipo, fecha);

ALTER TABLE productos ADD COLUMN activo INTEGER NOT NULL DEFAULT 1;
ALTER TABLE productos ADD COLUMN stock_minimo INTEGER;
ALTER TABLE proveedores ADD COLUMN lead_time_dias INTEGER NOT NULL DEFAULT 3;

-- SKU único por cliente: vacíos pasan a NULL y los duplicados existentes se
-- limpian (se conserva el primero) antes de crear el índice.
UPDATE productos SET sku = NULL WHERE TRIM(COALESCE(sku, '')) = '';
UPDATE productos SET sku = NULL
  WHERE sku IS NOT NULL AND rowid NOT IN (
    SELECT MIN(rowid) FROM productos WHERE sku IS NOT NULL GROUP BY cliente_id, sku);
CREATE UNIQUE INDEX ux_productos_cliente_sku ON productos(cliente_id, sku) WHERE sku IS NOT NULL;

-- El stock que ya existe entra al kardex como movimiento inicial.
INSERT INTO movimientos_stock (id, cliente_id, producto_id, tipo, cantidad, costo_unit, fecha, created_at)
  SELECT lower(hex(randomblob(16))), cliente_id, id, 'inicial', stock, costo, created_at, created_at
  FROM productos WHERE stock <> 0 AND cliente_id IS NOT NULL;
