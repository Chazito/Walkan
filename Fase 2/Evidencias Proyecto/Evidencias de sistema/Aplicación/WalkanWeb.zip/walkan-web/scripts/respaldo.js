#!/usr/bin/env node
// Respaldo de la base de datos de Walkan. Copia consistente aunque la app esté en uso (API de respaldo de SQLite),
// comprimida, y borra los respaldos con más de DIAS días.
//   node scripts/respaldo.js            → ~/respaldos-walkan/walkan-AAAA-MM-DD_HHMM.db.gz
// Variables opcionales: DB_PATH (por defecto ./data/walkan-web.db), RESPALDO_DIR, RESPALDO_DIAS (14).
// Se programa con cron (ver claude/deploy-primigenio.md).
// Los respaldos traen datos personales y hashes de claves: la carpeta queda 700 y los archivos 600
// (solo el usuario que corre Walkan). Ojo: no van cifrados; si se copian a otro equipo, cifrarlos antes.
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const Database = require('better-sqlite3');

const raiz = path.join(__dirname, '..');
const origen = path.resolve(raiz, process.env.DB_PATH || './data/walkan-web.db');
const dir = process.env.RESPALDO_DIR || path.join(os.homedir(), 'respaldos-walkan');
const dias = Number(process.env.RESPALDO_DIAS) || 14;
process.umask(0o077); // todo lo que cree este script nace sin permisos para otros usuarios

(async () => {
  if (!fs.existsSync(origen)) throw new Error('No existe la base: ' + origen);
  fs.mkdirSync(dir, { recursive: true });
  fs.chmodSync(dir, 0o700); // por si la carpeta ya existía con permisos más abiertos
  const d = new Date(), p = (n) => String(n).padStart(2, '0');
  const sello = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
  const tmp = path.join(dir, `walkan-${sello}.db`);

  const db = new Database(origen, { readonly: true });
  await db.backup(tmp);
  db.close();

  // Verifica que la copia esté sana antes de darla por buena.
  const copia = new Database(tmp, { readonly: true });
  const ok = copia.pragma('integrity_check', { simple: true });
  copia.close();
  if (ok !== 'ok') { fs.unlinkSync(tmp); throw new Error('La copia no pasó la revisión de integridad: ' + ok); }

  fs.writeFileSync(tmp + '.gz', zlib.gzipSync(fs.readFileSync(tmp)));
  for (const f of [tmp, tmp + '-wal', tmp + '-shm']) if (fs.existsSync(f)) fs.unlinkSync(f);

  const limite = Date.now() - dias * 86400000;
  let borrados = 0;
  for (const f of fs.readdirSync(dir)) {
    if (!/^walkan-.*\.db\.gz$/.test(f)) continue;
    const ruta = path.join(dir, f);
    if (fs.statSync(ruta).mtimeMs < limite) { fs.unlinkSync(ruta); borrados++; }
    else fs.chmodSync(ruta, 0o600); // respaldos anteriores a este cambio
  }
  const kb = Math.round(fs.statSync(tmp + '.gz').size / 1024);
  console.log(`${new Date().toISOString()} respaldo OK: ${tmp}.gz (${kb} KB); antiguos borrados: ${borrados}`);
})().catch((e) => { console.error(`${new Date().toISOString()} RESPALDO FALLÓ: ${e.message}`); process.exit(1); });
