// ============================================================================
// caja-simulador.js — Una caja "de mentira" que vende sola
// ----------------------------------------------------------------------------
// ¿Qué hace?
//   Hace de cuenta que hay un cajero vendiendo: cada cierto rato arma una
//   boleta con 1 a 3 productos al azar y la manda a la app, igual que lo haría
//   la caja real. Sirve para la demo: dejas el panel abierto y vas viendo cómo
//   entran las ventas y baja el stock sin tocar nada.
//
// ¿Qué necesita?
//   - La app corriendo en http://localhost:4000 (o la dirección que pongas en APP_URL).
//   - Haber corrido antes "npm run demo:seed". Ese script crea la caja y deja
//     su token guardado en data/demo-caja.json; sin ese archivo, esto no parte.
//   - Que haya productos con stock (si se agotan todos, no hay qué vender).
//
// ¿Cómo se usa?
//   npm run demo:caja            → una venta cada 20 segundos
//   npm run demo:caja -- 5       → una venta cada 5 segundos (para ir más rápido)
//   Ctrl+C para detenerlo.
// ============================================================================
const fs = require('fs');
const path = require('path');

const URL = process.env.APP_URL || 'http://localhost:4000';
const TOKEN_FILE = path.resolve(process.env.CAJA_FILE || './data/demo-caja.json'); // lo deja listo demo-seed.js
const CADA = (Number(process.argv[2]) || 20) * 1000; // cada cuánto vender (en milisegundos)
const PAGOS = ['Efectivo', 'Débito', 'Crédito'];

// Entra con la cuenta demo y trae la lista de productos que se pueden vender
// (los que tienen código de barras y todavía les queda stock).
async function productos() {
  const login = await fetch(URL + '/api/auth/login', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'admin@walkan.cl', password: 'walkan123' }),
  });
  if (!login.ok) throw new Error('No se pudo iniciar sesión: ' + login.status);
  const cookie = login.headers.get('set-cookie').split(';')[0];
  const r = await fetch(URL + '/api/productos', { headers: { cookie } });
  return (await r.json()).filter((p) => p.sku && p.stock > 0);
}

async function main() {
  // Sin el archivo del token no sabemos qué caja somos: hay que correr el seed primero.
  if (!fs.existsSync(TOKEN_FILE)) throw new Error('Falta ' + TOKEN_FILE + '. Corre primero: npm run demo:seed');
  const estado = JSON.parse(fs.readFileSync(TOKEN_FILE, 'utf8')); // { token, seq }
  let catalogo = await productos();
  console.log(`Caja simulada: una venta cada ${CADA / 1000}s con ${catalogo.length} productos. Ctrl+C para parar.`);

  // Arma y manda UNA venta.
  const vender = async () => {
    if (!catalogo.length) catalogo = await productos(); // si la lista quedó vacía, la volvemos a pedir
    // Elegimos de 1 a 3 productos distintos al azar, con 1 o 2 unidades cada uno.
    const n = 1 + Math.floor(Math.random() * 3);
    const items = [...catalogo].sort(() => Math.random() - 0.5).slice(0, n)
      .map((p) => ({ nombre: p.nombre, sku: p.sku, cantidad: 1 + Math.floor(Math.random() * 2), precio: p.precio }));
    const total = items.reduce((t, it) => t + it.cantidad * it.precio, 0);
    // Cada envío lleva un número correlativo (seq). La app lo usa para no contar
    // dos veces la misma venta si la caja la reenvía.
    const seq = estado.seq + 1;
    const fecha = new Date().toISOString();
    const r = await fetch(URL + '/api/sync', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-caja-token': estado.token },
      body: JSON.stringify({ eventos: [{ seq, tipo: 'venta', fecha, payload: { items, total, folio: 1000 + seq, cajero: 'Camila', medioPago: PAGOS[seq % 3], fecha } }] }),
    });
    const res = await r.json();
    if (!r.ok || !res.ok) return console.error('Sync rechazado:', r.status, JSON.stringify(res));
    // Salió bien: guardamos en qué número vamos, así si lo cierras y lo vuelves
    // a abrir sigue donde quedó.
    estado.seq = seq;
    fs.writeFileSync(TOKEN_FILE, JSON.stringify(estado, null, 2));
    console.log(`#${1000 + seq}  $${total.toLocaleString('es-CL')}  ${items.map((i) => i.nombre + ' x' + i.cantidad).join(', ')}`);
  };

  // Una venta al tiro para ver que funciona, y después una cada CADA segundos.
  await vender();
  setInterval(() => vender().catch((e) => console.error(e.message)), CADA);
}

main().catch((e) => { console.error(e.message); process.exit(1); });
