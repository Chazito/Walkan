// ============================================================================
// demo-seed.js — "Llena la tienda" para la demo
// ----------------------------------------------------------------------------
// ¿Qué hace?
//   Deja el negocio de prueba (admin@walkan.cl) listo para mostrar: crea
//   proveedores, productos y unos 3 meses de ventas, como si una caja real
//   hubiera estado vendiendo todo ese tiempo. Así los gráficos, el historial
//   de stock y la reposición sugerida tienen datos con sentido desde el día uno.
//
// ¿Qué necesita?
//   - La app corriendo (npm run start:dev o similar) en http://localhost:4000.
//     Si está en otro lado, pásale APP_URL=http://... antes del comando.
//   - Que la app haya arrancado al menos una vez, para que exista la cuenta
//     admin@walkan.cl (la crea el seed base de la app).
//   - Las dependencias instaladas (npm install), porque usa better-sqlite3
//     para el --reset.
//
// ¿Cómo se usa?
//   npm run demo:seed                → carga los datos (si la tienda está vacía)
//   ALLOW_DEMO_RESET=1 npm run demo:seed -- --reset → borra todo lo del negocio demo y lo carga de nuevo
//
// Después de esto puedes correr "npm run demo:caja" para ver ventas llegando en vivo.
// ============================================================================
const fs = require('fs');
const path = require('path');

// Dónde está la app, dónde está la base de datos y dónde guardamos el token de la caja.
const URL = process.env.APP_URL || 'http://localhost:4000';
const DB = path.resolve(process.env.DB_PATH || './data/walkan-web.db');
const TOKEN_FILE = path.resolve(process.env.CAJA_FILE || './data/demo-caja.json'); // lo usa después el simulador de caja
// Cuenta de prueba que viene en el seed del proyecto (solo para desarrollo).
const EMAIL = 'admin@walkan.cl';
const PASS = 'walkan123';
// Cuántos días hacia atrás inventamos ventas.
const DIAS = 90;

// Números "al azar" pero siempre los mismos: con la misma semilla la demo
// sale idéntica cada vez que la cargas. Nada de sorpresas antes de presentar.
let s = 42;
const rnd = () => ((s = (s * 1103515245 + 12345) % 2147483648) / 2147483648);
// Devuelve cuántas unidades se vendieron en un día, alrededor de un promedio "l".
// (Unos días se vende un poco más, otros un poco menos, como en la vida real.)
const poisson = (l) => { let k = 0, p = 1; const L = Math.exp(-l); do { k++; p *= rnd(); } while (p > L); return k - 1; };

// Los proveedores de la tienda. "lead" = cuántos días se demoran en traer un pedido;
// la predicción lo usa para saber con cuánta anticipación hay que pedir.
const PROVEEDORES = [
  { nombre: 'Distribuidora Central', tel: '+56911111111', rubro: 'Abarrotes y bebidas', lead: 3, visita: '1,4' },
  { nombre: 'Lácteos del Sur', tel: '+56922222222', rubro: 'Lácteos', lead: 2, visita: '2,5' },
  { nombre: 'Panificadora Quilicura', tel: '+56933333333', rubro: 'Panadería', lead: 1 },
];

// El catálogo de la tienda. Cada fila es un producto con estas columnas:
//   [nombre, sku, categoría, precio, costo, proveedor, ventas/día promedio, stock final, stock mínimo]
// - "proveedor" es la posición en la lista de arriba (0 = Distribuidora, 1 = Lácteos, 2 = Panificadora).
// - "stock final" es con cuánto queda HOY después de todas las ventas inventadas.
//   Algunos quedan bajos o en 0 a propósito, para que la demo muestre alertas.
// - "stock mínimo" es opcional (null = que el sistema lo calcule solo).
const PRODUCTOS = [
  ['Coca-Cola 1.5L', '7801610001', 'Bebidas', 1990, 1250, 0, 9, 40, null],
  ['Agua Mineral 1.6L', '7801610002', 'Bebidas', 990, 520, 0, 5, 8, null],
  ['Jugo Watts 1L', '7801610003', 'Bebidas', 1290, 780, 0, 3, 30, null],
  ['Leche Entera 1L', '7802900001', 'Lácteos', 1150, 820, 1, 8, 6, 12],
  ['Yogur Frutilla', '7802900002', 'Lácteos', 450, 260, 1, 6, 40, null],
  ['Queso Gauda 250g', '7802900003', 'Lácteos', 3290, 2300, 1, 1.5, 0, null],
  ['Pan Hallulla (kg)', '7800000001', 'Panadería', 2200, 1300, 2, 12, 20, null],
  ['Marraqueta (kg)', '7800000002', 'Panadería', 2200, 1300, 2, 10, 60, null],
  ['Arroz 1kg', '7801320001', 'Abarrotes', 1490, 950, 0, 2.5, 25, 10],
  ['Fideos Spaghetti 400g', '7801320002', 'Abarrotes', 890, 540, 0, 3, 4, null],
  ['Aceite Maravilla 1L', '7801320003', 'Abarrotes', 2890, 2100, 0, 1.2, 18, null],
  ['Azúcar 1kg', '7801320004', 'Abarrotes', 1190, 780, 0, 1.5, 22, null],
  ['Papas Fritas 180g', '7801550001', 'Snacks', 1990, 1150, 0, 4, 35, null],
  ['Galletas Tritón', '7801550002', 'Snacks', 790, 430, 0, 3.5, 3, null],
  ['Detergente 1L', '7804000001', 'Aseo', 3490, 2400, 0, 0.6, 12, 5],
  ['Papel Higiénico x4', '7804000002', 'Aseo', 2590, 1700, 0, 1.3, 16, null],
  // Sin costo a propósito: el Resumen avisa que no suma al valor del inventario a costo.
  ['Bolsa de Hielo 2kg', '7805000001', 'Otros', 1500, null, 0, 1, 10, null],
];
// Medios de pago que van rotando en las boletas (débito sale el doble, como pasa en la realidad).
const PAGOS = ['Efectivo', 'Débito', 'Débito', 'Crédito'];

// Perecibles: controlan vencimiento. El stock final de HOY queda repartido en estos lotes
// [cantidad, vence en N días (negativo = ya vencido), prefijo del lote], así la demo muestra
// FEFO, el aviso "Vender primero" y alertas de vencidos. La clave es la posición en PRODUCTOS.
// El código del lote se arma con la fecha real de vencimiento (LE-1014 = vence el 14 de octubre).
const LOTES = {
  3: [[2, -2, 'LE'], [4, 5, 'LE']],   // Leche: 2 vencidas + 4 que vencen pronto
  4: [[10, 3, 'YF'], [30, 28, 'YF']], // Yogur
  5: [],                              // Queso: agotado, sin lotes
  6: [[20, 2, 'PH']],                 // Pan Hallulla
  7: [[25, 1, 'MQ'], [35, 4, 'MQ']],  // Marraqueta
};
// Fecha local AAAA-MM-DD de dentro de d días.
const enDias = (d) => new Date(Date.now() + d * 86_400_000).toLocaleDateString('en-CA');
const codigoLote = (prefijo, d) => prefijo + '-' + enDias(d).slice(5).replace('-', '');

// Pequeño ayudante para hablarle a la API de la app.
// Guarda la cookie de sesión después del login, así las siguientes llamadas
// ya van "logueadas". Si algo sale mal, corta con un error que dice qué falló.
let cookie = '';
async function api(method, url, body, headers = {}) {
  const r = await fetch(URL + url, {
    method,
    headers: { 'content-type': 'application/json', cookie, ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const set = r.headers.get('set-cookie');
  if (set) cookie = set.split(';')[0];
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`${method} ${url}: ${r.status} ${JSON.stringify(data)}`);
  return data;
}

// --reset: borra todo lo del negocio demo directo en la base de datos
// (productos, lotes, ventas, proveedores, pedidos, compras, cajas e historial de stock).
// Ojo: solo toca los datos de admin@walkan.cl, nada de otros negocios.
// También borra el archivo del token de caja, porque esa caja deja de existir.
function reset() {
  // Freno de mano: corre en el mismo servidor que la app (incluido el de producción), así que borrar pide permiso explícito.
  if (process.env.ALLOW_DEMO_RESET !== '1') throw new Error('--reset borra los datos de ' + EMAIL + ' en ' + DB + '. Si es lo que quieres, repite con ALLOW_DEMO_RESET=1.');
  const db = require('better-sqlite3')(DB);
  const cli = db.prepare('SELECT cliente_id FROM usuarios WHERE email=?').get(EMAIL);
  if (!cli) throw new Error('No existe ' + EMAIL + ' (arranca la app una vez para el seed base).');
  db.transaction(() => {
    for (const t of ['movimientos_stock', 'lotes', 'ventas', 'cajas', 'pedidos', 'compras', 'productos', 'proveedores']) {
      db.prepare(`DELETE FROM ${t} WHERE cliente_id=?`).run(cli.cliente_id);
    }
  })();
  db.close();
  if (fs.existsSync(TOKEN_FILE)) fs.unlinkSync(TOKEN_FILE);
  console.log('Datos del negocio demo borrados.');
}

// Inventa las boletas día por día, desde hace 90 días hasta hoy.
// Para que se vea creíble:
//   - viernes y sábado se vende más, domingo un poco menos;
//   - las ventas caen entre las 9:00 y las 21:00, más cargadas hacia la tarde;
//   - cada boleta lleva de 1 a 4 productos;
//   - de hoy solo se inventan boletas hasta la hora actual (nada "del futuro"), en proporción
//     a lo que va del día; si se corre antes de abrir, igual quedan unas pocas desde medianoche
//     para que el Resumen de hoy nunca salga vacío.
function generarVentas() {
  const ventas = [];
  const ahora = new Date();
  for (let d = DIAS; d >= 0; d--) {
    const dia = new Date(ahora.getFullYear(), ahora.getMonth(), ahora.getDate() - d);
    const dow = dia.getDay(); // 0 = domingo, 5 = viernes, 6 = sábado
    // Hoy la tienda "abre" a las 9 o, si todavía no son las 9, a medianoche.
    const abre = d === 0 && ahora.getHours() < 9 ? 0 : 9;
    const horas = d === 0 ? ahora.getHours() - abre + 1 : 12;
    const avance = d === 0 ? Math.min(1, Math.max(0.15, (ahora.getHours() - 9) / 12)) : 1;
    const factor = (dow === 5 || dow === 6 ? 1.35 : dow === 0 ? 0.8 : 1) * avance;
    // Primero decidimos cuántas unidades de cada producto se vendieron ese día...
    const lineas = [];
    PRODUCTOS.forEach((p, i) => {
      const q = poisson(p[6] * factor);
      for (let k = 0; k < q; k++) lineas.push(i);
    });
    lineas.sort(() => rnd() - 0.5); // ...y las revolvemos
    // Después repartimos esas unidades en boletas de 1 a 4 líneas.
    while (lineas.length) {
      const n = 1 + Math.floor(rnd() * 4);
      const hora = abre + Math.floor(Math.pow(rnd(), 0.7) * horas);
      const f = new Date(dia.getFullYear(), dia.getMonth(), dia.getDate(), hora, Math.floor(rnd() * 60));
      const grupo = lineas.splice(0, n);
      if (f > ahora) continue; // hoy: solo las boletas hasta la hora actual
      // Si el mismo producto salió dos veces en la boleta, lo juntamos en una línea con cantidad 2.
      const cant = new Map();
      grupo.forEach((i) => cant.set(i, (cant.get(i) || 0) + 1));
      const items = [...cant].map(([i, c]) => ({ nombre: PRODUCTOS[i][0], sku: PRODUCTOS[i][1], cantidad: c, precio: PRODUCTOS[i][3] }));
      ventas.push({ fecha: f, items });
    }
  }
  return ventas.sort((a, b) => a.fecha - b.fecha); // de la más antigua a la más nueva
}

async function main() {
  // 1) Si pidieron --reset, limpiamos primero.
  if (process.argv.includes('--reset')) reset();

  // 2) Entramos como el admin de la tienda demo.
  await api('POST', '/api/auth/login', { email: EMAIL, password: PASS });
  // Si ya hay productos no hacemos nada, para no duplicar todo por accidente.
  if ((await api('GET', '/api/productos')).length) {
    console.log('El negocio demo ya tiene productos. Usa --reset para recargar.');
    return;
  }

  // 3) Inventamos las ventas y contamos cuánto se vendió de cada producto.
  const ventas = generarVentas();
  const vendidas = PRODUCTOS.map(() => 0);
  ventas.forEach((v) => v.items.forEach((it) => { vendidas[PRODUCTOS.findIndex((p) => p[1] === it.sku)] += it.cantidad; }));

  // 4) Creamos los proveedores y los productos usando la API normal de la app.
  //    Truco: cada producto parte con "stock final + todo lo que se va a vender",
  //    así cuando lleguen las ventas el stock baja justo hasta el número que queremos.
  //    Los perecibles parten solo con lo que se va a vender (un lote que se agota con las ventas)
  //    y su stock final entra después como un ingreso con varios lotes (paso 5b).
  const provIds = [];
  for (const p of PROVEEDORES) provIds.push((await api('POST', '/api/proveedores', p)).id);
  const prodIds = [];
  for (const [i, p] of PRODUCTOS.entries()) {
    const creado = await api('POST', '/api/productos', {
      nombre: p[0], sku: p[1], cat: p[2], precio: p[3], costo: p[4] ?? undefined, prov: provIds[p[5]],
      stock: (LOTES[i] ? 0 : p[7]) + vendidas[i], stockMin: p[8] ?? undefined,
      ...(LOTES[i] ? { controlaVence: true, vence: enDias(60), lote: 'INICIAL' } : {}),
    });
    prodIds.push(creado.id);
  }

  // 5) Registramos una caja ("Caja 1 (demo)") y le mandamos todas las ventas
  //    por el mismo camino que usa una caja de verdad (/api/sync).
  //    Así cada venta descuenta stock y queda en el historial, igual que en producción.
  //    Se mandan de a 200 para no hacer un envío gigante.
  const caja = await api('POST', '/api/cajas/registrar', { email: EMAIL, password: PASS, nombre: 'Caja 1 (demo)' });
  let seq = 0; // número correlativo de cada envío de la caja
  for (let i = 0; i < ventas.length; i += 200) {
    const eventos = ventas.slice(i, i + 200).map((v) => {
      seq++;
      const total = v.items.reduce((t, it) => t + it.cantidad * it.precio, 0);
      const fecha = v.fecha.toISOString();
      return { seq, tipo: 'venta', fecha, payload: { items: v.items, total, folio: 1000 + seq, cajero: 'Camila', medioPago: PAGOS[seq % 4], fecha } };
    });
    await api('POST', '/api/sync', { eventos }, { 'x-caja-token': caja.token });
  }
  // 5b) El stock final de los perecibles entra como un ingreso de mercadería con varios lotes.
  // Un ingreso de mercadería no acepta lotes ya vencidos (compras.service → sinVencidos). Los vencidos de la demo
  // representan mercadería que ya estaba en la góndola: entran por el ingreso rápido del producto, que sí lo permite.
  for (const [i, lotes] of Object.entries(LOTES)) {
    if (!lotes.length) continue;
    const p = PRODUCTOS[i];
    const vigentes = lotes.filter(([, d]) => d >= 0);
    if (vigentes.length) {
      await api('POST', '/api/compras', {
        prov: provIds[p[5]],
        items: vigentes.map(([qty, d, prefijo]) => ({ prod: prodIds[i], qty, costo: p[4], lote: codigoLote(prefijo, d), vence: enDias(d) })),
      });
    }
    for (const [qty, d, prefijo] of lotes.filter(([, d]) => d < 0)) {
      await api('POST', `/api/productos/${prodIds[i]}/ingreso`, { cantidad: qty, costo: p[4], lote: codigoLote(prefijo, d), vence: enDias(d) });
    }
  }

  // Guardamos el token de la caja y en qué número quedó, para que el simulador siga desde ahí.
  fs.writeFileSync(TOKEN_FILE, JSON.stringify({ token: caja.token, seq }, null, 2));

  // 6) Dejamos un pedido pendiente a Lácteos del Sur (leche y yogur),
  //    para poder mostrar en vivo cómo se recibe un pedido y sube el stock.
  await api('POST', '/api/pedidos', {
    prov: provIds[1], nota: 'Pedido semanal',
    items: [3, 4].map((i) => ({ prod: prodIds[i], nombre: PRODUCTOS[i][0], qty: 24, costo: PRODUCTOS[i][4] })),
  });

  // Y un borrador a la panificadora, para mostrar los 3 estados del pedido.
  await api('POST', '/api/pedidos', {
    prov: provIds[2], nota: 'Para el fin de semana', borrador: true,
    items: [6, 7].map((i) => ({ prod: prodIds[i], nombre: PRODUCTOS[i][0], qty: 30, costo: PRODUCTOS[i][4] })),
  });

  // 7) Unas mermas del mes, para que Analíticas › Mermas no salga vacío.
  for (const [i, cantidad, motivo] of [[0, -2, 'Botella rota'], [1, -1, 'Consumo interno'], [6, -3, 'Producto vencido']]) {
    await api('POST', `/api/productos/${prodIds[i]}/ajuste`, { cantidad, motivo });
  }

  console.log(`Listo: ${PROVEEDORES.length} proveedores, ${PRODUCTOS.length} productos, ${ventas.length} ventas en ${DIAS} días.`);
}

main().catch((e) => { console.error(e.message); process.exit(1); });
