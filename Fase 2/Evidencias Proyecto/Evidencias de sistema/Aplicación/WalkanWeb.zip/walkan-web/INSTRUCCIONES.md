# Walkan Web — cómo hacerla andar

Esta es la parte web de Walkan: la página comercial, el registro con pago (Flow), el panel del negocio
(inventario, compras, ventas, cajas, equipo) y la administración del equipo Walkan. También es "la nube"
con la que se sincronizan las cajas (la app local, que va en el otro zip).

## Qué necesitas

| Cosa | Versión | Para qué |
|---|---|---|
| Node.js | 20 o superior (probado con 22 y 24) | Corre la app |
| npm | el que viene con Node | Instala las librerías |
| Internet (solo para `npm install`) | — | Bajar las librerías |

No hay que instalar ninguna base de datos aparte: usa **SQLite** (archivo `data/walkan-web.db`), que viene
con la librería `better-sqlite3`. En Windows, si `npm install` no encuentra binario precompilado para tu
versión de Node, pide las "Build Tools" de Visual Studio; con Node 20/22/24 normalmente no hace falta.

### Librerías que usa (se instalan solas con `npm install`)

- **NestJS 10** (`@nestjs/core`, `@nestjs/common`, `@nestjs/platform-fastify`): el framework del backend.
- **Fastify** + plugins (`@fastify/static`, `@fastify/view`, `@fastify/cookie`, `@fastify/rate-limit`): servidor HTTP, archivos estáticos, vistas, cookies de sesión y tope de solicitudes.
- **better-sqlite3**: la base de datos SQLite.
- **ejs**: las plantillas de las páginas (carpeta `views/`).
- **class-validator** / **class-transformer**: validan lo que llega a la API.
- **nodemailer**: manda correos (comprobantes, recuperación de clave). Sin SMTP configurado, el envío queda "simulado".
- **qrcode**: arma los QR (cobro con QR, verificación en dos pasos).
- **reflect-metadata**, **rxjs**: los pide NestJS.
- De desarrollo: **typescript**, **@nestjs/cli** (compila), y los `@types/*`.

## Paso a paso

Abre una terminal dentro de esta carpeta (`walkan-web`):

```bash
# 1. Instalar librerías
npm install

# 2. Compilar (TypeScript → dist/)
npm run build

# 3. (Opcional) Crear la base de datos de cero. Si te lo saltas, la app la crea sola al arrancar.
node base-de-datos/crear-bd.js

# 4. Arrancar
npm start
```

Queda en **http://localhost:4000**.

Para desarrollo, en vez de `build` + `start` puedes usar `npm run start:dev` (recompila solo al guardar).

### Usuarios de prueba

Al arrancar por primera vez (sin `NODE_ENV=production`) la app crea sola estas cuentas:

| Correo | Clave | Qué es |
|---|---|---|
| `admin@walkan.cl` | `walkan123` | Dueño del negocio demo "Almacén Barrera" (plan Profesional). Entra al panel. |
| `staff@walkan.cl` | `walkan123` | Equipo Walkan. Entra a la administración (`/admin`). |

Entra en http://localhost:4000/mi-cuenta (o con el botón "Mi cuenta" de la página).

### Datos de prueba (seed)

Con la app corriendo, en otra terminal:

```bash
npm run demo:seed     # proveedores, productos y ~3 meses de ventas, para que los gráficos y la reposición tengan algo
npm run demo:caja     # (opcional) una caja "de mentira" que va vendiendo sola; se ve en vivo en el panel
```

Para borrar lo del negocio demo y cargarlo de nuevo:

```bash
# Linux / macOS / Git Bash
ALLOW_DEMO_RESET=1 npm run demo:seed -- --reset
# PowerShell
$env:ALLOW_DEMO_RESET=1; npm run demo:seed -- --reset
```

## Base de datos

- `migrations/` tiene los scripts SQL numerados (001, 002, ...). La app los corre sola al arrancar, en orden,
  y anota cuáles ya aplicó en la tabla `_migraciones`. No hay que hacer nada a mano.
- `base-de-datos/esquema-completo.sql` es lo mismo pero todo junto en un solo archivo, por si quieres ver
  el esquema completo o crear la base a mano con el cliente `sqlite3`:
  `sqlite3 data/walkan-web.db < base-de-datos/esquema-completo.sql`
- `base-de-datos/crear-bd.js` crea la base corriendo ese archivo (no necesita el cliente sqlite3).
- Para partir de cero: detén la app y borra `data/walkan-web.db` (y los `-wal` / `-shm` que estén al lado).

## Configuración (opcional)

Para probar en tu computador no hay que configurar nada: todo tiene valores por defecto. Si quieres cambiar
algo, crea un archivo `.env` en esta carpeta (una variable por línea, `NOMBRE=valor`):

| Variable | Por defecto | Qué hace |
|---|---|---|
| `PORT` | `4000` | Puerto de la app |
| `DB_PATH` | `./data/walkan-web.db` | Dónde queda la base |
| `APP_URL` | `http://localhost:4000` | URL pública (la usa Flow para volver después del pago) |
| `SESSION_SECRET` | uno de desarrollo | Firma las cookies. En producción, obligatorio y de 32+ caracteres |
| `FLOW_API_URL` | `https://sandbox.flow.cl/api` | API de Flow (sandbox = pagos de prueba) |
| `FLOW_API_KEY` / `FLOW_SECRET_KEY` | vacías | Llaves de Flow. Sin ellas, los pagos se **simulan** (sirve para probar el registro) |
| `PAGOS_SIMULADOS` | — | `1` fuerza pagos simulados aunque haya llaves |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_USER` / `SMTP_PASS` / `SMTP_FROM` | vacías | Correo saliente. Sin esto, los correos quedan "simulados" (se ven en el log) |
| `NODE_ENV` | — | `production` activa los chequeos de producción (no arranca con secretos de prueba ni crea usuarios demo) |
| `STAFF_PASSWORD_INICIAL` | — | Solo en producción: clave del primer usuario staff |

## Conectar una caja (la app local)

1. Deja esta app corriendo en http://localhost:4000.
2. Arranca la caja (ver `INSTRUCCIONES.md` del zip de la app local). Por defecto ya apunta a `http://localhost:4000`.
3. En la pantalla de bienvenida de la caja elige **Vincular caja** y entra con `admin@walkan.cl` / `walkan123`.
4. Desde ahí la caja baja el catálogo y los cajeros del panel, y las ventas que haga aparecen en el panel web.
